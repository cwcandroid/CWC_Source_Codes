package com.cwc.courierclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;

public class ServerCommunication{
	private String username;
	private String password;
	private String type;
	private String email;
	public String responseText;
	public String statusText;
	public JSONArray jsonArray;
	public ArrayList<String[]> taskList = new ArrayList<String[]>();

	
	public String task_id,reasontype,reasondetails,reportlatitude,reportlongitude,signaturefile;
	
	public ServerCommunication(String uName,String pass,String t,String mail){
		username = uName;
		password = pass;
		type = t;
		email = mail;
		responseText = null;
		
	}
	
	/**
	 * Send Login info to server
	 * @param Application Context
	 * @return response text in JSON format
	 */
	public String sendToServer(Context c) {
		String responText = null;
		String finalResponse = "testing...";
		try {
			if(type.equals("login"))
				responText = getResponseText(c.getString(R.string.server_url)+type+"?returnType=json&username="+username+"&password="+password);
			else if(type.equals("register"))
				responText = getResponseText(c.getString(R.string.server_url)+type+"?returnType=json&username="+username+"&password="+password+"&email="+email);
			else if(type.equals("getTaskList")){
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				String curentDate = sdf.format(new Date());
				Log.i("today", curentDate);
				responText = getResponseText(c.getString(R.string.server_url)+type+"?returnType=xml&username="+username+"&duedate="+curentDate);
			}
			else if(type.equals("getTaskHistory")){
				responText = getResponseText(c.getString(R.string.server_url)+type+"?returnType=xml&username="+username);
			}
			else if(type.equals("reportSpecificTask")){
				responText = getResponseText(c.getString(R.string.server_url)+type+"?returnType=json&username="+username+"&taskid="+task_id+"&reasontype="+reasontype+
																					"&reasondetails="+reasondetails+"&reportlatitude="+reportlatitude+"&reportlongitude="+reportlongitude+"&signaturefile="+signaturefile);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JSONObject mainResponseObject;
		try {
			XmlRead xmlRead = new XmlRead();
			if(type.equals("getTaskList")){
				
				xmlRead.type = "task";
				xmlRead.startReading(responText);
				//jsonArray = new JSONArray(responText);
				//Log.i("Number of entries " ,jsonArray.length()+"");
				taskList = xmlRead.dataList;
				finalResponse = "tasklisted";
			}
			
			else if(type.equals("getTaskHistory")){
				xmlRead.type = "history";
				xmlRead.startReading(responText);
				taskList = xmlRead.dataList;
				finalResponse = "tasklisted";
			}
			
			
			else{
				mainResponseObject = new JSONObject(responText);
				finalResponse = mainResponseObject.getString("status");
				
				if(type.equals("register"))
					statusText = mainResponseObject.getString("text");
				else if(type.equals("reportSpecificTask"))
					statusText = mainResponseObject.getString("signaturefile");
			}
			
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return finalResponse;
	} 
	
	/**
	 * Get Response text from the server
	 * @param url of the server
	 * @return
	 * @throws IOException
	 */
	private String getResponseText(String stringUrl) throws IOException
	{
		
		Log.i("server xml url", stringUrl);
	    StringBuilder response  = new StringBuilder();

	    URL url = new URL(stringUrl);
	    HttpURLConnection httpconn = (HttpURLConnection)url.openConnection();
	    if (httpconn.getResponseCode() == HttpURLConnection.HTTP_OK)
	    {
	        BufferedReader input = new BufferedReader(new InputStreamReader(httpconn.getInputStream()),8192);
	        String strLine = null;
	        while ((strLine = input.readLine()) != null)
	        {
	            response.append(strLine);
	        }
	        input.close();
	    }
	    Log.i("parsed xml: ", response.toString());
	    return response.toString();
	}

}
