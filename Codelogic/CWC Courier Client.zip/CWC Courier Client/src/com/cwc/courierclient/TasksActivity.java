package com.cwc.courierclient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.json.JSONArray;

import android.app.ActivityGroup;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.LinearLayout.LayoutParams;

public class TasksActivity extends ActivityGroup implements Runnable {
	
	ProgressDialog dialog;
	public static String username;
	ServerCommunication task_communication;
	String responseText;
	public JSONArray jsonArray;
	TableLayout item_container;
	Button btnMap;
	public ArrayList<String[]> taskList = new ArrayList<String[]>();
	Button sortDateBtn,sortDistanceBtn;
	
	// Need to keep track of the history if you want the back-button to work properly, don't use this if your activities requires a lot of memory.  
    private ArrayList<View> history = new ArrayList<View>();  
    public static TasksActivity group;  
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tasks);
		init();
	}
	
	@Override
	public void onPause() {
		
		 if(history.size() > 0) {
	    	Log.i("On Pause history size", history.size()+"");
	    	
	    	View v = history.get(history.size()-1);
	    	((ViewManager)v.getParent()).removeView(v);
	    	history.remove(history.size()-1);
	    	
	    	setContentView(R.layout.tasks);
	    	init();
	    }
		super.onPause();
	}
	
	
	private void init(){
		sortDateBtn = (Button)findViewById(R.id.sortDateBtn);
		sortDistanceBtn = (Button)findViewById(R.id.sortDistanceBtn);
		
		sortDateBtn.setOnClickListener(sortTasksByDate);
		
		btnMap = (Button)findViewById(R.id.BtnMap);
		btnMap.setOnClickListener(mapFunction);
		item_container = (TableLayout) findViewById(R.id.item_container);
		
		Log.i("getString Extra", username);
		task_communication = new ServerCommunication(username, null, "getTaskList", null);
		
		dialog = ProgressDialog.show(TasksActivity.this,
				"Please Wait....", "Creting the Task List");

		Thread thread = new Thread(TasksActivity.this); 
		thread.start();
	}
 
private OnClickListener sortTasksByDate = new View.OnClickListener() {
		
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Collections.sort(taskList,new Comparator<String[]>() {
	            public int compare(String[] strings, String[] otherStrings) {
	                return strings[7].compareTo(otherStrings[7]);
	            }
	        });
			
			View view = item_container.getChildAt(0);
			item_container.removeAllViews();
			item_container.addView(view);
			init();


		}
	};

	public void run() {
		// TODO Auto-generated method stub
		responseText = task_communication.sendToServer(getApplicationContext());
		Log.i("final response", responseText);
		handler.sendEmptyMessage(0);
	}
	
	private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
              dialog.dismiss();
              group = TasksActivity.this;
              
              if (responseText.equals("tasklisted")) {
            	//jsonArray = task_communication.jsonArray;
            	taskList = task_communication.taskList;
            	
            	TableRow tr;
            	TableLayout tl1,tl2;
          		LinearLayout layout;
          		TextView txt1,txt2;
          		LayoutParams frame;
          		ImageView img1,img2;
          		View v1,v2;
          		
          		for (int i = 0; i < taskList.size(); i++) {
					//JSONObject jsonObject = jsonArray.getJSONObject(i);
					
					tr = new TableRow(getApplicationContext());
					tl1 = new TableLayout(getApplicationContext());
					tl2 = new TableLayout(getApplicationContext());
					layout = new LinearLayout(getApplicationContext());
					txt1 = new TextView(getApplicationContext());
					txt2 = new TextView(getApplicationContext());
					img1 = new ImageView(getApplicationContext());
					img2 = new ImageView(getApplicationContext());
					//v1 = new View(getApplicationContext());
					v2 = new View(getApplicationContext());
					
					Log.i("tasks: get name and address", taskList.get(i)[7]+" "+taskList.get(i)[1]);
					
					txt1.setText(taskList.get(i)[7].toString());
					txt2.setText(taskList.get(i)[1].toString());
					tl2.addView(txt1);
					tl2.addView(txt2);
					
					Resources res = getResources();
					Drawable drawable;
					if(taskList.get(i)[8].toString().equals("1"))
						 drawable = res.getDrawable(R.drawable.item_complete);
					else
						drawable = res.getDrawable(R.drawable.item_pending);
					
					img1.setBackgroundDrawable(drawable);
					
					drawable = res.getDrawable(R.drawable.arrow);
					img2.setBackgroundDrawable(drawable);
					
					layout.addView(img1);
					layout.addView(tl2);
					layout.addView(img2);
					
					//tl1.addView(v1);
					tl1.addView(layout);
					tl1.addView(v2);
					
					frame = (LayoutParams) v2.getLayoutParams();
					frame.height = 2;
					frame.bottomMargin = 5;
					frame.topMargin = 5;
					frame.width = LayoutParams.FILL_PARENT;
					v2.setBackgroundColor(Color.BLACK);
					
					tr.addView(tl1);
					
					item_container.addView(tr);
					
					
					frame = (LayoutParams) img1.getLayoutParams();
					frame.gravity = Gravity.CENTER_VERTICAL;
					frame.leftMargin = 10;
					img1.setLayoutParams(frame);
					
					frame = (LayoutParams) img2.getLayoutParams();
					frame.gravity = Gravity.RIGHT|Gravity.CENTER_VERTICAL;
					img2.setLayoutParams(frame);
					
					frame = (LayoutParams) tl2.getLayoutParams();
					frame.gravity = Gravity.CENTER_VERTICAL;
					frame.weight = 4;
					frame.leftMargin = 10;
					tl2.setLayoutParams(frame);
					
					txt1.setTextColor(Color.BLACK);
					txt2.setTextColor(Color.BLACK);
					txt2.setLines(1);
					txt2.setMaxWidth(200);
					
					tr.setOnClickListener(gotoDetailsTask);
					tr.setTag(taskList.get(i));
          		}
            	  
              }
        }
	};

	public void back() {  
    	if(history.size() > 0){
        	Log.i("history size", history.size()+"");
        	
        	View v = history.get(history.size()-1);
        	((ViewManager)v.getParent()).removeView(v);
        	history.remove(history.size()-1);
        	
        	setContentView(R.layout.tasks);
        	init();
        	/*
        	v = history.get(history.size()-1);
        	((ViewManager)v.getParent()).removeView(v);
            setContentView(v); 
            v.invalidate();
            history.remove(history.size()-1);
            */
        }else {  
        	 TasksActivity.group.finish();  
        }  
    }  
	
	@Override  
    public void onBackPressed() {  
        TasksActivity.group.back();  
        return;  
    }  
	
	/**
	 * Registration Button Handler
	 */
	
	private OnClickListener gotoDetailsTask = new View.OnClickListener() {
		public void onClick(View v) {
			
			history = new ArrayList<View>();  
	        group = TasksActivity.this;  
			//history.add(v); 
			
			Intent detailsIntent = new Intent(v.getContext(), TaskDetailsActivity.class);
			//TaskDetailsActivity.jsonObject = (JSONObject) v.getTag();
			
			Log.i("click on task", v.getTag()+" ");
			
			TaskDetailsActivity.dataReceiverArray = (String[])v.getTag();
			TaskDetailsActivity.task_type = "task";
			replaceContentView("TaskDetailsActivity1", detailsIntent);
			
			/*View view = getLocalActivityManager().startActivity("CitiesActivity", new Intent(group,TaskDetailsActivity.class)  
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))  
                    .getDecorView();
                    
			
			 // Replace the view of this ActivityGroup  
	         replaceView(view);  
	         */
		}
	};
	
private OnClickListener mapFunction = new View.OnClickListener() {
		
		public void onClick(View v) {
			// TODO Auto-generated method stub
			/*
			Intent i = new Intent(TasksActivity.this,
					TaskLocationActivity.class);
			startActivity(i);
			*/
			/*
			Intent multi = new Intent(TasksActivity.this,
					TaskLocationmMarkerActivity.class);
			startActivity(multi);
			*/
			
			history = new ArrayList<View>();  
	        group = TasksActivity.this;  
			//history.add(v); 
			
			Intent mapIntent = new Intent(v.getContext(), TaskLocationActivity.class);
			replaceContentView("TaskLocationActivity", mapIntent);
			
		}
	};
	
	public void replaceView(View v) {  
        // Adds the old one to history  
		history.add(v);  
	    // Changes this Groups View to the new View.  
		setContentView(v);  
	}  
	
	public void replaceContentView(String id, Intent newIntent) {
		View view = getLocalActivityManager().startActivity(id,newIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView(); 
		history.add(view);  
		this.setContentView(view);
	}
	
}
