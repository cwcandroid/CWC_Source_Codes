package com.cwc.courierclient;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class ReportActivity extends Activity implements Runnable {

	//public static JSONObject jsonOjbect;
	public static ArrayList<String> taskList;
	public Spinner statusSpinner;
	View viewToLoad;
	TableRow spinnerRow;
	private String itemSelected;
	private int itemPos;
	
	Button sigBtn,submitBtn,cancelBtn;
	EditText detailComments;
	
	ProgressDialog dialog;
	ServerCommunication report_communication;
	String responseText;
	String statusText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		View viewToLoad = LayoutInflater.from(this.getParent().getParent()).inflate(R.layout.report, null);
        this.setContentView(viewToLoad);
        
        statusSpinner = (Spinner)findViewById(R.id.statusSpinner);
        sigBtn = (Button)findViewById(R.id.sigBtn);
        submitBtn = (Button)findViewById(R.id.submitBtn);
        cancelBtn = (Button)findViewById(R.id.cancelBtn);
        
        detailComments = (EditText)findViewById(R.id.detailComments);
		
		//ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getParent().getParent(), android.R.layout.simple_spinner_item, R.array.Delivery_Status_Array);
		//adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
		//statusSpinner.setAdapter(adapter);
		
        addListenerOnSpinnerItemSelection();
        
        cancelBtn.setOnClickListener(cancelReport);
        submitBtn.setOnClickListener(submitReport);
	}

	public void addListenerOnSpinnerItemSelection() {
		statusSpinner.setOnItemSelectedListener(new CustomOnItemSelectedListener());
	}

	public class CustomOnItemSelectedListener implements OnItemSelectedListener {

		public void onItemSelected(AdapterView<?> parent, View view, int pos,
				long id) {
				itemPos = pos;
				if(pos == 1)
					sigBtn.setVisibility(View.VISIBLE);
				else
					sigBtn.setVisibility(View.INVISIBLE);
				
				itemSelected = parent.getItemAtPosition(pos).toString();
			//Toast.makeText(parent.getContext(),"OnItemSelectedListener : "+ itemSelected + pos,Toast.LENGTH_SHORT).show();
		}

		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
		}

	}
	
	private OnClickListener cancelReport = new View.OnClickListener() {
		public void onClick(View v) {
			TasksActivity.group.back();
			//finish();
		}
	};
	
	private OnClickListener submitReport = new View.OnClickListener() {
		public void onClick(View v) {
			
			report_communication = new ServerCommunication(TasksActivity.username, null, "reportSpecificTask", null);
			
			report_communication.task_id = taskList.get(0);//jsonOjbect.getString("task_id");
			report_communication.reasontype = itemPos+"";
			report_communication.reasondetails = detailComments.getText().toString();
			
			LocationManager locationManager;
		    locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		    Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		    
		    double latitude = 0.0,longitude = 0.0;
		    
		    if(location != null ){
		    	latitude = location.getLatitude();
		    	longitude = location.getLongitude();
		    }

			report_communication.reportlatitude = latitude+"" ;
			report_communication.reportlongitude = longitude+"";
			report_communication.signaturefile = "N/A";
			
			
			dialog = ProgressDialog.show(ReportActivity.this.getParent().getParent(),
					"Please Wait....", "Submittin the Task Report");

			Thread thread = new Thread(ReportActivity.this); 
			thread.start();
		}
	};
	
	public void run() {
		// TODO Auto-generated method stub
		responseText = report_communication.sendToServer(this.getParent().getParent());
		statusText = report_communication.statusText;
		Log.i("final response", responseText);
		handler.sendEmptyMessage(0);
	}
	
	private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
              dialog.dismiss();
              if (responseText.equals("Success")) {
					// If reporting successful
					Toast.makeText(getApplicationContext(), "Reporting Successfull : Signature File"+ statusText, Toast.LENGTH_LONG).show();
					TasksActivity.group.back();
            }
            else {
            	Toast.makeText(getApplicationContext(), "Registration Failed : "+ statusText, Toast.LENGTH_LONG).show();
			  }
        }
	};
	

}
