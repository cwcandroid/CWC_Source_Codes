package com.cwc.courierclient;

import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TabHost.TabContentFactory;
import android.widget.TabHost.TabSpec;

public class CWCCourierClientMainScreenActivity extends TabActivity {
	TabHost tabHost;
	public String username;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		username = getIntent().getStringExtra("username");
		TasksActivity.username = username;
		
		tabHost = (TabHost) findViewById(android.R.id.tabhost);
		tabHost.setup();
		
		tabHost.getTabWidget().setDividerDrawable(R.drawable.tab_divider);

		setupTab(new TextView(this), "Tasks", 50, TasksActivity.class);
		setupTab(new TextView(this), "History", 60, HistoryActivity.class);
		setupTab(new TextView(this), "Performance", 90, PerformanceActivity.class);
		
	}
	
	private void setupTab(final View view, final String tag, final int width, Class<?> targetClass) {
		View tabview = createTabView(tabHost.getContext(), tag, width);
		Intent intent = new Intent().setClass(this, targetClass);
		
		TabSpec setContent = tabHost.newTabSpec(tag).setIndicator(tabview).setContent(new TabContentFactory() {
			public View createTabContent(String tag) {
				return view;
				}
		}).setContent(intent);
		
		
		tabHost.addTab(setContent);
	}
	
	private static View createTabView(final Context context, final String text, int width) {
		View view = LayoutInflater.from(context).inflate(R.layout.tabs_bg, null);
		TextView tv = (TextView) view.findViewById(R.id.tabsText);
		tv.setText(text);
		
		
		LayoutParams frame;
		frame = (LayoutParams) tv.getLayoutParams();
		frame.width = width;
		tv.setLayoutParams(frame);
		
		return view;
	}

}
