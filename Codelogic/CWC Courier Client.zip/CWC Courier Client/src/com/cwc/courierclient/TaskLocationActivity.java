package com.cwc.courierclient;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class TaskLocationActivity extends MapActivity implements Runnable{

	MapView mapView;
	public static String username;
	ServerCommunication task_communication;
	String responseText;
	public JSONArray jsonArray;
	LocationItemizedOvelay trackOverlay;
	List<Overlay> mapOverlays;
	Drawable drawable;
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map);
		mapView =(MapView)findViewById(R.id.mapview);
		mapView.setBuiltInZoomControls(true);

		mapOverlays = mapView.getOverlays();
		drawable = this.getResources().getDrawable(R.drawable.mark_red);
		trackOverlay = new LocationItemizedOvelay(drawable, TaskLocationActivity.this);

		username = TasksActivity.username;
		Log.i("getString Extra", username);
		task_communication = new ServerCommunication(username, null, "getTaskList", null);

		//Thread thread = new Thread(TaskLocationActivity.this); 
		//thread.start();
		run();

	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	public void run() {
		// TODO Auto-generated method stub
		responseText = task_communication.sendToServer(this.getParent());
		Log.i("final response", responseText);

		try {
			if (responseText.equals("tasklisted")) {
				jsonArray = task_communication.jsonArray;


				for (int i = 0; i < jsonArray.length(); i++) {
					JSONObject jsonObject = jsonArray.getJSONObject(i);

					Log.i("get name and address", jsonObject.getString("name")+" "+jsonObject.getString("address"));
					//Log.i("get latitude and longitude", jsonObject.getString("latitude")+" "+jsonObject.getString("latitude"));
					Log.i("get latitude and longitude", jsonObject.getDouble("latitude")+" "+jsonObject.getDouble("latitude"));

					int alatitude = (int) jsonObject.getDouble("latitude")*1000000;
					int alongitude =(int) jsonObject.getDouble("longitude")*1000000;

					GeoPoint point = new GeoPoint(alatitude, alongitude);
					//String name = jsonObject.getString("name");
					String address = jsonObject.getString("address");


					//OverlayItem overlayitem = new OverlayItem(point, " ",name+""+address);
					OverlayItem overlayitem = new OverlayItem(point, " "," "+address);
					trackOverlay.addOverlay(overlayitem);
					mapOverlays.add(trackOverlay);

					/*						Resources res = getResources();

					if(jsonObject.getString("status").equals("1"))
						 drawable = res.getDrawable(R.drawable.item_complete);
					else
						drawable = res.getDrawable(R.drawable.item_pending);*/

				}
				mapView.invalidate();

			}
			else {
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

}
