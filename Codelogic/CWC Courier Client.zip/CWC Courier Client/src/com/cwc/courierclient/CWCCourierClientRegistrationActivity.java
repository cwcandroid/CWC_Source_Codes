package com.cwc.courierclient;

import java.util.regex.Pattern;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CWCCourierClientRegistrationActivity extends Activity implements Runnable{
	EditText username,email,password,conf_password;
	Button btnRegister, btnBackToLogin;
	ServerCommunication register_communication;
	String responseText;
	String statusText;
	ProgressDialog dialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		
		username = (EditText) findViewById(R.id.username);
		password = (EditText) findViewById(R.id.password);
		email = (EditText) findViewById(R.id.email);
		conf_password = (EditText) findViewById(R.id.conf_password);
		
		btnRegister=(Button)findViewById(R.id.button1);
		btnBackToLogin=(Button)findViewById(R.id.button2);
		
		btnRegister.setOnClickListener(registerFunction);
		btnBackToLogin.setOnClickListener(backToLogin);
		
	}
	
	/**
	 * Back to Login Handler function
	 */
	private OnClickListener backToLogin = new View.OnClickListener() {
		public void onClick(View v) {
			finish();
		}
	};
	
	/**
	 * User Registration Handler function
	 */
	private OnClickListener registerFunction = new View.OnClickListener() {
		public void onClick(View v) {
			responseText = null;
			String uName = username.getText().toString();
			String pass = password.getText().toString();
			String conf_pass = conf_password.getText().toString();
			String mail = email.getText().toString();
			
			dialog = ProgressDialog.show(CWCCourierClientRegistrationActivity.this,
					"Please Wait....", "Registering New User");
			
			if(uName.trim().equals("")){
				responseText = "Failed";
				statusText = "Please Insert Username.";
			}
			else if(pass.equals("")){
				responseText = "Failed";
				statusText = "Please Insert Password.";
			}
			else if(pass.length()<6){
				responseText = "Failed";
				statusText = "Password Must be 6 characters long.";
			}
			else if(email.equals("")){
				responseText = "Failed";
				statusText = "Please Insert Email.";
			}
			else if(!pass.equals(conf_pass)){
				responseText = "Failed";
				statusText = "Password Mismatch.";
			}
			else if(!checkEmail(mail)){
				responseText = "Failed";
				statusText = "Invalid Email.";
			}
			else{
				responseText = "Running";
				register_communication = new ServerCommunication(uName ,pass , "register", mail);
			}
			
			Thread thread = new Thread(CWCCourierClientRegistrationActivity.this); 
			thread.start();
			
		}
	};

	public void run() {
		// TODO Auto-generated method stub
		if(responseText.equals("Running")){
			responseText = register_communication.sendToServer(getApplicationContext());
			statusText = register_communication.statusText;
		}
		Log.i("final response", responseText);
		handler.sendEmptyMessage(0);
	}
	
	private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
              dialog.dismiss();
              
              if (responseText.equals("Success")) {
					// If authentication successful
					Intent i = new Intent(
							CWCCourierClientRegistrationActivity.this,
							CWCCourierClientMainScreenActivity.class);
					i.putExtra("username", username.getText().toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
              }
              else {
            	  Toast.makeText(getApplicationContext(), "Registration Failed : "+ statusText, Toast.LENGTH_LONG).show();
			  }

        }
	};
	
	private final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(
	          "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
	          "\\@" +
	          "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
	          "(" +
	          "\\." +
	          "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
	          ")+"
	      );
	
	private boolean checkEmail(String email) {
        return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
	}
	


}
