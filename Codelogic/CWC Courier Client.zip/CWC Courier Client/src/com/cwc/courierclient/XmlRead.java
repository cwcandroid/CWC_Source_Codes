package com.cwc.courierclient;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.util.Log;

public class XmlRead {
	 public ArrayList<String[]> dataList;// = new ArrayList<String[]>();
	 public String type;
	 
	 public XmlRead(){
		
	 }
	 
	 public void startReading(final String xmlDoc){
		 dataList = new ArrayList<String[]>();
		 readXml(xmlDoc);
		 /*
		 new Thread(new Runnable() {
			    public void run() {
			    	readXml(xmlDoc);
			    }
			  }).start();
		  */
	 }
	 
	 public void readXml(String xmlDoc){
				
				try {
				//XmlResourceParser xpp =  xmlDoc;
				XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			    factory.setNamespaceAware(true);

				XmlPullParser xpp = factory.newPullParser();

		        xpp.setInput( new StringReader ( xmlDoc ) );
					
				 int eventType = xpp.getEventType();
			        String tempString;
			        String[] tempArray;
			        tempArray = new String[16];
			        
			        
			         while (eventType != XmlPullParser.END_DOCUMENT) {
				          if(eventType == XmlPullParser.START_TAG) {
				        	  
				        	  if(xpp.getName().equals("id")){
				        		  tempString = xpp.nextText();
				        		  
				        		  if(type.equals("history"))
							        	 tempArray = new String[16];
							        else
							        	 tempArray = new String[10];
				        		  
				        		  tempArray[0] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("address")){
				        		  tempString = xpp.nextText();
				        		  tempArray[1] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  else if(xpp.getName().equals("comments")){
				        		  tempString = xpp.nextText();
				        		  tempArray[2] = tempString;
				        		  eventType = xpp.next();
				        		  
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("contactno")){
				        		  tempString = xpp.nextText();
				        		  tempArray[3] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("description")){
				        		  tempString = xpp.nextText();
				        		  tempArray[4] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  else if(xpp.getName().equals("latitude")){
				        		  tempString = xpp.nextText();
				        		  tempArray[5] = tempString;
				        		  eventType = xpp.next();
				        		  
				        		  continue;
				        	  }
				        	  else if(xpp.getName().equals("longitude")){
				        		  tempString = xpp.nextText();
			        			  tempArray[6] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("name")){
				        		  tempString = xpp.nextText();
				        		  tempArray[7] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        		  
				        	  }
				        	  else if(xpp.getName().equals("status")){
				        		  tempString = xpp.nextText();
				        		  tempArray[8] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        		  
				        	  }
				        	  else if(xpp.getName().equals("time")){
				        		  tempString = xpp.nextText();
				        		  tempArray[9] = tempString;
				        		  eventType = xpp.next();
				        		  
				        		  if(type.equals("task"))
				        			  dataList.add(tempArray);
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("reasontype")){
				        		  tempString = xpp.nextText();
				        		  tempArray[9] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("reasondetails")){
				        		  tempString = xpp.nextText();
				        		  tempArray[10] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("reportlatitude")){
				        		  tempString = xpp.nextText();
				        		  tempArray[11] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("reportlongitude")){
				        		  tempString = xpp.nextText();
				        		  tempArray[12] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("signaturefile")){
				        		  tempString = xpp.nextText();
				        		  tempArray[13] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  
				        	  else if(xpp.getName().equals("duedate")){
				        		  tempString = xpp.nextText();
				        		  tempArray[14] = tempString;
				        		  eventType = xpp.next();
				        		  continue;
				        	  }
				        	  else if(xpp.getName().equals("duetime")){
				        		  tempString = xpp.nextText();
				        		  tempArray[15] = tempString;
				        		  eventType = xpp.next();
				        		  
				        		  if(type.equals("history"))
				        			  dataList.add(tempArray);
				        		  continue;
				        	  }
				        	  
				        	  
				        	  
				          } 
				          eventType = xpp.next();
				         }
		 		}
				
		 		catch (Exception e) {
		 			//Toast.makeText(getApplicationContext(), "XML Parsing Error!!!!".toString(),300).show();
		 			Log.e("error in reading", e+"");
		 		}
			
			
			Log.w("data List size", dataList.size()+"");
			
			
			for (String[] sa : dataList) {
	        	Log.w("Sorting Output for MapList",Arrays.toString(sa)+ " ");
	        }
			
	 		//return dataList;
		}
}
