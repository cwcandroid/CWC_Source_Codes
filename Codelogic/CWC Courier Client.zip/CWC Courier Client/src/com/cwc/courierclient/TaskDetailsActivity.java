package com.cwc.courierclient;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import android.app.ActivityGroup;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class TaskDetailsActivity extends ActivityGroup{
	//public static JSONObject jsonObject; 
	Button infoBtn,mapBtn,phoneBtn,reportBtn;
	TextView itemName,itemId,receiverName,receiverAddress,phoneNumber,deliverDateTxt,statusTxt;
	ImageView signatureImg;
	
	LinearLayout totalContainer;
	TableRow rowId;
	TableLayout info_container,deliverLayout;
	TableRow signatureRow;
	public static String[] dataReceiverArray;
	public ArrayList<String> taskList;// = new ArrayList<String>();
	
	// Need to keep track of the history if you want the back-button to work properly, don't use this if your activities requires a lot of memory.  
    private ArrayList<View> history = new ArrayList<View>();  
    public static TaskDetailsActivity group;  
	
	public static String task_type;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.task_details);
		
		taskList = new ArrayList<String>(Arrays.asList(dataReceiverArray));
		
		infoBtn = (Button)findViewById(R.id.infoBtn);
		mapBtn = (Button)findViewById(R.id.mapBtn);
		phoneBtn = (Button)findViewById(R.id.phoneBtn);
		reportBtn = (Button)findViewById(R.id.reportBtn);
		
		itemName = (TextView)findViewById(R.id.itemName);
		itemId = (TextView)findViewById(R.id.itemId);
		receiverName = (TextView)findViewById(R.id.receiverName);
		receiverAddress = (TextView)findViewById(R.id.receiverAddress);
		
		deliverDateTxt = (TextView)findViewById(R.id.deliverDateTxt);
		statusTxt = (TextView)findViewById(R.id.statusTxt);
		signatureImg = (ImageView)findViewById(R.id.signatureImg);
		
		totalContainer = (LinearLayout)findViewById(R.id.totalContainer);
		rowId = (TableRow)findViewById(R.id.rowId);
		info_container = (TableLayout)findViewById(R.id.info_container);
		deliverLayout = (TableLayout)findViewById(R.id.deliverLayout);
		signatureRow = (TableRow)findViewById(R.id.signatureRow);
		
		upadteValues();
		
		infoBtn.setOnClickListener(showInfo);
		mapBtn.setOnClickListener(showMap);
		phoneBtn.setOnClickListener(callNumber);
		reportBtn.setOnClickListener(gotoReportActivity);
		
		group = TaskDetailsActivity.this;
		
		Log.i("task details", taskList+"");
		
	}
	
	private void upadteValues(){
		//phoneBtn.setText(jsonObject.getString("contactno"));
		phoneBtn.setText(taskList.get(3));
		//itemName.setText(jsonObject.getString("name"));
		
		itemName.setText(taskList.get(7));
		itemId.setText(taskList.get(0));
		
		receiverName.setText(taskList.get(4));
		receiverAddress.setText(taskList.get(1));
		
		Log.i("task_type", task_type+"");
		
		if(task_type.equals("history")){
			totalContainer.removeView(reportBtn);
			deliverDateTxt.setText(taskList.get(14)+" "+taskList.get(15));
			
			String deliveryStatus;
			deliveryStatus = taskList.get(8);
			if(deliveryStatus.equals("0"))
				deliveryStatus = "Not Delivered";
			else if(deliveryStatus.equals("1"))
				deliveryStatus = "Delivered";
			else if(deliveryStatus.equals("2"))
				deliveryStatus = "Address Not Found";
			else if(deliveryStatus.equals("3"))
				deliveryStatus = "No One Available";
			
			statusTxt.setText(deliveryStatus);
			
			
			if(deliveryStatus.equals("Delivered")){
				String image_url = taskList.get(13); 
				if(!image_url.equals("N/A")){
					Drawable drawable = LoadImageFromWebOperations(image_url);
					signatureImg.setBackgroundDrawable(drawable);
				}
				else
					signatureRow.removeView(signatureImg);
			}
			else
				signatureRow.removeView(signatureImg);
			
		}
		else if(task_type.equals("task")){
			info_container.removeView(deliverLayout);
		}
		
		
	}
	
	private Drawable LoadImageFromWebOperations(String url) {
		try {
			InputStream is = (InputStream) new URL(url).getContent();
			Drawable d = Drawable.createFromStream(is, "src name");
			return d;
		} catch (Exception e) {
			return null;
		}
	}
	
	private OnClickListener showInfo = new View.OnClickListener() {
		public void onClick(View v) {
			infoBtn.setBackgroundResource(R.drawable.custom_button_selected);
			mapBtn.setBackgroundResource(R.drawable.custom_button_normal);
		}
	};
	
	private OnClickListener showMap = new View.OnClickListener() {
		public void onClick(View v) {
			mapBtn.setBackgroundResource(R.drawable.custom_button_selected);
			infoBtn.setBackgroundResource(R.drawable.custom_button_normal);
		}
	};
	
	private OnClickListener callNumber = new View.OnClickListener() {
		public void onClick(View v) {
			try {
		        Intent callIntent = new Intent(Intent.ACTION_CALL);
		        callIntent.setData(Uri.parse("tel:"+phoneBtn.getText()));
		        startActivity(callIntent);
		    } catch (ActivityNotFoundException e) {
		        Log.e("dialing.........", "Call failed", e);
		    }
		}
	};
	
	private OnClickListener gotoReportActivity = new View.OnClickListener() {
		public void onClick(View v) {
			history = new ArrayList<View>();  
	        group = TaskDetailsActivity.this;  
	        
			Intent detailsIntent = new Intent(v.getContext(), ReportActivity.class);
			//ReportActivity.jsonOjbect = jsonObject;
			ReportActivity.taskList = taskList;
			replaceContentView("ReportActivity", detailsIntent);
		}
	};
	
	public void replaceContentView(String id, Intent newIntent) {
		View view = getLocalActivityManager().startActivity(id,newIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView(); 
		history.add(view);  
		this.setContentView(view);
	}
	
}
