package com.cwc.courierclient;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class CWCCourierClientLoginActivity extends Activity implements Runnable {
	Button btnLogin, btnRegister;
	TextView errorTxt;
	EditText username, password;
	ProgressDialog dialog;
	ServerCommunication login_communication;
	String responseText;
	CheckBox rememberCheckbox;
	Boolean isRemember;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {

		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		username = (EditText) findViewById(R.id.username);
		password = (EditText) findViewById(R.id.password);
		
		errorTxt = (TextView) findViewById(R.id.errorTxt);

		btnLogin = (Button) findViewById(R.id.button1);
		btnRegister = (Button) findViewById(R.id.button2);

		btnLogin.setOnClickListener(logInFunction);
		btnRegister.setOnClickListener(registerFunction);
		
		rememberCheckbox = (CheckBox) findViewById(R.id.rememberCheckbox);
		rememberCheckbox.setOnCheckedChangeListener(rememberCheckFunc);
		
		readPerson();
	}
	

	/**
	 * Remember Checking Function
	 */
	private OnCheckedChangeListener rememberCheckFunc = new OnCheckedChangeListener() {
		
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			// TODO Auto-generated method stub
			Log.i("check box", isChecked+"");
			isRemember = true;
			if(isRemember)
				reminderMe(buttonView);
			
		}
	};
	
	
	/**
	 * Login Button Handler
	 */
	private OnClickListener logInFunction = new View.OnClickListener() {

		public void onClick(View v) {
			// TO DO: User input validation
			// TO DO: Client Authentication and handle different error cases
			
			
			login_communication = new ServerCommunication(username.getText()
					.toString(), password.getText().toString(), "login", null);
			
			dialog = ProgressDialog.show(CWCCourierClientLoginActivity.this,
					"Please Wait....", "Checking Authentication");

			Thread thread = new Thread(CWCCourierClientLoginActivity.this); 
			thread.start();
			
		}
	};
	
	/**
	 * Registration Button Handler
	 */
	
	private OnClickListener registerFunction = new View.OnClickListener() {
		public void onClick(View v) {
			Intent i = new Intent(CWCCourierClientLoginActivity.this,
					CWCCourierClientRegistrationActivity.class);
			startActivity(i);
		}
	};

	public void run() {
		// TODO Auto-generated method stub
		responseText = login_communication.sendToServer(getApplicationContext());
		Log.i("final response", responseText);
		handler.sendEmptyMessage(0);
	}
	
	private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
             
              
              if (responseText.equals("true")) {
					errorTxt.setText("");
					// If authentication successful
					Intent i = new Intent(
							CWCCourierClientLoginActivity.this,
							CWCCourierClientMainScreenActivity.class);
					
					i.putExtra("username", username.getText().toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
              }
              else {
            	  errorTxt.setText("Invalid Username or Password");
			  }
              
              dialog.dismiss();

        }
	};
	
	public void reminderMe(View view) {
		String nameText = username.getText().toString();
		String passwordText = password.getText().toString();
//		String ageText = age.getText().toString();
		
		if (nameText != null)
			PreferenceConnector.writeString(this, PreferenceConnector.NAME,
					nameText);
		if (passwordText != null)
			PreferenceConnector.writeString(this, PreferenceConnector.PASSWORD,
					passwordText);
		
	}

/*	public void reset(View view) {
		 A better way to delete all is:
		 * PreferenceConnector.getEditor(this).clear().commit();
		 
		PreferenceConnector.getEditor(this).remove(PreferenceConnector.NAME)
				.commit();
		PreferenceConnector.getEditor(this).remove(PreferenceConnector.PASSWORD)
				.commit();
		PreferenceConnector.getEditor(this).remove(PreferenceConnector.AGE)
				.commit();
		readPerson();
	}
*/

	/*
	 * Read the data refer to saved person and visualize them into Edittexts
	 */
	private void readPerson() {
		username.setText(PreferenceConnector.readString(this,
				PreferenceConnector.NAME, null));
		password.setText(PreferenceConnector.readString(this,
				PreferenceConnector.PASSWORD, null));
		
	}

}