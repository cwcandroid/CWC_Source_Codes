package com.cwc.courierclient;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.OnGestureListener;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class TaskLocationmMarkerActivity extends MapActivity implements Runnable,  OnGestureListener, OnDoubleTapListener{

	MapView mapView;
	private MapController mapController;
	private PlacesItemizedOverlay placesItemizedOverlay;
	ProgressDialog dialog;
	public static String username;
	ServerCommunication task_communication;
	String responseText;
	public JSONArray jsonArray;
	//LocationItemizedOvelay trackOverlay;
	List<Overlay> mapOverlays;
	Drawable drawable;
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.multiplemarker);
		//mapView =(MapView)findViewById(R.id.mapviewMulti);
		//mapView.setBuiltInZoomControls(true);
		initialiseMapView();

		// mapOverlays = mapView.getOverlays();
		//drawable = this.getResources().getDrawable(R.drawable.mark_red);
		//trackOverlay = new LocationItemizedOvelay(drawable, TaskLocationmMarkerActivity.this);
		username = TasksActivity.username;
		Log.i("getString Extra", username);
		task_communication = new ServerCommunication(username, null, "getTaskList", null);

		Thread thread = new Thread(TaskLocationmMarkerActivity.this); 
		thread.start();

	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	private void initialiseMapView() {
		mapView = (MapView) findViewById(R.id.mapviewMulti);
	    mapController = mapView.getController();

		mapView.setBuiltInZoomControls(true);
		mapView.setSatellite(false);

		// GeoPoint startPoint = new GeoPoint((int)(40.7575 * 1E6), (int)(-73.9785 * 1E6));
		//mapController.setCenter(startPoint);

		// mapController.setZoom(8);
	}


	public void run() {
		// TODO Auto-generated method stub
		responseText = task_communication.sendToServer(getApplicationContext());
		Log.i("final response", responseText);

		try {
			if (responseText.equals("tasklisted")) {
				jsonArray = task_communication.jsonArray;


				for (int i = 0; i < jsonArray.length(); i++) {
					JSONObject jsonObject = jsonArray.getJSONObject(i);

					Log.i("get name and address", jsonObject.getString("name")+" "+jsonObject.getString("address"));						
					//Log.i("get latitude and longitude", jsonObject.getString("latitude")+" "+jsonObject.getString("latitude"));
					Log.i("get latitude and longitude", jsonObject.getDouble("latitude")+" "+jsonObject.getDouble("latitude"));
					
					int alatitude = (int) jsonObject.getDouble("latitude")*1000000;
					int alongitude =(int) jsonObject.getDouble("longitude")*1000000;

					//List<>
					//GeoPoint point = new GeoPoint(alatitude, alongitude);
					//String name = jsonObject.getString("name");
					String address = jsonObject.getString("address");

					//List<address> addresses  = 
					Drawable defaultMarker = getResources().getDrawable(R.drawable.mark_red);
					placesItemizedOverlay = new PlacesItemizedOverlay(getApplicationContext(), defaultMarker);

					placesItemizedOverlay.addOverlayItem(new OverlayItem(new GeoPoint(alatitude,
							alongitude), " ", address));
					placesItemizedOverlay.addOverlayItem(new OverlayItem(new GeoPoint( alatitude, 
							alongitude), " ",address));
					placesItemizedOverlay.addOverlayItem(new OverlayItem(new GeoPoint(
							alatitude, alongitude), " ",
							address));
					placesItemizedOverlay.addOverlayItem(new OverlayItem(new GeoPoint(
							alatitude, alongitude), " ",address));


					// Add the overlays to the map
					mapView.getOverlays().add(placesItemizedOverlay);

					//OverlayItem overlayitem = new OverlayItem(point, " ",name+""+address);
					//OverlayItem overlayitem = new OverlayItem(point, " ",""+address);
					//trackOverlay.addOverlay(overlayitem);
					//mapOverlays.add(trackOverlay);

					/*						Resources res = getResources();

					if(jsonObject.getString("status").equals("1"))
						 drawable = res.getDrawable(R.drawable.item_complete);
					else
						drawable = res.getDrawable(R.drawable.item_pending);*/


				}

			}
			else {
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}


	public boolean onDoubleTap(MotionEvent e) {
		// TODO Auto-generated method stub
		GeoPoint p = mapView.getProjection().fromPixels((int)e.getX(), (int)e.getY());

		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("Double Tap");
		dialog.setMessage("Location: " + p.getLatitudeE6() + ", " + p.getLongitudeE6());
		dialog.show();

		return false;
	}

	public boolean onDoubleTapEvent(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean onSingleTapConfirmed(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		// TODO Auto-generated method stub
		return false;
	}

	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub

	}

	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		// TODO Auto-generated method stub
		return false;
	}

	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub

	}

	public boolean onSingleTapUp(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}

}
