package com.cwc.courierclient;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationActivity extends Activity implements OnClickListener{
	
	// ===========================================================
    // Fields
    // ===========================================================
	
	private Button btnLogin, btnSubmit;
	private EditText etxtUserId, etxtEmail, etxtPass, etxtConfirmPass;
	private Context CONTEXT;
	private String from_server = "";
	
	// ===========================================================
    // Methods for/from SuperClass/Interfaces
    // ===========================================================	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		CONTEXT = this;
		
		
		etxtUserId =  (EditText)findViewById(R.id.input_text_user_id);
		etxtEmail =  (EditText)findViewById(R.id.input_text_email);
		etxtPass = (EditText)findViewById(R.id.input_text_password);
		etxtConfirmPass = (EditText)findViewById(R.id.input_text_confirm_password);
		btnLogin=(Button)findViewById(R.id.button_login);
		btnSubmit=(Button)findViewById(R.id.button_submit);	
		
		/*etxtUserId.setText("sifat");
		etxtEmail.setText("t.b@g.c");
		etxtPass.setText("qwerty");
		etxtConfirmPass.setText("qwerty");*/
		
		btnLogin.setOnClickListener(this);
		btnSubmit.setOnClickListener(this);
	}		
	
	public void onClick(View view) {
		if(view == btnLogin){
			Intent i=new Intent(CONTEXT, LoginActivity.class);
			i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(i);
		}else if(view == btnSubmit){					
			if(Utils.isNetworkAvailable(CONTEXT) == false){
				Utils.t(CONTEXT, "Please check your internet connection");
				return;
			}
			// TO DO: user input validation
			if(inputValidation()== false)return;
			// TO DO: Submit request for registration and handle different error cases
			List<NameValuePair> params = new LinkedList<NameValuePair>();				
			params.add(new BasicNameValuePair("username", etxtUserId.getText().toString()));			
			params.add(new BasicNameValuePair("password",etxtPass.getText().toString()));
			params.add(new BasicNameValuePair("returnType","json"));
			params.add(new BasicNameValuePair("email", etxtEmail.getText().toString()));
			
			new MyAsyncTask().execute(params);
			
			//sample url
			//http://test.sentisol.com/cwc/index.php/android/register?username=cwcuser1&password=123456&returnType=json&email=cwcuser1@gmail.com			
			
		}		
	}
	
	// ===========================================================
    // Methods
    // ===========================================================
	
	protected boolean inputValidation() {

		if(Constants.USERNAME_PATTERN.matcher(etxtUserId.getText().toString()).matches() == false){			//
			Utils.t(CONTEXT, "Enter a valid usename with more than 2 characters");
			return false;
		}
		else if(Constants.EMAIL_ADDRESS_PATTERN.matcher(etxtEmail.getText().toString()).matches() == false){			
			Utils.t(CONTEXT, "Enter a valid email address");
			return false;
		}
		else if(Constants.PASSWORD_PATTERN.matcher(etxtPass.getText().toString()).matches() == false){			
			Utils.t(CONTEXT, "Enter a valid password with more than 5 characters");
			return false;
		}
		else if(etxtConfirmPass.getText().toString().equals(etxtPass.getText().toString()) == false){			
			Utils.t(CONTEXT, "Passwords don't match");
			return false;
		}
		return true;
	}
	
	
	
	public void showResultDialog() {
		
		String status ="";
		String extra_text = "";
		try {
			JSONObject jsonObj = new JSONObject(from_server);
			status = jsonObj.getString("status");
			extra_text = jsonObj.getString("text");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		AlertDialog alertDialog = new AlertDialog.Builder(CONTEXT).create();
         alertDialog.setTitle("Result");
         if(status.equals("Failed")){
        	 alertDialog.setMessage(extra_text);
         }else if(status.equals("Success")){
        	 alertDialog.setMessage("Registrion Successful");
         }
         final String s = status;
         alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
             public void onClick(DialogInterface dialog, int which) {
            	 if(s.equals("Success")){
            		Intent i=new Intent(CONTEXT, LoginActivity.class);
     				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
     				startActivity(i);
            	 }
           } });
         alertDialog.show();
	}
	
	
	// ===========================================================
    // Inner and Anonymous Classes
    // =========================================================== 
	
	private class MyAsyncTask extends AsyncTask<List<NameValuePair>, Long, Long>{
		ProgressDialog progressDialog;
		@Override
		protected Long doInBackground(List<NameValuePair>... arg0) {					
			from_server = HttpClient.makeGetRequest(CONTEXT, "register", arg0[0]);		
			return null;
		}
	     protected void onPreExecute() {
	         progressDialog = ProgressDialog.show(CONTEXT, "", "Please Wait");
	     }

	     protected void onPostExecute(Long result) {
	    	 if(progressDialog!=null)progressDialog.dismiss();
	         showResultDialog();
	     }

	}

}
