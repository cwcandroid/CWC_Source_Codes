package com.cwc.courierclient;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

import org.apache.http.HttpResponse;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.Context;
import android.graphics.Bitmap.CompressFormat;
import android.util.Config;
import android.util.Log;

public class HttpClient {
	
	public static String makeGetRequest(Context context,String page,List<NameValuePair> params){
		
		DefaultHttpClient hc=new DefaultHttpClient();  
		ResponseHandler <String> res=new BasicResponseHandler();
		
		// for get method
		String url = Constants.URL_BASE + page + "?" + URLEncodedUtils.format(params, "utf-8");	
		Utils.l(url);
		HttpGet httpGet=new HttpGet(url);
		
		String str_ret="";
		try {
			str_ret = hc.execute(httpGet, res);
		} catch (Exception ex){
			ex.printStackTrace();
		}
		// Do something with the returned string
		Utils.l(str_ret);
		String local_return = "[{\"address\":\"House: 154 Road: 22, Mohakhali DOHS, Dhaka\",\"comments\":\"Urgent\",\"contactno\":\"01718777777\",\"description\":\"One Samsung Galaxy Tab\",\"latitude\":\"23.78286\",\"longitude\":\"90.39544\",\"name\":\"Deliver Samsung Galaxy Tab\",\"status\":\"0\",\"task_id\":\"1\"}";
		local_return += ",{\"address\":\"House: 154 Road: 22, Mohakhali DOHS, Dhaka\",\"comments\":\"Urgent\",\"contactno\":\"01718777777\",\"description\":\"One Samsung Galaxy Tab\",\"latitude\":\"24.79286\",\"longitude\":\"90.39644\",\"name\":\"Deliver Samsung Galaxy Tab\",\"status\":\"1\",\"task_id\":\"21\"}]";
		return (str_ret.length()>10)?str_ret:local_return;

		
	}

	public static String makePostRequest(Context context,String page,List<NameValuePair> params){
		
		DefaultHttpClient hc=new DefaultHttpClient();  
		ResponseHandler <String> res=new BasicResponseHandler();
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		Constants.SIGN_BITMAP.compress(CompressFormat.JPEG, 75, bos);
		byte[] data = bos.toByteArray();
		ByteArrayBody bab = new ByteArrayBody(data, "sign.jpg");
		
		// for post method
		String url = Constants.URL_BASE + page + "?" + URLEncodedUtils.format(params, "utf-8");	
		HttpPost httpPost=new HttpPost(url);
		Utils.l(url);
		MultipartEntity reqEntity = new MultipartEntity(
				HttpMultipartMode.BROWSER_COMPATIBLE);
		reqEntity.addPart("signaturefile", bab);		
				
		String str_ret = "";
		try {
			httpPost.setEntity(reqEntity);
			//httpPost.setEntity(new UrlEncodedFormEntity(params));
			str_ret = hc.execute(httpPost, res);
		} catch (Exception ex){
			ex.printStackTrace();
		}
		
		// Do something with the returned string
		Utils.l(str_ret);

		String local_return = "[{\"address\":\"House: 154 Road: 22, Mohakhali DOHS, Dhaka\",\"comments\":\"Urgent\",\"contactno\":\"01718777777\",\"description\":\"One Samsung Galaxy Tab\",\"latitude\":\"23.78286\",\"longitude\":\"90.39544\",\"name\":\"Deliver Samsung Galaxy Tab\",\"status\":\"0\",\"task_id\":\"1\"}";
		local_return += ",{\"address\":\"House: 154 Road: 22, Mohakhali DOHS, Dhaka\",\"comments\":\"Urgent\",\"contactno\":\"01718777777\",\"description\":\"One Samsung Galaxy Tab\",\"latitude\":\"24.79286\",\"longitude\":\"90.39644\",\"name\":\"Deliver Samsung Galaxy Tab\",\"status\":\"1\",\"task_id\":\"21\"}]";
		return (str_ret.length()>10)?str_ret:local_return;
	
	}

}
