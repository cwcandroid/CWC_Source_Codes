package com.cwc.courierclient;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;

public class TakeSign extends Activity{

	TouchPaint panel;
	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);
		
		
		
		panel = new TouchPaint(this);
		setContentView(panel);
	}
	

}
