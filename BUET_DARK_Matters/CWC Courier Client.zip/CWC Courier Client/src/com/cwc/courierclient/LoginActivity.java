package com.cwc.courierclient;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.inputmethodservice.Keyboard.Key;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class LoginActivity extends Activity implements OnClickListener{
	
	// ===========================================================
    // Fields
    // ===========================================================
	
	private static final String PREFS_NAME = "LOGIN_PREFS";
	private SharedPreferences prefs; 
	
	
	Context CONTEXT;
	private EditText etxtUserId;
	private EditText etxtPass;
	private CheckBox chkRemember;
	private Button btnLogin; 
	private Button btnRegister;
	
	private String from_server = "";
	
	
	// ===========================================================
    // Methods for/from SuperClass/Interfaces
    // ===========================================================	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	DisplayMetrics metrics = new DisplayMetrics();
		Display display = ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay();
		display.getMetrics(metrics);
    	Constants.init(metrics);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        CONTEXT = this;
        Utils.l(new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
        Utils.l(DateFormat.getDateInstance().format(new Date()));
        
        etxtUserId = (EditText)findViewById(R.id.input_text_user_id);
        etxtPass = (EditText)findViewById(R.id.input_text_password);
        chkRemember = (CheckBox)findViewById(R.id.remember_me);
        btnLogin=(Button)findViewById(R.id.button_login);
        btnRegister=(Button)findViewById(R.id.button_new_user);
        
        
        prefs = getSharedPreferences(PREFS_NAME, 0);
        
        etxtUserId.setText(prefs.getString("name", ""));
        etxtPass.setText(prefs.getString("pass", ""));
        chkRemember.setChecked(prefs.getBoolean("remember", false));
        
        btnLogin.setOnClickListener(this);        
        btnRegister.setOnClickListener(this);
        
        
    }

	public void onClick(View view) {			
		if(view == btnLogin){
			if(Utils.isNetworkAvailable(CONTEXT) == false){
				Utils.t(CONTEXT, "Please check your internet connection");
				return;
			}
			// TO DO: User input validation
			if(inputValidation()== false)return;			
			// TO DO: Client Authentication and handle different error cases
			List<NameValuePair> params = new LinkedList<NameValuePair>();				
			params.add(new BasicNameValuePair("username", etxtUserId.getText().toString()));			
			params.add(new BasicNameValuePair("password",etxtPass.getText().toString()));
			params.add(new BasicNameValuePair("returnType","json"));
			
			SharedPreferences.Editor editor = prefs.edit();
			if(chkRemember.isChecked()){				
				editor.putString("name", etxtUserId.getText().toString());
				editor.putString("pass", etxtPass.getText().toString());
				editor.putBoolean("remember",chkRemember.isChecked());				
			}else{
				editor.putString("name", "");
				editor.putString("pass", "");
				editor.putBoolean("remember",false);
			}
			editor.commit();
			
			
			
			new MyAsyncTask().execute(params);
			
			
		}else if(view == btnRegister){
			Intent intent=new Intent(LoginActivity.this, RegistrationActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
		}
	}
    
    // ===========================================================
    // Methods
    // ===========================================================

	protected boolean inputValidation() {
		
		if(Constants.USERNAME_PATTERN.matcher(etxtUserId.getText().toString()).matches() == false){			//
			Utils.t(CONTEXT, "Enter a valid usename with at least 3 characters");
			return false;
		}
		else if(Constants.PASSWORD_PATTERN.matcher(etxtPass.getText().toString()).matches() == false){			
			Utils.t(CONTEXT, "Enter a valid password with at least 6 characters");
			return false;
		}

		return true;
	}
	
	public void showResultDialog() {
		
		String status ="";
		try {
			JSONObject jsonObj = new JSONObject(from_server);
			status = jsonObj.getString("status");
		} catch (JSONException e) {
			e.printStackTrace();
		}
				
         if(status.equals("false")){
        	 AlertDialog alertDialog = new AlertDialog.Builder(CONTEXT).create();
             alertDialog.setTitle("Failed");
        	 alertDialog.setMessage("Invalid Username or Password");
        	 alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                 public void onClick(DialogInterface dialog, int which) {
               } });
             alertDialog.show();
         }else if(status.equals("true")){
        	 //Log in successful
        	 //saving log in information for this session
        	Constants.USER_NAME = new String(etxtUserId.getText().toString());
     		Intent i=new Intent(CONTEXT, MainScreenActivity.class);
			i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(i);			
         }         
         
	}	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		
		if(keyCode == KeyEvent.KEYCODE_BACK ){
			SharedPreferences.Editor editor = prefs.edit();
			if(chkRemember.isChecked()){				
				editor.putString("name", etxtUserId.getText().toString());
				editor.putString("pass", etxtPass.getText().toString());
				editor.putBoolean("remember",chkRemember.isChecked());				
			}else{
				editor.putString("name", "");
				editor.putString("pass", "");
				editor.putBoolean("remember",false);
			}
			editor.commit();			
		}
		
		
		return super.onKeyDown(keyCode, event);
	}
	
	
	// ===========================================================
    // Inner and Anonymous Classes
    // =========================================================== 
	
	private class MyAsyncTask extends AsyncTask<List<NameValuePair>, Long, Long>{
		ProgressDialog progressDialog;
		@Override
		protected Long doInBackground(List<NameValuePair>... arg0) {					
			from_server = HttpClient.makeGetRequest(CONTEXT, "login", arg0[0]);		
			return null;
		}
	     protected void onPreExecute() {
	         progressDialog = ProgressDialog.show(CONTEXT, "", "Logging in");
	     }

	     protected void onPostExecute(Long result) {
	    	 if(progressDialog!=null)progressDialog.dismiss();
	         showResultDialog();
	         
	     }

	}

	
	
}