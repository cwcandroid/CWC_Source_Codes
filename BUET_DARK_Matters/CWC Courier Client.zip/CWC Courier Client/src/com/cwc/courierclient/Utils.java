package com.cwc.courierclient;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.widget.Toast;

public class Utils {

	
	public static void l(String str){
		if(str == null || str.equals("")){
			Log.d(Constants.LOG_TAG, "NULL");
		}
		Log.d(Constants.LOG_TAG, str);
	}
	public static void t(Context context,String str){
		if(str == null || str.equals("")){
			Toast.makeText(context, "NULL", Toast.LENGTH_SHORT);
		}
		Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
	}
	
	public static boolean isNetworkAvailable(Context context) {
	    ConnectivityManager connectivityManager 
	          = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
	    return activeNetworkInfo != null;
	}

	
}
