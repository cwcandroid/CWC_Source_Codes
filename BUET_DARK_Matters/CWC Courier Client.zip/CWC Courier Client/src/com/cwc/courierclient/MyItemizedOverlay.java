package com.cwc.courierclient;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.Drawable;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class MyItemizedOverlay extends ItemizedOverlay<OverlayItem> {
   
   private ArrayList<OverlayItem> mapOverlays = new ArrayList<OverlayItem>();
   
   private Context context;
   private boolean clickableItems;

private float mTextSize;
   
   public MyItemizedOverlay(Drawable defaultMarker) {
        super(boundCenterBottom(defaultMarker));
   }
   
   public MyItemizedOverlay(Drawable defaultMarker, Context context, float textSize, boolean clickableItems) {
        this(defaultMarker);
        this.context = context;
        this.mTextSize = textSize;
        this.clickableItems = clickableItems;

   }

   @Override
   protected OverlayItem createItem(int i) {
      return mapOverlays.get(i);
   }

   @Override
   public int size() {
      return mapOverlays.size();
   }
   
   @Override
   protected boolean onTap(int index) {
      OverlayItem item = mapOverlays.get(index);
      AlertDialog.Builder dialog = new AlertDialog.Builder(context);
      dialog.setTitle(item.getTitle());
      dialog.setMessage(item.getSnippet());
      //dialog.show();
      if(this.clickableItems){
    	  if(context instanceof TasksActivity)((TasksActivity)context).loadTaskDetailView(Integer.parseInt(item.getSnippet()));
    	  else if( context instanceof HistoryActivity)((HistoryActivity)context).loadHistoryDetailView(Integer.parseInt(item.getSnippet()));
      }
      return true;
   }
   
   @Override
   public void draw(android.graphics.Canvas canvas, MapView mapView, boolean shadow)
   {
       super.draw(canvas, mapView, shadow);

       if (shadow == false)
       {
           //cycle through all overlays
           for (int index = 0; index < mapOverlays.size(); index++)
           {
               OverlayItem item = mapOverlays.get(index);

               // Converts lat/lng-Point to coordinates on the screen
               GeoPoint point = item.getPoint();
               Point ptScreenCoord = new Point() ;
               mapView.getProjection().toPixels(point, ptScreenCoord);

               //Paint
               Paint paint = new Paint();
               paint.setTextAlign(Paint.Align.CENTER);
               paint.setTextSize(mTextSize);
               paint.setARGB(250, 0, 0, 0); // alpha, r, g, b (Black, semi see-through)

               //show text to the right of the icon
               canvas.drawText(item.getTitle(), ptScreenCoord.x, ptScreenCoord.y, paint);
           }
       }
   }
   
   
   public void addOverlay(OverlayItem overlay) {
      mapOverlays.add(overlay);
       this.populate();
   }

}

