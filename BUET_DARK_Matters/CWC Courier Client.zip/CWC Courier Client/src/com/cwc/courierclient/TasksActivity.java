package com.cwc.courierclient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.opengl.Visibility;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

public class TasksActivity extends MapActivity implements LocationListener  {
	
	private int LIST_VIEW = 0;
	private int DETAIL_VIEW = 1;
	private int MAP_VIEW = 2;
	private int REPORT_VIEW = 3;
	private int currentView = LIST_VIEW;
	private int currentRootView = LIST_VIEW;
	public static boolean reloadListItems = true; 
	private Activity CONTEXT;
	
	//For task list view
	List<String>names = new ArrayList<String>();
	List<String>address = new ArrayList<String>();
	List<Integer>status = new ArrayList<Integer>();	
	private ListView listView;
	private Button btnMapItems;
	//---------------------
	
	//For task Detail view
	
	private LinearLayout detailWrapper;
	private LinearLayout mapWrapper;
	private TextView etxtName;
	private TextView etxtId;
	private TextView etxtAddress;	
	private Button btnShowInfo;
	private Button btnshowMap;
	private Button btnCall;
	//--------------------
	
	//Form map View
	private MapView mapView;
	private Button btnReport;
	//-------------
	
	//For report View
	private Spinner spinnerType;
	private Button btnSign;
	private Button btnLocate;
	private TextView txtLatitude;
	private TextView txtLongitude;
	LocationManager locationManager;
	private Button btnSubmit;
	double latidute;
	double longitude;
	//---------------
	private Button btnCancel;
	private EditText etxtComment;
	private boolean locationDirty = true;
	private ImageView imageViewSign;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.tasklist);
		CONTEXT = this;
		mapView = new MapView(this, "0E8FeLOTNRv-koTZI3VGCCWmmFkYmLMUd-G8NOg");
		mapView.setClickable(true);
		mapView.setEnabled(true);		
		mapView.setBuiltInZoomControls(true);
		

		
		loadTaskData();
		

		
	}
	
	
	private void loadTaskData() {
		List<NameValuePair> params = new LinkedList<NameValuePair>();				
		params.add(new BasicNameValuePair("username", Constants.USER_NAME));					
		params.add(new BasicNameValuePair("returnType","json"));
		params.add(new BasicNameValuePair("duedate", new SimpleDateFormat("dd-MM-yyyy").format(new Date())));		
		new MyAsyncTaskGet("getTaskList").execute(params);
		
	}


	// show task list view
	public void loadTaskListView() {
		
		names.clear();
		address.clear();
		status.clear();
		try {			
			JSONArray taskList = new JSONArray(Constants.TASK_LIST);
			int len = taskList.length();
			for(int i = 0 ; i < len ; i++){
				JSONObject taskObj = taskList.getJSONObject(i);
				names.add(taskObj.getString("name"));
				address.add(taskObj.getString("address"));
				status.add(taskObj.getInt("status"));
			}
			
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		setContentView(R.layout.tasklist);
		this.currentView = LIST_VIEW;
		this.currentRootView = LIST_VIEW;
		
		btnMapItems = (Button) findViewById(R.id.button_map_items);
		btnMapItems.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// view map here
				loadMapItemsView();
				

			}
		});
		
		
		listView = (ListView) findViewById(R.id.listView1);
		
		listView.setAdapter(new MyArrayAdapter(this, R.layout.rowlayout, names,address, status));
		listView.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> arg0, View arg1, int pos,long arg3) {			
				loadTaskDetailView(pos);
			}
			
		});
	}

	protected void loadMapItemsView() {
		this.currentView = MAP_VIEW;
		this.currentRootView = MAP_VIEW;
		//setContentView(R.layout.googlemap);
		//mapView = (MapView) findViewById(R.id.mapview);
		
		if(mapWrapper!=null && mapWrapper.getChildCount()>0)mapWrapper.removeAllViews();
		setContentView(mapView);
		
		mapView.getOverlays().clear();
		mapView.invalidate();
		List<Overlay> mapOverlays = mapView.getOverlays();
        Drawable drawable_pending = this.getResources().getDrawable(R.drawable.pending_icon_small);
        Drawable drawable_delivered = this.getResources().getDrawable(R.drawable.ok_icon_small);
        Drawable drawable_undelivered = this.getResources().getDrawable(R.drawable.not_ok_small);
        MyItemizedOverlay pendingOverlay = new MyItemizedOverlay(drawable_pending, this,20,true);
        MyItemizedOverlay deliveredOverlay = new MyItemizedOverlay(drawable_delivered, this,20,true);
        MyItemizedOverlay unDeliveredOverlay = new MyItemizedOverlay(drawable_undelivered, this,20,true);
        
        MyItemizedOverlay dummyOverlay = new MyItemizedOverlay(drawable_undelivered, this,20,true);
        MapController mapController = mapView.getController();
        
        GeoPoint point = null;
        Point center_of_dest = new Point(0,0);
        OverlayItem overlayitem = null;
        try {			
			JSONArray taskList = new JSONArray(Constants.TASK_LIST);
			int len = taskList.length();
			for(int i = 0 ; i < len ; i++){
				JSONObject taskObj = taskList.getJSONObject(i);
				double lat = taskObj.getDouble("latitude");
				double lon = taskObj.getDouble("longitude");
				String id = taskObj.getString("task_id");
				int status = taskObj.getInt("status");
				point = new GeoPoint((int) (lat*1e6), (int) (lon*1e6));	
				center_of_dest.x += point.getLatitudeE6();
				center_of_dest.y += point.getLongitudeE6();
				//mapController.animateTo(point);
		        overlayitem = new OverlayItem(point, id, i+"");
		        if(status == 0){
		        	unDeliveredOverlay.addOverlay(overlayitem);
		        }else if(status == 1){
		        	deliveredOverlay.addOverlay(overlayitem);
		        }else {
		        	pendingOverlay.addOverlay(overlayitem);
		        }
		        dummyOverlay.addOverlay(overlayitem);
			}
			
			
		} catch (JSONException e) {
			
			e.printStackTrace();
		}  
        
    	if(unDeliveredOverlay.size()>0) mapOverlays.add(unDeliveredOverlay);
    	if(deliveredOverlay.size()>0)mapOverlays.add(deliveredOverlay);
    	if(pendingOverlay.size()>0)mapOverlays.add(pendingOverlay);
    	int len = pendingOverlay.size() + deliveredOverlay.size()  + unDeliveredOverlay.size(); 
    	mapController.animateTo(new GeoPoint(center_of_dest.x/len,center_of_dest.y/len));
    	mapController.zoomToSpan(dummyOverlay.getLatSpanE6(), dummyOverlay.getLonSpanE6());    	
    	    	
    	//mapController.setZoom(14);
        
        
                
        
        
        //mapController.setZoom(6);
		
	}
	
	

	//show detail view
	protected void loadTaskDetailView(int pos) {
		
		this.setContentView(R.layout.taskdetail);
		this.currentView = DETAIL_VIEW;
		
		detailWrapper = (LinearLayout) findViewById(R.id.detail_wrapper);
		mapWrapper = (LinearLayout) findViewById(R.id.map_loader);
		mapWrapper.removeAllViews();
		mapWrapper.addView(mapView); 
		mapWrapper.setVisibility(View.GONE);
		
		btnReport = (Button)findViewById(R.id.button_report);
		
		btnShowInfo = (Button)findViewById(R.id.button_info);
		btnshowMap = (Button)findViewById(R.id.button_map);
		etxtName = (TextView)findViewById(R.id.txt_name);
		etxtId = (TextView)findViewById(R.id.txt_id);
		etxtAddress = (TextView)findViewById(R.id.txt_address);
		btnCall = (Button)findViewById(R.id.button_call);
				
		mapView.getOverlays().clear();
		mapView.invalidate();
		MapController mapController = mapView.getController();
		List<Overlay> mapOverlays = mapView.getOverlays();
		
		String desc ="";
		String address="";
		String phone = "";
		String id= "";
		try {			
			JSONArray taskList = new JSONArray(Constants.TASK_LIST);						
			JSONObject taskObj = taskList.getJSONObject(pos);
			desc = taskObj.getString("description");
			id = taskObj.getString("task_id");
			address = taskObj.getString("address");	
			phone = taskObj.getString("contactno");
			double lat = taskObj.getDouble("latitude");
			double lon = taskObj.getDouble("longitude");
			int status = taskObj.getInt("status");
			GeoPoint point = new GeoPoint((int) (lat*1e6), (int) (lon*1e6));
			mapController.animateTo(point);
			mapController.setZoom(14);
			Drawable drawable = null;
			if(status == 0){
				drawable = this.getResources().getDrawable(R.drawable.not_ok_small);
			}else if(status == 1){
				drawable = this.getResources().getDrawable(R.drawable.ok_icon_small);
			}else{
				drawable = this.getResources().getDrawable(R.drawable.pending_icon_small);
			}
			MyItemizedOverlay overlay = new MyItemizedOverlay(drawable, this,20,false);
			OverlayItem overlayitem = new OverlayItem(point, id, pos+"");
			overlay.addOverlay(overlayitem);
			mapOverlays.add(overlay);
	        	        	       
		} catch (JSONException e) {
			e.printStackTrace();			
		}
		
		etxtName.setText("Item Name: " +desc);
		etxtId.setText("Item Id: " +id);
		etxtAddress.setText("Receiver Address: " +address);
		btnCall.setText("Call: " + phone);
		
		
		
		
		final String phone_no = phone;
		btnCall.setOnClickListener(new OnClickListener() {			
			public void onClick(View v) {				
				Intent intent = new Intent(getApplicationContext(),
						CallDialog.class);
				intent.putExtra("phone_no", phone_no);
				startActivity(intent);
			}
		});		
		final String id2 = id;
		btnReport.setOnClickListener(new OnClickListener() {			
			public void onClick(View v) {				
				loadReportTaskView(id2);
			}
		});
		
		btnShowInfo.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				detailWrapper.setVisibility(View.VISIBLE);
				mapWrapper.setVisibility(View.GONE);
			}
		});
		
		btnshowMap.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				detailWrapper.setVisibility(View.GONE);
				mapWrapper.setVisibility(View.VISIBLE);
				
			}
		});
	}
	
	
	protected void loadReportTaskView(String id) {		
		this.currentView = REPORT_VIEW;
		setContentView(R.layout.report);
		
		locationDirty  = true;
		
		spinnerType = (Spinner) findViewById(R.id.spinner_type);
	    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
	            this, R.array.type_array, android.R.layout.simple_spinner_item);
	    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    spinnerType.setAdapter(adapter);
	    
	    btnSign = (Button) findViewById(R.id.button_sign);
	    btnSign.setEnabled(false);
	    
	    btnLocate = (Button) findViewById(R.id.button_locate);
	    
	    txtLatitude = (TextView) findViewById(R.id.etxt_lat);
	    txtLongitude = (TextView) findViewById(R.id.etxt_lon);
	    
	    imageViewSign = (ImageView)findViewById(R.id.imageView_sign);

	    
	    
	    
	    etxtComment = (EditText) findViewById(R.id.etxt_comment);
	    
	    btnSubmit = (Button)findViewById(R.id.button_submit);
	    btnCancel = (Button)findViewById(R.id.button_cancel);
	    
	    spinnerType.setOnItemSelectedListener(new OnItemSelectedListener() {
	    	public void onItemSelected(AdapterView<?> parent,
	    	        View view, int pos, long id) {
	    	    	if(pos == 1){
	    				btnSign.setEnabled(true);
	    			}else{
	    				btnSign.setEnabled(false);
	    			}
	    	    }
    	    public void onNothingSelected(AdapterView parent) {
    	      // Do nothing.
    	    }	    	
		});
	    
	    btnLocate.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
				if ( !locationManager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
			        buildAlertMessageNoGps();
					//Utils.t(CONTEXT, "GPS diabled");
			    }
				locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 500.0f, TasksActivity.this);
			}
		});
	    
	    btnSign.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(CONTEXT,TakeSign.class);
				startActivityForResult(intent, 91);
				
			}
		});
	    
	    final String id2 = id;
	    btnSubmit.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				if(locationDirty){
					Utils.t(CONTEXT,"Location not updated");
					return;
				}
				if(Constants.SIGN_BITMAP == null){
					Utils.t(CONTEXT, "Take Recipients Signature");
					return;
				}
				List<NameValuePair> params = new LinkedList<NameValuePair>();				
				params.add(new BasicNameValuePair("username", Constants.USER_NAME));					
				params.add(new BasicNameValuePair("returnType","json"));
				params.add(new BasicNameValuePair("task_id",id2));
				params.add(new BasicNameValuePair("reasondetails",etxtComment.getText().toString()));
				params.add(new BasicNameValuePair("reasontype",spinnerType.getSelectedItemPosition()+""));
				params.add(new BasicNameValuePair("reportlatitude",latidute +"" ));
				params.add(new BasicNameValuePair("reportlongitude",longitude +"" ));
				params.add(new BasicNameValuePair("signaturefile","sign.jpg"));
				new MyAsyncTaskGet("reportSpecificTask").execute(params);
				locationDirty = true;
			}
		});
	    
		
	}
	
	private void buildAlertMessageNoGps() {
	    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
	    builder.setMessage("Yout GPS seems to be disabled, do you want to enable it?")
	           .setCancelable(false)
	           .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
	               public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
	            	   Intent callGPSSettingIntent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
	            	   startActivity(callGPSSettingIntent);
	               }
	           })
	           .setNegativeButton("No", new DialogInterface.OnClickListener() {
	               public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
	                    dialog.cancel();
	               }
	           });
	    final AlertDialog alert = builder.create();
	    alert.show();
	}

	
	// ===========================================================
    // Methods for/from SuperClass/Interfaces
    // ===========================================================		

	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode == 91){
			if(Constants.SIGN_BITMAP != null){
		    	imageViewSign.setImageBitmap(Constants.SIGN_BITMAP);
		    }
		}
	}

	@Override
	public void onBackPressed() {
		this.mapWrapper.removeAllViews();
		mapView.invalidate();
		Constants.SIGN_BITMAP = null;
		if(this.currentView == DETAIL_VIEW){
			if(currentRootView == LIST_VIEW)loadTaskListView();
			else if(currentRootView == MAP_VIEW)loadMapItemsView();			
		}
		else if(this.currentView == MAP_VIEW){			 
			loadTaskListView();			
		}else if(this.currentView == REPORT_VIEW){
			loadTaskListView();
		}		
		else super.onBackPressed();
	}
	@Override
	protected boolean isRouteDisplayed() {		
		return false;
	}


	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		if (location != null) {
			latidute = location.getLatitude();
			longitude  = location.getLongitude();
			txtLatitude.setText(latidute+"");
			txtLongitude.setText(longitude + "");
			locationManager.removeUpdates(this);
			locationDirty = false;
		}
	}


	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}


	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		txtLatitude.setText("Getting Location...");
		txtLongitude.setText("Getting Location...");
		
	}


	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}



	// ===========================================================
    // Inner and Anonymous Classes
    // =========================================================== 
	

	private class MyAsyncTaskGet extends AsyncTask<List<NameValuePair>, Long, Long>{ 
		ProgressDialog progressDialog;
		
		String page = "getTaskList";
		public MyAsyncTaskGet(String page) {
			this.page = page;
		}
		
		@Override
		protected Long doInBackground(List<NameValuePair>... arg0) {					
			Constants.TASK_LIST = HttpClient.makeGetRequest(CONTEXT, page, arg0[0]);		
			return null;
		}
	     protected void onPreExecute() {
	         progressDialog = ProgressDialog.show(CONTEXT, "", "Please Wait");
	     }

	     protected void onPostExecute(Long result) {
	         if(progressDialog!=null)progressDialog.dismiss();
	         if(page.equals("getTaskList") == false){
	        	 loadTaskData();	        	 
	         }
	         loadTaskListView();
	     }

	}
	
	private class MyAsyncTaskPost extends AsyncTask<List<NameValuePair>, Long, Long>{ 
		ProgressDialog progressDialog;
		
		String page = "getTaskList";
		public MyAsyncTaskPost(String page) {
			this.page = page;
		}
		
		@Override
		protected Long doInBackground(List<NameValuePair>... arg0) {					
			Constants.TASK_LIST = HttpClient.makePostRequest(CONTEXT, page, arg0[0]);		
			return null;
		}
	     protected void onPreExecute() {
	         progressDialog = ProgressDialog.show(CONTEXT, "", "Please Wait");
	     }

	     protected void onPostExecute(Long result) {
	         if(progressDialog!=null)progressDialog.dismiss();
	         if(page.equals("getTaskList") == false){
	        	 loadTaskData();	        	 
	         }
	         loadTaskListView();
	     }

	}


}
