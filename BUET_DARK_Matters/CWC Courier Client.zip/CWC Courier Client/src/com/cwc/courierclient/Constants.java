package com.cwc.courierclient;

import java.util.regex.Pattern;

import android.graphics.Bitmap;
import android.util.DisplayMetrics;

public class Constants {
	
	public static final String LOG_TAG = "sifat";
	
	public static String USER_NAME ="";
	public static String TASK_LIST = "";
	public static String HISTORY_LIST = "";

	public static final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(
	          "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
	          "\\@" +
	          "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
	          "(" +
	          "\\." +
	          "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
	          ")+"
	      );
	
	public static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-z0-9_-]{3,15}$");
	public static final Pattern PASSWORD_PATTERN = Pattern.compile(".{6,20}$");

	public static final String URL_BASE = "http://test.sentisol.com/cwc/index.php/android/";
	
	public static Bitmap SIGN_BITMAP;
	public static  DisplayMetrics METRICS;
	public static void init(DisplayMetrics metric){
		METRICS = metric;
	}
}
