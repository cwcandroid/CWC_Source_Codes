package com.cwc.courierclient;

import org.json.JSONObject;

public class MyParser {
	
	public static JSONObject parseJSON(String str){
		
		
		return null;
	}
}
