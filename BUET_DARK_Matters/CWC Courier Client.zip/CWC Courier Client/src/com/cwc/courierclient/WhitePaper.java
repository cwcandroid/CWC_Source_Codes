package com.cwc.courierclient;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

public class WhitePaper extends SurfaceView implements SurfaceHolder.Callback {
    private CanvasThread canvasThread;
	private WhitePaper CONTEXT;
	private Paint paint;
	
	List<List<Point>> curves = new ArrayList<List<Point>>();
	
 
    public WhitePaper(Context context) {
        super(context);
        CONTEXT = this;
        this.getHolder().addCallback(CONTEXT);
        
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStrokeCap(Cap.ROUND);
        paint.setStrokeWidth(10);
    }
 
   
 
    public void startDrawImage() {
        
    }
 
    public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
        // TODO Auto-generated method stub
 
    }
 
    public void surfaceCreated(SurfaceHolder arg0) {
        // TODO Auto-generated method stub

    	this.canvasThread = new CanvasThread(getHolder());
        this.setFocusable(true);
        canvasThread.setRunning(true);
        canvasThread.start();
    }
    
	public static Bitmap loadBitmapFromView(View v) {
	    Bitmap b = Bitmap.createBitmap( 320, 480, Bitmap.Config.ARGB_8888);                
	    Canvas c = new Canvas(b);
	    v.layout(0, 0, v.getLayoutParams().width, v.getLayoutParams().height);
	    v.draw(c);
	    return b;
	}
 
    public void surfaceDestroyed(SurfaceHolder arg0) {
        // TODO Auto-generated method stub
    	Constants.SIGN_BITMAP = loadBitmapFromView(this); 
        boolean retry = true;
        canvasThread.setRunning(false); 
        while(retry) {
            try {
                canvasThread.join();
                retry = false;
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
 
    @Override
    protected void onDraw(Canvas canvas) {
        // TODO Auto-generated method stub
        //Bitmap sweet = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
        canvas.drawColor(Color.WHITE);
        //canvas.drawBitmap(sweet, 0, 0, null);
        int len1 = curves.size();
        for ( int i = 0 ; i < len1 ; i++){
        	int len2 = curves.get(i).size();
        	List<Point> line = curves.get(i);
        	for(int j = 0 ; j < len2 - 1; j++){
        		canvas.drawLine(line.get(j).x, line.get(j).y, line.get(j+1).x, line.get(j+1).y, paint);
        	}
        }
        
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent event) {
    	int x = (int) event.getX();
    	int y = (int) event.getY();
    	Utils.l("touching");
    	switch(event.getAction()){
    	case MotionEvent.ACTION_DOWN:
    		curves.add(new ArrayList<Point>());
    		break;
    	case MotionEvent.ACTION_UP:    		
    		break;
    	case MotionEvent.ACTION_MOVE:
    		curves.get(curves.size() - 1).add(new Point(x,y));
    		break;
    	}
    	
    	
    	return super.onTouchEvent(event);
    }
    
 
    private class CanvasThread extends Thread {
        private SurfaceHolder surfaceHolder;
        private boolean isRun = false;
 
        public CanvasThread(SurfaceHolder holder) {
            this.surfaceHolder = holder;
        }
 
        public void setRunning(boolean run) {
            this.isRun = run;
        }
 
        @Override
        public void run() {
            // TODO Auto-generated method stub
            Canvas c;
 
            while(isRun) {
                c = null;
                try {
                    c = this.surfaceHolder.lockCanvas(null);
                    synchronized(this.surfaceHolder) {
                    	WhitePaper.this.onDraw(c);
                    }
                } finally {
                	if (c != null) {
                		this.surfaceHolder.unlockCanvasAndPost(c);
                	}
                }
            }
        }
    }
}