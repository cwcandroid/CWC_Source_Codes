package com.cwc.courierclient;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;

public class CallDialog extends Activity {

	private Button call;
	private Button cancel;
	private boolean offhook,idle;
	private ListenToPhoneState listener;

	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.call);
		
		final String phone = getIntent().getExtras().getString("phone_no");

		Log.d("Call Dialog", "At onCreate");
		call = (Button) findViewById(R.id.call);
		cancel = (Button) findViewById(R.id.cancel);

		cancel.setOnClickListener(new OnClickListener() {

			
			public void onClick(View v) {
				finish();
			}
		});

		call.setOnClickListener(new OnClickListener() {

			
			public void onClick(View v) {				
				String number = "tel:" + phone.trim();
				Intent callIntent = new Intent(Intent.ACTION_CALL, Uri
						.parse(number));
				startActivity(callIntent);

				try {
					TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
					listener = new ListenToPhoneState();
					tManager.listen(listener,
							PhoneStateListener.LISTEN_CALL_STATE);
					
					while(offhook == true && idle == false ){
						try {
							wait(10);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					
					finish();
							
				} catch (ActivityNotFoundException activityException) {
					Log.d("telephony-example", "Call failed", activityException);
				}

			}
		});
	}

	private class ListenToPhoneState extends PhoneStateListener {

		public void onCallStateChanged(int state, String incomingNumber) {
			Log.d("telephony-example", "State changed: " + stateName(state));
		}

		String stateName(int state) {
			switch (state) {
			case TelephonyManager.CALL_STATE_IDLE:
				offhook = false;
				idle = true;
				return "Idle";
			case TelephonyManager.CALL_STATE_OFFHOOK:
				idle = false;
				offhook = true;
				return "Off hook";
			case TelephonyManager.CALL_STATE_RINGING:
				return "Ringing";
			}
			return Integer.toString(state);
		}
	}

}
