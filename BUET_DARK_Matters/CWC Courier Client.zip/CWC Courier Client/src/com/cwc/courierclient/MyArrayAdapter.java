package com.cwc.courierclient;

import java.util.List;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyArrayAdapter extends ArrayAdapter<String>{

	private final Activity context;
	private final List<String> names;	
	private final int id;
	private final List<Integer>status;
	private final List<String>address;
	
	public MyArrayAdapter(Activity context,int id, List<String> names,List<String>address,List<Integer>status) {
		super(context, id, names);		
		this.context = context;
		this.id = id;
		this.names = names;
		this.status = status;
		this.address = address;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = context.getLayoutInflater();
		View rowView = inflater.inflate(this.id, null, true);
		TextView nameTextView = (TextView) rowView.findViewById(R.id.txt_label);
		TextView addressTextView  = (TextView) rowView.findViewById(R.id.txt_address);
		ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
		String name = this.names.get(position);
		String address = this.address.get(position);
		int pos = this.status.get(position);
		nameTextView.setText(name);
		addressTextView.setText(address);
		if (pos == 0) {
			imageView.setImageResource(R.drawable.not_ok_icon);
		} else if(pos == 1) {
			imageView.setImageResource(R.drawable.ok_icon);
		}else{
			imageView.setImageResource(R.drawable.pending_icon);
		}

		return rowView;
	}
}
