package com.cwc.courierclient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class HistoryActivity extends MapActivity{

	private static final int LIST_VIEW = 0;
	private static final int DETAIL_VIEW = 1;

	private HistoryActivity CONTEXT;
	
	List<String>names = new ArrayList<String>();
	List<String>address = new ArrayList<String>();
	List<Integer>status = new ArrayList<Integer>();

	private int currentView = LIST_VIEW;
	private ListView listView;
	private TextView etxtName;
	private TextView etxtId;
	private TextView etxtAddress;
	private Button btnCall;
	private View btnShowInfo;
	private View btnshowMap;
	private LinearLayout detailWrapper;
	private LinearLayout mapWrapper;
	
	private MapView mapView;
	private TextView txtDate;
	private TextView txtStatus;
	private TextView txtComment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.historylist);
		CONTEXT = this;
		mapView = new MapView(this, "0E8FeLOTNRv-koTZI3VGCCWmmFkYmLMUd-G8NOg");
		mapView.setClickable(true);
		mapView.setEnabled(true);		
		mapView.setBuiltInZoomControls(true);
		
		loadHistoryData();
	}
	
	private void loadHistoryData() {
		List<NameValuePair> params = new LinkedList<NameValuePair>();				
		params.add(new BasicNameValuePair("username", Constants.USER_NAME));					
		params.add(new BasicNameValuePair("returnType","json"));
		//params.add(new BasicNameValuePair("duedate", new SimpleDateFormat("dd-MM-yyyy").format(new Date())));		
		new MyAsyncTaskGet("getTaskHistory").execute(params); 
		
	}
	

	public void loadTaskHistoryView() {
		
		names.clear();
		address.clear();
		status.clear();
		try {			
			JSONArray taskList = new JSONArray(Constants.HISTORY_LIST);
			int len = taskList.length();
			for(int i = 0 ; i < len ; i++){
				JSONObject taskObj = taskList.getJSONObject(i);
				names.add(taskObj.getString("name"));
				address.add(taskObj.getString("address"));
				status.add(taskObj.getInt("status"));
			}						
		} catch (JSONException e) {
			e.printStackTrace();
		}
		setContentView(R.layout.historylist);
		this.currentView = LIST_VIEW;
		
		listView = (ListView) findViewById(R.id.listView1);
		
		listView.setAdapter(new MyArrayAdapter(this, R.layout.rowlayout, names,address, status));
		listView.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> arg0, View arg1, int pos,long arg3) {			
				loadHistoryDetailView(pos);
			}
			
		});
		
		
	}	

	
	
	protected void loadHistoryDetailView(int pos) {
		
		this.setContentView(R.layout.historydetail);
		this.currentView = DETAIL_VIEW;
		detailWrapper = (LinearLayout) findViewById(R.id.detail_wrapper);
		
		mapWrapper = (LinearLayout) findViewById(R.id.map_loader);
		mapWrapper.removeAllViews();
		mapWrapper.addView(mapView); 
		mapWrapper.setVisibility(View.GONE);
		
		
		btnShowInfo = (Button)findViewById(R.id.button_info);
		btnshowMap = (Button)findViewById(R.id.button_map);
		etxtName = (TextView)findViewById(R.id.txt_name);
		etxtId = (TextView)findViewById(R.id.txt_id);
		etxtAddress = (TextView)findViewById(R.id.txt_address);
		btnCall = (Button)findViewById(R.id.button_call);
		
		txtDate = (TextView)findViewById(R.id.txt_deliver_date);
		txtStatus = (TextView)findViewById(R.id.txt_status);
		txtComment = (TextView)findViewById(R.id.txt_comments);
				
		mapView.getOverlays().clear();
		mapView.invalidate();
		MapController mapController = mapView.getController();
		List<Overlay> mapOverlays = mapView.getOverlays();
		
		String desc ="";
		String address="";
		String phone = "";
		String id= "";
		int status = 0;
		String comments = "";
		String date = "";
		String time = "";
		try {			
			JSONArray taskList = new JSONArray(Constants.HISTORY_LIST);						
			JSONObject taskObj = taskList.getJSONObject(pos);
			desc = taskObj.getString("description");
			id = taskObj.getString("id");
			address = taskObj.getString("address");	
			phone = taskObj.getString("contactno");
			
			status = taskObj.getInt("status");
			Utils.l(status +"");
			comments = taskObj.getString("reasondetails");
			Utils.l(comments);
			date = taskObj.getString("duedate");
			Utils.l(date);
			time = taskObj.getString("duetime");
			double lat = taskObj.getDouble("latitude");
			double lon = taskObj.getDouble("longitude");
			GeoPoint point = new GeoPoint((int) (lat*1e6), (int) (lon*1e6));
			mapController.animateTo(point);
			mapController.setZoom(14);
			Drawable drawable = null;
			if(status == 0){
				drawable = this.getResources().getDrawable(R.drawable.not_ok_small);
			}else if(status == 1){
				drawable = this.getResources().getDrawable(R.drawable.ok_icon_small);
			}else{
				drawable = this.getResources().getDrawable(R.drawable.pending_icon_small);
			}
			MyItemizedOverlay overlay = new MyItemizedOverlay(drawable, this,20,false);
			OverlayItem overlayitem = new OverlayItem(point, id, pos+"");
			overlay.addOverlay(overlayitem);
			mapOverlays.add(overlay);
	        	        	       
		} catch (JSONException e) {
			e.printStackTrace();			
		} 
		
		etxtName.setText("Item Name: " +desc);
		etxtId.setText("Item Id: " +id);
		etxtAddress.setText("Receiver Address: " +address);
		btnCall.setText("Call: " + phone);
		
		txtDate.setText("Delivered On : "+date +"," + time);
		if(status == 1)txtStatus.setText("Status : Delivered");
		else txtStatus.setText("Status : Pending");
		
		txtComment.setText("Comments : " + comments);
		
		
		
		
		final String phone_no = phone;
		btnCall.setOnClickListener(new OnClickListener() {			
			public void onClick(View v) {				
				Intent intent = new Intent(getApplicationContext(),
						CallDialog.class);
				intent.putExtra("phone_no", phone_no);
				startActivity(intent);
			}
		});		
		final String id2 = id;

		
		btnShowInfo.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				detailWrapper.setVisibility(View.VISIBLE);
				mapWrapper.setVisibility(View.GONE);
			}
		});
		
		btnshowMap.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				detailWrapper.setVisibility(View.GONE);
				mapWrapper.setVisibility(View.VISIBLE);
				
			}
		});
	}
	
	@Override
	public void onBackPressed() {
		mapWrapper.removeAllViews();
		mapView.invalidate();		
		if(this.currentView == DETAIL_VIEW){
			loadTaskHistoryView();		
		}		
		else super.onBackPressed();
	}



	// ===========================================================
    // Inner and Anonymous Classes
    // =========================================================== 
	
	
	private class MyAsyncTaskGet extends AsyncTask<List<NameValuePair>, Long, Long>{ 
		ProgressDialog progressDialog;
		
		String page = "getTaskHistory";
		public MyAsyncTaskGet(String page) {
			this.page = page;
		}
		
		@Override
		protected Long doInBackground(List<NameValuePair>... arg0) {					
			Constants.HISTORY_LIST = HttpClient.makeGetRequest(CONTEXT, page, arg0[0]);		
			return null;
		}
	     protected void onPreExecute() {
	         progressDialog = ProgressDialog.show(CONTEXT, "", "Please Wait");
	     }

	     protected void onPostExecute(Long result) {
	    	 if(progressDialog!=null)progressDialog.dismiss();
	    	 loadTaskHistoryView();
	     }

	}



	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}



}


