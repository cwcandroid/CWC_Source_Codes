package com.strawberriesandcream.courierclient.provider;

import java.sql.SQLException;
import java.util.HashMap;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import com.strawberriesandcream.courierclient.provider.TaskProviderMetaData.TaskHistoryTableMetaData;

public class TaskHistoryProvider extends ContentProvider{
	private static HashMap<String, String> sTaskListProjectionMap;
	static{
		sTaskListProjectionMap = new HashMap<String, String>();
		sTaskListProjectionMap.put(TaskHistoryTableMetaData._ID, TaskHistoryTableMetaData._ID);
		
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.ADDRESS, TaskHistoryTableMetaData.ADDRESS);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.COMMENTS, TaskHistoryTableMetaData.COMMENTS);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.CONTACT_NO, TaskHistoryTableMetaData.CONTACT_NO);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.DESCRIPTION, TaskHistoryTableMetaData.DESCRIPTION);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.LATITUDE, TaskHistoryTableMetaData.LATITUDE);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.LONGITUDE, TaskHistoryTableMetaData.LONGITUDE);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.NAME, TaskHistoryTableMetaData.NAME);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.STATUS, TaskHistoryTableMetaData.STATUS);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.ID, TaskHistoryTableMetaData.ID);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.DUE_DATE, TaskHistoryTableMetaData.DUE_DATE);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.DUE_TIME, TaskHistoryTableMetaData.DUE_TIME);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.EXTRA, TaskHistoryTableMetaData.EXTRA);
		
		// created, modified, data
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.CREATED_DATE, TaskHistoryTableMetaData.CREATED_DATE);
		sTaskListProjectionMap.put(TaskHistoryTableMetaData.MODIFIED_DATE, TaskHistoryTableMetaData.MODIFIED_DATE);
	}
	
	private static final UriMatcher sUriMatcher;
	private static final int INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR = 1;
	private static final int INCOMING_SINGLE_TASK_LIST_URI_INDICATOR = 2;
	
	static{
		sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		
		sUriMatcher.addURI(
				TaskProviderMetaData.AUTHORITY, 
				TaskHistoryTableMetaData.TABLE_NAME, 
				INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR
		);
		
		sUriMatcher.addURI(
				TaskProviderMetaData.AUTHORITY, 
				TaskHistoryTableMetaData.TABLE_NAME + "/#", 
				INCOMING_SINGLE_TASK_LIST_URI_INDICATOR
		);
	}

	@Override
	public int delete(Uri uri, String where, String[] whereArgs){
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		int count;
		switch(sUriMatcher.match(uri)){
		case INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR:
			count = db.delete(TaskHistoryTableMetaData.TABLE_NAME, where, whereArgs);
			break;
			
		case INCOMING_SINGLE_TASK_LIST_URI_INDICATOR:
			String rowId = uri.getPathSegments().get(1);
			count = db.delete(TaskHistoryTableMetaData.TABLE_NAME,
					TaskHistoryTableMetaData._ID + "=" + rowId +
					(!TextUtils.isEmpty(where) ? " AND (" + where + ")" : "" ), whereArgs);
			break;
		
		default:
			throw new IllegalArgumentException("Unknow URI " + uri);
		}
		
		getContext().getContentResolver().notifyChange(uri, null);
		
		return count;
	}

	@Override
	public String getType(Uri uri){
		switch(sUriMatcher.match(uri)){
		case INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR:
			return TaskHistoryTableMetaData.CONTENT_TYPE;		
		case INCOMING_SINGLE_TASK_LIST_URI_INDICATOR:
			return TaskHistoryTableMetaData.CONTENT_ITEM_TYPE;
		default:
			throw new IllegalArgumentException("Unknow URI " + uri);
		}
	}

	@Override
	public Uri insert(Uri uri, ContentValues values){
		System.out.println("inside insert");
		
		if (sUriMatcher.match(uri) != INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR){
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
		
		Long now = Long.valueOf(System.currentTimeMillis());
		
		
		if (values.containsKey(TaskHistoryTableMetaData.CREATED_DATE) == false){
			values.put(TaskHistoryTableMetaData.CREATED_DATE, now);
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.MODIFIED_DATE) == false){
			values.put(TaskHistoryTableMetaData.MODIFIED_DATE, now);
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.ADDRESS) == false){
			try {
				throw new SQLException("Failed to insert row because 'address' is needed " + uri);
			} catch (SQLException e){}
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.COMMENTS) == false){
			values.put(TaskHistoryTableMetaData.COMMENTS, TaskHistoryTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.CONTACT_NO)== false){
			values.put(TaskHistoryTableMetaData.CONTACT_NO, TaskHistoryTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.DESCRIPTION)== false){
			values.put(TaskHistoryTableMetaData.DESCRIPTION, TaskHistoryTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.LATITUDE)== false){			
			try {
				throw new SQLException("Failed to insert row because 'latitude' is needed " + uri);
			} catch (SQLException e) {}		
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.LONGITUDE) == false){			
			try {
				throw new SQLException("Failed to insert row because 'longitude' is needed " + uri);
			} catch (SQLException e) {}			
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.NAME)== false){
			values.put(TaskHistoryTableMetaData.NAME, TaskHistoryTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.ID) == false){
			try {
				throw new SQLException("Failed to insert row because 'task_id' is needed " + uri);
			} catch (SQLException e) {}
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.DUE_TIME) == false){
			try {
				throw new SQLException("Failed to insert row because 'duedate' is needed " + uri);
			} catch (SQLException e) {}
		}

		if (values.containsKey(TaskHistoryTableMetaData.DUE_DATE) == false){
			values.put(TaskHistoryTableMetaData.DUE_DATE, TaskHistoryTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskHistoryTableMetaData.EXTRA) == false){
			values.put(TaskHistoryTableMetaData.EXTRA, TaskHistoryTableMetaData.NOT_AVAILABLE);
		}
		
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		long rowId = db.insert(TaskHistoryTableMetaData.TABLE_NAME, TaskHistoryTableMetaData.ID, values);
		
		System.out.println("we are nearly done inserting!");
		
		if (rowId > 0){
			Uri insertedTaskUri = ContentUris.withAppendedId(TaskHistoryTableMetaData.CONTENT_URI, rowId);
			getContext().getContentResolver().notifyChange(insertedTaskUri, null);
			return insertedTaskUri;
		}
		
		try {
			throw new SQLException("Failed to insert row into " + uri);
		} catch (SQLException e){}
		
		return null;
	}
	
	private DatabaseHelper mOpenHelper;

	@Override
	public boolean onCreate(){
		mOpenHelper = new DatabaseHelper(getContext());
		return true;
	}
	
	private static class DatabaseHelper extends SQLiteOpenHelper{
		DatabaseHelper(Context context){			
			super(context, TaskProviderMetaData.DATABASE_NAME, null, TaskProviderMetaData.DATABASE_VERSION);
		}
		
		@Override
		public void onCreate(SQLiteDatabase db){
			System.out.println("Creating database");
			
			db.execSQL
			("CREATE TABLE " + TaskHistoryTableMetaData.TABLE_NAME 
				+ " ("					
					+ TaskHistoryTableMetaData._ID + " INTEGER AUTO INCREMENT,"
					+ TaskHistoryTableMetaData.ADDRESS + " TEXT,"
					+ TaskHistoryTableMetaData.COMMENTS + " TEXT,"
					+ TaskHistoryTableMetaData.CONTACT_NO + " TEXT,"
					+ TaskHistoryTableMetaData.DESCRIPTION + " TEXT,"
					+ TaskHistoryTableMetaData.LATITUDE + " TEXT,"
					+ TaskHistoryTableMetaData.LONGITUDE + " TEXT,"
					+ TaskHistoryTableMetaData.NAME + " TEXT,"
					+ TaskHistoryTableMetaData.STATUS + " TEXT,"
					+ TaskHistoryTableMetaData.ID + " INTEGER PRIMARY KEY,"
					+ TaskHistoryTableMetaData.CREATED_DATE + " INTEGER,"
					+ TaskHistoryTableMetaData.MODIFIED_DATE + " INTEGER,"
					+ TaskHistoryTableMetaData.DUE_DATE + " TEXT,"
					+ TaskHistoryTableMetaData.DUE_TIME + " TEXT,"
					+ TaskHistoryTableMetaData.REASON_DETAILS + " TEXT,"
					+ TaskHistoryTableMetaData.REASON_TYPE + " TEXT,"
					+ TaskHistoryTableMetaData.REPORT_LATITUDE + " TEXT,"
					+ TaskHistoryTableMetaData.REPORT_LONGITUDE + " TEXT,"
					+ TaskHistoryTableMetaData.SIGNATURE_FILE + " TEXT,"
					+ TaskHistoryTableMetaData.EXTRA + " TEXT"
				+ ");"
			);
			
			System.out.println("Finished creating database!");
		}
		
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
			Log.w("TAG", "Upgrading database from version " + oldVersion + " to " + newVersion
					+ ", which will destroy all old data!");
			db.execSQL("DROP TABLE IF EXISTS " + TaskHistoryTableMetaData.TABLE_NAME);
			onCreate(db);
		}
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder){
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		switch(sUriMatcher.match(uri)){
		case INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR:
			qb.setTables(TaskHistoryTableMetaData.TABLE_NAME);
			qb.setProjectionMap(sTaskListProjectionMap);
			break;
		case INCOMING_SINGLE_TASK_LIST_URI_INDICATOR:
			qb.setTables(TaskHistoryTableMetaData.TABLE_NAME);
			qb.setProjectionMap(sTaskListProjectionMap);
			qb.appendWhere(TaskHistoryTableMetaData.ID + "=" + uri.getPathSegments().get(1));
			break;
		default: throw new IllegalArgumentException("Uknown URI " + uri);
		}
		
		String orderBy;
		if (TextUtils.isEmpty(sortOrder)){
			orderBy = TaskHistoryTableMetaData.DEFAULT_SORT_ORDER;
		}
		else orderBy = sortOrder;
		
		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
		Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, orderBy);		
		
		c.setNotificationUri(getContext().getContentResolver(), uri);		

		return c;
	}

	@Override
	public int update(Uri uri, ContentValues values, String where, String[] whereArgs){
		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
		int count;
		
		switch(sUriMatcher.match(uri)){
		case INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR:
			count = db.update(TaskHistoryTableMetaData.TABLE_NAME, values, where, whereArgs); 
			break;
			
		case INCOMING_SINGLE_TASK_LIST_URI_INDICATOR: String rowId = uri.getPathSegments().get(1);
			count = db.update(TaskHistoryTableMetaData.TABLE_NAME, values, TaskHistoryTableMetaData._ID
					+ "=" + rowId
					+ (!TextUtils.isEmpty(where)? " AND (" + where +")" : ""), whereArgs);
			break;
			
		default: throw new IllegalArgumentException("Unknown URI " + uri);
		}
		
		getContext().getContentResolver().notifyChange(uri, null);
		
		return count;
	}
	
	public void deleteAllData(){
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		db.execSQL("DROP TABLE IF EXISTS " + TaskHistoryTableMetaData.TABLE_NAME);
	}
	
	public void reCreatedb(){
		onCreate();
	}
}
