package com.strawberriesandcream.courierclient.provider;

import java.sql.SQLException;
import java.util.HashMap;

import com.strawberriesandcream.courierclient.provider.TaskProviderMetaData.TaskListTableMetaData;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

public class TaskListProvider extends ContentProvider{
	// Create a Projection Map for Columns
	
	private static HashMap<String, String> sTaskListProjectionMap;
	static{
		sTaskListProjectionMap = new HashMap<String, String>();
		sTaskListProjectionMap.put(TaskListTableMetaData._ID, TaskListTableMetaData._ID);
		
		sTaskListProjectionMap.put(TaskListTableMetaData.ADDRESS, TaskListTableMetaData.ADDRESS);
		sTaskListProjectionMap.put(TaskListTableMetaData.COMMENTS, TaskListTableMetaData.COMMENTS);
		sTaskListProjectionMap.put(TaskListTableMetaData.CONTACT_NO, TaskListTableMetaData.CONTACT_NO);
		sTaskListProjectionMap.put(TaskListTableMetaData.DESCRIPTION, TaskListTableMetaData.DESCRIPTION);
		sTaskListProjectionMap.put(TaskListTableMetaData.LATITUDE, TaskListTableMetaData.LATITUDE);
		sTaskListProjectionMap.put(TaskListTableMetaData.LONGITUDE, TaskListTableMetaData.LONGITUDE);
		sTaskListProjectionMap.put(TaskListTableMetaData.NAME, TaskListTableMetaData.NAME);
		sTaskListProjectionMap.put(TaskListTableMetaData.STATUS, TaskListTableMetaData.STATUS);
		sTaskListProjectionMap.put(TaskListTableMetaData.ID, TaskListTableMetaData.ID);
		sTaskListProjectionMap.put(TaskListTableMetaData.TIME, TaskListTableMetaData.TIME);
		sTaskListProjectionMap.put(TaskListTableMetaData.EXTRA, TaskListTableMetaData.EXTRA);
		
		// created, modified, data
		sTaskListProjectionMap.put(TaskListTableMetaData.CREATED_DATE, TaskListTableMetaData.CREATED_DATE);
		sTaskListProjectionMap.put(TaskListTableMetaData.MODIFIED_DATE, TaskListTableMetaData.MODIFIED_DATE);
	}
	
	private static final UriMatcher sUriMatcher;
	private static final int INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR = 1;
	private static final int INCOMING_SINGLE_TASK_LIST_URI_INDICATOR = 2;
	
	static{
		sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		
		sUriMatcher.addURI(
				TaskProviderMetaData.AUTHORITY, 
				TaskListTableMetaData.TABLE_NAME, 
				INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR
		);
		
		sUriMatcher.addURI(
				TaskProviderMetaData.AUTHORITY, 
				TaskListTableMetaData.TABLE_NAME + "/#", 
				INCOMING_SINGLE_TASK_LIST_URI_INDICATOR
		);
	}

	@Override
	public int delete(Uri uri, String where, String[] whereArgs){
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		int count;
		switch(sUriMatcher.match(uri)){
		case INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR:
			count = db.delete(TaskListTableMetaData.TABLE_NAME, where, whereArgs);
			break;
			
		case INCOMING_SINGLE_TASK_LIST_URI_INDICATOR:
			String rowId = uri.getPathSegments().get(1);
			count = db.delete(TaskListTableMetaData.TABLE_NAME,
					TaskListTableMetaData._ID + "=" + rowId +
					(!TextUtils.isEmpty(where) ? " AND (" + where + ")" : "" ), whereArgs);
			break;
		
		default:
			throw new IllegalArgumentException("Unknow URI " + uri);
		}
		
		getContext().getContentResolver().notifyChange(uri, null);
		
		return count;
	}

	@Override
	public String getType(Uri uri){
		switch(sUriMatcher.match(uri)){
		case INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR:
			return TaskListTableMetaData.CONTENT_TYPE;		
		case INCOMING_SINGLE_TASK_LIST_URI_INDICATOR:
			return TaskListTableMetaData.CONTENT_ITEM_TYPE;
		default:
			throw new IllegalArgumentException("Unknow URI " + uri);
		}
	}

	@Override
	public Uri insert(Uri uri, ContentValues values){
		System.out.println("inside insert");
		
		if (sUriMatcher.match(uri) != INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR){
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
		
		Long now = Long.valueOf(System.currentTimeMillis());
		
		
		if (values.containsKey(TaskListTableMetaData.CREATED_DATE) == false){
			values.put(TaskListTableMetaData.CREATED_DATE, now);
		}
		
		if (values.containsKey(TaskListTableMetaData.MODIFIED_DATE) == false){
			values.put(TaskListTableMetaData.MODIFIED_DATE, now);
		}
		
		if (values.containsKey(TaskListTableMetaData.ADDRESS) == false){
			try {
				throw new SQLException("Failed to insert row because 'address' is needed " + uri);
			} catch (SQLException e){}
		}
		
		if (values.containsKey(TaskListTableMetaData.COMMENTS) == false){
			values.put(TaskListTableMetaData.COMMENTS, TaskListTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskListTableMetaData.CONTACT_NO)== false){
			values.put(TaskListTableMetaData.CONTACT_NO, TaskListTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskListTableMetaData.DESCRIPTION)== false){
			values.put(TaskListTableMetaData.DESCRIPTION, TaskListTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskListTableMetaData.LATITUDE)== false){			
			try {
				throw new SQLException("Failed to insert row because 'latitude' is needed " + uri);
			} catch (SQLException e) {}		
		}
		
		if (values.containsKey(TaskListTableMetaData.LONGITUDE) == false){			
			try {
				throw new SQLException("Failed to insert row because 'longitude' is needed " + uri);
			} catch (SQLException e) {}			
		}
		
		if (values.containsKey(TaskListTableMetaData.NAME)== false){
			values.put(TaskListTableMetaData.NAME, TaskListTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskListTableMetaData.ID) == false){
			try {
				throw new SQLException("Failed to insert row because 'task_id' is needed " + uri);
			} catch (SQLException e) {}
		}
		
		if (values.containsKey(TaskListTableMetaData.TIME) == false){
			try {
				throw new SQLException("Failed to insert row because 'duedate' is needed " + uri);
			} catch (SQLException e) {}
		}
		
		if (values.containsKey(TaskListTableMetaData.TIME) == false){
			values.put(TaskListTableMetaData.TIME, TaskListTableMetaData.NOT_AVAILABLE);
		}
		
		if (values.containsKey(TaskListTableMetaData.EXTRA) == false){
			values.put(TaskListTableMetaData.EXTRA, TaskListTableMetaData.NOT_AVAILABLE);
		}
		
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		long rowId = db.insert(TaskListTableMetaData.TABLE_NAME, TaskListTableMetaData.ID, values);
		
		System.out.println("we are nearly done inserting!");
		
		if (rowId > 0){
			Uri insertedTaskUri = ContentUris.withAppendedId(TaskListTableMetaData.CONTENT_URI, rowId);
			getContext().getContentResolver().notifyChange(insertedTaskUri, null);
			return insertedTaskUri;
		}
		
		try {
			throw new SQLException("Failed to insert row into " + uri);
		} catch (SQLException e){}
		
		return null;
	}
	
	private DatabaseHelper mOpenHelper;

	@Override
	public boolean onCreate(){
		mOpenHelper = new DatabaseHelper(getContext());
		return true;
	}
	
	private static class DatabaseHelper extends SQLiteOpenHelper{
		DatabaseHelper(Context context){			
			super(context, TaskProviderMetaData.DATABASE_NAME, null, TaskProviderMetaData.DATABASE_VERSION);
		}
		
		@Override
		public void onCreate(SQLiteDatabase db){
			System.out.println("Creating database");
			
			db.execSQL
			("CREATE TABLE " + TaskListTableMetaData.TABLE_NAME 
				+ " ("					
					+ TaskListTableMetaData._ID + " INTEGER AUTO INCREMENT,"
					+ TaskListTableMetaData.ADDRESS + " TEXT,"
					+ TaskListTableMetaData.COMMENTS + " TEXT,"
					+ TaskListTableMetaData.CONTACT_NO + " TEXT,"
					+ TaskListTableMetaData.DESCRIPTION + " TEXT,"
					+ TaskListTableMetaData.LATITUDE + " TEXT,"
					+ TaskListTableMetaData.LONGITUDE + " TEXT,"
					+ TaskListTableMetaData.NAME + " TEXT,"
					+ TaskListTableMetaData.STATUS + " TEXT,"
					+ TaskListTableMetaData.ID + " INTEGER PRIMARY KEY,"
					+ TaskListTableMetaData.CREATED_DATE + " INTEGER,"
					+ TaskListTableMetaData.MODIFIED_DATE + " INTEGER,"
					+ TaskListTableMetaData.TIME + " TEXT,"
					+ TaskListTableMetaData.EXTRA + " TEXT"
				+ ");"
			);
			
			System.out.println("Finished creating database!");
		}
		
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
			Log.w("TAG", "Upgrading database from version " + oldVersion + " to " + newVersion
					+ ", which will destroy all old data!");
			db.execSQL("DROP TABLE IF EXISTS " + TaskListTableMetaData.TABLE_NAME);
			onCreate(db);
		}
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder){
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		switch(sUriMatcher.match(uri)){
		case INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR:
			qb.setTables(TaskListTableMetaData.TABLE_NAME);
			qb.setProjectionMap(sTaskListProjectionMap);
			break;
		case INCOMING_SINGLE_TASK_LIST_URI_INDICATOR:
			qb.setTables(TaskListTableMetaData.TABLE_NAME);
			qb.setProjectionMap(sTaskListProjectionMap);
			qb.appendWhere(TaskListTableMetaData.ID + "=" + uri.getPathSegments().get(1));
			break;
		default: throw new IllegalArgumentException("Uknown URI " + uri);
		}
		
		String orderBy;
		if (TextUtils.isEmpty(sortOrder)){
			orderBy = TaskListTableMetaData.DEFAULT_SORT_ORDER;
		}
		else orderBy = sortOrder;
		
		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
		Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, orderBy);		
		
		c.setNotificationUri(getContext().getContentResolver(), uri);		

		return c;
	}

	@Override
	public int update(Uri uri, ContentValues values, String where, String[] whereArgs){
		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
		int count;
		
		switch(sUriMatcher.match(uri)){
		case INCOMING_TASK_LIST_COLLECTION_URI_INDICATOR:
			count = db.update(TaskListTableMetaData.TABLE_NAME, values, where, whereArgs); 
			break;
			
		case INCOMING_SINGLE_TASK_LIST_URI_INDICATOR: String rowId = uri.getPathSegments().get(1);
			count = db.update(TaskListTableMetaData.TABLE_NAME, values, TaskListTableMetaData._ID
					+ "=" + rowId
					+ (!TextUtils.isEmpty(where)? " AND (" + where +")" : ""), whereArgs);
			break;
			
		default: throw new IllegalArgumentException("Unknown URI " + uri);
		}
		
		getContext().getContentResolver().notifyChange(uri, null);
		
		return count;
	}
	
	public void deleteAllData(){
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		db.execSQL("DROP TABLE IF EXISTS " + TaskListTableMetaData.TABLE_NAME);
	}
	
	public void reCreatedb(){
		onCreate();
	}
}
