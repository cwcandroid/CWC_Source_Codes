package com.strawberriesandcream.courierclient.provider;

import java.util.HashMap;
import java.util.Map;

import android.net.Uri;
import android.provider.BaseColumns;

public class TaskProviderMetaData {
	public static final String AUTHORITY = "com.strawberriesandcream.courierclient.provider.TaskProvider";
	
	public static final String DATABASE_NAME = "task.db";
	public static final int DATABASE_VERSION = 2;
	
	public static final String TASK_LIST_TABLE_NAME = "tasklist";	
	
	
	// inner class describing the TasksTable
	
	public static final class TaskListTableMetaData implements BaseColumns{
		private TaskListTableMetaData() {}
		public static final String TABLE_NAME = "tasklist";
		
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/" + TABLE_NAME);

		// MIME type definitions
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.cwccourierclient.task";
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.cwccourierclient.task";
		
		public static final String DEFAULT_SORT_ORDER = "task_id ASC";		
		// columns
		
		public static final String ADDRESS = "address";			// String type
		public static final String ID = "task_id";				// int type
		public static final String COMMENTS = "comments";		// String type
		public static final String CONTACT_NO = "contactno";	// String type
		public static final String DESCRIPTION = "description";	// String type
		public static final String LATITUDE = "latitude";		// String type: later converted to float
		public static final String LONGITUDE = "longitude";		// String type: later converted to float
		public static final String NAME = "name";				// String type
		public static final String STATUS = "status";			// int type
		public static final String TIME = "duetime";			// Time type
		public static final String EXTRA = "extra";				// String type
		
		public static final String NOT_AVAILABLE = "N/A";
		
		public static final Map<Integer, String> EXPECTED_KEYS_TASK_LIST = new HashMap<Integer, String>();
		static {
			EXPECTED_KEYS_TASK_LIST.put(ADDRESS.hashCode(), ADDRESS);
			EXPECTED_KEYS_TASK_LIST.put(ID.hashCode(), ID);
			EXPECTED_KEYS_TASK_LIST.put(COMMENTS.hashCode(), COMMENTS);
			EXPECTED_KEYS_TASK_LIST.put(CONTACT_NO.hashCode(), CONTACT_NO);
			EXPECTED_KEYS_TASK_LIST.put(DESCRIPTION.hashCode(), DESCRIPTION);
			EXPECTED_KEYS_TASK_LIST.put(LATITUDE.hashCode(), LATITUDE);
			EXPECTED_KEYS_TASK_LIST.put(LONGITUDE.hashCode(), LONGITUDE);
			EXPECTED_KEYS_TASK_LIST.put(NAME.hashCode(), NAME);
			EXPECTED_KEYS_TASK_LIST.put(STATUS.hashCode(), STATUS);
			EXPECTED_KEYS_TASK_LIST.put(TIME.hashCode(), TIME);
		}
		
		
		/* For internal house-keeping: WILL NOT BE USED IN THIS VERSION  */
		
		public static final String CREATED_DATE = "created";	// Integer type from System.currentTimeMillis()
		public static final String MODIFIED_DATE = "modified";	// Integer type from System.currentTimemillis()
	}
	
	
	public static final String TASK_HISTORY_TABLE_NAME = "taskhistory";	

	
	public static final class TaskHistoryTableMetaData implements BaseColumns{
		private TaskHistoryTableMetaData() {}
		public static final String TABLE_NAME = "taskhistory";
		
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/" + TABLE_NAME);

		// MIME type definitions
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.cwccourierclient.task";
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.cwccourierclient.task";
		
		public static final String DEFAULT_SORT_ORDER = "task_id ASC";		
		// columns
		
		public static final String ADDRESS = "address";			// String type
		public static final String ID = "task_id";				// int type
		public static final String COMMENTS = "comments";		// String type
		public static final String CONTACT_NO = "contactno";	// String type
		public static final String DESCRIPTION = "description";	// String type
		public static final String LATITUDE = "latitude";		// String type: later converted to float
		public static final String LONGITUDE = "longitude";		// String type: later converted to float
		public static final String NAME = "name";				// String type
		public static final String STATUS = "status";			// int type
		public static final String EXTRA = "extra";				// String type
		public static final String DUE_TIME = "duetime";
		public static final String DUE_DATE = "duedate";
		public static final String SIGNATURE_FILE = "signaturefile";
		public static final String REASON_TYPE = "reasontype";
		public static final String REASON_DETAILS = "reasondetails";
		public static final String REPORT_LATITUDE = "reportlatitude";
		public static final String REPORT_LONGITUDE = "reportlongitude";
		
		public static final String NOT_AVAILABLE = "N/A";
		
		public static final Map<Integer, String> EXPECTED_KEYS_TASK_LIST = new HashMap<Integer, String>();
		static {
			EXPECTED_KEYS_TASK_LIST.put(ADDRESS.hashCode(), ADDRESS);
			EXPECTED_KEYS_TASK_LIST.put(ID.hashCode(), ID);
			EXPECTED_KEYS_TASK_LIST.put(COMMENTS.hashCode(), COMMENTS);
			EXPECTED_KEYS_TASK_LIST.put(CONTACT_NO.hashCode(), CONTACT_NO);
			EXPECTED_KEYS_TASK_LIST.put(DESCRIPTION.hashCode(), DESCRIPTION);
			EXPECTED_KEYS_TASK_LIST.put(LATITUDE.hashCode(), LATITUDE);
			EXPECTED_KEYS_TASK_LIST.put(LONGITUDE.hashCode(), LONGITUDE);
			EXPECTED_KEYS_TASK_LIST.put(NAME.hashCode(), NAME);
			EXPECTED_KEYS_TASK_LIST.put(STATUS.hashCode(), STATUS);
			EXPECTED_KEYS_TASK_LIST.put(DUE_TIME.hashCode(), DUE_TIME);
			EXPECTED_KEYS_TASK_LIST.put(DUE_DATE.hashCode(), DUE_DATE);
			EXPECTED_KEYS_TASK_LIST.put(REPORT_LATITUDE.hashCode(), REPORT_LATITUDE);
			EXPECTED_KEYS_TASK_LIST.put(REPORT_LONGITUDE.hashCode(), REPORT_LONGITUDE);
			EXPECTED_KEYS_TASK_LIST.put(REASON_DETAILS.hashCode(), REASON_DETAILS);
			EXPECTED_KEYS_TASK_LIST.put(REASON_TYPE.hashCode(), REASON_TYPE);
			EXPECTED_KEYS_TASK_LIST.put(SIGNATURE_FILE.hashCode(), SIGNATURE_FILE);
			
		}
		
		
		/* For internal house-keeping: WILL NOT BE USED IN THIS VERSION  */
		
		public static final String CREATED_DATE = "created";	// Integer type from System.currentTimeMillis()
		public static final String MODIFIED_DATE = "modified";	// Integer type from System.currentTimemillis()
	}
	
	


}
