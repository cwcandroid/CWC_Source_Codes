package com.strawberriesandcream.courierclient;

import java.io.IOException;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.strawberriesandcream.courierclient.network.CWCCourierNetworkAPI;
import com.strawberriesandcream.courierclient.util.Alert;
import com.strawberriesandcream.courierclient.util.Constants;
import com.strawberriesandcream.courierclient.util.SimpleCrypto;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class CWCCourierClientRegistrationActivity extends Activity{
	private ProgressDialog pd;
	private String errorMessage = null;
	
	private EditText usernameEdit;
	private EditText emailEdit;
	private EditText passwordEdit;
	private EditText passwordConfirmEdit;
	
	private String username, email, password;
	
	boolean ok = false;
	boolean networkError = false;
	
	private JSONObject status;
	
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		
		usernameEdit = (EditText)findViewById(R.id.register_username_edit);
		emailEdit= (EditText)findViewById(R.id.register_email_edit);
		passwordEdit = (EditText)findViewById(R.id.register_password_edit);
		passwordConfirmEdit=(EditText)findViewById(R.id.register_confirm_password_edit);
		
		setResult(Constants.DUMMY);
		setupButtonListeners();
	}
	
	private void setupButtonListeners(){
		Button backButton = (Button)findViewById(R.id.register_button_back);
		backButton.setOnClickListener(new OnClickListener(){			
			public void onClick(View v){
				finish();
			}
		});
		
		Button registerButton = (Button)findViewById(R.id.register_button_register);
		registerButton.setOnClickListener(new OnClickListener(){			
			public void onClick(View v){
				if (!validData()){
					Alert.showAlert(
							getString(R.string.error_alert_title_invalid_input), 
							errorMessage,
							CWCCourierClientRegistrationActivity.this
					);
					return;
				}
				
				register();
			}
		});
	}	
	
	private boolean validData(){
		username = usernameEdit.getText().toString();		
		java.util.regex.Pattern usernamePattern = Pattern.compile("^[a-z0-9]{6,32}$");				
		java.util.regex.Matcher usernameMatcher = usernamePattern.matcher(username);
		
		password = passwordEdit.getText().toString();		
		java.util.regex.Pattern passwordPattern = Pattern.compile("^[a-zA-Z0-9]{6,32}$");
		java.util.regex.Matcher passwordMatcher = passwordPattern.matcher(password);
		
		String confirmPassword = passwordConfirmEdit.getText().toString();
		email = emailEdit.getText().toString();
		
		if (!usernameMatcher.matches()){
			errorMessage = getString(R.string.register_invalid_username);
			return false;
		}
		else if (email.indexOf('@') == -1){
			errorMessage = getString(R.string.register_invalid_email);
			return false;
		}
		else if (!passwordMatcher.matches()){
			errorMessage = getString(R.string.register_invalid_password);
			return false;
		}		
		else if (passwordMatcher.matches() && !password.equals(confirmPassword)){
			errorMessage = getString(R.string.register_invalid_confirm_password);
			return false;
		}		
		return true;
	}
	
	private void register(){
		pd = ProgressDialog.show(this, null, getString(R.string.register_spinning_wheel));
		new Thread(runnable).start();
	}
	
	private Runnable runnable = new Runnable(){
		public void run() {
			try {
				String regStatus = CWCCourierNetworkAPI.registerUser(username, email, password, Constants.RETURN_TYPE_JSON);
				JSONArray jsonArray = new JSONArray("[" + regStatus +"]");
				status = jsonArray.getJSONObject(0);
				
				String returnValue = status.getString(Constants.JSON_CONSTANTS.STATUS);
				if (returnValue.equalsIgnoreCase(Constants.JSON_CONSTANTS.SUCCESS)){
					ok = true;					
				}
				else ok = false;
				networkError = false;
			} 
			catch (IOException e) { networkError = true; } 
			catch (JSONException e) { ok = false; }
			
			handler.sendEmptyMessage(0);
		}
	};
	
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			pd.dismiss();
			
			if (networkError){
				Alert.showAlert(
						getString(R.string.network_error_title),
						getString(R.string.network_error_msg),
						CWCCourierClientRegistrationActivity.this);
				return;
			}
			
			if (!ok){
				try {
					Alert.showAlert(
							getString(R.string.login_error_title),
							status.getString(Constants.JSON_CONSTANTS.TEXT),
							CWCCourierClientRegistrationActivity.this);
				} 
				catch (JSONException e) {}
				return;
			}
			
			SharedPreferences settings = getSharedPreferences(Constants.PREF, Context.MODE_PRIVATE);			
			Editor editor = settings.edit();
		
			editor.putString(Constants.USERNAME, username);
			try {
				editor.putString(Constants.PASSWORD, SimpleCrypto.encrypt(Constants.SEED, password));
				System.out.println("Saving username and password");
			} 
			catch (Exception e) {}
			
			editor.commit();			
			
			setResult(Constants.FINISH);
			Intent intent = new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientMainScreenActivity.class);
			startActivity(intent);
			CWCCourierClientRegistrationActivity.this.finish();
		}
	};
}
