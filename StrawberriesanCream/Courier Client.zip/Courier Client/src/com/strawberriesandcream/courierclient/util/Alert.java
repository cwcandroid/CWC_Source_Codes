package com.strawberriesandcream.courierclient.util;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class Alert{
	public static void showAlert(String title, String message, Context ctx){
		AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
		builder.setTitle(title);
		builder.setMessage(message);		
		
		builder.setPositiveButton("Ok",
				new DialogInterface.OnClickListener(){								// Empty Listener
					public void onClick(DialogInterface dialog, int which) { }
				}
		);
		
		AlertDialog ad = builder.create();
		ad.show();
	}	
}