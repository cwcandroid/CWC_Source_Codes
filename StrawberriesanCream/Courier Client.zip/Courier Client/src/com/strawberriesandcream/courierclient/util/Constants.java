package com.strawberriesandcream.courierclient.util;

public class Constants{
	/* user-preference management constants */
	
	public final static String PREF = "strawberries";
	public static final String PASSWORD = "secret";
	public static final String SEED = "cream";
	public static final String DEFAULT_STRING = "prestige";
	public static final String USERNAME = "username";
	public static final String PREF_STORED = "prefstored";
	
	/* Network: URL Constants */
	
	public static final String RETURN_TYPE_JSON = "json";
	public static final String RETURN_TYPE_XML = "xml";
	public static final String LOGIN_URL = "http://192.168.1.2/cwc/index.php/android/login";
	public static final String USER_REGISTER_URL = "http://192.168.1.2/cwc/index.php/android/register";
	public static final String GET_TASK_LIST_URL = "http://192.168.1.2/cwc/index.php/android/getTaskList";
	public static final String REPORT_SPECIFIC_TASK_URL = "http://192.168.1.2/cwc/index.php/android/reportSpecificTask";
	public static final String GET_TASK_HISTORY_URL = "http://192.168.1.2/cwc/index.php/android/getTaskHistory";
	
	public static final class JSON_CONSTANTS{
		public static final String STATUS = "status";
		public static final String FALSE = "false";
		public static final String TRUE = "true";
		public static final String SUCCESS = "Success";
		public static final String FAILURE = "Failure";
		
		public static final String[] TASK_LIST = new String[] {
			"address",
			"comments",
			"contactno",
			"description",
			"latitude",
			"longitude",
			"name",
			"status"
		};
		
		public static final String TEXT = "text";
		
	}
	
	/* Unsorted constants */
	public static final int FINISH = 0;
	public static final int DUMMY = 5;
	public static final long SPLASH_SCREEN_WAIT_TIME = 1;
}
