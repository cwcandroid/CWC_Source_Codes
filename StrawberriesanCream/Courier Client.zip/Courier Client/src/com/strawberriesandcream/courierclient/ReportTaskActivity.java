package com.strawberriesandcream.courierclient;

import java.io.File;
import java.io.IOException;

import com.strawberriesandcream.courierclient.network.CWCCourierNetworkAPI;
import com.strawberriesandcream.courierclient.provider.TaskProviderMetaData.TaskListTableMetaData;
import com.strawberriesandcream.courierclient.util.Alert;
import com.strawberriesandcream.courierclient.util.Constants;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class ReportTaskActivity extends Activity{
	private ProgressDialog pd;
	
	private Button submit;
	private String username;
	private String taskid;
	private String reasonType = "";
	private String reasonDetails = "";
	private String reportlatitude = "";
	private String reportlongitude;
	
	private Uri outputFileUri;
	
	private static int TAKE_PICTURE = 3;
	
	boolean fine = true;
	boolean readyToGo = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.report);
		
		Bundle extras = getIntent().getExtras();
		
		username = extras.getString(Constants.USERNAME);
		taskid = extras.getString(TaskListTableMetaData.ID);
		
				
		final Button button = (Button)findViewById(R.id.signature);
		
		RadioGroup rg = (RadioGroup)findViewById(R.id.report_radio_group);
		
		int index = rg.indexOfChild(findViewById(rg.getCheckedRadioButtonId()));
		rg.setOnCheckedChangeListener(new OnCheckedChangeListener(){			
			public void onCheckedChanged(RadioGroup rg, int index){
				System.out.println("Clicked at index: " + index);
				if (index == R.id.report_status_1){
					button.setEnabled(true);
				}
				else button.setEnabled(false);
			}
		});
		
		
		reasonType = "" + index;
		
		EditText et = (EditText)findViewById(R.id.report_reason_details);
		if (et.getText() != null)
			reasonDetails = et.getText().toString();
		else reasonDetails = "None provided!";
		
		/* Doesn't always work! Needs improvement */
		
		
		System.out.println("Location Manager");
		
		LocationManager locManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		
		System.out.println("We are done getting location manager");
		
		Location location = locManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		if (location != null){
			reportlatitude = Double.toString(location.getLatitude());
			reportlongitude = Double.toString(location.getLongitude());
		}
		else reportlatitude=reportlongitude="5.5";
				
		button.setOnClickListener(new OnClickListener(){			
			public void onClick(View v){
				TakeImage();				
			}
		});		
		
	    submit = (Button)findViewById(R.id.submit_button);
		Button cancel = (Button)findViewById(R.id.cancelButton);
		
		submit.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0) {
				new Thread(runnable).start();
			}			
		});
		
		cancel.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View view){
				finish();
			}
		});
	}
	
	private void TakeImage(){		
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
      
        outputFileUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);        
        
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
        startActivityForResult(intent, TAKE_PICTURE);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == TAKE_PICTURE && resultCode == RESULT_OK){
			submit.setEnabled(true);
		}
	}
	
	private String getImagePath(Uri contentUri) {
		String[] proj = { MediaStore.Images.Media.DATA };
		Cursor cursor = managedQuery(contentUri, proj, null, null, null);
		int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
		cursor.moveToFirst();
		return cursor.getString(column_index);
	}
	
	private Runnable runnable = new Runnable(){
		public void run() {
			pd = ProgressDialog.show(ReportTaskActivity.this, null, "Sending task report to server, Please wait!");
			postReport();
			handler.sendEmptyMessage(0);
		}
	};
	
	private void postReport(){
		String filePath = getImagePath(outputFileUri);
		
		File file = new File(filePath);
		
		try {
			System.out.println("REPORTED: " + CWCCourierNetworkAPI.reportSpecificTask(username, taskid, reasonType,
																					reasonDetails, reportlatitude, reportlongitude, 
																					file, Constants.RETURN_TYPE_JSON));
		} catch (IOException e) {
			fine = false;
		}
	}
	
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			pd.dismiss();
			if (!fine){
				Alert.showAlert("Error", "Failed to send report to server", ReportTaskActivity.this);
			}
			else{
				Alert.showAlert("Success", "Successfully reported to server", ReportTaskActivity.this);
				ReportTaskActivity.this.finish();
			}
		}
	};
	
}
