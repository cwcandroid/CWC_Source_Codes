package com.strawberriesandcream.courierclient;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.strawberriesandcream.courierclient.network.CWCCourierNetworkAPI;
import com.strawberriesandcream.courierclient.util.Alert;
import com.strawberriesandcream.courierclient.util.Constants;
import com.strawberriesandcream.courierclient.util.SimpleCrypto;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class CWCCourierClientLoginActivity extends Activity{
	private ProgressDialog pd;
	
	private String username = null;
	private String password = null;
	
	private EditText usernameEdit;
	private EditText passwordEdit;
	
	private boolean ok = false;
	private boolean networkError = false;
	
	private static final short REQUEST_CODE = 512;
	
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);		
		
		usernameEdit = (EditText)findViewById(R.id.login_username_edit);
		passwordEdit = (EditText)findViewById(R.id.login_password_edit);
		
		if (getUsernameAndPasswordFromPref()){
			usernameEdit.setText(username);
			passwordEdit.setText(password);
		}
		
		setupButtonListeners();
	}
	
	private boolean getUsernameAndPasswordFromPref(){
		Bundle extras = getIntent().getExtras();
		if (extras.getBoolean(Constants.PREF_STORED)){
			System.out.println("YES");
			username = extras.getString(Constants.USERNAME);
			try {
				password = extras.getString(Constants.PASSWORD);			
				System.out.println("FOUND: " + password + " and " + username);
				return true;
			}
			catch (Exception e) {
				System.out.println("Exception: " + e);
				return false; 
			}
		}
		else System.out.println("NO");
		return false;
	}
	
	private void getUsernameAndPasswordFromEdits(){
		username = usernameEdit.getText().toString();
		password = passwordEdit.getText().toString();
	}
	
	private void setupButtonListeners(){
		Button loginButton = (Button)findViewById(R.id.login_button_login);
		loginButton.setOnClickListener(new OnClickListener() {			
			public void onClick(View view){
				getUsernameAndPasswordFromEdits();
				
				if (!vaildUsername()){
					Alert.showAlert(
							getString(R.string.error_alert_title_invalid_input),
							getString(R.string.error_invalid_input_username_msg),
							CWCCourierClientLoginActivity.this
					);
					return;
				}			
				
				if (!validPassword()){
					Alert.showAlert(
							getString(R.string.error_alert_title_invalid_input),
							getString(R.string.error_invalid_input_password_msg),
							CWCCourierClientLoginActivity.this
					);
					return;
				}
				
				login();
			}
		});
		
		
		Button registerButton = (Button)findViewById(R.id.login_button_register);
		registerButton.setOnClickListener(new OnClickListener(){			
			public void onClick(View view){
				Intent intent = new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientRegistrationActivity.class);
				startActivity(intent);
			}
		});
	}
	
	private void login(){
		pd = ProgressDialog.show(this, null, getString(R.string.login_spinning_wheel));
		new Thread(runnable).start();
	}
	
	private boolean vaildUsername(){
		return !(username==null || username.length() == 0);
	}
	
	private boolean validPassword(){
		return !(password == null || password.length() == 0);
	}
	
	
	private Runnable runnable = new Runnable(){		
		public void run() {
			try {
				String loginStatus = CWCCourierNetworkAPI.loginUser(username, password, Constants.RETURN_TYPE_JSON);
				JSONArray jsonArray = new JSONArray("[" + loginStatus +"]");
				JSONObject status = jsonArray.getJSONObject(0);
				
				String returnValue = status.getString(Constants.JSON_CONSTANTS.STATUS);
				if (returnValue.equalsIgnoreCase(Constants.JSON_CONSTANTS.TRUE)){
					ok = true;					
				}
				else ok = false;
				networkError = false;
			} 
			catch (IOException e) { networkError = true; } 
			catch (JSONException e) { ok = false; }
			
			handler.sendEmptyMessage(0);
		}
	};
	
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			pd.dismiss();
			
			if (networkError){
				Alert.showAlert(
						getString(R.string.network_error_title),
						getString(R.string.network_error_msg),
						CWCCourierClientLoginActivity.this);
				return;
			}
			
			if (!ok){
				Alert.showAlert(
						getString(R.string.login_error_title),
						getString(R.string.login_error_msg),
						CWCCourierClientLoginActivity.this);
				return;
			}
			
			CheckBox cb = (CheckBox)findViewById(R.id.login_checkbox);
			
			SharedPreferences settings = getSharedPreferences(Constants.PREF, Context.MODE_PRIVATE);			
			Editor editor = settings.edit();		
						
			
			if (cb.isChecked()){
				editor.putString(Constants.USERNAME, username);
				try {
					editor.putString(Constants.PASSWORD, SimpleCrypto.encrypt(Constants.SEED, password));
					System.out.println("Saving username and password");
				} 
				catch (Exception e) {}								
			}
			else{
				System.out.println("Earsing username and password from shared preferences!");
				editor.clear();				
			}
			
			editor.commit();
			
			Intent intent = new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientMainScreenActivity.class);
			intent.putExtra(Constants.USERNAME, username);
			startActivityForResult(intent, REQUEST_CODE);
			CWCCourierClientLoginActivity.this.finish();
		}
	};
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		System.out.println("reuquestCode: " + requestCode + " resultCode: " + resultCode);
		if (requestCode == REQUEST_CODE){
			if (resultCode == Constants.FINISH){
				System.out.println("Finishing up!");
				Intent intent = new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientMainScreenActivity.class);
				startActivity(intent);
				finish();
			}
		}
	}
}


























