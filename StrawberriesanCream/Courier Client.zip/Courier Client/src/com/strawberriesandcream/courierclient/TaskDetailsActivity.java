package com.strawberriesandcream.courierclient;

import com.strawberriesandcream.courierclient.provider.TaskProviderMetaData.TaskListTableMetaData;
import com.strawberriesandcream.courierclient.util.Constants;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class TaskDetailsActivity extends Activity{
	private static final int REQUEST_CODE = 555;
	private String TASK_ID;
	private TextView itemName;
	private TextView itemId;
	private TextView itemDesc;
	private TextView itemReceiverAddress;
	
	private Button itemReceiverNumber;
	private Button reportTask;
	private Button viewOnMap;
	private Button info;
	
	private String username;
	
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.task_detail);
			

		
		System.out.println("TaskDetailsActivity started!");
		
		Bundle extras = getIntent().getExtras();
		TASK_ID = extras.getString(TaskListTableMetaData.ID);
		username = extras.getString(Constants.USERNAME);
		
		setUpView();
		populateViewsWithData();
		setupListeners();
	}
	
	private void setUpView(){
		itemName = (TextView)findViewById(R.id.task_item_name);
		itemId = (TextView)findViewById(R.id.task_item_id);
		itemDesc = (TextView)findViewById(R.id.task_item_receiver_name);
		itemReceiverAddress = (TextView)findViewById(R.id.task_item_receiver_address);
		
		itemReceiverNumber = (Button)findViewById(R.id.task_receiver_phone_number);
		reportTask = (Button)findViewById(R.id.task_report);
		viewOnMap = (Button)findViewById(R.id.task_view_on_map);
		info = (Button)findViewById(R.id.task_info);
		info.setEnabled(false);
	}
	
	private void populateViewsWithData(){
		String[] projection = new String[]{
			TaskListTableMetaData.NAME,
			TaskListTableMetaData.DESCRIPTION,
			TaskListTableMetaData.ADDRESS,
			TaskListTableMetaData.CONTACT_NO
		};
		
		
		Uri uri = ContentUris.withAppendedId(TaskListTableMetaData.CONTENT_URI, Long.parseLong(TASK_ID));
		
		System.out.println("URI: " + uri.toString());
		
		Cursor cur = managedQuery(uri, null, null, null, null);
		if (cur.moveToFirst() == false){
			finish();
		}
		else System.out.println("Cursor has data: " + cur.getColumnCount());
		
		int nameI = cur.getColumnIndex(TaskListTableMetaData.NAME);
		itemName.setText("Item Name: " + cur.getString(nameI));
		
		itemId.setText("Item Id: " + "N/A");
		
		int descI = cur.getColumnIndex(TaskListTableMetaData.DESCRIPTION);
		itemDesc.setText("Description: " + cur.getString(descI));
		
		int addressI = cur.getColumnIndex(TaskListTableMetaData.ADDRESS);
		itemReceiverAddress.setText("Address: " + cur.getString(addressI));
		
		int contactI = cur.getColumnIndex(TaskListTableMetaData.CONTACT_NO);
		final String number = cur.getString(contactI);
		itemReceiverNumber.setText(number);
		
		itemReceiverNumber.setOnClickListener(new OnClickListener() {			
			public void onClick(View v){
				Intent intent = new Intent(Intent.ACTION_CALL);
				intent.setData(Uri.parse("tel:" + number));
				startActivity(intent);
			}
		});
	}
	
	void setupListeners(){
		reportTask.setOnClickListener(new OnClickListener(){			
			public void onClick(View v){
				System.out.println("Will start ReporTaskActivity now");
				Intent intent = new Intent(TaskDetailsActivity.this, ReportTaskActivity.class);
				intent.putExtra(Constants.USERNAME, username);
				intent.putExtra(TaskListTableMetaData.ID, TASK_ID);
				
				startActivityForResult(intent, REQUEST_CODE);
			}
		});
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data){
		if (requestCode == REQUEST_CODE){
			if (resultCode == Activity.RESULT_OK){
				finish();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	
}
