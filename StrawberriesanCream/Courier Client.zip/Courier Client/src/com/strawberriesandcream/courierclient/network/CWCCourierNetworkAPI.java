package com.strawberriesandcream.courierclient.network;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import com.strawberriesandcream.courierclient.util.ClientHttpRequest;
import com.strawberriesandcream.courierclient.util.Constants;

public class CWCCourierNetworkAPI{
	public static String loginUser(String username, String password, String returnType) throws IOException{
		String data = "username=" + URLEncoder.encode(username, "UTF-8") 
					+ "&password=" + URLEncoder.encode(password, "UTF-8")
					+ "&returnType=" + URLEncoder.encode(returnType, "UTF-8");
			
		URLConnection conn = setupConnection(Constants.LOGIN_URL);
		writeData(conn, data);		
	
		String responseString = "";
		
		int responseCode = getResponseCode(conn);		
		
		if (responseCode == HttpURLConnection.HTTP_OK){
			responseString = getResponseString(conn);
		}
		
		return responseCode == HttpURLConnection.HTTP_OK ? responseString : null;
	}
	
	public static String registerUser(String username, String email, String password, String returnType) throws IOException{
		String data = "username=" + URLEncoder.encode(username, "UTF-8")
					+ "&password=" + URLEncoder.encode(password, "UTF-8")
					+ "&email=" + URLEncoder.encode(email, "UTF-8")
					+ "&returnType=" + URLEncoder.encode(returnType, "UTF-8");
		
		URLConnection conn = setupConnection(Constants.USER_REGISTER_URL);
		writeData(conn, data);
	
		String responseString = "";		
		int responseCode = getResponseCode(conn);		
		
		if (responseCode == HttpURLConnection.HTTP_OK){
			responseString = getResponseString(conn);
		}		
		return responseCode == HttpURLConnection.HTTP_OK ? responseString : null;
	}
	
	public static String getTaskList(String username, String duedate, String returnType) throws IOException{
		String data = "username=" + URLEncoder.encode(username, "UTF-8")
				+ "&duedate=" + URLEncoder.encode(duedate, "UTF-8")				
				+ "&returnType=" + URLEncoder.encode(returnType, "UTF-8");
	
		URLConnection conn = setupConnection(Constants.GET_TASK_LIST_URL);
		writeData(conn, data);
	
		String responseString = "";		
		int responseCode = getResponseCode(conn);		
		
		if (responseCode == HttpURLConnection.HTTP_OK){
			responseString = getResponseString(conn);
		}		
		return responseCode == HttpURLConnection.HTTP_OK ? responseString : null;
	}
	
	
	//TODO: image post :)
	public static String reportSpecificTask(String username, String taskid,
			String reasonType, String reasonDetails, String reportLatitude, String reportLongitude, 
			File signaturefile, String returnType) throws IOException
	{
			ClientHttpRequest request = new ClientHttpRequest(Constants.REPORT_SPECIFIC_TASK_URL);
			request.setParameter("constants", username);
			request.setParameter("taskid", taskid);
			request.setParameter("reasontype", reasonType);
			request.setParameter("reasondetails", reasonDetails);
			request.setParameter("reportlatitude", reportLatitude);
			request.setParameter("reportlongitude", reportLongitude);
			request.setParameter("signaturefile", signaturefile);
			
			String ret = request.postAndGetResponseCode();	
			int responseCode = getResponseCode(ret);
			
			return "" + responseCode;
	}
	
	public static String getTaskHistory(String username, String returnType) throws IOException{
		String data = "username=" + URLEncoder.encode(username, "UTF-8")							
				+ "&returnType=" + URLEncoder.encode(returnType, "UTF-8");
	
		URLConnection conn = setupConnection(Constants.GET_TASK_HISTORY_URL);
		writeData(conn, data);
	
		String responseString = "";		
		int responseCode = getResponseCode(conn);		
		
		if (responseCode == HttpURLConnection.HTTP_OK){
			responseString = getResponseString(conn);
		}		
		return responseCode == HttpURLConnection.HTTP_OK ? responseString : null;
	}
	
	private static String getResponseString(URLConnection conn) throws IOException{
		String responseString = "";
		
		HttpURLConnection httpConnection = (HttpURLConnection)conn;			
		InputStreamReader reader = new InputStreamReader(httpConnection.getInputStream());
		
		int r;
		while ((r = reader.read()) != -1){
			responseString += (char)r;
		}
		reader.close();	
		
		return responseString;
	}
	
	private static URLConnection setupConnection(String url) throws IOException{
		URL u = new URL(url);
		URLConnection conn = u.openConnection();
		conn.setDoOutput(true);
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		return conn;
	}
	
	private static void writeData(URLConnection conn, String data) throws IOException{
		OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
		writer.write(data);
		writer.flush();			
		writer.close();
	}
	
	private static int getResponseCode(URLConnection conn) throws IOException{
        String response = conn.getHeaderField(0);
        int responseCode = 0;
        if (response != null)
        	responseCode = Integer.parseInt(response.substring(response.indexOf(' ')+1, response.indexOf(' ')+4));
        return responseCode;
	}
	
	private static int getResponseCode(String s){
		return Integer.parseInt(s.substring(s.indexOf(' ') + 1, s.indexOf(' ') + 4));
	}

}
