package com.strawberriesandcream.courierclient;


import com.strawberriesandcream.courierclient.util.Constants;
import com.strawberriesandcream.courierclient.util.SimpleCrypto;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

public class SplashScreenActivity extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.splash_screen);
		new SplashScreenTask().execute();
	}
	
	private class SplashScreenTask extends AsyncTask<String, Void, Object>{		
		@Override
		protected Object doInBackground(String... params){
			SharedPreferences settings = getSharedPreferences(Constants.PREF, Context.MODE_PRIVATE);			
			Intent intent = new Intent(SplashScreenActivity.this, CWCCourierClientLoginActivity.class);
			
			if (settings.contains(Constants.PASSWORD)){
				String username = settings.getString(Constants.USERNAME, Constants.DEFAULT_STRING);
				String password = null;				
				try {
					password = SimpleCrypto.decrypt(
							Constants.SEED, 
							settings.getString(Constants.PASSWORD, Constants.DEFAULT_STRING)
					);
				}
				catch (Exception e){}
				
				intent.putExtra(Constants.PREF_STORED, true);				
				intent.putExtra(Constants.USERNAME, username);
				intent.putExtra(Constants.PASSWORD, password);				
			}
			else{
				intent.putExtra(Constants.PREF_STORED, false);
			}
			
			try{
				System.out.println("Thread.sleep(3000)");
				Thread.sleep(Constants.SPLASH_SCREEN_WAIT_TIME);
			}
			catch (InterruptedException e) {}
			
			System.out.println("Starting Login Activity");			
			startActivity(intent);
			
			System.out.println("Login Activity started!");
			
			finish();			
			return null;
		}		
	}
}
