package com.strawberriesandcream.courierclient;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.strawberriesandcream.courierclient.network.CWCCourierNetworkAPI;
import com.strawberriesandcream.courierclient.provider.TaskProviderMetaData.TaskListTableMetaData;
import com.strawberriesandcream.courierclient.util.Constants;

import android.app.Activity;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class TasksActivity extends ListActivity{
	private static final int REQUEST_CODE = 45;
	private String username;
	private final static int GROUP = 1;
	private final static int BASE = 0;
	
	private class BackgroudLoadList extends AsyncTask<Void, Void, Void>{	
		String sortOrder = null;
		
		private Cursor c;
		private String cols[];
		private int names[];	
		
		public BackgroudLoadList(String sortOrder){
			this.sortOrder = sortOrder;
		}
		
		private void extarctKeyValuePairsFromServerAndStoreInDB(){
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			String date = sdf.format(new Date());
			
			System.out.println(date + " IMPRON");
			String jsonResponse = "";
			try {			
				jsonResponse = CWCCourierNetworkAPI.getTaskList(username, date, Constants.RETURN_TYPE_JSON);
				System.out.println("jsonResponse: " + jsonResponse);
			} 
			catch (IOException e){
				System.out.println("IOException: " + e);
			}
			
			try {
				JSONArray jsonArray = new JSONArray(jsonResponse);
				ArrayList<String> arrList = new ArrayList<String>();
				
				int len = jsonArray.length();
				
				for (int i = 0; i < len; i++){
					JSONObject object = jsonArray.getJSONObject(i);
					ContentValues getTaskListContentValues = new ContentValues();
					
					Iterator<?> it = object.keys();
					while (it.hasNext()){
						String key = (String)it.next();
						String value = object.getString(key);
						if (TaskListTableMetaData.EXPECTED_KEYS_TASK_LIST.containsKey(key.hashCode()))
							getTaskListContentValues.put(key, value);						
						else{
							arrList.add(key);
							arrList.add(value);
						}
					}
					getTaskListContentValues.put(TaskListTableMetaData.EXTRA, new JSONArray(arrList).toString());
					TasksActivity.this.getContentResolver().insert(TaskListTableMetaData.CONTENT_URI, getTaskListContentValues);
					
					extractKeyValuePairsFromDBAndShowInList();
				}
			} catch (JSONException e) { 
				System.out.println("JSONException: " + e);
			}
		}
		
		
		
		private void extractKeyValuePairsFromDBAndShowInList(){
			c = getContentResolver().query(TaskListTableMetaData.CONTENT_URI, null, null, null, sortOrder);
			startManagingCursor(c);
			
			cols = new String[]{TaskListTableMetaData.NAME, TaskListTableMetaData.ADDRESS, TaskListTableMetaData.TIME};			
			names = new int[]{R.id.list_item_name1, R.id.list_item_name2, R.id.list_item_name3};	
		}
		
		@Override
		protected Void doInBackground(Void... params){			
			extarctKeyValuePairsFromServerAndStoreInDB();			
			return null;
		}
		
		
		@Override
		protected void onPostExecute(Void result){
			TasksActivity.this.setListAdapter(
					new SimpleCursorAdapter(TasksActivity.this, 
							R.layout.tasks, 
							c, 
							cols, 
							names));
			((SimpleCursorAdapter)TasksActivity.this.getListAdapter()).notifyDataSetChanged();
		}
		
	}
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Bundle extras = getIntent().getExtras();
		username = extras.getString(Constants.USERNAME);	
		
		new BackgroudLoadList(null).execute();
	}
	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		Intent intent = new Intent(TasksActivity.this, TaskDetailsActivity.class);
		intent.putExtra(TaskListTableMetaData.ID, "212");
		intent.putExtra(Constants.USERNAME, username);
		
		startActivityForResult(intent, REQUEST_CODE);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(GROUP, BASE, BASE, "Sort by time");
		menu.add(GROUP, BASE+1, BASE+1, "Sort by distance from current location");
		
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch(item.getItemId()){
		case BASE:
			sortByTime();
		case BASE+1:
			sortByLoc();
		}
		return super.onMenuItemSelected(featureId, item);
	}
	
	private void sort(){
		
	}
	
	
	private void sortByTime(){
		new BackgroudLoadList(TaskListTableMetaData.TIME + " ASC").execute();
	}
	
	private void sortByLoc(){
		new BackgroudLoadList(TaskListTableMetaData.LATITUDE + " ASC, " + TaskListTableMetaData.LONGITUDE + " ASC");
	}
	

	
	
}
