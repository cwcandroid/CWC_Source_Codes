package com.cwc.courierclient;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import android.util.Log;

public class HTTPUtils {
	
	
	public static String doget(String URL) 
	{
		final String str = "";
		
		try {			

			final HttpClient httpClient = new DefaultHttpClient();
			final HttpGet getRequest = new HttpGet(URL);

			final HttpResponse res = httpClient.execute(getRequest);
			
			System.out.println("Response: " + res.getEntity());
			return new String(EntityUtils.toString(res.getEntity()));

		} catch (final Exception e) {			
			e.printStackTrace();
		}

		return "[]";
	}

}
