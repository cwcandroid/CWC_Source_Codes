package com.cwc.courierclient;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

public class WMSOverlay extends Overlay {
	@Override
	public void draw(Canvas canvas, MapView mapView, boolean shadow) {
		super.draw(canvas, mapView, shadow);

		WMSLoader wmsclient = new WMSLoader();
		Point centerPx = new Point();
		Projection projection = mapView.getProjection();
		projection.toPixels(mapView.getMapCenter(), centerPx);
		// GeoPoint[] cornerCoords =
		// MapUtils.getCornerCoordinates(mapView.getProjection(), canvas);

		int width = canvas.getWidth();
		int height = canvas.getHeight();

		// GeoPoint ul = projection.fromPixels(centerPx.x - width / 2,
		// centerPx.y - height / 2);
		// GeoPoint lr = projection.fromPixels(centerPx.x + width / 2,
		// centerPx.y + height / 2);

		GeoPoint ul = projection.fromPixels(0, 0);
		GeoPoint lr = projection.fromPixels(canvas.getWidth(), canvas
				.getHeight());

		try {
			Bitmap image = wmsclient.loadMap(canvas.getWidth(), canvas
					.getHeight(), ul, lr);
			// if (true) return;
			Paint semitransparent = new Paint();
			semitransparent.setAlpha(0x44);
			canvas.drawBitmap(image, 0, 0, semitransparent);
		} catch (NullPointerException e) {

		}
	}
}
