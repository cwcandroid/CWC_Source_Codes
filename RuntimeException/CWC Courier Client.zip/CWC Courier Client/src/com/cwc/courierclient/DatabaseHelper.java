package com.cwc.courierclient;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

//	private static final String TABLE_NAME_ALLFIXTURE = "tbl_all_fixture";
//	private static final String TABLE_NAME_RUGBYDATA = "RugbyTableData";
//	private static final String TABLE_NAME_COMPETITION = "dataCompetition";
	private static String DB_PATH = "/data/data/"+CommonStatic.pName+"/databases/";
	 
    private static String DB_NAME = "cwcdb";
 
    private SQLiteDatabase myDataBase; 
 
    private final Context myContext;
    
	public DatabaseHelper(Context context) {
		super(context, DB_NAME, null, 1);
		this.myContext=context;
		try {
			createDataBase();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public void createDataBase() throws IOException
    {
    	Log.v("create database:", "create database");
    	 
    	boolean dbExist = checkDataBase();
    	Log.v("dbExist:", dbExist+"");
    	if(dbExist)
    	{
    		
    		//do nothing - database already exist
    	}
    	else
    	{
 
    		//By calling this method and empty database will be created into the default system path
               //of your application so we are gonna be able to overwrite that database with our database.
        	this.getReadableDatabase().close();
 
        	try {
 
    			copyDataBase();
 
    		} catch (IOException e) {
 
        		throw new Error("Error copying database");
 
        	}
    	}
 
    }
    private boolean checkDataBase()
    {
    	 
    	SQLiteDatabase checkDB = null;
 
    	try{
    		String myPath = DB_PATH + DB_NAME;
    		checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.NO_LOCALIZED_COLLATORS);
 
    	}catch(SQLiteException e)
    	{
 
    		//database does't exist yet.
 
    	}
 
    	if(checkDB != null){
 
    		checkDB.close();
 
    	}
 
    	return checkDB != null ? true : false;
    }
    private void copyDataBase() throws IOException
    {
    	InputStream databaseInput = null;
        String outFileName = DB_PATH + DB_NAME;
        Log.v("outFileName:", outFileName);
        OutputStream databaseOutput = new FileOutputStream(outFileName);

        byte[] buffer = new byte[1024];
        int length;

        databaseInput = myContext.getResources().openRawResource(R.raw.cwcdb);
        while((length = databaseInput.read(buffer)) > 0) 
        {
        	Log.v("Length:", length+"");
            databaseOutput.write(buffer, 0, length);
            databaseOutput.flush();
        }
        databaseInput.close();
        databaseOutput.flush();
        databaseOutput.close();

 
    }
    public void openDataBase() throws SQLException{
    	 
    	//Open the database
        String myPath = DB_PATH + DB_NAME;
    	myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.NO_LOCALIZED_COLLATORS);
    	myDataBase=this.getWritableDatabase();
    }
    @Override
	public synchronized void close() {
 
    	    if(myDataBase != null)
    		    myDataBase.close();
 
    	    super.close();
 
	}

    @Override
	public void onCreate(SQLiteDatabase db) {
 
	}
 
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
 
	}


}
