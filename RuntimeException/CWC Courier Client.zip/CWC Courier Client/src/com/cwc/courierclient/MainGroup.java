package com.cwc.courierclient;

import android.app.ActivityGroup;
import android.os.Bundle;

public class MainGroup extends ActivityGroup {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

}
