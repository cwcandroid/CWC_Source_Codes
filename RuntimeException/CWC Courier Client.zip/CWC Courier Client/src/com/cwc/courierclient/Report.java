package com.cwc.courierclient;

import android.graphics.Bitmap;

public class Report {
	static private String userName="";
	static private String taskId="";
	static private String reasonType="";
	static private String comment="";
	static private String longitude="";
	static private String latitude="";
	static private Bitmap signature=null;
	
	public String getUserName()
	{
		return userName;
	}
	public void setUserName(String userName)
	{
		this.userName=userName;
	}
	
	public String getTaskId()
	{
		return taskId;
	}
	public void setTaskId(String taskId)
	{
		this.taskId=taskId;
	}
	
	public String getReasonType()
	{
		return reasonType;
	}
	public void setReasonType(String reasonType)
	{
		this.reasonType=reasonType;
	}
	
	public String getComment()
	{
		return comment;
	}
	public void setComment(String comment)
	{
		this.comment=comment;
	}
	
	public String getLongitude()
	{
		return longitude;
	}
	public void setLongitude(String longitude)
	{
		this.longitude=longitude;
	}
	
	public String getLatitude()
	{
		return latitude;
	}
	public void setLatitude(String latitude)
	{
		this.latitude=latitude;
	}
	
	public Bitmap getSignature()
	{
		return signature;
	}
	public void setSignature(Bitmap signature)
	{
		this.signature=signature;
	}
	
	
}
