package com.cwc.courierclient;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class TaskDetailsActivity extends Activity {
	
	String itemName,itemId, itemDescription;
	String receiverName,receiverAddress,contactNo;
	
	Button reportBtn, infoBtn, viewOnMapBtn, contactBtn;
	TextView itemNameTxt,itemIdTxt, itemDescriptionTxt;
	TextView receiverAddressTxt,receiverNameTxt;
	Task taskObj;
	
	Context con;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.task_details);
		
		con=getParent();
		CommonStatic obj=new CommonStatic();
		taskObj=obj.getTask();
		itemName=taskObj.getName();
		itemId=taskObj.getId();
		itemDescription=taskObj.getDescription();
		receiverName=taskObj.getName();
		receiverAddress=taskObj.getAddress();
		contactNo=taskObj.getContactNo();
		
		itemNameTxt=(TextView)findViewById(R.id.itemNameTxt);
		itemIdTxt=(TextView)findViewById(R.id.itemIdTxt);
		itemDescriptionTxt=(TextView)findViewById(R.id.itemDescriptionTxt);
		receiverNameTxt=(TextView)findViewById(R.id.receiverNameTxt);
		receiverAddressTxt=(TextView)findViewById(R.id.receiverAddressTxt);
		
		reportBtn=(Button)findViewById(R.id.reportBtn);
		infoBtn=(Button)findViewById(R.id.infoBtn);
		viewOnMapBtn=(Button)findViewById(R.id.viewOnMapBtn);
		contactBtn=(Button)findViewById(R.id.contactBtn);
		
		setInfo();
		
		
		reportBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent i=new Intent(con,ReportTaskActivity.class);
				View v= TaskGroup.group.getLocalActivityManager()
						.startActivity("ReportTaskActivity", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
						.getDecorView();
				TaskGroup.group.replaceView(v);
			}
		});
		
		viewOnMapBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent i=new Intent(con,MapForSinglePOI.class);
				i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				
				CommonStatic.taskObject=taskObj;
				View v=TaskGroup.group.getLocalActivityManager()
						.startActivity("MapForSinglePOI", i)
						.getDecorView();
				TaskGroup.group.replaceView(v);
			}
		});
		
		contactBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String number="tel:"+contactNo;
				Intent i=new Intent(Intent.ACTION_CALL,Uri.parse(number));
				startActivity(i);
			}
		});
		
		infoBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				setInfo();
			}
		});	
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	TaskGroup.group.back();
	        return true;
	    }

	    return super.onKeyDown(keyCode, event);
	}
	
	private void setInfo()
	{
		itemNameTxt.setText(itemName);
		itemIdTxt.setText(itemId);
		itemDescriptionTxt.setText(itemDescription);
		receiverNameTxt.setText(receiverName);
		receiverAddressTxt.setText(receiverAddress);
		
		contactBtn.setText(contactNo);
	}
}
