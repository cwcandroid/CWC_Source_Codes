package com.cwc.courierclient;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class ReportTaskActivity extends Activity{
	
	Spinner reportStatusSpinner;
	ImageView signatureImg;
	
	Button submitBtn,cancelBtn,takeSignatureBtn;
	EditText commentET;
	
	ArrayAdapter<String> itemAdapter;
	Context con;
	Task taskObj;
	Report reportObj;
	
	String userName,taskId,reasonType,comment,longitude,latitude;
	Bitmap signature;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		View layoutView=LayoutInflater.from(this.getParent()).inflate(R.layout.report_task, null);
		setContentView(layoutView);
		
		taskObj=CommonStatic.taskObject;
		
		con=getParent();
		
		reportStatusSpinner=(Spinner)findViewById(R.id.spinner_reportStatus);
		
		signatureImg=(ImageView)findViewById(R.id.signatureImg);
		
		takeSignatureBtn=(Button)findViewById(R.id.takeSignatureBtn);
		submitBtn=(Button)findViewById(R.id.submitBtn);
		cancelBtn=(Button)findViewById(R.id.cancelBtn);
		
		commentET=(EditText)findViewById(R.id.commentET);
		
		signature=null;
		
		initializeSpinner();
		
		takeSignatureBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent i=new Intent(con,TakeSignatureActivity.class);
				i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				
				View v=TaskGroup.group.getLocalActivityManager()
						.startActivity("TakeSignatureActivity", i)
						.getDecorView();
				TaskGroup.group.replaceView(v);
			}
		});
		
		reportStatusSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,int position, long arg3) {
				reasonType=reportStatusSpinner.getItemAtPosition(position)+"";
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
		submitBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				reportObj.setComment(commentET.getText().toString());
				reportObj.setLatitude(taskObj.getLatitude());
				reportObj.setLongitude(taskObj.getLongitude());
				reportObj.setReasonType(reasonType);
				reportObj.setTaskId(taskObj.getId());
				reportObj.setUserName(taskObj.getName());
//				if(signature==null)
//				{
//					Toast.makeText(con, "Signature not taken", Toast.LENGTH_LONG).show();
//					return;
//				}
				reportObj.setSignature(signature);
			}
		});
		
	}
	
	public void initializeSpinner()
	{
		ArrayList<String> items=new ArrayList<String>();
		
		items.add("Not delivered");
		items.add("Delivered");
		items.add("Address not found");
		items.add("No one available");
		
		itemAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items);
        itemAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reportStatusSpinner.setAdapter(itemAdapter);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	TaskGroup.group.back();   
	    }
	    return true;
	}
}
