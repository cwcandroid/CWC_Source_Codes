package com.cwc.courierclient;

import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;


public class TasksListActivity extends Activity {
	ListView listView;
	ArrayList<Task> taskList;
	int day,mon,yar;
	String date = "",sDay = "",sMon = "",sYar = "",userName = "";
	JSONParsing jParse;
	TaskListAdapter adapter;
	ProgressDialog pd;
	Button btnTaskMap;
	
	Context con;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.task_list_layout);
		//taskList = new ArrayList<Task>();
		
		con=getParent();
		
		listView = (ListView)findViewById(R.id.TaskListView1);
		btnTaskMap = (Button)findViewById(R.id.btnTaskMapItems);
		
		userName = "cwcuser1";
		
		jParse = new JSONParsing();
		
		Calendar cal = Calendar.getInstance();
		day = cal.get(Calendar.DATE);
		mon = cal.get(Calendar.MONTH);
		yar = cal.get(Calendar.YEAR);
		sDay = ""+day;
		if(sDay.length() == 1)
			sDay = "0"+sDay;
		sMon = ""+(mon+1);
		if(sMon.length() == 1)
			sMon = "0"+sMon;
		sYar = ""+yar;
		date = sDay+"-"+sMon+"-"+sYar;
		//date = "20-01-2012";
		Log.d("TaskListClass", "Day: "+day+",Month: "+mon+", Year: "+yar);
		Log.d("TaskListClass", "Date: "+date+" ***********");
		//Check network
		if(CheckInternet.checkConn(con))
		{
			pd = ProgressDialog.show(con,"Loading...","Please wait a moment.");
//			RequestThread thread = new RequestThread();
			
			new Thread(){
				@Override
				public void run() {
					/*JSON Parsing*/
//					String url = "http://test.sentisol.com/cwc/index.php/android/getTaskList?username="+userName+"&returnType=json&duedate="+date;
//					taskList = jParse.parseForTask(url);
//					Message messageToHandler = new Message();
//					messageToHandler.what = 0;
//					handler.sendEmptyMessage(messageToHandler.what);
					
					/*XML Parsing*/
					String url = CommonStatic.TASK_LIST_URL+"username="+userName+"&returnType=xml&duedate="+date;
					
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp;
					try {
						sp = spf.newSAXParser();
						XMLReader xr = sp.getXMLReader();
				    	URL sourceUrl = new URL(url);
				    	TaskXMLHandler myXMLHandler = new TaskXMLHandler();
				    	xr.setContentHandler(myXMLHandler);
				    	xr.parse(new InputSource(sourceUrl.openStream()));
				    	taskList = myXMLHandler.tasklist;
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					Message messageToHandler = new Message();
					messageToHandler.what = 0;
					handler.sendEmptyMessage(messageToHandler.what);
					
				};
			}.start();
//			thread.start();
		}
		else Toast.makeText(con, "Internet not available", Toast.LENGTH_LONG).show();
		
		btnTaskMap.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View view) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(TasksListActivity.this,GPSMapSetMarkerActivity.class);
				//intent.putExtra("TaskListClass", taskList);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				CommonStatic com = new CommonStatic();
				com.setTaskList(taskList);
				Log.d("TaskListClass", "SizeOfTaskList: "+taskList.size());
				Log.d("Latitude: ", taskList.get(0).getLatitude());
				View v=TaskGroup.group.getLocalActivityManager()
						.startActivity("GPSMapSetMarkerActivity",intent)
						.getDecorView();
				TaskGroup.group.replaceView(v);
			}
		});
		listView.setOnItemClickListener(new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			Task tsk =  new Task();
			tsk = taskList.get(arg2);
			Intent intentToMap = new Intent(TasksListActivity.this,TaskDetailsActivity.class);
			CommonStatic com = new CommonStatic();
			com.setTask(tsk);
			View v=TaskGroup.group.getLocalActivityManager()
					.startActivity("TaskDetailsActivity",intentToMap.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					.getDecorView();
			TaskGroup.group.replaceView(v);
		}
	});
	}
//public class RequestThread extends Thread{
//	@Override
//	public void run()
//		{
//		String url = "http://test.sentisol.com/cwc/index.php/android/getTaskList?username="+userName+"&returnType=json&duedate="+date;
//		taskList = jParse.parseForTask(url);
//		Message messageToHandler = new Message();
//		messageToHandler.what = 0;
//		handler.sendEmptyMessage(messageToHandler.what);
//		}
//}
Handler handler = new Handler(){
	public void handleMessage(android.os.Message msg) {
			pd.dismiss();
			adapter = new TaskListAdapter(TasksListActivity.this, R.layout.task_list_row_layout, taskList);
			listView.setAdapter(adapter);
	}
};
@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	TaskGroup.group.back();   
	    }
	    return true;
	}
}
