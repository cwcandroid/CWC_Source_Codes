package com.cwc.courierclient;

import java.util.ArrayList;
import java.util.Vector;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

public class HistoryXMLHandler extends DefaultHandler {

	Boolean currentElement = false;
	String currentValue = null;
	public ArrayList<History> tasklist = new ArrayList<History>();
	boolean enclosureFound=false;
	public static History taskItemList= null;

	public static History getSitesList() {
		return taskItemList;
	}

	public static void setSitesList(History taskList) {
		HistoryXMLHandler.taskItemList= taskList;
	}

	/** Called when tag starts ( ex:- <name>AndroidPeople</name>
	 * -- <name> )*/
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		
		currentElement = true;
		currentValue = "";
		if (localName.equals("node"))
		{
			/** Start */
			taskItemList= new History();
		}
		
		if (localName.equals("task"))
		{
			/** Start */
			taskItemList= new History();
		}
	}

	/** Called when tag closing ( ex:- <name>AndroidPeople</name>
	 * -- </name> )*/
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		
		currentElement = false;
		currentValue = currentValue.trim();
		if (localName.equalsIgnoreCase("task"))
		{
			
			
			tasklist.add(taskItemList);
			enclosureFound=false;
		}
		/** set value */
		else if (localName.equalsIgnoreCase("id")){
			
			taskItemList.setId(currentValue);
			Log.v("link:::::", currentValue);
		}	
		else if (localName.equalsIgnoreCase("address")){
			
			taskItemList.setAddress(currentValue);
			Log.v("title:::::", currentValue);
		
		}
		else if (localName.equalsIgnoreCase("comments"))
		{
			taskItemList.setComment(currentValue);
			Log.v("description:::::", currentValue);
		}
		else if (localName.equalsIgnoreCase("contactno"))
		{
			taskItemList.setContactNo(currentValue);
			Log.v("date:::::", currentValue);
		
		}
		else if (localName.equalsIgnoreCase("description"))
		{
			taskItemList.setDescription(currentValue);
			Log.v("date:::::", currentValue);
		
		}
		else if (localName.equalsIgnoreCase("latitude"))
		{
			taskItemList.setLatitude(currentValue);
			Log.v("date:::::", currentValue);
		
		}
		else if (localName.equalsIgnoreCase("longitude"))
		{
			taskItemList.setLongitude(currentValue);
			Log.v("date:::::", currentValue);
		
		}
		else if (localName.equalsIgnoreCase("name"))
		{
			taskItemList.setName(currentValue);
			Log.v("date:::::", currentValue);
		
		}
		else if (localName.equalsIgnoreCase("status"))
		{
			taskItemList.setStatus(currentValue);
			Log.v("date:::::", currentValue);
		
		}
		else if (localName.equalsIgnoreCase("duetime"))
		{
			taskItemList.setDueTime(currentValue);
			Log.v("date:::::", currentValue);
		}
		else if (localName.equalsIgnoreCase("duedate"))
		{
			taskItemList.setDueDate(currentValue);
			Log.v("date:::::", currentValue);
		}
		else if (localName.equalsIgnoreCase("reasontype"))
		{
			taskItemList.setReasonType(currentValue);
			Log.v("date:::::", currentValue);
		}
		else if (localName.equalsIgnoreCase("reasondetails"))
		{
			taskItemList.setReasonDetails(currentValue);
			Log.v("date:::::", currentValue);
		}
		else if (localName.equalsIgnoreCase("reportlatitude"))
		{
			taskItemList.setReportLatitude(currentValue);
			Log.v("date:::::", currentValue);
		}
		else if (localName.equalsIgnoreCase("reportlongitude"))
		{
			taskItemList.setReportLongitude(currentValue);
			Log.v("date:::::", currentValue);
		}
		else if (localName.equalsIgnoreCase("signature"))
		{
			taskItemList.setSignature(currentValue);
			Log.v("date:::::", currentValue);
		}
		

	}

	/** Called to get tag characters ( ex:- <name>AndroidPeople</name>
	 * -- to get AndroidPeople Character ) */
	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		
		if (currentElement) {
			currentValue+= new String(ch, start, length);
//			currentElement = false;
		}

	}

}
