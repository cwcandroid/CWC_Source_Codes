package com.cwc.courierclient;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import com.cwc.courierclient.MapForHistory.MyLocationListener;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class GPSPath_Source_DestinationActivity extends MapActivity implements LocationListener {
    MapView mapView;
    GeoPoint gp1,gp2;
    WMSOverlay myLocationOverlay;
	int day,mon,yar;
	Intent serviceIntent;
	String date = "",sDay = "",sMon = "",sYar = "",userName = "";
	ArrayList<GeoPoint> listPoint;

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_location_history);
        
        mapView = (MapView)findViewById(R.id.mapview);
        mapView.getController().setZoom(7);
        mapView.setClickable(true);
        mapView.setEnabled(true);
        mapView.setBuiltInZoomControls(true);
        mapView = (MapView)findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
        
        listPoint = new ArrayList<GeoPoint>();
        
        /*serviceIntent = new Intent(this,NotificationService.class);
        startService(serviceIntent);*/
        
        LocationManager locMan = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        //locMan.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 10, this); //<7>

        LocationListener listener = new MyLocationListener();
        locMan.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3600000, 0, listener);
        
        Location loc = locMan.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        
        mapView.getController().setZoom(12);
        
        //drawLine();
//        mapview.invalidate();
 
    }
    
    public void drawLine()
    {
    	//Code to request for kml
    	if(listPoint.size()>0){
    	gp1 = listPoint.get(0);
    	Drawable draw = getResources().getDrawable(R.drawable.map_marker);
    	MyItemizedOverlay overlay = new MyItemizedOverlay(draw, GPSPath_Source_DestinationActivity.this);
    	OverlayItem item = new OverlayItem(gp1, "", "");
    	overlay.addItem(item);
    	mapView.getOverlays().add(overlay);
    	mapView.getController().animateTo(gp1);
    	Log.d("DrawMethod", "if executed ***********");
    	}
		for(int i=1;i<listPoint.size();i++)
		{
			Log.d("DrawMethod", "for executed ***********"+i);
			gp2 = listPoint.get(i);
        	Drawable drw = getResources().getDrawable(R.drawable.map_marker);
        	MyItemizedOverlay overly = new MyItemizedOverlay(drw, GPSPath_Source_DestinationActivity.this);
        	OverlayItem itm = new OverlayItem(gp2, "", "");
        	overly.addItem(itm);
        	mapView.getOverlays().add(overly);

	    	LineOverlay line = new LineOverlay(gp1,gp2);
	    	mapView.getOverlays().add(line);    	
	    	gp1 = gp2;
	    	//Log.d("xxx", "pair:"+pairs[i]);
		}

    }
    public class MyLocationListener implements LocationListener
    {

		@Override
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub
		      int latitude = (int)(location.getLatitude() * 1000000);
		      int longitude = (int)(location.getLongitude() * 1000000);

		      GeoPoint point = new GeoPoint(latitude,longitude);
		      Log.d("onLocationChanged", "Latitude: "+latitude+", longitude: "+longitude);
		      listPoint.add(point);
		      drawLine();			
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}
    	
    }

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
	      int latitude = (int)(location.getLatitude() * 1000000);
	      int longitude = (int)(location.getLongitude() * 1000000);

	      GeoPoint point = new GeoPoint(latitude,longitude);
	      Log.d("onLocationChanged", "Latitude: "+latitude+", longitude: "+longitude);
	      listPoint.add(point);
	      drawLine();
	      //mapController.animateTo(point); 
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}
}