package com.cwc.courierclient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;

public class JSONParsing {
ArrayList<Task> listOfTask;
public JSONParsing(){
	
	}

public ArrayList<Task> parseForTask(String urlString){
	listOfTask = new ArrayList<Task>();
	try {

		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet();
		request.setURI(new URI(urlString));
		HttpResponse response = client.execute(request);
		InputStream ips = response.getEntity().getContent();
		BufferedReader buf = new BufferedReader(new InputStreamReader(ips, "UTF-8"));
		String sResponse;
		StringBuilder s = new StringBuilder();
		while((sResponse = buf.readLine())!=null){
			s = s.append(sResponse);
		}
		
		String sx ="{\"array\":"+ s.toString()+"}";
	
		Log.d("*****output******",sx+"    *******");

		buf.close();
		ips.close();
		
		JSONObject json = new JSONObject(sx);
		JSONArray meson = (JSONArray) json.get("array");
		for(int j=0;j<meson.length();j++){
			Task task = new Task();
			JSONObject data=meson.getJSONObject(j);
			task.setAddress(data.getString("address"));
			task.setComment(data.getString("comments"));
			task.setContactNo(data.getString("contactno"));
			task.setDescription(data.getString("description"));
			task.setId(data.getString("task_id"));
			task.setLatitude(data.getString("latitude"));
			task.setLongitude(data.getString("longitude"));
			task.setName(data.getString("name"));
			task.setStatus(data.getString("status"));
			listOfTask.add(task);
			}
		
	}catch(Exception e){
		e.printStackTrace();
	}

	return listOfTask;
}
}
