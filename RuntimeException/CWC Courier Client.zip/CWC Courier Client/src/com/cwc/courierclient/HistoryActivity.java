package com.cwc.courierclient;

import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;



public class HistoryActivity extends Activity{
	ListView listView;
	ArrayList<History> historyList;
	int day,mon,yar;
	String date = "",sDay = "",sMon = "",sYar = "",userName = "";
	JSONParsing jParse;
	HistoryListAdapter adapter;
	ProgressDialog pd;
	Button btnTaskMap;
	SharedPreferences pref;
	
	DatabaseHelper db;
	
	Context con;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.history_list_layout);
		//taskList = new ArrayList<Task>();
		pref = PreferenceManager.getDefaultSharedPreferences(HistoryActivity.this);
		con=getParent();
		
		db=new DatabaseHelper(con);
		
		listView = (ListView)findViewById(R.id.TaskListView1);
		//btnTaskMap = (Button)findViewById(R.id.btnTaskMapItems);
		
		//userName = "cwcuser1";
		userName = pref.getString("USERID", "");
		Log.d("TasksList", "UserName: "+ userName);
		
		jParse = new JSONParsing();
		
		Calendar cal = Calendar.getInstance();
		day = cal.get(Calendar.DATE);
		mon = cal.get(Calendar.MONTH);
		yar = cal.get(Calendar.YEAR);
		sDay = ""+day;
		if(sDay.length() == 1)
			sDay = "0"+sDay;
		sMon = ""+(mon+1);
		if(sMon.length() == 1)
			sMon = "0"+sMon;
		sYar = ""+yar;
		date = sDay+"-"+sMon+"-"+sYar;
		//date = "20-01-2012";
		Log.d("TaskList", "Day: "+day+",Month: "+mon+", Year: "+yar);
		Log.d("TaskList", "Date: "+date+" ***********");
		//Check network
		if(CheckInternet.checkConn(HistoryActivity.this))
		{
			pd = ProgressDialog.show(HistoryActivity.this.getParent(),"Loading...","Please wait a moment.");
//			RequestThread thread = new RequestThread();
			
			new Thread(){
				@Override
				public void run() {
					
					/*For JSON parsing*/
//					String url = "http://test.sentisol.com/cwc/index.php/android/getTaskList?username="+userName+"&returnType=json&duedate="+date;
//					historyList = jParse.parseForTask(url);
//					Message messageToHandler = new Message();
//					messageToHandler.what = 0;
//					handler.sendEmptyMessage(messageToHandler.what);
					
					/*For XML Parsing*/
					
					String url = CommonStatic.HISTORY_URL+"username="+userName+"&returnType=xml&duedate="+date;
					
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp;
					try {
						sp = spf.newSAXParser();
						XMLReader xr = sp.getXMLReader();
				    	URL sourceUrl = new URL(url);
				    	HistoryXMLHandler myXMLHandler = new HistoryXMLHandler();
				    	xr.setContentHandler(myXMLHandler);
				    	xr.parse(new InputSource(sourceUrl.openStream()));
				    	historyList=myXMLHandler.tasklist;
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					Message messageToHandler = new Message();
					messageToHandler.what = 0;
					handler.sendEmptyMessage(messageToHandler.what);
				};
			}.start();
//			thread.start();
		}
		else Toast.makeText(con, "Internet not available", Toast.LENGTH_LONG).show();
		
		/*btnTaskMap.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HistoryActivity.this,GPSMapSetMarkerActivity.class);
				//intent.putExtra("TaskList", taskList);
				CommonStatic com = new CommonStatic();
				com.setTaskList(taskList);
				Log.d("TaskList", "SizeOfTaskList: "+taskList.size());
				Log.d("Latitude: ", taskList.get(0).getLatitude());
				startActivity(intent);
			}
		});*/
		listView.setOnItemClickListener(new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			History history =  new History();
			history= historyList.get(arg2);
			Intent intentToMap = new Intent(HistoryActivity.this,HistoryDetails.class);
			CommonStatic com = new CommonStatic();
			com.setHistory(history);
			View v=HistoryGroup.group.getLocalActivityManager()
					.startActivity("HistoryDetails",intentToMap.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					.getDecorView();
			HistoryGroup.group.replaceView(v);
		}
	});
	}
//public class RequestThread extends Thread{
//	@Override
//	public void run()
//		{
//		String url = "http://test.sentisol.com/cwc/index.php/android/getTaskList?username="+userName+"&returnType=json&duedate="+date;
//		taskList = jParse.parseForTask(url);
//		Message messageToHandler = new Message();
//		messageToHandler.what = 0;
//		handler.sendEmptyMessage(messageToHandler.what);
//		}
//}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	HistoryGroup.group.back();   
	    }
	    return true;
	}

Handler handler = new Handler(){
	public void handleMessage(android.os.Message msg) {
			pd.dismiss();
			for(int i=0;i<historyList.size();i++){
				History history= new History();
				history= historyList.get(i);
			}
			adapter = new HistoryListAdapter(HistoryActivity.this, R.layout.task_list_row_layout, historyList);
			listView.setAdapter(adapter);
	}

};

}
