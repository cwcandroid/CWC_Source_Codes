package com.cwc.courierclient;

import org.json.JSONObject;

import android.R.bool;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CWCCourierClientRegistrationActivity extends Activity{
	
	private final int DIALOGOFF =0;
	private final int SUCCESS=1;
	private final int FAILED=2;
	
	private final String RETURN_TYPE="json";
	
	Button backBtn, submitBtn;
	EditText nameET,emailET,passwordET,confirmPasswordET;
	
	String name,email,password,confirmPassword;
	
	Context con;
	
	ProgressDialog progressDialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		con=this;
		
		setContentView(R.layout.register);
		
		backBtn=(Button)findViewById(R.id.backBtn);
		submitBtn=(Button)findViewById(R.id.submitBtn);
		
		nameET=(EditText)findViewById(R.id.idET);
		emailET=(EditText)findViewById(R.id.emailET);
		passwordET=(EditText)findViewById(R.id.passwordET);
		confirmPasswordET=(EditText)findViewById(R.id.confirmPasswordET);
		
		backBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i=new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientLoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		submitBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {

				name=nameET.getText().toString();
				email=emailET.getText().toString();
				password=passwordET.getText().toString();
				confirmPassword=confirmPasswordET.getText().toString();
				
				name=name.replaceAll(" ", "%20");
				email=email.replaceAll(" ", "%20");
				password=password.replaceAll(" ", "%20");
				confirmPassword=confirmPassword.replaceAll(" ", "%20");
				if(name.length()==0 || email.length()==0 || password.length()==0 || confirmPassword.length()==0)
				{
					if(name.length()==0)
					{
						nameET.setHintTextColor(Color.RED);
						passwordET.setText("");
						confirmPasswordET.setText("");
					}
					if(email.length()==0)
					{
						emailET.setHintTextColor(Color.RED);
						passwordET.setText("");
						confirmPasswordET.setText("");
					}
					if(password.length()==0)
					{
						passwordET.setHintTextColor(Color.RED);
						passwordET.setText("");
						confirmPasswordET.setText("");
					}
					if(confirmPassword.length()==0)
					{
						confirmPasswordET.setHintTextColor(Color.RED);
						passwordET.setText("");
						confirmPasswordET.setText("");
					}
					
					Toast.makeText(con, "Fill all the fields", Toast.LENGTH_LONG).show();
					return;
				}
				
				if(!validatePassword(password, confirmPassword))
				{
					Toast.makeText(con, "Password missmatch", Toast.LENGTH_LONG).show();
					return;
				}
				
				if(CheckInternet.checkConn(con))
				{
					Log.d("Inside check conn",name+" "+password);
					progressDialog=ProgressDialog.show(con, null, "Connecting server. Please wait...");
					progressDialog.setCancelable(true);
					new Thread()
					{ 
						@Override
						public void run() {
							authenticate(name, email,password);
						}
					}.start();
				}
				else
					Toast.makeText(con, "Internet not available", Toast.LENGTH_LONG).show();
			}
		});
	}
	
	private boolean validatePassword(String pass1, String pass2)
	{
		if(pass1.equals(pass2))return true;
		return false;
	}
	
	private boolean authenticate(String name, String email, String password)
    {
    	String registerUrl=CommonStatic.REGISTER_URL+"username="+name+"&password="+password+"&returnType="+RETURN_TYPE+"&email="+email;
    	String status=null;
    	String text=null;
    	
		String response=HTTPUtils.doget(registerUrl);
		
		try
		{
			JSONObject jsonObj=new JSONObject(response);
			if(jsonObj!=null)
    		{
    			status=jsonObj.getString("status");
    			if(status.equalsIgnoreCase("Failed"))
    				text=jsonObj.getString("text");
    			else text="New user created";
    			Log.d("Status",registerUrl+" "+status);
    		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		Message msg=new Message();
		
    	if(status!=null && status.equalsIgnoreCase("Success"))
    	{
    		msg.what=SUCCESS;
    		msg.obj=text;
    		searchHandler.handleMessage(msg);
    		return true;
    	}
    	msg.what=FAILED;
    	msg.obj=text;
		searchHandler.handleMessage(msg);
    	return false;
    }
	
	private Handler searchHandler=new Handler(){
    	@Override
    	public void handleMessage(final Message msg) {
    		switch(msg.what){
    		case DIALOGOFF:
    			progressDialog.dismiss();
    			break;
    		case SUCCESS:
    			progressDialog.dismiss();
    			
    			Intent i=new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientMainScreenActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				i.putExtra("USERID", name);
				i.putExtra("PASSWORD", password);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
				break;
			case FAILED:
    			progressDialog.dismiss();
    			
				CWCCourierClientRegistrationActivity.this.runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						if((msg.obj+"").contains("Email"))
		    			{
									emailET.setText("");
			    					emailET.setHintTextColor(Color.RED);
			    					passwordET.setText("");
									confirmPasswordET.setText("");
						}
		    			else if((msg.obj+"").contains("User"))
		    			{
		    						nameET.setText("");
		        					nameET.setHintTextColor(Color.RED);
		        					passwordET.setText("");
		    						confirmPasswordET.setText("");
						}
		    			else
		    			{
		    						emailET.setHintTextColor(Color.BLACK);
		        					nameET.setHintTextColor(Color.BLACK);
						}
						
						Toast.makeText(con, "Failed : "+msg.obj, Toast.LENGTH_LONG).show();
					}
				});
    			break;
    		}
    		super.handleMessage(msg);
    	}
    };
}
