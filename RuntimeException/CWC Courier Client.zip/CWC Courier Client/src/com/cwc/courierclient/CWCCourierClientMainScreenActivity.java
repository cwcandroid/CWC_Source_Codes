package com.cwc.courierclient;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.Toast;

public class CWCCourierClientMainScreenActivity extends TabActivity {

	String pass,id;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		id=getIntent().getStringExtra("USERID");
		pass=getIntent().getStringExtra("PASSWORD");
		
		// setup tabs
		TabHost tabHost = getTabHost();
		TabHost.TabSpec tabSpec;
		Intent intent;

		Toast.makeText(this, "Welcome "+id, Toast.LENGTH_LONG).show();
		
		intent = new Intent().setClass(this, TaskGroup.class);
		tabSpec = tabHost.newTabSpec("tasks").setIndicator("Tasks", null)
				.setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, HistoryGroup.class);
		tabSpec = tabHost.newTabSpec("history").setIndicator("History", null)
				.setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, PerformanceActivity.class);
		tabSpec = tabHost.newTabSpec("performance").setIndicator("Performance", null)
				.setContent(intent);
		tabHost.addTab(tabSpec);
		
		intent = new Intent().setClass(this, GPSPath_Source_DestinationActivity.class);
		tabSpec = tabHost.newTabSpec("Location History").setIndicator("Location History", null)
				.setContent(intent);
		tabHost.addTab(tabSpec);
	}

}
