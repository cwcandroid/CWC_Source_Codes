package com.cwc.courierclient;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.View;

import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;

public class MyItemizedOverlay extends ItemizedOverlay<OverlayItem> {
	ArrayList<Task> taskList;
	Context context;
	ArrayList<OverlayItem> items = new ArrayList<OverlayItem>();
	public MyItemizedOverlay(Drawable defaultMarker, Context context) {
		super(boundCenterBottom(defaultMarker));
		this.context=context;
		taskList = new ArrayList<Task>();
        CommonStatic com = new CommonStatic();
        taskList = com.getTaskList();
		// TODO Auto-generated constructor stub
	}

	public void addItem(OverlayItem item){
		items.add(item);
		populate();
	}
	
	@Override
	protected OverlayItem createItem(int pos) {
		// TODO Auto-generated method stub
		return items.get(pos);
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return items.size();
	}
	@Override
	public boolean onTap(int index) {
		// TODO Auto-generated method stub
		OverlayItem selectedItem = items.get(index);
		AlertDialog.Builder alert = new AlertDialog.Builder(context);
		alert.setTitle(selectedItem.getTitle());
		alert.setMessage(selectedItem.getSnippet());
		alert.setPositiveButton("Task Report", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(context,TaskDetailsActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				View v=TaskGroup.group.getLocalActivityManager()
						.startActivity("TaskDetailsActivity",intent)
						.getDecorView();
				TaskGroup.group.replaceView(v);
			}
		});
		alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				
			}
		});		
		alert.show();
		
		return true;
	}
}
