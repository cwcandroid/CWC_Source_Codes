package com.cwc.courierclient;

import java.net.UnknownHostException;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CWCCourierClientLoginActivity extends Activity {
	protected static final int DIALOGOFF = 0;
	protected static final int NOUSER = 1;
	protected static final int USERFOUND = 2;
	protected static final int NOCONNECTION = 3;
	Button btnLogin, btnRegister;
	EditText passwordET, idET;
	TextView invalidTxt;
	CheckBox rememberChk;
	String userId,password;
	Context con;
	ProgressDialog progressDialog;
	SharedPreferences loginPreference;
	SharedPreferences.Editor editor;
	boolean isRemembered=false;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        setContentView(R.layout.login);
        con=this;
        
        loginPreference=PreferenceManager.getDefaultSharedPreferences(con);
        editor=loginPreference.edit();
        
        btnLogin=(Button)findViewById(R.id.loginBtn);
        btnRegister=(Button)findViewById(R.id.registerBtn);
        
        passwordET=(EditText)findViewById(R.id.passwordET);
        idET=(EditText)findViewById(R.id.idET);
        
        invalidTxt=(TextView)findViewById(R.id.invalidTxt);
        rememberChk=(CheckBox)findViewById(R.id.rememberChkBox);
        
        isRemembered=loginPreference.getBoolean("REMEMBERED", false);
        userId=loginPreference.getString("USERID", "");
        password=loginPreference.getString("PASSWORD", "");
        

        
        if(isRemembered)
        {
        	progressDialog=ProgressDialog.show(con,"","Loging in");
        	Message msg=new Message();
        	msg.what=USERFOUND;
        	searchHandler.handleMessage(msg);
        }
        
//        idET.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				if(idET.getText().length()>0 && passwordET.getText().length()>0)
//				{
//					btnLogin.setEnabled(true);
//				}
//				else btnLogin.setEnabled(false);
//				
//				
//				return false;
//			}
//		});
        
//        passwordET.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				if(idET.getText().length()>0 && passwordET.getText().length()>0)
//				{
//					btnLogin.setEnabled(true);
//				}
//				else btnLogin.setEnabled(false);
//				
//				return false;
//			}
//		});
        btnLogin.setOnClickListener(onClickLoginBtn);
        
        btnRegister.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientRegistrationActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
    }
    
    View.OnClickListener onClickLoginBtn=new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			userId=idET.getText().toString();
			password=passwordET.getText().toString();
			
			if(userId.length()==0 || password.length()==0)
			{
				if(userId.length()==0)
				{
					idET.setHintTextColor(Color.RED);
					passwordET.setText("");
				}
				if(password.length()==0)
				{
					passwordET.setHintTextColor(Color.RED);
					passwordET.setText("");
				}
				Toast.makeText(con, "Fill all the fields", Toast.LENGTH_LONG).show();
				return;
			}
			
			userId=userId.replaceAll(" ", "%20");
			password=password.replaceAll(" ", "%20");
			
			Log.d("",userId+" "+password);
			if(CheckInternet.checkConn(con))
			{
				Log.d("Inside check conn",userId+" "+password);
				progressDialog=ProgressDialog.show(con, null, "Connecting server. Please wait...");
				progressDialog.setCancelable(true);
				new Thread()
				{ 
					@Override
					public void run() {
						authenticate(userId, password);
					}
				}.start();
			}
			else
				Toast.makeText(con, "Internet not available", Toast.LENGTH_LONG).show();
			
		}
	};
	@Override
	protected void onResume() {
		super.onResume();
	};
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		//this.setContentView(R.layout.login);
		
//		Display display = ((WindowManager) con.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
//		int rotation = display.getOrientation();
	};
	
	@Override
	protected void onRestart() {
		super.onRestart();
	};
	
//	@Override
//	public boolean onKeyDown(int keyCode, KeyEvent event)  {
//	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
//	    	NewsGroup.group.back();
//	        return true;
//	    }
//
//	    return super.onKeyDown(keyCode, event);
//	}
	
    private Handler searchHandler=new Handler(){
    	@Override
    	public void handleMessage(Message msg) {
    		switch(msg.what){
    		case DIALOGOFF:
    			progressDialog.dismiss();
    			break;
    		case USERFOUND:
    			progressDialog.dismiss();
    			
    			if(rememberChk.isChecked())
    			{
    				editor.putBoolean("REMEMBERED", true);
    				editor.putString("USERID", userId);
    				editor.putString("PASSWORD", password);
    				editor.commit();
    			}
    			else
    			{
    				editor.putBoolean("REMEMBERED", false);
    				editor.putString("USERID", userId);
    				editor.putString("PASSWORD", password);
    				editor.commit();
    			}
    			
				Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientMainScreenActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				i.putExtra("USERID", userId);
				i.putExtra("PASSWORD", password);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
				break;
			case NOUSER:
    			progressDialog.dismiss();
    			CWCCourierClientLoginActivity.this.runOnUiThread(new Runnable() {
    			    public void run() {
    			    	Toast.makeText(con, "Incorrect user or password", Toast.LENGTH_LONG).show();
    			    }
    			});
    			
    			break;
			case NOCONNECTION:
    			progressDialog.dismiss();
    			CWCCourierClientLoginActivity.this.runOnUiThread(new Runnable() {
    			    public void run() {
    			    	Toast.makeText(con, "Internet connection problem", Toast.LENGTH_LONG).show();
    			    }
    			});
    			
    			break;
    		}
    		super.handleMessage(msg);
    	}
    };
    
    private boolean authenticate(String userId, String password)
    {
    	String loginUrl=CommonStatic.LOGIN_URL+"username="+userId+"&password="+password+"&returnType=json";
    	String status=null;
    	
		String response=HTTPUtils.doget(loginUrl);
		
		try
		{
			JSONObject jsonObj=new JSONObject(response);
			if(jsonObj!=null)
    		{
    			status=jsonObj.getString("status");
    		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		Message msg=new Message();
		
    	if(status!=null && status.equals("true"))
    	{
    		msg.what=USERFOUND;
    		searchHandler.handleMessage(msg);
    		return true;
    	}
    	msg.what=NOUSER;
		searchHandler.handleMessage(msg);
    	return false;
    }
}