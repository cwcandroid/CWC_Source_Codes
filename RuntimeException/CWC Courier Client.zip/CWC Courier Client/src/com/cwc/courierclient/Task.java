package com.cwc.courierclient;

public class Task {
String address,comment,contactNo,description,latitude,longitude,name,status,id,time;

public Task(String address,String comment,String contactNo,String description,String latitude,String longitude,String name,String status,String id,String time){
	this.address = address;
	this.comment = comment;
	this.contactNo = contactNo;
	this.description = description;
	this.latitude = latitude;
	this.longitude = longitude;
	this.name =  name;
	this.status = status;
	this.id = id;
	this.time=time;
}
public Task(){
	
}
public String getAddress(){
	return address;
}
public void setAddress(String address){
	this.address = address;
}
public String getComment(){
	return comment;
}
public void setComment(String comment){
	this.comment = comment;
}
public String getContactNo(){
	return contactNo;
}
public void setContactNo(String contactNo){
	this.contactNo = contactNo;
}
public String getDescription(){
	return description;
}
public void setDescription(String description){
	this.description = description;
}
public String getLatitude(){
	return latitude;
}
public void setLatitude(String latitude){
	this.latitude = latitude;
}
public String getLongitude(){
	return longitude;
}
public void setLongitude(String longitude){
	this.longitude = longitude;
}
public String getName(){
	return name;
}
public void setName(String name){
	this.name = name;
}
public String getStatus(){
	return status;
}
public void setStatus(String status){
	this.status = status;
}
public String getId(){
	return id;
}
public void setId(String id){
	this.id = id;
}
public String getTime()
{
	return time;
}
public void setTime(String time)
{
	this.time=time;
}
}
