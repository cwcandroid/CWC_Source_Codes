package com.cwc.courierclient;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class HistoryListAdapter extends ArrayAdapter<History> {
	private final Context context;
	private ArrayList<History> historyList;
	public HistoryListAdapter(Context context, int textViewResourceId,ArrayList<History> historyList) {
		super(context, textViewResourceId,historyList);
		// TODO Auto-generated constructor stub
		this.historyList = historyList;
		this.context = context;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		//return super.getView(position, convertView, parent);
//		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = convertView;
		if (v == null) {
			LayoutInflater vi = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			v = vi.inflate(R.layout.task_list_row_layout, null);
		}
		
		History data = new History();
		ImageView img = (ImageView) v.findViewById(R.id.ActivityImage);
		data = historyList.get(position);
		
		if((data.getStatus()).equalsIgnoreCase("0"))
			img.setBackgroundResource(R.drawable.cross);
		else if((data.getStatus()).equalsIgnoreCase("1"))
			img.setBackgroundResource(R.drawable.check);
		else if((data.getStatus()).equalsIgnoreCase("2"))
			img.setBackgroundResource(R.drawable.pending_green);
		
		TextView name = (TextView) v.findViewById(R.id.TaskName);
		Log.d("FavouritesArrayAdapter...",".....//....."+data.getName());
		name.setText((data.getName()).toString());
		TextView details = (TextView) v.findViewById(R.id.TaskDetails);
		details.setText((data.getAddress()).toString());
		return v;
	}

}
