package com.cwc.courierclient;

public class History {
String address,comment,contactNo,description,latitude,longitude,name,status,id;
String dueTime,dueDate;
String reasonType, reasonDetails, reportLatitude, reportLongitude,signatureFile;

	public History(String address,String comment,String contactNo,String description,
				String latitude,String longitude,String name,String status,String id,String dueTime, String dueDate,
				String reasonType, String reasonDetails, String reportLatitude, String reportLongitude,String signatureFile){
		this.address = address;
		this.comment = comment;
		this.contactNo = contactNo;
		this.description = description;
		this.latitude = latitude;
		this.longitude = longitude;
		this.name =  name;
		this.status = status;
		this.id = id;
		this.dueTime=dueTime;
		this.dueDate=dueDate;
		
		this.reasonDetails=reasonDetails;
		this.reasonType=reasonType;
		this.reportLatitude=reportLatitude;
		this.reportLongitude=reportLongitude;
		this.signatureFile=signatureFile;
		
	}
	public History(){
		
	}
	public String getAddress(){
		return address;
	}
	public void setAddress(String address){
		this.address = address;
	}
	public String getComment(){
		return comment;
	}
	public void setComment(String comment){
		this.comment = comment;
	}
	public String getContactNo(){
		return contactNo;
	}
	public void setContactNo(String contactNo){
		this.contactNo = contactNo;
	}
	public String getDescription(){
		return description;
	}
	public void setDescription(String description){
		this.description = description;
	}
	public String getLatitude(){
		return latitude;
	}
	public void setLatitude(String latitude){
		this.latitude = latitude;
	}
	public String getLongitude(){
		return longitude;
	}
	public void setLongitude(String longitude){
		this.longitude = longitude;
	}
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name = name;
	}
	public String getStatus(){
		return status;
	}
	public void setStatus(String status){
		this.status = status;
	}
	public String getId(){
		return id;
	}
	public void setId(String id){
		this.id = id;
	}
	public String getDueTime()
	{
		return dueTime;
	}
	public void setDueTime(String time)
	{
		this.dueTime=dueTime;
	}
	
	public String getDueDate()
	{
		return dueDate;
	}
	public void setDueDate(String dueDate)
	{
		this.dueDate=dueDate;
	}
	
	public String getReasonType()
	{
		return reasonType;
	}
	public void setReasonType(String reasonType)
	{
		this.reasonType=reasonType;
	}
	
	public String getReasonDetails()
	{
		return reasonDetails;
	}
	public void setReasonDetails(String reasonDetails)
	{
		this.reasonDetails=reasonDetails;
	}
	
	public String getReportLatitude()
	{
		return reportLatitude;
	}
	public void setReportLatitude(String reportLatitude)
	{
		this.reportLatitude=reportLatitude;
	}
	
	public String getReportLongitude()
	{
		return reportLongitude;
	}
	public void setReportLongitude(String reportLongitude)
	{
		this.reportLongitude=reportLongitude;
	}
	
	public String getSignature()
	{
		return signatureFile;
	}
	public void setSignature(String signature)
	{
		this.signatureFile=signature;
	}
}
