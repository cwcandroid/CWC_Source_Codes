package com.cwc.courierclient;

import java.util.ArrayList;

public class CommonStatic {

	public final static String LOGIN_URL="http://test.sentisol.com/cwc/index.php/android/login?";
	public final static String REGISTER_URL="http://test.sentisol.com/cwc/index.php/android/register?";
	
	public final static String TASK_LIST_URL="http://192.168.1.2/cwc/index.php/android/getTaskList?";
	public final static String HISTORY_URL="http://192.168.1.2/cwc/index.php/android/getTaskHistory?";
	
	public final static String pName="com.cwc.courierclient";
	public static ArrayList<Task> taskList;
	public static ArrayList<History> historyList;
	public static Task taskObject;
	public static History historyObj;
	public static Report reportObj;
		public CommonStatic(){
			
		}
		
	public ArrayList<History> getHistoryList()
	{
		return historyList;
	}
	public void setHistoryList(ArrayList<History> historyList)
	{
		this.historyList=historyList;
	}
	
	public ArrayList<Task> getTaskList()
	{
		return taskList;
	}
	public void setTaskList(ArrayList<Task> taskList){
		//taskList = new ArrayList<Task>();
		CommonStatic.taskList = taskList;
	}
	
	public void setTask(Task taskObject)
	{
		CommonStatic.taskObject = taskObject;
	}
	public History getHistory()
	{
		return historyObj;
	}
	
	public void setHistory(History historyObj)
	{
		CommonStatic.historyObj= historyObj;
	}
	public Task getTask()
	{
		return taskObject;
	}


}
