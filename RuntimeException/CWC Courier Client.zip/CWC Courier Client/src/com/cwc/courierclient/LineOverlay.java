/**
 * 
 */
package com.cwc.courierclient;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

/**
 * @author Erfan
 *
 */
public class LineOverlay extends Overlay {
	GeoPoint gp1,gp2;
	
	public LineOverlay(GeoPoint gp1,GeoPoint gp2){
		this.gp1 = gp1;
		this.gp2 = gp2;
	}
	
	@Override
	public boolean draw(Canvas canvas, MapView mapView, boolean shadow,
			long when) {
		// TODO Auto-generated method stub
		
		Projection projection = mapView.getProjection();
		Paint paint = new Paint();
		Point point1 = new Point();
		Point point2 = new Point();
		projection.toPixels(gp1, point1);
		projection.toPixels(gp2, point2);
		
		paint.setColor(Color.RED);
		paint.setStrokeWidth(5);
		paint.setAlpha(120);
		
		canvas.drawLine(point1.x,point1.y, point2.x, point2.y, paint);
		
		return super.draw(canvas, mapView, shadow, when);
	}

}
