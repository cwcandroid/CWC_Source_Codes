package com.cwc.courierclient;

import java.util.ArrayList;

import android.app.ActivityGroup;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;

public class HistoryGroup extends ActivityGroup {
	public static HistoryGroup group;
	private static ArrayList<View> history;
	
	Context con;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.history = new ArrayList<View>();
		group = this;
		con=this;

		// Start the root activity withing the group and get its view
		View view = getLocalActivityManager().startActivity(
				"HistoryActivity",
				new Intent(this, HistoryActivity.class)
						.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
				.getDecorView();

		// Replace the view of this ActivityGroup
		replaceView(view);

	}
	
	public void replaceView(View v) {
		// Adds the old one to history
		history.add(v);
		Log.v("History size:", history.size()+"");
		// Changes this Groups View to the new View.
		setContentView(v);
	}
	public void replaceView(View v,String s)
	{
		setContentView(v);
	}
	public static void historySizeDecrese()
	{
		history.remove(history.size() - 1);
		Log.v("history size:", history.size()+"");
	}

	public void back() {
		Log.v("history.size()", history.size()+"");
		if (history.size() > 1) {
			history.remove(history.size() - 1);
			setContentView(history.get(history.size() - 1));
		}
		else 
		{
			Log.e("history.size() finish:", history.size()+"");
			finish();
		}
	}
//
//	
//	
    public void onBackPressed() {
		//finish();
		HistoryGroup.group.back();
        //return;
    }
    
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	HistoryGroup.group.back();   
	    }
	    return true;
	}

}
