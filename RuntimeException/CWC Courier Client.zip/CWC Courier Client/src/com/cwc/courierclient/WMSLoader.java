package com.cwc.courierclient;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.google.android.maps.GeoPoint;

public class WMSLoader {
 public static String TAG = "WMSLoader";
 
 public Bitmap loadMap(int width, int height, GeoPoint ul, GeoPoint lr) {
  URL url = null;
     
  try {
   url = new URL(String.format("http://174.123.33.202:8082/geoserver/gwc/service/wms?LAYERS=Egypt_allinone&FORMAT=image/gif&TILED=true&TILESORIGIN=25.06213671874999,25.912181118327&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&EXCEPTIONS=application/vnd.ogc.se_inimage&SRS=EPSG:4326&BBOX=25.3125,28.125,28.125,30.9375&WIDTH=256&HEIGHT=256" 
     ));
  } catch (MalformedURLException e) {
   Log.e(TAG, e.getMessage());
  }
  InputStream input = null;
  try {
   input = url.openStream();
  } catch (IOException e) {
   Log.e(TAG, e.getMessage());
  }
  return BitmapFactory.decodeStream(input);
 }
}