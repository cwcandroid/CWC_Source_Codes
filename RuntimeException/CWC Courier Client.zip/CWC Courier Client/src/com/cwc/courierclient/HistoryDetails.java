package com.cwc.courierclient;

import java.util.Calendar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class HistoryDetails extends Activity {
	String itemName,itemId, itemDescription;
	String receiverName,receiverAddress,contactNo;
	
	Button reportBtn, infoBtn, viewOnMapBtn, contactBtn;
	TextView itemNameTxt,itemIdTxt, itemDescriptionTxt;
	TextView receiverAddressTxt,receiverNameTxt;
	History historyObj;
	int day,mon,yar,mHour,mMin;
	String date = "",sDay = "",sMon = "",sYar = "",userName = "";

	Context con;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.history);
		
		con=getParent();
		CommonStatic obj=new CommonStatic();
		historyObj=obj.getHistory();
		itemName=historyObj.getName();
		itemId=historyObj.getId();
		itemDescription=historyObj.getDescription();
		receiverName=historyObj.getName();
		receiverAddress=historyObj.getAddress();
		contactNo=historyObj.getContactNo();
		
		itemNameTxt=(TextView)findViewById(R.id.itemNameTxt);
		itemIdTxt=(TextView)findViewById(R.id.itemIdTxt);
		itemDescriptionTxt=(TextView)findViewById(R.id.itemDescriptionTxt);
		receiverNameTxt=(TextView)findViewById(R.id.receiverNameTxt);
		receiverAddressTxt=(TextView)findViewById(R.id.receiverAddressTxt);
//		time = (TextView)findViewById(R.id.txthistoryDelivery);
		
		reportBtn=(Button)findViewById(R.id.reportBtn);
		infoBtn=(Button)findViewById(R.id.infoBtn);
		viewOnMapBtn=(Button)findViewById(R.id.viewOnMapBtn);
		contactBtn=(Button)findViewById(R.id.contactBtn);
		
		contactBtn.setClickable(false);
		
		Calendar cal = Calendar.getInstance();
		day = cal.get(Calendar.DATE);
		mon = cal.get(Calendar.MONTH);
		yar = cal.get(Calendar.YEAR);
		sDay = ""+day;
		if(sDay.length() == 1)
			sDay = "0"+sDay;
		sMon = ""+(mon+1);
		if(sMon.length() == 1)
			sMon = "0"+sMon;
		sYar = ""+yar;
		date = sDay+"-"+sMon+"-"+sYar;
        mHour = cal.get(Calendar.HOUR);
        mMin = cal.get(Calendar.MINUTE);
        //String showTime = date+"  "+mHour
		setInfo();
		
		
		/*reportBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent i=new Intent(con,ReportTaskActivity.class);
				View v= TaskGroup.group.getLocalActivityManager()
						.startActivity("ReportTaskActivity", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
						.getDecorView();
				TaskGroup.group.replaceView(v);
			}
		});*/
		
		viewOnMapBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent i=new Intent(con,MapForHistory.class);
				i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				
				CommonStatic.historyObj=historyObj;
				View v=HistoryGroup.group.getLocalActivityManager()
						.startActivity("MapForHistory", i)
						.getDecorView();
				HistoryGroup.group.replaceView(v);
			}
		});
		
		/*contactBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String number="tel:"+contactNo;
				Intent i=new Intent(Intent.ACTION_CALL,Uri.parse(number));
				startActivity(i);
			}
		});*/
		
		infoBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				setInfo();
			}
		});	
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	HistoryGroup.group.back();
	        return true;
	    }

	    return super.onKeyDown(keyCode, event);
	}
	
	private void setInfo()
	{
		itemNameTxt.setText(itemName);
		itemIdTxt.setText(itemId);
		itemDescriptionTxt.setText(itemDescription);
		receiverNameTxt.setText(receiverName);
		receiverAddressTxt.setText(receiverAddress);
		
		contactBtn.setText(contactNo);
	}

}
