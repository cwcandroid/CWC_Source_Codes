package com.cwc.courierclient;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class MapForSinglePOI extends MapActivity {
	MapView mapView;
	int day,mon,yar;
	String date = "",sDay = "",sMon = "",sYar = "";
	ArrayList<Task> taskList;
	CommonStatic com;
	
	Context con;
	/** Called when the activity is first created. */
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gps_map);
        //taskList = new ArrayList<Task>();
       // CommonStatic com = new CommonStatic();
       // taskList = com.getTaskList();
       // Log.d("GPSMap", "SizeOfTaskList: "+taskList.size()+" *******");
        con=getParent();
        
        mapView = (MapView)findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
        mapView.setClickable(true);
        mapView.setEnabled(true);
		
        LocationManager locMan = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        LocationListener listener = new MyLocationListener();
        locMan.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);
        
        Location loc = locMan.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        
        //for(int i=0;i<taskList.size();i++){
        	com = new CommonStatic();
        	Task task = new Task();
        	//task = taskList.get(i);
        	task = com.getTask();
        	double lati=0,longi=0;
        	Log.d("GPSMapSet", "Latitude: "+task.getLatitude().toString()+", Longitude: "+task.getLongitude().toString());
        	lati = Double.parseDouble(task.getLatitude().toString());
        	longi = Double.parseDouble(task.getLongitude().toString());
        	GeoPoint gp = new GeoPoint((int)lati*1000000, (int)longi*1000000);
        	Drawable draw = getResources().getDrawable(R.drawable.map_marker);
        	MyItemizedOverlay overlay = new MyItemizedOverlay(draw, con);
        	OverlayItem item = new OverlayItem(gp, task.getName(), task.getAddress());
        	overlay.addItem(item);
        	mapView.getOverlays().add(overlay);
        //}
	}
	
    public class MyLocationListener implements LocationListener
    {

		@Override
		public void onLocationChanged(Location loc) {
			// TODO Auto-generated method stub
	        GeoPoint gp = new GeoPoint((int)loc.getLatitude()*1000000, (int)loc.getLongitude()*1000000);
	        mapView.getController().animateTo(gp);
	        
	        Drawable icon = getResources().getDrawable(R.drawable.map_marker);
	        MyItemizedOverlay overlay = new MyItemizedOverlay(icon, MapForSinglePOI.this);
	        OverlayItem item = new OverlayItem(gp, "My location", "I am here");
	        overlay.addItem(item);
	        
	        mapView.getOverlays().add(overlay);
			
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}
    	
    }

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	TaskGroup.group.back();   
	    }
	    return true;
	}

}
