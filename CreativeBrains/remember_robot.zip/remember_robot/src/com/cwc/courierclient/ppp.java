package com.cwc.courierclient;

import com.jayway.android.robotium.solo.Solo;
import android.test.ActivityInstrumentationTestCase2;

@SuppressWarnings("unchecked") 
public class ppp extends ActivityInstrumentationTestCase2{ 

	private static final String TARGET_PACKAGE_ID="com.cwc.courierclient"; 
	private static final String LAUNCHER_ACTIVITY_FULL_CLASSNAME="com.cwc.courierclient.CWCCourierClientLoginActivity"; 
	private static Class launcherActivityClass; 

	static{ 
		try { 
			launcherActivityClass=Class.forName(LAUNCHER_ACTIVITY_FULL_CLASSNAME); 
		} catch (ClassNotFoundException e){ 
			throw new RuntimeException(e); 
		} 
	}
	public ppp()throws ClassNotFoundException{ 
		super(TARGET_PACKAGE_ID,launcherActivityClass); 
	}
	
	 private Solo solo; 

	 @Override protected void setUp() throws Exception { 
	 solo = new Solo(getInstrumentation(),getActivity()); 
	 }
	 
	 
	 public void test2(){
		 //solo.clickOnButton("Login");
		 solo.clickOnButton("Register");
		 solo.enterText(0, "rabby"); //USERNAMW
		 solo.enterText(1, "123456"); //PASS
		 solo.enterText(2, "rabby@yahoo.com"); //EMAIL
		 solo.enterText(3, "123456"); //CON
		 
		 
		 solo.clickOnButton("Submit");
		 solo.sleep(5000);
		 solo.clickOnText("OK");
	 }
	 
	 public void testDisplayBlackBox(){ 
		//Enter any integer/decimal value for first editfield, we are writing 10 

		 /*solo.enterText(1, "Baal");
		 solo.enterText(0, "20");
		 solo.enterText(2, "100");
		 
		 solo.clickOnButton(0); //click on '+'
		 solo.sleep(500);
		 
		 solo.clickOnButton(1); //click on 'right'
		 solo.sleep(500);
		 
		 solo.enterText(0, "agora");
		 solo.clickOnButton("Proceed");
		 solo.sleep(500);
		 
		 solo.clickOnButton("Accept");
		 solo.sleep(9000);*/
		 
		 solo.enterText(0, "123456");
		 solo.enterText(1, "cwcuser1");
		 solo.clickOnCheckBox(0);
		 solo.clickOnButton("Login");
		 
		 solo.clickOnText("History");
		 
		 solo.sleep(9000);
		 
	}

	 @Override
	 public void tearDown() throws Exception {
		 solo.finishOpenedActivities();
	 }
}


