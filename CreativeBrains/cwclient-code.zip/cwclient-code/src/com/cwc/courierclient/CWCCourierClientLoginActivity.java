package com.cwc.courierclient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.loopj.android.http.*;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class CWCCourierClientLoginActivity extends Activity {
	Button btnLogin, btnRegister;
	EditText edtxName,edtxPassword;
	final String USERNAME_KEY="username";
	final String PASSWORD_KEY="password";
	final String SHARED_PREF_NAME="shared_pref";
	CheckBox rememberMeBox;
	ProgressDialog progressView;
	Context ctx;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        ctx=getApplicationContext();
        initViewItems();
        restorePreferences();
        btnLogin.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TO DO: User input validation
				// TO DO: Client Authentication and handle different error cases
				login();
				
			}
		});
        
        btnRegister.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				register();
				
			}
		});
        
        
        
    }
    
    private void restorePreferences() {
		SharedPreferences settings = getSharedPreferences(SHARED_PREF_NAME, 0);
		String username=settings.getString(USERNAME_KEY,"");
		String password=settings.getString(PASSWORD_KEY,"");
		if(!(username.equals("")||password.equals("")))
		{
			edtxName.setText(username);
        	edtxPassword.setText(password);
		}
	}
    
    private void saveToPreferences()
    {
    	SharedPreferences settings = getSharedPreferences(SHARED_PREF_NAME, 0);
    	final Editor edit=settings.edit();
        edit.putString(USERNAME_KEY, edtxName.getText().toString().trim());
        edit.putString(PASSWORD_KEY, edtxPassword.getText().toString().trim());
        edit.commit();
    }

	private void initViewItems() {
		btnLogin=(Button)findViewById(R.id.loginButton);
        btnRegister=(Button)findViewById(R.id.regButton);
        edtxName=(EditText)findViewById(R.id.userNameBox);
        edtxPassword=(EditText)findViewById(R.id.passWordBox);
        rememberMeBox=(CheckBox)findViewById(R.id.rememberMeCheckBox);
        progressView=new ProgressDialog(ctx);
	}
    
    void login()
    {
    	final String username = edtxName.getText().toString().trim();
    	String password = edtxPassword.getText().toString().trim();
    	if(!(username.equals("") || password.equals("")))
    	{
    		//SAVE THE LOGIN DATA WHEN REMEMBER ME IS CHECKED.
    		if(rememberMeBox.isChecked())
    			saveToPreferences();
    		

    		//
	    	String url ="http://test.sentisol.com/cwc/index.php/android/login?username="+username+"&password="+password+"&returnType=json"; 
	    
	    	AsyncHttpClient client = new AsyncHttpClient();
			client.get(url,  new AsyncHttpResponseHandler() {
	            @Override
	            public void onSuccess(String response) {
	            	String status = null;
	            
	            	try {
	            		
						JSONObject obj = new JSONObject(response);
				
						status = obj.getString("status");
					
					} catch (JSONException e) {
				
						e.printStackTrace();
					}
					if(status.equals("true")){
						Intent i=new Intent(CWCCourierClientLoginActivity.this,BackgroundActivity.class);
						i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						i.putExtra("username", username);
						startActivity(i);
						
					}else{
						showAlert("Hay Man!","username or password is incorrect");
					}
	            
	            }
	            @Override
	            public void onStart() {
	                // Initiated the request
	            	//showAlert("respons","started");
	            }
	            @Override
	            public void onFailure(Throwable e) {
	                // Response failed :(
	            	showAlert("Crap!","The system somehow failed to log you in!");
	            }

	            @Override
	            public void onFinish() {
	                // Completed the request (either success or failure)
	            	//showAlert("respons","finished");
	            }
	        });

			
    	}
    	else
    	{
    		showAlert("Hey Man!","You should enter some value!");
    	}
    	
    }
    
    void register()
    {
    	Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientRegistrationActivity.class);
		startActivity(i);
		
    }
    public void showAlert(String title,String text)
    {
    	//ask user he wants to delete or not
		 AlertDialog.Builder builder = new AlertDialog.Builder(this);
		 builder.setMessage(text);
		 builder.setTitle(title);
		 builder.setIcon(R.drawable.alert_icon);
		 builder.setNeutralButton("OK", new OnClickListener()
		 {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				dialog.cancel();
			}
			 
		 });
		 AlertDialog alert = builder.create();
		 alert.show();
    }

}