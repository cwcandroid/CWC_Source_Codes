package com.cwc.courierclient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class TaskMapperActivity extends MapActivity{
	List<Overlay> mapOverlays;
	ArrayList pushpin;
	MapView mapView;
	MyDatabase db;

	Cursor c;
	overlayForMap itemizedoverlay;
	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return true;
	}
	
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mapview);
		mapView = (MapView) findViewById(R.id.mapview);
	    mapView.setBuiltInZoomControls(true);
		mapOverlays = mapView.getOverlays();
	    Drawable drawable = this.getResources().getDrawable(R.drawable.ic_launcher);
	    itemizedoverlay = new overlayForMap(drawable,this.getApplicationContext());
	    db = new MyDatabase(this);
	     
	    
	    //ADDING PUSHPIN ON MAP
	    
Log.d("in map", " before forloop");
	    
		/*
	    for(int i=0;i<DataCommunicator.list.size();i++){
	    	HashMap<String, String> temp=DataCommunicator.list.get(i);
	    	
	    	//TASK NAME
	    	String name= temp.get(DataCommunicator.NAME_KEY);
	    	//ADDRESS
	    	String address = temp.get(DataCommunicator.ADDRESS_KEY);
	    	
	    	//GETTING LATITUDE AND LONGITUDE FROM STRING TO FLOAT TO INTIGER
	    	
	    	String Stringlatitude = temp.get(DataCommunicator.LATITUDE_KEY);
	    	String Stringlongititude =temp.get(DataCommunicator.LONGITUDE_KEY);
	    	float floatlatitude = Float.valueOf(Stringlatitude);
	    	int latitude = (int) (floatlatitude*1000000);
	    	float floatlongitude =Float.valueOf(Stringlongititude);
	    	int longitude =(int) (floatlongitude*1000000);
	    	
	    	Log.d("in map", name +" "+address+" "+latitude+" "+longitude);
	    	
	    	GeoPoint point =new GeoPoint(latitude,longitude);
	    	OverlayItem overlayitem = new OverlayItem(point,name,address);
	    	itemizedoverlay.addOverlay(overlayitem);
	    	mapOverlays.add(itemizedoverlay);
	    }
		
		*/

	db.open();
	
	c = db.getAllItem();
	int numOfItem = c.getCount();
	
	
	for(int i=0;i<numOfItem;i++){
		//HashMap<String, String> temp=DataCommunicator.list.get(i);
		
		//TASK NAME
		String name= c.getString(c.getColumnIndex("item_name"));
		//ADDRESS
		String task_id = c.getString(c.getColumnIndex("item_id"));
		
		//GETTING LATITUDE AND LONGITUDE FROM STRING TO FLOAT TO INTIGER
		
		String Stringlatitude = c.getString(c.getColumnIndex("lat"));
		String Stringlongititude =c.getString(c.getColumnIndex("lng"));
		float floatlatitude = Float.valueOf(Stringlatitude);
		int latitude = (int) (floatlatitude*1000000);
		float floatlongitude =Float.valueOf(Stringlongititude);
		int longitude =(int) (floatlongitude*1000000);
		
		Log.d("in map", name +" "+task_id+" "+latitude+" "+longitude);
		
		GeoPoint point =new GeoPoint(latitude,longitude);
		OverlayItem overlayitem = new OverlayItem(point,name,task_id);
		itemizedoverlay.addOverlay(overlayitem);
		mapOverlays.add(itemizedoverlay);
		
		c.moveToNext();
	}
	
	db.close();
	    
	    	}
	/*public void onStart()
	{
		mapOverlays = mapView.getOverlays();
	    Drawable drawable = this.getResources().getDrawable(R.drawable.ic_launcher);
	    itemizedoverlay = new overlayForMap(drawable,this.getApplicationContext());
	    Log.d("in map", " before forloop");
	    
	    for(int i=0;i<DataCommunicator.list.size();i++){
	    	HashMap<String, String> temp=DataCommunicator.list.get(i);
	    	
	    	//TASK NAME
	    	String name= temp.get(DataCommunicator.NAME_KEY);
	    	//ADDRESS
	    	String address = temp.get(DataCommunicator.ADDRESS_KEY);
	    	
	    	//GETTING LATITUDE AND LONGITUDE FROM STRING TO FLOAT TO INTIGER
	    	
	    	String Stringlatitude = temp.get(DataCommunicator.LATITUDE_KEY);
	    	String Stringlongititude =temp.get(DataCommunicator.LONGITUDE_KEY);
	    	float floatlatitude = Float.valueOf(Stringlatitude);
	    	int latitude = (int) (floatlatitude*1000000);
	    	float floatlongitude =Float.valueOf(Stringlongititude);
	    	int longitude =(int) (floatlongitude*1000000);
	    	
	    	Log.d("in map", name +" "+address+" "+latitude+" "+longitude);
	    	
	    	GeoPoint point =new GeoPoint(latitude,longitude);
	    	OverlayItem overlayitem = new OverlayItem(point,name,address);
	    	itemizedoverlay.addOverlay(overlayitem);
	    	mapOverlays.add(itemizedoverlay);
	    }
	}*/
}
