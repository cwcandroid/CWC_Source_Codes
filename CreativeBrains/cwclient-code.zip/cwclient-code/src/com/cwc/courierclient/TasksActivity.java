package com.cwc.courierclient;

import java.util.ArrayList;
import java.util.HashMap;
import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.SimpleAdapter;

public class TasksActivity extends ListActivity implements OnClickListener {
	
	private SimpleAdapter adapter;
	MyDatabase db;
	ArrayList<HashMap<String,String>> list =new ArrayList<HashMap<String,String>>();
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.taskview);
		db = new MyDatabase(this);
		initAdapter();
	}
	
	private void initAdapter() {
		adapter= new SimpleAdapter(
                this,
                list,
                R.layout.custom_list_row,
                new String[] {"item","address"},
                new int[] {R.id.nameOfItem,R.id.addressTextView}

                );
	}
	
	private void populateList()
	{
		db.open();
		
		Cursor c = db.getAllItem();
		
		int numOfItem = c.getCount();
		
		for(int i = 0; i < numOfItem ; i++){
		
			HashMap<String,String> temp=new HashMap<String,String>();
			temp.put(DataCommunicator.NAME_KEY, c.getString(c.getColumnIndex("item_name")));
			temp.put(DataCommunicator.TASK_ID_KEY, c.getString(c.getColumnIndex("item_id")));
			temp.put(DataCommunicator.ADDRESS_KEY, c.getString(c.getColumnIndex("address")));
			list.add(temp);
			
			
			c.moveToNext();
			
		}
		
		adapter.notifyDataSetChanged();
		
		db.close();
	}


	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}
}
