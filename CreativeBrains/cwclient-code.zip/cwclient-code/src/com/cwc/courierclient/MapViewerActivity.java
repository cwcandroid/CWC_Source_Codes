package com.cwc.courierclient;

public class MapViewerActivity {

}
