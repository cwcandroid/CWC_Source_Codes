package com.cwc.courierclient;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


public class DrawingActivity extends Activity {
	Context ctx;
	SingleTouchEventActivity drawingPane;
	ImageView image;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.drawingpane);
		//GET THE APP CONTEXT.
		ctx=getApplicationContext();
		
		try
		{
			drawingPane=new SingleTouchEventActivity(ctx,null);
			drawingPane.setBackgroundColor(Color.WHITE);
			drawingPane.setDrawingCacheEnabled(true);
			ViewGroup view=(ViewGroup)findViewById(R.id.drawingPaneHolder);
			view.addView(drawingPane);
			
		}catch(Exception ex)
		{
			Log.e(ex.getMessage().toString(), ex.getCause().toString());
		}
		
		image=(ImageView)findViewById(R.id.signatureImageView);
		
		Button saveButton=(Button)findViewById(R.id.saveDrawingButton);
		saveButton.setText("Save Signature");

		saveButton.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						Bitmap bt;
						bt=drawingPane.getDrawingCache();
						try {
							saveBitmap(bt);
							Toast.makeText(ctx, "Saved!",Toast.LENGTH_SHORT).show();
							finish();
						} catch (Exception ex) {
						    // TODO Auto-generated catch block
							   Toast.makeText(ctx, "Error occured:"+ex.getCause(),Toast.LENGTH_LONG).show();
						   }
					
						
					}
				});
		
		Button clearButton=(Button)findViewById(R.id.clearAllDrawingButton);
		clearButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				drawingPane.clearData();
				
			}
		});
		
		
		
		
	}
	
	
	public void saveBitmap(Bitmap bmp)
	{
		FileOutputStream fos;
		   try {
		    fos = openFileOutput("BITMAP_A", Context.MODE_PRIVATE);
		    bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
		    fos.close();
		   } catch (Exception ex) {
		    // TODO Auto-generated catch block
			   Toast.makeText(ctx, "Error occured:"+ex.getCause(),Toast.LENGTH_LONG);
			   
		   }
	}
	
	
	
}