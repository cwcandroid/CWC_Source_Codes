package com.cwc.courierclient;

import java.util.ArrayList;
import java.util.HashMap;

public class DataCommunicator 
{
	public static ArrayList<HashMap<String,String>> list=new ArrayList<HashMap<String,String>>();
	public static String ADDRESS_KEY="address";
	public static String TASK_ID_KEY="task_id";
	public static String COMMENTS_KEY="comments";
	public static String CONTACTNO_KEY="contactno";
	public static String DESCRIPTION_KEY="description";
	public static String LATITUDE_KEY="latitude";
	public static String LONGITUDE_KEY="longitude";
	public static String NAME_KEY="name";
	public static String STATUS_KEY="status";
	public static String DUETIME_KEY="duetime";

}
