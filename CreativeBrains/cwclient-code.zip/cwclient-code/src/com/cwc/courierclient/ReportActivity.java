package com.cwc.courierclient;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

public class ReportActivity extends Activity 
{
	Context ctx;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reportview);
		ctx=getApplicationContext();
	}
}
