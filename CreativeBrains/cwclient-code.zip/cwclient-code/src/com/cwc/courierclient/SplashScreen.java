package com.cwc.courierclient;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class SplashScreen extends Activity{
	protected boolean _active=true;
	protected int splashtime=3000;
	Activity current=this;
	
	@Override
	public void onCreate(Bundle icicle)
	{
		super.onCreate(icicle);
		
		setContentView(R.layout.splash);
		
		Thread splashThread=new Thread()
		{
			@Override
			public void run()
			{
				try
				{
					int waited=0;
					while(_active && (waited<splashtime))
					{
						sleep(100);
						waited+=100;
					}
				}
				catch(Exception ex)
				{}
				finally
				{
					finish();
					startActivity(new Intent(current,CWCCourierClientLoginActivity.class));
				}
			}
		};
		splashThread.start();
	}

}
