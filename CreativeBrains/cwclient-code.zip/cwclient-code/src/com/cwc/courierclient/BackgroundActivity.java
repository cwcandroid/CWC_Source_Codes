package com.cwc.courierclient;

import java.util.Calendar;
import java.util.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.loopj.android.http.*;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class BackgroundActivity extends Activity {
	//ArrayList<HashMap<String,String>> list;
	
	//MyDatabase db;
	 @Override
	    public void onCreate(Bundle savedInstanceState) 
	    {
	        super.onCreate(savedInstanceState);
	        
	        Bundle bundle = getIntent().getExtras();
	        //INIT THE LIST.
	       // list=new ArrayList<HashMap<String,String>>();
	        //GETTING THE USERNAME 
	        String username = bundle.getString("username");
	        
	        //db = new MyDatabase(this);
	        //GEETING DATE
	        Calendar c = Calendar.getInstance(); 
	        int date = c.get(Calendar.DATE);
	        int month = c.get(Calendar.MONTH);
	        month=month+1;
	        String monthstring;
	        if(month<10){
	        	monthstring = "0"+month;
	        }else{
	        	monthstring = ""+month;
	        }
	        int year = c.get(Calendar.YEAR);
	        
	        //URL
	        String url = "http://test.sentisol.com/cwc/index.php/android/getTaskList?username="+username+"&returnType=json&duedate="+date+"-"+monthstring+"-"+year;
	        
	        //String url = "http://test.sentisol.com/cwc/index.php/android/getTaskList?username=cwcuser1&returnType=json&duedate=28-01-2012";
	        Log.d("url", url);
	        
	        //GET DATA FROM SERVER
	        AsyncHttpClient client = new AsyncHttpClient();
			client.get(url,  new AsyncHttpResponseHandler() {
	            @Override
	            public void onSuccess(String response) {
	            
	           
	            	try {
	            			JSONArray array = new JSONArray(response);
	            			setData(array);
	            			
				
					
					} catch (JSONException e) {
				
						e.printStackTrace();
					}catch (Exception e) {
						e.printStackTrace();
					}
					
					//STARTING MAIN SCREAN 
					Intent i=new Intent(BackgroundActivity.this, CWCCourierClientMainScreenActivity.class);
					startActivity(i);
	            
	            }
	            @Override
	            public void onStart() {
	                
	            }
	            @Override
	            public void onFailure(Throwable e) {
	                
	            }

	            @Override
	            public void onFinish() {
	               
	            }
	            
	        });

	        
	        
	        
	        
	    }
	 private void setData(JSONArray array)
	 {
		 ArrayList<HashMap<String,String>> LocalList = new ArrayList<HashMap<String,String>>();
		 for(int i=0;i<array.length();i++)
		 {
			 
			 try {
				 //parsing json
				 JSONObject obj = array.getJSONObject(i);
				 String address = obj.getString(DataCommunicator.ADDRESS_KEY);
				 String task_id = obj.getString(DataCommunicator.TASK_ID_KEY);
				 String comments = obj.getString(DataCommunicator.COMMENTS_KEY);
				 String contactno = obj.getString(DataCommunicator.CONTACTNO_KEY);
				 String description = obj.getString(DataCommunicator.DESCRIPTION_KEY);
				 String latitude =obj.getString(DataCommunicator.LATITUDE_KEY);
				 String longitude = obj.getString(DataCommunicator.LONGITUDE_KEY);
				 String name = obj.getString(DataCommunicator.NAME_KEY);
				 String status = obj.getString(DataCommunicator.STATUS_KEY);
				 String duetime = obj.getString(DataCommunicator.DUETIME_KEY);
				 
				 /*
				 db.open();
				 
				 db.insertItemInfo(task_id, name, "", address, contactno, comments, latitude, longitude, status, duetime);
				 
				 db.close();
				 */
				 
				 //insert into list as hashmap
				 
				 HashMap<String, String> temp=new HashMap<String,String>();
				 temp.put(DataCommunicator.ADDRESS_KEY, address);
				 temp.put(DataCommunicator.COMMENTS_KEY, comments);
				 temp.put(DataCommunicator.CONTACTNO_KEY, contactno);
				 temp.put(DataCommunicator.DESCRIPTION_KEY, description);
				 temp.put(DataCommunicator.DUETIME_KEY, duetime);
				 temp.put(DataCommunicator.LATITUDE_KEY, latitude);
				 temp.put(DataCommunicator.LONGITUDE_KEY, longitude);
				 temp.put(DataCommunicator.NAME_KEY, name);
				 temp.put(DataCommunicator.STATUS_KEY, status);
				 temp.put(DataCommunicator.TASK_ID_KEY, task_id);
				 //ADD DATA TO LIST.
				 LocalList.add(temp);
			
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
		 }
		 //AT LAST PUT IT IN DATA COMMUNICATOR
		 DataCommunicator.list.addAll(LocalList);
		
	 }

}
