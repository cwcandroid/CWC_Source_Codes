package com.cwc.courierclient;

public class DetailTaskInfoActivity {
//SHOWS THE DETAILS OF A TASK
}
