package com.cwc.courierclient;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MyDatabase{

	private static final String TAG = "MyDatabase";

	/**
	 * Database Name
	 */
	private static final String DATABASE_NAME = "courier";

	/**
	 * Database Version
	 */
	private static final int DATABASE_VERSION = 1;

	/**
	 * Table Name
	 */
	private static final String DATABASE_TABLE_ITEM = "item";
	private static final String DATABASE_TABLE_REPORT="report"; 
	private static final String DATABASE_TABLE_ITEM_REPORT = "item_report";
	

	/**
	 * Table columns
	 */
	public static final String KEY_ITEM_ID = "item_id";
	public static final String KEY_ITEM_NAME = "item_name";
	public static final String KEY_RECEIVER_NAME = "receiver_name";
	public static final String KEY_ADDRESS = "address";
	public static final String KEY_STATUS = "status";
	public static final String KEY_MOBILE = "mobile";
	public static final String KEY_ISREPORTED="isReported";
	public static final String KEY_LAT = "lat";
	public static final String KEY_LNG = "lng";	
	public static final String KEY_REPORT_ID = "report_id";
	public static final String KEY_REPORT_TYPE = "report_type";	
	public static final String KEY_REPORT_DES = "des";
	public static final String KEY_SIGNATURE = "signature";
	public static final String KEY_COMMENT = "comment";
	public static final String KEY_DATE = "date";
	public static final String KEY_TIME="time";	

	/**
	 * Database creation sql statement
	 */
	
	//Table Storing ITEMs
	private static final String CREATE_TABLE_ITEM =
			"create table " + DATABASE_TABLE_ITEM + " ( " + KEY_ITEM_ID + " text primary key  , "
			+ KEY_ITEM_NAME + " text , " + KEY_RECEIVER_NAME +" text , "
			+ KEY_ADDRESS + " text , " + KEY_STATUS +" text , "
			+ KEY_MOBILE + " text , " + KEY_ISREPORTED +" integer , "
			+ KEY_LAT + " text , " + KEY_LNG +" text , "
			+ KEY_DATE + " text , " + KEY_COMMENT +" text ); ";
	
	//Table Storing Reports
	private static final String CREATE_TABLE_REPORT =
			"create table " + DATABASE_TABLE_REPORT + " ( " + KEY_REPORT_ID + " integer primary key autoincrement , "
					+ KEY_ITEM_ID + " text  , "
					+ KEY_REPORT_TYPE + " text , " + KEY_SIGNATURE + " blob , " + KEY_REPORT_DES + " text , "
			+ KEY_DATE + " text , " + KEY_TIME + " text ); ";
	
	/*
	//Table Relational
	private static final String CREATE_TABLE_ITEM_REPORT =
			"create table " + DATABASE_TABLE_ITEM_REPORT + " ( " + KEY_ITEM_ID + " text , "
			+ KEY_REPORT_ID + " integer autoincrement ); ";
	*/
	
		/**
	 * Context
	 */
	private final Context mCtx;

	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	/**
	 * Inner private class. Database Helper class for creating and updating database.
	 */
	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
		/**
		 * onCreate method is called for the 1st time when database doesn\'t exists.
		 */
		@Override
		public void onCreate(SQLiteDatabase db) {
			Log.i(TAG, "Creating DataBase: " + CREATE_TABLE_ITEM);
			db.execSQL(CREATE_TABLE_ITEM);
			db.execSQL(CREATE_TABLE_REPORT);
			//db.execSQL(CREATE_TABLE_ITEM_REPORT);	
			
			
			
			
			
		}
		
		/**
		 * onUpgrade method is called when database version changes.
		 */
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion);			
			
		}
	}

	/**
	 * Constructor - takes the context to allow the database to be
	 * opened/created
	 *
	 * @param ctx the Context within which to work
	 */
	public MyDatabase(Context ctx) {
		this.mCtx = ctx;
	}
	/**
	 * This method is used for creating/opening connection
	 * @return instance of MyDatabase
	 * @throws SQLException
	 */
	
	public MyDatabase open() throws SQLException {
		mDbHelper = new DatabaseHelper(mCtx);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}
	
	/**
	 * This method is used for closing the connection.
	 */
	
	public void close() {
		mDbHelper.close();
	}

	/**
	 * This method is used to create/insert new record
	 * @param name
	 * @param grade
	 * @return long
	 */
	public long insertItemInfo(String item_id, String item_name, String receiver_name, String address, String mobile, String comment, String lat, String lng, String status ) {
		
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_ITEM_ID, item_id);
		initialValues.put(KEY_ITEM_NAME, item_name);
		initialValues.put(KEY_RECEIVER_NAME, receiver_name);
		initialValues.put(KEY_ADDRESS, address);
		initialValues.put(KEY_MOBILE, mobile);
		initialValues.put(KEY_COMMENT, comment);
		initialValues.put(KEY_LAT, lat);
		initialValues.put(KEY_LNG, lng);	
		initialValues.put(KEY_STATUS, status);
		return mDb.insert(DATABASE_TABLE_ITEM, null, initialValues);
	}
	
	public long insertReportInfo(String item_id, int report_type, String report_description, byte[] signature, String date) {
		
	
		
		ContentValues initialValues = new ContentValues();
		
		initialValues.put(KEY_REPORT_TYPE, report_type);
		initialValues.put(KEY_REPORT_DES, report_description);
		initialValues.put(KEY_SIGNATURE, signature);
		initialValues.put(KEY_DATE, date);
			
		mDb.insert(DATABASE_TABLE_REPORT, null, initialValues);
		
		initialValues.put(KEY_ITEM_ID, item_id);
		return mDb.insert(DATABASE_TABLE_ITEM_REPORT, null, initialValues);
	}	
	
	
	
	/**
	 * This method will delete record.
	 * @param rowId
	 * @return boolean
	 */
	public boolean deleteItem(long rowId) {
		return mDb.delete(DATABASE_TABLE_ITEM, KEY_ITEM_ID + "=" + rowId, null) > 0;
	}
	
	public boolean deleteReport(long rowId) {
		return mDb.delete(DATABASE_TABLE_REPORT, KEY_REPORT_ID + "=" + rowId, null) > 0;
	}
	
	public boolean deleteItemReport(long rowId) {
		return mDb.delete(DATABASE_TABLE_ITEM_REPORT, KEY_ITEM_ID + "=" + rowId, null) > 0;
	}
	

	/**
	 * This method will return Cursor holding all the records.
	 * @return Cursor
	 */
	public Cursor getAllItem() {
		Cursor mCursor = mDb.rawQuery("Select * from " + DATABASE_TABLE_ITEM + " Where 1", null);
		if(mCursor.getCount()>0)
			mCursor.moveToFirst();
		return mCursor;
	}

	/**
	 * This method will return Cursor holding the specific record.
	 * @param id
	 * @return Cursor
	 * @throws SQLException
	 */
	public Cursor getItemById(String id) throws SQLException {
		Cursor mCursor = mDb.rawQuery("Select * from " + DATABASE_TABLE_ITEM + " Where " + KEY_ITEM_ID + " = '" + id + "' " , null);
		if (mCursor.getCount()>0) {
			mCursor.moveToFirst();
		}
		return mCursor;
		
	}	
	
	
	
	public Cursor getReportByItem(String item_id) throws SQLException {
		Cursor mCursor = mDb.rawQuery("Select * from " + DATABASE_TABLE_REPORT + " Where " + KEY_REPORT_ID + " = " 
										+ "( Select " + KEY_REPORT_ID + " FROM " + DATABASE_TABLE_ITEM_REPORT + " WHERE " 
											+ KEY_ITEM_ID + " = '" + item_id + "' )" , null);
		if (mCursor.getCount()>0) {
			mCursor.moveToFirst();
		}
		return mCursor;
		
	}
		
	
	/*
	 * @param type is 0 or 1,0 for item and 1 for shop
	 */
	
	public Cursor updateInfoWhenCompleted(String item_id, int checkCompleted) throws SQLException {
		Cursor mCursor = mDb.rawQuery("UPDATE " + DATABASE_TABLE_ITEM + " SET " + KEY_STATUS + " = '" + checkCompleted + "' where " + KEY_ITEM_ID + " = '" + item_id + "' ", null);
		if (mCursor.getCount()>0) {
			mCursor.moveToFirst();
		}
		return mCursor;
		
	}
	
	public Cursor updateInfoWhenReported(String item_id, int isReported) throws SQLException {
		Cursor mCursor = mDb.rawQuery("UPDATE " + DATABASE_TABLE_ITEM + " SET " + KEY_ISREPORTED + " = " + isReported + " where " + KEY_ITEM_ID + " = '" + item_id + "' ", null);
		if (mCursor.getCount()>0) {
			mCursor.moveToFirst();
		}
		return mCursor;
		
	}	

	
	
	/**
	 * This method will delete the whole Database
	 */
	public void deleteDatabase() {
	      mDbHelper.close();
	      mDb.close();
	      if (mCtx.deleteDatabase(DATABASE_NAME)) {
	        Log.d(TAG, "deleteDatabase(): database deleted.");
	      } else {
	        Log.d(TAG, "deleteDatabase(): database NOT deleted.");
	      }
	} 
	
	public void deleteAllItem(){
		
		mDb.rawQuery("DELETE FROM " + DATABASE_TABLE_ITEM , null);
		
	}
	
	public String returnItemQuery(){
		return this.CREATE_TABLE_ITEM;
	}
	
	public String returnReportQuery(){
		return this.CREATE_TABLE_REPORT;
		
	}
	
	/*
	public String returnItemReportQuery(){
		return this.CREATE_TABLE_ITEM_REPORT;
	}
	
	*/
}
