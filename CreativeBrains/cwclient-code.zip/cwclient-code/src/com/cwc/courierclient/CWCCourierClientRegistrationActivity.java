package com.cwc.courierclient;

import org.json.JSONException;
import org.json.JSONObject;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CWCCourierClientRegistrationActivity extends Activity{
	Button btnLogin, btnSubmit;
	EditText edtxUsername,edtxEmail,edtxPassword,edtxCnPassword;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		
		btnLogin=(Button)findViewById(R.id.homeButton);
		btnSubmit=(Button)findViewById(R.id.submitButton);
		
		edtxUsername=(EditText)findViewById(R.id.usernameInputBox);
		edtxEmail=(EditText)findViewById(R.id.emailnputBox);
		edtxPassword=(EditText)findViewById(R.id.registerPasswordBox);
		edtxCnPassword=(EditText)findViewById(R.id.confirmPasswordBox);
		
		btnLogin.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();			
			}
		});
		
		btnSubmit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				submited();
				// TO DO: user input validation
				// TO DO: Submit request for registration and handle different error cases
				/*
				Intent i=new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientLoginActivity.class);
				startActivity(i);
				*/
			}
		});
		
	}
	
	public void submited(){
		String username =edtxUsername.getText().toString().trim();
		String email = edtxEmail.getText().toString().trim();
		String password =edtxPassword.getText().toString().trim();
		String conPassword = edtxCnPassword.getText().toString().trim();
		if(!(username.equals("")||email.equals("")||password.equals("")||conPassword.equals(""))){
			
			if(password.equals(conPassword)){
				String url = "http://test.sentisol.com/cwc/index.php/android/register?username="+username+"&password="+password+"&returnType=json&email="+email;
				AsyncHttpClient client = new AsyncHttpClient();
				client.get(url,  new AsyncHttpResponseHandler() {
		            @Override
		            public void onSuccess(String response) {
		            	String status = null;
		            
		            	try {
		            		
							JSONObject obj = new JSONObject(response);
					
							status = obj.getString("status");
						
						} catch (JSONException e) {
					
							e.printStackTrace();
						}
						if(status.equals("Success")){
							showAlert("Registration successful!","You have successfully reistered.Now,you can Login.");
							
						}else{
							showAlert("Hay Man !","username or password is incorrect");
						}
		            
		            }
		            @Override
		            public void onStart() {
		                // Initiated the request
		            	//showAlert("respons","started");
		            }
		            @Override
		            public void onFailure(Throwable e) {
		                // Response failed :(
		            	showAlert("respons",e.getMessage());
		            }

		            @Override
		            public void onFinish() {
		                // Completed the request (either success or failure)
		            	//showAlert("respons","finished");
		            }
		        });
			}else{
				showAlert("What","password Doesnot Match ");
			}
			
			
		}else{
			showAlert("What","please fillup all the fields ");
		}
		
		
	}
	
	public void showAlert(String title,String text)
    {
    	//ask user he wants to delete or not
		 AlertDialog.Builder builder = new AlertDialog.Builder(this);
		 builder.setMessage(text);
		 builder.setTitle(title);
		 builder.setIcon(R.drawable.alert_icon);
		 builder.setNeutralButton("OK", new OnClickListener()
		 {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				dialog.cancel();
			}
			 
		 });
		 AlertDialog alert = builder.create();
		 alert.show();
    }

}
