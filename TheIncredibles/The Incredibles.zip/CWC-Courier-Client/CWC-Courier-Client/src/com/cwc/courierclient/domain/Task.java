package com.cwc.courierclient.domain;

import java.io.Serializable;
import java.util.Arrays;

/**
 * Author: sharafat
 * Date: 1/22/12 6:40 PM
 */
public class Task implements Serializable {
    public static final int STATUS_INCOMPLETE = 0;
    public static final int STATUS_COMPLETE = 1;
    public static final int STATUS_PENDING = 2;

    public static final int REASON_TYPE_NOT_DELIVERED = 0;
    public static final int REASON_TYPE_DELIVERED = 1;
    public static final int REASON_TYPE_ADDRESS_NOT_FOUND = 2;
    public static final int REASON_TYPE_RECIPIENT_ABSENT = 3;
    public static final int REASON_TYPE_OTHERS = 4;

    public int id;
    public int status;
    public String name;
    public String description;
    public String comments;
    public String contactno;
    public String address;
    public double latitude;
    public double longitude;
    public String duedate;
    public String duetime;

    public Integer reasontype;
    public String reasondetails;
    public Double reportlatitude;
    public Double reportlongitude;
    public byte[] signaturefile;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getContactno() {
        return contactno;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getDuedate() {
        return duedate;
    }

    public void setDuedate(String duedate) {
        this.duedate = duedate;
    }

    public Integer getReasontype() {
        return reasontype;
    }

    public void setReasontype(Integer reasontype) {
        this.reasontype = reasontype;
    }

    public String getReasondetails() {
        return reasondetails;
    }

    public void setReasondetails(String reasondetails) {
        this.reasondetails = reasondetails;
    }

    public Double getReportlatitude() {
        return reportlatitude;
    }

    public void setReportlatitude(Double reportlatitude) {
        this.reportlatitude = reportlatitude;
    }

    public Double getReportlongitude() {
        return reportlongitude;
    }

    public void setReportlongitude(Double reportlongitude) {
        this.reportlongitude = reportlongitude;
    }

    public byte[] getSignaturefile() {
        return signaturefile;
    }

    public void setSignaturefile(byte[] signaturefile) {
        this.signaturefile = signaturefile;
    }

    public String getDuetime() {
        return duetime;
    }

    public void setDuetime(String duetime) {
        this.duetime = duetime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Task task = (Task) o;

        if (id != task.id) {
            return false;
        }
        if (Double.compare(task.latitude, latitude) != 0) {
            return false;
        }
        if (Double.compare(task.longitude, longitude) != 0) {
            return false;
        }
        if (status != task.status) {
            return false;
        }
        if (address != null ? !address.equals(task.address) : task.address != null) {
            return false;
        }
        if (comments != null ? !comments.equals(task.comments) : task.comments != null) {
            return false;
        }
        if (contactno != null ? !contactno.equals(task.contactno) : task.contactno != null) {
            return false;
        }
        if (description != null ? !description.equals(task.description) : task.description != null) {
            return false;
        }
        if (duedate != null ? !duedate.equals(task.duedate) : task.duedate != null) {
            return false;
        }
        if (duetime != null ? !duetime.equals(task.duetime) : task.duetime != null) {
            return false;
        }
        if (!name.equals(task.name)) {
            return false;
        }
        if (reasondetails != null ? !reasondetails.equals(task.reasondetails) : task.reasondetails != null) {
            return false;
        }
        if (reasontype != null ? !reasontype.equals(task.reasontype) : task.reasontype != null) {
            return false;
        }
        if (reportlatitude != null ? !reportlatitude.equals(task.reportlatitude) : task.reportlatitude != null) {
            return false;
        }
        if (reportlongitude != null ? !reportlongitude.equals(task.reportlongitude) : task.reportlongitude != null) {
            return false;
        }
        if (!Arrays.equals(signaturefile, task.signaturefile)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = id;
        result = 31 * result + status;
        result = 31 * result + name.hashCode();
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (comments != null ? comments.hashCode() : 0);
        result = 31 * result + (contactno != null ? contactno.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        temp = latitude != +0.0d ? Double.doubleToLongBits(latitude) : 0L;
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = longitude != +0.0d ? Double.doubleToLongBits(longitude) : 0L;
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (duedate != null ? duedate.hashCode() : 0);
        result = 31 * result + (duetime != null ? duetime.hashCode() : 0);
        result = 31 * result + (reasontype != null ? reasontype.hashCode() : 0);
        result = 31 * result + (reasondetails != null ? reasondetails.hashCode() : 0);
        result = 31 * result + (reportlatitude != null ? reportlatitude.hashCode() : 0);
        result = 31 * result + (reportlongitude != null ? reportlongitude.hashCode() : 0);
        result = 31 * result + (signaturefile != null ? Arrays.hashCode(signaturefile) : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", status=" + status +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", comments='" + comments + '\'' +
                ", contactno='" + contactno + '\'' +
                ", address='" + address + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", duedate='" + duedate + '\'' +
                ", duetime='" + duetime + '\'' +
                ", reasontype=" + reasontype +
                ", reasondetails='" + reasondetails + '\'' +
                ", reportlatitude=" + reportlatitude +
                ", reportlongitude=" + reportlongitude +
                ", signaturefileLength=" + (signaturefile == null ? 0 : signaturefile.length) +
                '}';
    }
}
