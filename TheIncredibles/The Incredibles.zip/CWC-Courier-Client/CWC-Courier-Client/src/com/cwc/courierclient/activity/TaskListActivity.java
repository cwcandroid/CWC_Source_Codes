package com.cwc.courierclient.activity;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.service.TaskRepository;
import com.cwc.courierclient.utils.Dialogs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TaskListActivity extends ListActivity {
    public static final String SELECTED_TASK = "selected_task";
    public static final String FROM_TODAYS_TASK_LIST_ACTIVITY = "from_todays_task_list_activity";
    private static final int DIALOG_TASK_FETCHING_IN_PROGRESS = 0;

    private Handler updateTaskListHandler = new Handler() {
        public void handleMessage(Message message) {
            List<Task> taskList = TaskRepository.getTodaysTasks();
            setListAdapter(new TaskListAdapter(TaskListActivity.this, taskList));
            dismissDialog(DIALOG_TASK_FETCHING_IN_PROGRESS);

            Button mapTasksBtn = (Button) findViewById(R.id.map_tasks_btn);
            mapTasksBtn.setEnabled(taskList.size() > 0);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.task_list);

        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent = new Intent(getParent(), TaskDetailsActivity.class);
                intent.putExtra(FROM_TODAYS_TASK_LIST_ACTIVITY, true);
                intent.putExtra(SELECTED_TASK, (Serializable) getListAdapter().getItem(position));
                ((TabGroupActivity) getParent()).startChildActivity(
                        TaskDetailsActivity.class.getCanonicalName(), intent);
            }
        });

        findViewById(R.id.map_tasks_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getParent(), TasksOnMapActivity.class);
                ((TabGroupActivity) getParent()).startChildActivity(
                        TasksOnMapActivity.class.getCanonicalName(), intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (TaskRepository.isTodaysTasksInitialized()) {
            setListAdapter(new TaskListAdapter(this, TaskRepository.getTodaysTasks()));
        } else {
            setListAdapter(new TaskListAdapter(this, new ArrayList<Task>()));

            showDialog(DIALOG_TASK_FETCHING_IN_PROGRESS);
            TaskRepository.initializeTodaysTasks(this, updateTaskListHandler);
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_TASK_FETCHING_IN_PROGRESS:
                return Dialogs.buildIndeterminateProgressDialog(getParent(), R.string.fetching_tasks_progress_msg, true);
        }

        return null;
    }

}
