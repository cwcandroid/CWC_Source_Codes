package com.cwc.courierclient.activity;

import android.content.Intent;
import android.os.Bundle;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.service.TaskRepository;
import com.cwc.courierclient.utils.gmaps.GeneralMapUtils;
import com.cwc.courierclient.utils.gmaps.MapMarkerUtil;
import com.cwc.courierclient.utils.gmaps.OnMarkerBalloonTapListener;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

import java.util.List;

/**
 * Author: sharafat
 * Date: 1/25/12 2:42 PM
 */
public class TasksOnMapActivity extends MapActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_view);

        MapView mapView = (MapView) findViewById(R.id.mapView);
        mapView.setBuiltInZoomControls(true);
        GeneralMapUtils.centerMapToMyLocation(mapView, getResources());

        final List<Task> taskList = TaskRepository.getTodaysTasks();
        mapView.getOverlays().add(MapMarkerUtil.getMarkerOverlay(mapView, getResources(), taskList,
                new OnMarkerBalloonTapListener() {
                    @Override
                    public boolean onMarkerBalloonTapped(int index, OverlayItem overlayItem) {
                        Intent intent = new Intent(getParent(), TaskDetailsActivity.class);
                        intent.putExtra(TaskListActivity.SELECTED_TASK, taskList.get(index));
                        ((TabGroupActivity) getParent()).startChildActivity(
                                TaskDetailsActivity.class.getCanonicalName(), intent);
                        return true;
                    }
                }));
    }

    @Override
    protected boolean isRouteDisplayed() {
        return false;
    }
}
