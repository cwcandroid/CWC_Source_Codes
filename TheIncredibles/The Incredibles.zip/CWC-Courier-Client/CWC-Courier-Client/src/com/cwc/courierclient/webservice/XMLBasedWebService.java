package com.cwc.courierclient.webservice;

import android.content.Context;
import android.util.Log;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.exception.ServerConnectionException;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Author: sharafat
 * Date: 1/23/12 2:10 AM
 */
public class XMLBasedWebService extends WebService {

    public XMLBasedWebService(Context context) {
        super(context);
    }

    @Override
    Map<String, String> getResponse(String url) {
        return null;    //TODO: Implement
    }

    @Override
    List<Task> getTaskList(String url) throws SAXException, ParserConfigurationException, IOException {
        MyListHandler df = new MyListHandler();

        SAXParserFactory spf = SAXParserFactory.newInstance();
        SAXParser sp = spf.newSAXParser();
        XMLReader xr = sp.getXMLReader();
        xr.setContentHandler(df);
        InputSource is = new InputSource();
        is.setCharacterStream(new StringReader(getServerResponseBody(url)));
        xr.parse(is);

        return df.getTaskList();
    }

    private String getServerResponseBody(String url) throws ServerConnectionException {
        String response;

        try {
            HttpResponse httpResponse = new DefaultHttpClient().execute(new HttpGet(url));
            response = EntityUtils.toString(httpResponse.getEntity());
        } catch (IOException e) {
            throw new ServerConnectionException(e.getClass().getCanonicalName() + ": " + e.getMessage());
        }

        return response;
    }

    private class MyListHandler extends DefaultHandler {
        private List<Task> taskList = new ArrayList<Task>();
        Task currentTask;
        String currentElement;
        StringBuffer content;
        Field field = null;
        Class<?> c;

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            if ("node".equalsIgnoreCase(localName)) {
                return;
            }
            if ("task".equalsIgnoreCase(localName)) {
                currentTask = new Task();
                c = currentTask.getClass();
            } else {
                currentElement = localName;
                content = new StringBuffer("");
            }
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            content.append(ch, start, length);
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if ("task".equalsIgnoreCase(localName)) {
                taskList.add(currentTask);
                return;
            } else if ("node".equalsIgnoreCase(localName)) {
                return;
            }
            try {
                Log.d(getClass().getCanonicalName(), localName);
                field = c.getDeclaredField("time".equalsIgnoreCase(localName) ? "duetime" : currentElement);
                Log.d(getClass().getCanonicalName(), "Field name: " + field.getName());
            } catch (SecurityException e) {
                e.printStackTrace();
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            }

            String elementContent = (content.length() == 0) ? null : content.toString();

            if (field.getType() == Integer.TYPE) {
                try {
                    Log.d(getClass().getCanonicalName(), " Type: " + field.getType().getName());
                    field.set(currentTask, Integer.parseInt(elementContent));
                } catch (NumberFormatException e) {

                    e.printStackTrace();
                } catch (IllegalArgumentException e) {

                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    try {
                        Log.d(getClass().getCanonicalName(), "Trying again...");
                        field.setInt(currentTask, Integer.parseInt(elementContent));
                    } catch (IllegalAccessException e1) {
                        e1.printStackTrace();
                    }
                    e.printStackTrace();
                }

            } else if (field.getType() == Double.TYPE) {
                try {
                    Log.d(getClass().getCanonicalName(), " Type: " + field.getType().getName());
                    field.set(currentTask, Double.parseDouble(elementContent));
                } catch (IllegalArgumentException e) {

                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    try {
                        Log.d(getClass().getCanonicalName(), "Trying again...");
                        field.setDouble(currentTask, Double.parseDouble(elementContent));
                    } catch (IllegalAccessException e1) {
                        e1.printStackTrace();
                    }
                    e.printStackTrace();
                }
            } else if (field.getType() == String.class) {
                try {
                    Log.d(getClass().getCanonicalName(), " Type: " + field.getType().getName());
                    field.set(currentTask, elementContent);
                } catch (IllegalArgumentException e) {

                    e.printStackTrace();
                } catch (IllegalAccessException e) {

                    e.printStackTrace();
                }
            }
        }

        public List<Task> getTaskList() {
            return taskList;
        }
    }

}
