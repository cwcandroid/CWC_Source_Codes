package com.cwc.courierclient.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.service.TaskService;
import com.cwc.courierclient.utils.chart.LineChart;
import com.cwc.courierclient.utils.chart.LineChartLineElement;
import org.achartengine.GraphicalActivity;
import org.achartengine.chart.PointStyle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PerformanceActivity extends TabGroupActivity {
    private TaskService taskService;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        taskService = new TaskService(this);

//        TaskRepository.insertDummyTasksInDb(this);

        int noOfDaysForRetrievingCounts = Integer.parseInt(getString(R.string.no_of_days_for_measuring_performance));
        List<LineChartLineElement> lineElements = prepareTaskCountsForAllTaskStatuses(noOfDaysForRetrievingCounts);

        LineChart lineChart = new LineChart(lineElements, getString(R.string.chart_name_first_part) + " "
                + noOfDaysForRetrievingCounts + " " + getString(R.string.chart_name_last_part),
                getString(R.string.x_axis_label), getString(R.string.y_axis_label));
        Intent intent = lineChart.execute(this);
        this.startChildActivity(GraphicalActivity.class.getCanonicalName(), intent);
    }

    private List<LineChartLineElement> prepareTaskCountsForAllTaskStatuses(int noOfDaysForRetrievingCounts) {
        List<LineChartLineElement> lineElements = new ArrayList<LineChartLineElement>();

        LineChartLineElement completeTasksLine = prepareTaskCounts(Task.STATUS_COMPLETE, noOfDaysForRetrievingCounts);
        completeTasksLine.setLineName(TaskService.getStatusText(this, Task.STATUS_COMPLETE));
        completeTasksLine.setLineColor(Color.GREEN);
        completeTasksLine.setPointStyle(PointStyle.CIRCLE);
        lineElements.add(completeTasksLine);

        LineChartLineElement incompleteTasksLine = prepareTaskCounts(Task.STATUS_INCOMPLETE, noOfDaysForRetrievingCounts);
        incompleteTasksLine.setLineName(TaskService.getStatusText(this, Task.STATUS_INCOMPLETE));
        incompleteTasksLine.setLineColor(Color.RED);
        incompleteTasksLine.setPointStyle(PointStyle.CIRCLE);
        lineElements.add(incompleteTasksLine);

        LineChartLineElement pendingTasksLine = prepareTaskCounts(Task.STATUS_PENDING, noOfDaysForRetrievingCounts);
        pendingTasksLine.setLineName(TaskService.getStatusText(this, Task.STATUS_PENDING));
        pendingTasksLine.setLineColor(Color.YELLOW);
        pendingTasksLine.setPointStyle(PointStyle.CIRCLE);
        lineElements.add(pendingTasksLine);

        return lineElements;
    }

    private LineChartLineElement prepareTaskCounts(int status, int noOfDaysForRetrievingCounts) {
        Object[] taskCounts = getTaskCounts(status, noOfDaysForRetrievingCounts);
        return new LineChartLineElement((Date[]) taskCounts[0], (double[]) taskCounts[1]);
    }

    private Object[] getTaskCounts(int status, int noOfDaysForRetrievingCounts) {
        List<Object[]> datesWithTaskCountsList =
                taskService.findTaskCountsPerDayByStatusAndNoOfDaysService(status, noOfDaysForRetrievingCounts);

        String[] datesAsStrings = new String[datesWithTaskCountsList.size()];
        double[] counts = new double[datesWithTaskCountsList.size()];

        for (int k = 0; k < datesWithTaskCountsList.size(); k++) {
            Object[] objects = datesWithTaskCountsList.get(k);
            datesAsStrings[k] = (String) objects[0];
            counts[k] = Double.parseDouble(Integer.toString((Integer) objects[1]));
        }

        Date[] datesAsDateObjects = new Date[datesAsStrings.length];
        for (int i = 0; i < datesAsStrings.length; i++) {
            String[] dateStringParts = datesAsStrings[i].split("-");
            int year = Integer.parseInt(dateStringParts[0]);
            int month = Integer.parseInt(dateStringParts[1]);
            int day = Integer.parseInt(dateStringParts[2]);
            datesAsDateObjects[i] = new Date(year - 1900, month - 1, day);
        }

        return new Object[]{datesAsDateObjects, counts};
    }

}
