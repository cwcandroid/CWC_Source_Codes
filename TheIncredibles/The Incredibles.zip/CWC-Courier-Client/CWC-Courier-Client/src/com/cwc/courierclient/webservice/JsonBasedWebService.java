package com.cwc.courierclient.webservice;

import android.content.Context;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.exception.ServerConnectionException;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Author: sharafat
 * Date: 1/23/12 2:10 AM
 */
public class JsonBasedWebService extends WebService {

    public JsonBasedWebService(Context context) {
        super(context);
    }

    @Override
    Map<String, String> getResponse(String url) {
        String response = getServerResponseBody(url);
        return new Gson().fromJson(response, new TypeToken<Map<String, String>>() {
        }.getType());
    }

    @Override
    List<Task> getTaskList(String url) {
        String response = getServerResponseBody(url);
        return new Gson().fromJson(response, new TypeToken<List<Task>>() {
        }.getType());
    }

    private String getServerResponseBody(String url) throws ServerConnectionException {
        String response;

        try {
            HttpResponse httpResponse = new DefaultHttpClient().execute(new HttpGet(url));
            response = EntityUtils.toString(httpResponse.getEntity());
        } catch (IOException e) {
            throw new ServerConnectionException(e.getClass().getCanonicalName() + ": " + e.getMessage());
        }

        return response;
    }
}
