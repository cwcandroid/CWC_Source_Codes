package com.cwc.courierclient.service;

import android.content.Context;
import com.cwc.courierclient.R;
import com.cwc.courierclient.webservice.WebService;
import com.cwc.courierclient.webservice.WebServiceFactory;

/**
 * Author: sharafat
 * Date: 1/22/12 9:09 PM
 */
public class LoginService {

    public void login(Context context, String username, String password) {
        WebService webService = WebServiceFactory.getWebService(context.getString(R.string.login_returnType), context);
        webService.login(username, password);
    }
}
