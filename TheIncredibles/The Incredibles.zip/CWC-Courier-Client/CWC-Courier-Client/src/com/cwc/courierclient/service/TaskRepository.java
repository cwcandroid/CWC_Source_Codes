package com.cwc.courierclient.service;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import com.cwc.courierclient.R;
import com.cwc.courierclient.dao.TaskDao;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.webservice.WebService;
import com.cwc.courierclient.webservice.WebServiceFactory;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Author: sharafat
 * Date: 1/24/12 6:44 PM
 */
public class TaskRepository {
    private static List<Task> todaysTaskList;
    private static List<Task> taskHistory;

    public static boolean isTodaysTasksInitialized() {
        return todaysTaskList != null;
    }

    public static boolean isTaskHistoryInitialized() {
        return taskHistory != null;
    }

    public static List<Task> getTodaysTasks() {
        return todaysTaskList;
    }

    public static List<Task> getTaskHistory() {
        return taskHistory;
    }

    public static void initializeTodaysTasks(final Context context, final Handler updateTaskListHandler) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        final String now = dateFormat.format(new Date());
        final TaskService taskService = new TaskService(context);

        new Thread() {
            public void run() {
                String userName = SharedPreferencesService.getInstance(context).getUsername();
                WebService webService = WebServiceFactory.getWebService(context.getString(R.string.taskList_returnType), context);

                List<Task> currentFromWeb = new ArrayList<Task>();
                try {
                    currentFromWeb = webService.getTaskList(userName, now);
                } catch (IOException ignore) {
                } catch (SAXException ignore) {
                } catch (ParserConfigurationException ignore) {
                }

                for (Task task : currentFromWeb) {
                    task.setDuedate(now);
                    taskService.insert(task);
                    setAlarm(task, context);
                }

                setDummyAlarmForTest(context);

                todaysTaskList = currentFromWeb;

                Message message = updateTaskListHandler.obtainMessage();
                updateTaskListHandler.sendMessage(message);
            }
        }.start();
    }

    private static void setDummyAlarmForTest(Context context) {
        Intent intent = new Intent(context, AlarmService.class);
        PendingIntent sender = PendingIntent.getBroadcast(context, 0, intent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(new Date(2012 - 1900, 0, 28, 18, 19).getTime());
        calendar.add(Calendar.MINUTE, -5);

        AlarmManager am = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
        am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), sender);
    }

    private static void setAlarm(Task task, Context context) {
        Intent intent = new Intent(context, AlarmService.class);
        PendingIntent sender = PendingIntent.getBroadcast(context, 0, intent, 0);

        String[] date = task.getDuedate().split("-");
        String[] time = task.getDuetime().split(":");
        int year = Integer.parseInt(date[0]) - 1900;
        int month = Integer.parseInt(date[1]) - 1;
        int day = Integer.parseInt(date[2]);
        int hour = Integer.parseInt(time[0]);
        int min = Integer.parseInt(time[1]);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(new Date(year, month, day, hour, min).getTime());
        calendar.add(Calendar.MINUTE, -5);

        AlarmManager am = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
        am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), sender);
    }

    public static void initializeTaskHistory(final Context context, final Handler updateTaskHistoryHandler) {
        final TaskService taskService = new TaskService(context);

        new Thread() {
            public void run() {
                String userName = SharedPreferencesService.getInstance(context).getUsername();
                WebService webService = WebServiceFactory.getWebService(context.getString(R.string.taskList_returnType), context);

                List<Task> currentFromWeb = new ArrayList<Task>();
                try {
                    currentFromWeb = webService.getTaskHistory(userName);
                } catch (IOException ignore) {
                } catch (SAXException ignore) {
                } catch (ParserConfigurationException ignore) {
                }

                for (Task task : currentFromWeb) {
                    try {
                        taskService.insert(task);
                    } catch (Exception ignore) {
                    }
                }

                taskHistory = currentFromWeb;

                Message message = updateTaskHistoryHandler.obtainMessage();
                updateTaskHistoryHandler.sendMessage(message);
            }
        }.start();
    }

    private static Task createDummyTask(int id, String name, String address, double latitude, double longitude, int status) {
        Task task = new Task();
        task.setId(id);
        task.setName(name);
        task.setAddress(address);
        task.setLatitude(latitude);
        task.setLongitude(longitude);
        task.setStatus(status);
        return task;
    }

}
