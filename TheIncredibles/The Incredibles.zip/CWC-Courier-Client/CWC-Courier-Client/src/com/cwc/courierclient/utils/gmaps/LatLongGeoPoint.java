package com.cwc.courierclient.utils.gmaps;

import com.google.android.maps.GeoPoint;

/**
 * Author: sharafat
 * Date: 1/25/12 4:20 PM
 */
public final class LatLongGeoPoint extends GeoPoint {
    private double latitude, longitude;

    public LatLongGeoPoint(double latitude, double longitude) {
        super((int) (latitude * 1E6), (int) (longitude * 1E6));
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }
}
