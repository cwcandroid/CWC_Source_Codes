package com.cwc.courierclient.utils;

import java.util.regex.Pattern;

/**
 * Author: sharafat
 * Date: 1/22/12 10:37 PM
 */
public class Validator {
    private static final String USERNAME_REGEX = "^[\\w]+$";
    private static final String EMAIL_REGEX =
            "^[a-zA-Z0-9]+([_\\.\\-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([\\.\\-][a-zA-Z0-9]+)*(\\.[A-Za-z]{2,})$";

    public static boolean validUsername(String input) {
        return Pattern.matches(USERNAME_REGEX, input);
    }

    public static boolean validEmail(String input) {
        return Pattern.matches(EMAIL_REGEX, input);
    }
}
