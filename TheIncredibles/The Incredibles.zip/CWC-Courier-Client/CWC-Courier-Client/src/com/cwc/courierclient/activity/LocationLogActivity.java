package com.cwc.courierclient.activity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cwc.courierclient.R;
import com.cwc.courierclient.dao.LocationLogDao;
import com.cwc.courierclient.domain.LocationHistory;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.service.TaskRepository;
import com.cwc.courierclient.utils.gmaps.GeneralMapUtils;
import com.cwc.courierclient.utils.gmaps.MapMarkerUtil;
import com.cwc.courierclient.utils.gmaps.OnMarkerBalloonTapListener;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class LocationLogActivity extends MapActivity {

	private MapController mc = null;
	private Drawable defaultMarker = null;
	private GeoPoint p = null;
	private LocationLogDao locationLogDao;
	private LocationManager locationManager;
	private Location currentLocation;
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	String currentDate = dateFormat.format(new Date());

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.location_log);
		locationLogDao = new LocationLogDao(this);

		this.locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		// Subscribe to the location manager's updates on the current location
		this.locationManager.requestLocationUpdates(
				locationManager.NETWORK_PROVIDER, (long) 30000, (float) 10.0,
				new LocationListener() {
					public void onLocationChanged(Location arg0) {
						handleLocationChanged(arg0);
					}

					public void onProviderDisabled(String arg0) {
						// TODO Auto-generated method stub

					}

					public void onProviderEnabled(String arg0) {
						// TODO Auto-generated method stub

					}

					public void onStatusChanged(String arg0, int arg1,
							Bundle arg2) {
						// TODO Auto-generated method stub
					}
				});
		
		
		MapView mapView = (MapView) findViewById(R.id.locationlogmapView);
        mapView.setBuiltInZoomControls(true);
        GeneralMapUtils.centerMapToMyLocation(mapView, getResources());

        //final List<Task> taskList = TaskRepository.getTodaysTasks();
        final List<LocationHistory> locationList = locationLogDao.listAllByDate(currentDate);
        final List<Task> tasklist = new ArrayList<Task>();
        

        for(LocationHistory lh : locationList){
        	Task task = new Task();
        	task.setLatitude(lh.getLatitude());
        	task.setLongitude(lh.getLongitude());
        	task.setName("");
        	task.setAddress("");
        	tasklist.add(task);
        }
        
        mapView.getOverlays().add(MapMarkerUtil.getMarkerOverlay(mapView, getResources(), tasklist, null));
		
	}

	private void handleLocationChanged(Location loc) {
		// Save the latest location
		this.currentLocation = loc;

		Log.d("location log", "latitude: " + Double.toString(loc.getLatitude())
				+ "longitude: " + Double.toString(loc.getLongitude()));

		LocationHistory locationHistory = new LocationHistory(
				loc.getLatitude(), loc.getLongitude(), currentDate);
		long id = locationLogDao.insert(locationHistory);
	}
	
    @Override
    protected boolean isRouteDisplayed() {
        return false;
    }
}
