package com.cwc.courierclient.exception;

/**
 * Author: sharafat
 * Date: 1/23/12 8:15 PM
 */
public class RegistrationFailedException extends RuntimeException {
    public RegistrationFailedException() {
    }

    public RegistrationFailedException(String detailMessage) {
        super(detailMessage);
    }

    public RegistrationFailedException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public RegistrationFailedException(Throwable throwable) {
        super(throwable);
    }
}
