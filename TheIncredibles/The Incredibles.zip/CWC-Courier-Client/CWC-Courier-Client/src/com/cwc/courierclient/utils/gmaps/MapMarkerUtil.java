package com.cwc.courierclient.utils.gmaps;

import android.content.res.Resources;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.utils.GPSLocation;
import com.google.android.maps.MapView;

import java.util.List;

/**
 * Author: sharafat
 * Date: 1/25/12 3:08 PM
 */
public class MapMarkerUtil {
    public static final int MARKER_TYPE_DEFAULT = 0;
    public static final int MARKER_TYPE_MY_LOCATION = 1;
    public static final int MARKER_TYPE_TASK_INCOMPLETE = 2;
    public static final int MARKER_TYPE_TASK_COMPLETE = 3;
    public static final int MARKER_TYPE_TASK_PENDING = 4;

    public static MapMarkerOverlay getMarkerOverlay(MapView mapView, Resources resources, List<Task> tasks,
                                              OnMarkerBalloonTapListener onMarkerBalloonTapListener) {
        MapMarkerOverlay mapMarkerOverlay = new MapMarkerOverlay(
                resources.getDrawable(getDrawableResourceByMarkerType(
                        MARKER_TYPE_DEFAULT)), mapView, onMarkerBalloonTapListener);

        // Warning: addMarkersForTasks() must come before addMarkerForMyLocation() in the following two statements.
        // Otherwise, the index returned from OnMarkerBalloonTapped event would not match with the task list.
        addMarkersForTasks(resources, mapMarkerOverlay, tasks);
        addMarkerForMyLocation(GPSLocation.getMyLocation(), resources, mapMarkerOverlay);

        mapMarkerOverlay.populateOverlays();

        return mapMarkerOverlay;
    }

    private static void addMarkerForMyLocation(LatLongGeoPoint myLocation, Resources resources, MapMarkerOverlay mapMarkerOverlay) {
        mapMarkerOverlay.addMarkerOverlayItem(myLocation.getLatitude(), myLocation.getLongitude(),
                resources.getString(R.string.my_location), "", resources.getDrawable(
                getDrawableResourceByMarkerType(MARKER_TYPE_MY_LOCATION)));
    }

    private static void addMarkersForTasks(Resources resources, MapMarkerOverlay mapMarkerOverlay, List<Task> tasks) {
        for (Task task : tasks) {
            mapMarkerOverlay.addMarkerOverlayItem(task.getLatitude(), task.getLongitude(),
                    task.getName(), task.getAddress(),
                    resources.getDrawable(getDrawableResourceByMarkerType(
                            getMarkerTypeByTaskStatus(task.getStatus()))));
        }
    }

    private static int getDrawableResourceByMarkerType(int markerType) {
        switch (markerType) {
            case MARKER_TYPE_TASK_COMPLETE:
                return R.drawable.marker_complete;
            case MARKER_TYPE_TASK_INCOMPLETE:
                return R.drawable.marker_incomplete;
            case MARKER_TYPE_TASK_PENDING:
                return R.drawable.marker_pending;
            case MARKER_TYPE_MY_LOCATION:
                return R.drawable.marker_my_location;
            case MARKER_TYPE_DEFAULT:
                return R.drawable.marker_default;
            default:
                return R.drawable.marker_default;
        }
    }

    private static int getMarkerTypeByTaskStatus(int taskStatus) {
        switch (taskStatus) {
            case Task.STATUS_COMPLETE:
                return MARKER_TYPE_TASK_COMPLETE;
            case Task.STATUS_INCOMPLETE:
                return MARKER_TYPE_TASK_INCOMPLETE;
            case Task.STATUS_PENDING:
                return MARKER_TYPE_TASK_PENDING;
            default:
                return -1;
        }
    }
}
