package com.cwc.courierclient.utils.imagecrop;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import com.cwc.courierclient.activity.ReportTaskActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: sharafat
 * Date: 1/27/12 12:34 AM
 */
public class ImageCrop {

    public static boolean imageCroppingAppAvailable(Activity activity) {
        PackageManager packageManager = activity.getPackageManager();
        List<ResolveInfo> list = packageManager.queryIntentActivities(getImageCroppingIntent(), 0);
        return list.size() > 0;
    }

    private static Intent getImageCroppingIntent() {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setType("image/*");
        return intent;
    }

    public static void cropImage(final Uri imageCaptureUri, final Activity activity, int imageWidth, int imageHeight,
                                 int aspectX, int aspectY, boolean scale) {
        final ArrayList<CropOption> cropOptions = new ArrayList<CropOption>();

        Intent intent = getImageCroppingIntent();
        List<ResolveInfo> list = activity.getPackageManager().queryIntentActivities(intent, 0);
        int size = list.size();

        if (size == 0) {    // No crop app found
            return;
        }

        intent.setData(imageCaptureUri);

        intent.putExtra("outputX", imageWidth);
        intent.putExtra("outputY", imageHeight);
        if (aspectX != 0) {
            intent.putExtra("aspectX", aspectX);
        }
        if (aspectY != 0) {
            intent.putExtra("aspectY", aspectY);
        }
        intent.putExtra("scale", scale);
        intent.putExtra("return-data", true);

        if (size == 1) {
            Intent i = new Intent(intent);
            ResolveInfo res = list.get(0);

            i.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));

            activity.startActivityForResult(i, ReportTaskActivity.CROP_IMAGE);
        } else {
            for (ResolveInfo res : list) {
                CropOption cropOption = new CropOption();

                cropOption.title = activity.getPackageManager().getApplicationLabel(res.activityInfo.applicationInfo);
                cropOption.icon = activity.getPackageManager().getApplicationIcon(res.activityInfo.applicationInfo);
                cropOption.appIntent = new Intent(intent);

                cropOption.appIntent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));

                cropOptions.add(cropOption);
            }

            CropOptionAdapter adapter = new CropOptionAdapter(activity.getApplicationContext(), cropOptions);

            new AlertDialog.Builder(activity)
                    .setTitle("Choose Crop App")
                    .setAdapter(adapter,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int item) {
                                    activity.startActivityForResult(cropOptions.get(item).appIntent,
                                            ReportTaskActivity.CROP_IMAGE);
                                }
                            })
                    .setOnCancelListener(
                            new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    if (imageCaptureUri != null) {
                                        activity.getContentResolver().delete(imageCaptureUri, null, null);
                                        // imageCaptureUri = null;
                                    }
                                }
                            })
                    .create().show();
        }
    }
}
