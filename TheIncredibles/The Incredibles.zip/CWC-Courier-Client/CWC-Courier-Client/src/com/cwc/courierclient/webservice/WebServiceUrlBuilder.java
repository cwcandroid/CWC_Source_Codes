package com.cwc.courierclient.webservice;

import android.content.Context;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.utils.UrlBuilder;

/**
 * Author: sharafat
 * Date: 1/23/12 2:18 AM
 */
public class WebServiceUrlBuilder {

    public static String buildRegistrationUrl(Context context, String username, String email, String password) {
        String registrationUrl = context.getString(R.string.registration_base_url);
        String usernameParamName = context.getString(R.string.registration_param_username);
        String emailParamName = context.getString(R.string.registration_param_email);
        String passwordParamName = context.getString(R.string.registration_param_password);
        String returnTypeParamName = context.getString(R.string.registration_param_returnType);
        String returnType = context.getString(R.string.registration_returnType);

        return UrlBuilder.build(registrationUrl,
                new String[]{usernameParamName, emailParamName, passwordParamName, returnTypeParamName},
                new String[]{username, email, password, returnType});
    }

    public static String buildLoginUrl(Context context, String username, String password) {
        String loginUrl = context.getString(R.string.login_base_url);
        String usernameParamName = context.getString(R.string.login_param_username);
        String passwordParamName = context.getString(R.string.login_param_password);
        String returnTypeParamName = context.getString(R.string.login_param_returnType);
        String returnType = context.getString(R.string.login_returnType);

        return UrlBuilder.build(loginUrl,
                new String[]{usernameParamName, passwordParamName, returnTypeParamName},
                new String[]{username, password, returnType});
    }

    public static String buildTaskListUrl(Context context, String username, String dueDate) {
        String taskListUrl = context.getString(R.string.taskList_base_url);
        String usernameParamName = context.getString(R.string.taskList_param_username);
        String dueDateParamName = context.getString(R.string.taskList_param_duedate);
        String returnTypeParamName = context.getString(R.string.taskList_param_returnType);
        String returnType = context.getString(R.string.taskList_returnType);

        return UrlBuilder.build(taskListUrl,
                new String[]{usernameParamName, dueDateParamName, returnTypeParamName},
                new String[]{username, dueDate, returnType});
    }

    public static String buildTaskHistoryUrl(Context context, String username) {
        String taskHistoryUrl = context.getString(R.string.taskHistory_base_url);
        String usernameParamName = context.getString(R.string.taskHistory_param_username);
        String returnTypeParamName = context.getString(R.string.taskHistory_param_returnType);
        String returnType = context.getString(R.string.taskHistory_returnType);

        return UrlBuilder.build(taskHistoryUrl,
                new String[]{usernameParamName, returnTypeParamName},
                new String[]{username, returnType});
    }

    public static String buildReportTaskUrl(Context context, String username, Task task,
                                            double latitude, double longitude, String signatureFileName) {
        String reportTaskUrl = context.getString(R.string.reportTask_base_url);
        String usernameParamName = context.getString(R.string.reportTask_param_username);
        String taskIdParamName = context.getString(R.string.reportTask_param_taskid);
        String reasonTypeParamName = context.getString(R.string.reportTask_param_reasontype);
        String reasonDetailsParamName = context.getString(R.string.reportTask_param_reasondetails);
        String reportLatitudeParamName = context.getString(R.string.reportTask_param_reportlatitude);
        String reportLongitudeParamName = context.getString(R.string.reportTask_param_reportlongitude);
        String signatureFileParamName = context.getString(R.string.reportTask_param_signaturefile);
        String returnTypeParamName = context.getString(R.string.reportTask_param_returnType);
        String returnType = context.getString(R.string.reportTask_returnType);

        return UrlBuilder.build(reportTaskUrl,
                new String[]{usernameParamName, taskIdParamName, reasonTypeParamName, reasonDetailsParamName,
                        reportLatitudeParamName, reportLongitudeParamName, signatureFileParamName, returnTypeParamName},
                new String[]{username, Integer.toString(task.getId()), Integer.toString(task.getReasontype()),
                        task.getReasondetails(), Double.toString(latitude), Double.toString(longitude),
                        signatureFileName, returnType});
    }

}
