package com.cwc.courierclient.service;

import android.content.Context;
import com.cwc.courierclient.R;
import com.cwc.courierclient.webservice.WebService;
import com.cwc.courierclient.webservice.WebServiceFactory;

/**
 * Author: sharafat
 * Date: 1/22/12 9:09 PM
 */
public class RegistrationService {

    public void register(Context context, String username, String email, String password) {
        WebService webService = WebServiceFactory.getWebService(context.getString(R.string.registration_returnType), context);
        webService.register(username, email, password);
    }
}
