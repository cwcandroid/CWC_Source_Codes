package com.cwc.courierclient.utils.chart;

import org.achartengine.chart.PointStyle;

import java.util.Date;

/**
 * Author: sharafat
 * Date: 1/28/12 1:20 AM
 */
public class LineChartLineElement {
    private Date[] dates;
    private double[] taskCounts;
    private String lineName;
    private int lineColor;
    private PointStyle pointStyle;

    public LineChartLineElement() {
    }

    public LineChartLineElement(Date[] dates, double[] taskCounts) {
        this.dates = dates;
        this.taskCounts = taskCounts;
    }

    public Date[] getDates() {
        return dates;
    }

    public void setDates(Date[] dates) {
        this.dates = dates;
    }

    public double[] getTaskCounts() {
        return taskCounts;
    }

    public void setTaskCounts(double[] taskCounts) {
        this.taskCounts = taskCounts;
    }

    public String getLineName() {
        return lineName;
    }

    public void setLineName(String lineName) {
        this.lineName = lineName;
    }

    public int getLineColor() {
        return lineColor;
    }

    public void setLineColor(int lineColor) {
        this.lineColor = lineColor;
    }

    public PointStyle getPointStyle() {
        return pointStyle;
    }

    public void setPointStyle(PointStyle pointStyle) {
        this.pointStyle = pointStyle;
    }
}
