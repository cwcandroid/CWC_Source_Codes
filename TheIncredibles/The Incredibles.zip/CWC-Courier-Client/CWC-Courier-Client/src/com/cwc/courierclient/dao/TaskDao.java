package com.cwc.courierclient.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import com.cwc.courierclient.domain.Task;

import java.util.ArrayList;
import java.util.List;

public class TaskDao {
    private static final String TABLE = "task";

    private static final String COL_ID = "_id";
    private static final String COL_STATUS = "status";
    private static final String COL_NAME = "name";
    private static final String COL_DESCRIPTION = "description";
    private static final String COL_COMMENTS = "comments";
    private static final String COL_CONTACT = "contact";
    private static final String COL_ADDRESS = "address";
    private static final String COL_LATITUDE = "latitude";
    private static final String COL_LONGITUDE = "longitude";
    private static final String COL_DUE_DATE = "duedate";
    private static final String COL_DUE_TIME = "duetime";
    private static final String COL_REASON_TYPE = "reasontype";
    private static final String COL_REASON_DETAILS = "reasondetails";
    private static final String COL_REPORT_LATITUDE = "reportlatitude";
    private static final String COL_REPORT_LONGITUDE = "reportlongitude";
    private static final String COL_SIGNATURE_FILE = "signaturefile";

    private DB db;

    public TaskDao(Context context) {
        db = DB.getInstance(context);
    }

    public List<Task> listAll() {
        List<Task> tasks = new ArrayList<Task>();

//        Cursor mCursor = db.getReadableDatabase().query(TABLE, getAllColumns(), null, null, null, null, null);
        Cursor mCursor = db.getReadableDatabase().rawQuery("select * from " + TABLE, new String[] {});
        if (mCursor != null) {
            if (mCursor.moveToFirst()) {
                do {
                    tasks.add(populateTask(mCursor));
                } while (mCursor.moveToNext());
            }
            mCursor.close();
        }

        return tasks;
    }

    public Task findById(long id) throws SQLException {
        Task task = null;

        Cursor cursor = db.getReadableDatabase().query(TABLE, getAllColumns(), COL_ID + "=" + id, null, null, null, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                task = populateTask(cursor);
            }
            cursor.close();
        }

        return task;
    }

    public List<Task> findByDueDate(String dueDate) throws SQLException {
        List<Task> tasks = new ArrayList<Task>();

        Cursor cursor = db.getReadableDatabase().rawQuery("select * from " + TABLE + " where duedate = " + dueDate, new String[]{});
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    tasks.add(populateTask(cursor));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        return tasks;
    }

    public List<Object[]> findTaskCountsPerDayByStatusAndNoOfDays(int taskStatus, int days) {
        List<Object[]> taskCountsForEachDay = new ArrayList<Object[]>();

        String sql = "SELECT duedate, count(_id) as counts FROM task WHERE duedate >= DATETIME('now', '-"
                + days + " days') and status = ? group by duedate";

        Cursor cursor = db.getReadableDatabase().rawQuery(sql, new String[]{Integer.toString(taskStatus)});
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    taskCountsForEachDay.add(new Object[]{cursor.getString(0), cursor.getInt(1)});
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        return taskCountsForEachDay;
    }

    public long insert(Task task) {
        return db.getWritableDatabase().insertOrThrow(TABLE, null, getContentValues(task));
    }

    public boolean update(Task task) {
        return db.getWritableDatabase().update(TABLE, getContentValues(task),
                COL_ID + "= ?", new String[]{String.valueOf(task.getId())}) > 0;
    }

    public boolean delete(Task task) {
        return db.getWritableDatabase().delete(TABLE, COL_ID + "= ?", new String[]{String.valueOf(task.getId())}) > 0;
    }

    private Task populateTask(Cursor cursor) {
        Task task = new Task();

        task.setId(cursor.getInt(0));
        task.setStatus(cursor.getInt(1));
        task.setName(cursor.getString(2));
        task.setDescription(cursor.getString(3));
        task.setComments(cursor.getString(4));
        task.setContactno(cursor.getString(5));
        task.setAddress(cursor.getString(6));
        task.setLatitude(cursor.getDouble(7));
        task.setLongitude(cursor.getDouble(8));
        task.setDuedate(cursor.getString(9));
        task.setDuetime(cursor.getString(10));
        task.setReasontype(cursor.getInt(11));
        task.setReasondetails(cursor.getString(12));
        task.setReportlatitude(cursor.getDouble(13));
        task.setReportlongitude(cursor.getDouble(14));
        task.setSignaturefile(cursor.getBlob(15));

        return task;
    }

    private ContentValues getContentValues(Task task) {
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_ID, task.getId());
        contentValues.put(COL_STATUS, task.getStatus());
        contentValues.put(COL_NAME, task.getName());
        contentValues.put(COL_DESCRIPTION, task.getDescription());
        contentValues.put(COL_COMMENTS, task.getComments());
        contentValues.put(COL_CONTACT, task.getContactno());
        contentValues.put(COL_ADDRESS, task.getAddress());
        contentValues.put(COL_LATITUDE, task.getLatitude());
        contentValues.put(COL_LONGITUDE, task.getLongitude());
        contentValues.put(COL_DUE_DATE, task.getDuedate());
        contentValues.put(COL_DUE_TIME, task.getDuetime());
        contentValues.put(COL_REASON_TYPE, task.getReasontype());
        contentValues.put(COL_REASON_DETAILS, task.getReasondetails());
        contentValues.put(COL_REPORT_LATITUDE, task.getReportlatitude());
        contentValues.put(COL_REPORT_LONGITUDE, task.getReportlongitude());
        contentValues.put(COL_SIGNATURE_FILE, task.getSignaturefile());

        return contentValues;
    }

    private String[] getAllColumns() {
        return new String[]{COL_ID, COL_STATUS, COL_NAME, COL_DESCRIPTION, COL_COMMENTS, COL_CONTACT,
                COL_ADDRESS, COL_LATITUDE, COL_LONGITUDE, COL_DUE_DATE, COL_DUE_TIME, COL_REASON_TYPE,
                COL_REASON_DETAILS, COL_REPORT_LATITUDE, COL_REPORT_LONGITUDE, COL_SIGNATURE_FILE};
    }
}
