package com.cwc.courierclient.webservice;

import android.content.Context;

/**
 * Author: sharafat
 * Date: 1/23/12 2:11 AM
 */
public class WebServiceFactory {
    public static final String JSON_WEB_SERVICE = "json";
    public static final String XML_WEB_SERVICE = "xml";

    public static WebService getWebService(String webServiceType, Context context) {
        if (JSON_WEB_SERVICE.equals(webServiceType)) {
            return new JsonBasedWebService(context);
        } else if (XML_WEB_SERVICE.equals(webServiceType)) {
            return new XMLBasedWebService(context);
        }

        return null;
    }

}
