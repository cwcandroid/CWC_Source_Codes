package com.cwc.courierclient.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Author: sharafat
 * Date: 1/27/12 3:34 PM
 */
public class DB extends SQLiteOpenHelper {
    private static final String DB_NAME = "cwc_courier_client.db";
    private static final int DB_VERSION = 1;

    private static DB db;

    public static DB getInstance(Context context) {
        if (db == null) {
            db = new DB(context, DB_NAME, DB_VERSION);
        }

        return db;
    }

    private DB(Context context, String name, int version) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE task ("
                + "_id INTEGER PRIMARY KEY,"
                + "status INTEGER NOT NULL,"
                + "name TEXT NOT NULL,"
                + "description TEXT NULLABLE,"
                + "comments TEXT NULLABLE,"
                + "contact TEXT NOT NULL,"
                + "address TEXT NOT NULL,"
                + "latitude DOUBLE NOT NULL,"
                + "longitude DOUBLE NOT NULL,"
                + "duedate TEXT NOT NULL,"
                + "duetime TEXT NOT NULL,"
                + "reasontype INTEGER NULLABLE,"
                + "reasondetails TEXT NULLABLE,"
                + "reportlatitude DOUBLE NULLABLE,"
                + "reportlongitude DOUBLE NULLABLE,"
                + "signaturefile BLOB NULLABLE)");

        db.execSQL("CREATE TABLE locationlog ("
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "duedate TEXT NOT NULL,"
                + "latitude DOUBLE NOT NULL,"
                + "longitude DOUBLE NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

}
