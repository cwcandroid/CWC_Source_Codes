package com.cwc.courierclient.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.cwc.courierclient.R;

/**
 * Author: sharafat
 * Date: 1/28/12 6:36 PM
 */
public class AlarmService extends BroadcastReceiver {
    private static final int APP_ID = 0;

    @Override
    public void onReceive(Context context, Intent intent) {
        NotificationManager mManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Notification notification = new Notification(R.drawable.ic_launcher, "5 Minute remaining for next delivery",
                System.currentTimeMillis());
        notification.setLatestEventInfo(context, context.getString(R.string.app_name), "5 Minute remaining for next delivery", null);
        mManager.notify(APP_ID, notification);
    }
}
