package com.cwc.courierclient.utils;

import com.cwc.courierclient.utils.gmaps.LatLongGeoPoint;

/**
 * Author: sharafat
 * Date: 1/25/12 6:47 PM
 */
public class GPSLocation {

    public static LatLongGeoPoint getMyLocation() {
        double myLatitude = 23.7950922;
        double myLongitude = 90.400758;

        return new LatLongGeoPoint(myLatitude, myLongitude);
    }

}
