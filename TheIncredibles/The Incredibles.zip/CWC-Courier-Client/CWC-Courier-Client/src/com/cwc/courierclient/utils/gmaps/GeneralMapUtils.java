package com.cwc.courierclient.utils.gmaps;

import android.content.res.Resources;
import com.cwc.courierclient.R;
import com.cwc.courierclient.utils.GPSLocation;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;

/**
 * Author: sharafat
 * Date: 1/26/12 12:51 PM
 */
public class GeneralMapUtils {

    public static void centerMapToMyLocation(MapView mapView, Resources resources) {
        MapController mapController = mapView.getController();
        mapController.setZoom(Integer.parseInt(resources.getString(R.string.gmaps_default_zoom_level)));
        mapController.animateTo(GPSLocation.getMyLocation());
        mapView.invalidate();
    }

}
