package com.cwc.courierclient.webservice;

import android.content.Context;
import android.util.Log;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.exception.IncorrectLoginException;
import com.cwc.courierclient.exception.NoInternetConnectionException;
import com.cwc.courierclient.exception.RegistrationFailedException;
import com.cwc.courierclient.exception.ServerConnectionException;
import com.cwc.courierclient.utils.ConnectivityStatus;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Author: sharafat
 * Date: 1/23/12 1:53 AM
 */
public abstract class WebService {
    private static final String REGISTRATION_SUCCESS_KEY = "status";
    private static final String REGISTRATION_SUCCESS_VALUE = "Success";
    private static final String REGISTRATION_FAILURE_MSG_KEY = "text";
    private static final String LOGIN_SUCCESS_KEY = "status";
    private static final String LOGIN_SUCCESS_VALUE = "true";
    private static final String TASK_REPORTING_SUCCESS_KEY = "status";
    private static final String TASK_REPORTING_SUCCESS_VALUE = "Success";

    private static final String LOG_TAG = WebService.class.getCanonicalName();

    private Context context;

    public WebService(Context context) {
        this.context = context;
    }

    abstract Map<String, String> getResponse(String url);
    abstract List<Task> getTaskList(String url) throws SAXException, ParserConfigurationException, IOException;

    public void register(String username, String email, String password)
            throws NoInternetConnectionException, ServerConnectionException, RegistrationFailedException {
        checkInternetConnectivity();

        String url = WebServiceUrlBuilder.buildRegistrationUrl(context, username, email, password);
        Log.d(LOG_TAG, "Registration URL: " + url);
        Map<String, String> result = getResponse(url);

        if (!REGISTRATION_SUCCESS_VALUE.equalsIgnoreCase(result.get(REGISTRATION_SUCCESS_KEY))) {
            throw new RegistrationFailedException(result.get(REGISTRATION_FAILURE_MSG_KEY));
        }
    }

    public void login(String username, String password)
            throws NoInternetConnectionException, IncorrectLoginException, ServerConnectionException {
        checkInternetConnectivity();

        String url = WebServiceUrlBuilder.buildLoginUrl(context, username, password);
        Log.d(LOG_TAG, "Login URL: " + url);
        Map<String, String> result = getResponse(url);

        if (!LOGIN_SUCCESS_VALUE.equalsIgnoreCase(result.get(LOGIN_SUCCESS_KEY))) {
            throw new IncorrectLoginException();
        }
    }

    public void reportSpecificTask(String username, Task task, double latitude, double longitude, String signatureFileName)
            throws NoInternetConnectionException, ServerConnectionException {
        checkInternetConnectivity();

        String url = WebServiceUrlBuilder.buildReportTaskUrl(context, username, task, latitude, longitude, signatureFileName);
        Log.d(LOG_TAG, "reportSpecificTask URL: " + url);
        Map<String, String> result = getResponse(url);
    }

    public List<Task> getTaskList(String username, String duedate)
            throws NoInternetConnectionException, ServerConnectionException,
            IOException, SAXException, ParserConfigurationException {
        checkInternetConnectivity();

        String url = WebServiceUrlBuilder.buildTaskListUrl(context, username, duedate);
        Log.d(LOG_TAG, "getTaskList URL: " + url);
        List<Task> result = getTaskList(url);

        return result;
    }

    public List<Task> getTaskHistory(String username)
            throws NoInternetConnectionException, ServerConnectionException,
            IOException, SAXException, ParserConfigurationException {
        checkInternetConnectivity();

        String url = WebServiceUrlBuilder.buildTaskHistoryUrl(context, username);
        Log.d(LOG_TAG, "getTaskHistory URL: " + url);
        List<Task> result = getTaskList(url);

        return result;
    }

    private void checkInternetConnectivity() throws NoInternetConnectionException {
        if (!ConnectivityStatus.isInternetOnline(context)) {
            throw new NoInternetConnectionException();
        }
    }

}
