package com.cwc.courierclient.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewSwitcher;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.service.TaskService;
import com.cwc.courierclient.utils.gmaps.GeneralMapUtils;
import com.cwc.courierclient.utils.gmaps.MapMarkerUtil;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;

import java.util.Arrays;

/**
 * Author: sharafat
 * Date: 1/25/12 2:26 AM
 */
public class TaskDetailsActivity extends MapActivity {
    public static final String SELECTED_TASK = "selected_task";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.task_details);

        Intent intent = getIntent();
        Task task = (Task) intent.getSerializableExtra(TaskListActivity.SELECTED_TASK);

        prepareReportTaskButton(intent, task);
        buildTaskDetailsTextViewContent(task);
        prepareContactNoButton(task);
        buildTaskHistoryTextViewContent(task);
        prepareSigntureImageView(task);
        prepareMapView(task);
        prepareViewSwitchingMechanisms();
    }

    private void prepareReportTaskButton(Intent intent, final Task task) {
        Button reportTaskButton = (Button) findViewById(R.id.report_task_btn);

        boolean arrivedFromTodaysTaskListActivity = intent.getBooleanExtra(
                TaskListActivity.FROM_TODAYS_TASK_LIST_ACTIVITY, false);
        if (arrivedFromTodaysTaskListActivity) {
            reportTaskButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getParent(), ReportTaskActivity.class);
                    intent.putExtra(SELECTED_TASK, task);
                    ((TabGroupActivity) getParent()).startChildActivity(
                            ReportTaskActivity.class.getCanonicalName(), intent);
                }
            });
        } else {
            ((ViewGroup) reportTaskButton.getParent()).removeView(reportTaskButton);
        }
    }

    private void buildTaskDetailsTextViewContent(Task task) {
        StringBuilder taskDetails = new StringBuilder("");

        taskDetails.append("<b>ID:</b> ").append(task.getId()).append("<br/>");
        taskDetails.append("<b>Name:</b> ").append(task.getName()).append("<br/>");

        if (!isEmpty(task.getComments())) {
            taskDetails.append("<b>Comments:</b> ").append(task.getComments()).append("<br/>");
        }
        if (!isEmpty(task.getDescription())) {
            taskDetails.append("<b>Description:</b> ").append(task.getDescription()).append("<br/>");
        }

        taskDetails.append("<b>Receiver Address:</b> ").append(task.getAddress()).append("<br/>");

        ((TextView) findViewById(R.id.task_info_textview)).setText(Html.fromHtml(taskDetails.toString()));
    }

    private void prepareContactNoButton(Task task) {
        Button contactNoButton = (Button) findViewById(R.id.contact_no_btn);
        final String contactNo = task.getContactno() == null ? "" : task.getContactno().trim();

        if (!isEmpty(contactNo)) {
            contactNoButton.setText(contactNo);
            contactNoButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getParent().startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + contactNo)));
                }
            });
        } else {
            ((ViewGroup) contactNoButton.getParent()).removeView(contactNoButton);
        }
    }

    private void buildTaskHistoryTextViewContent(Task task) {
        StringBuilder taskHistory = new StringBuilder("");

        taskHistory.append("<b>Due Date:</b> ").append(task.getDuedate()).append("<br/>")
                .append("<b>Status:</b> ").append(TaskService.getStatusText(this, task.getStatus())).append("<br/>");

        if (task.getReasontype() != null) {
            taskHistory.append("<b>Reason:</b> ").append(TaskService.getReasonText(this, task.getReasontype())).append("<br/>");
        }
        if (!isEmpty(task.getReasondetails())) {
            taskHistory.append("<b>Reason Details:</b> ").append(task.getReasondetails()).append("<br/>");
        }

        ((TextView) findViewById(R.id.task_history_textview)).setText(Html.fromHtml(taskHistory.toString()));
    }

    private void prepareSigntureImageView(Task task) {
        ImageView signatureImageView = (ImageView) findViewById(R.id.signature_imageview);
        byte[] signature = task.getSignaturefile();

        if (signature != null && signature.length != 0) {
            //TODO: set signature image
        } else {
            ((ViewGroup) signatureImageView.getParent()).removeView(signatureImageView);
        }
    }

    private void prepareMapView(Task task) {
        MapView mapView = (MapView) findViewById(R.id.mapView);
        mapView.setBuiltInZoomControls(true);
        GeneralMapUtils.centerMapToMyLocation(mapView, getResources());
        mapView.getOverlays().add(MapMarkerUtil.getMarkerOverlay(mapView, getResources(), Arrays.asList(task), null));
    }

    private void prepareViewSwitchingMechanisms() {
        final ViewSwitcher viewSwitcher = (ViewSwitcher) findViewById(R.id.task_info_and_map_switcher);
        final TextView taskInfoButton= (TextView) findViewById(R.id.task_info_btn);
        final TextView taskOnMapButton = (TextView) findViewById(R.id.task_on_map_btn);
        taskInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewSwitcher.showNext();

                taskInfoButton.setBackgroundResource(R.color.task_info_toggler_bg_selected);
                taskInfoButton.setTextColor(R.color.task_info_toggler_fg_selected);

                taskOnMapButton.setBackgroundResource(R.color.task_info_toggler_bg_unselected);
                taskOnMapButton.setTextColor(R.color.task_info_toggler_fg_unselected);
            }
        });
        taskOnMapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewSwitcher.showNext();

                taskOnMapButton.setBackgroundResource(R.color.task_info_toggler_bg_selected);
                taskOnMapButton.setTextColor(R.color.task_info_toggler_fg_selected);

                taskInfoButton.setBackgroundResource(R.color.task_info_toggler_bg_unselected);
                taskInfoButton.setTextColor(R.color.task_info_toggler_fg_unselected);
            }
        });
    }

    private boolean isEmpty(String str) {
        return str == null || "".equals(str);
    }

    @Override
    protected boolean isRouteDisplayed() {
        return false;
    }

}
