package com.cwc.courierclient.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import com.cwc.courierclient.R;
import com.cwc.courierclient.exception.IncorrectLoginException;
import com.cwc.courierclient.exception.NoInternetConnectionException;
import com.cwc.courierclient.exception.ServerConnectionException;
import com.cwc.courierclient.service.LoginService;
import com.cwc.courierclient.service.SharedPreferencesService;
import com.cwc.courierclient.utils.Dialogs;

public class LoginActivity extends Activity {
    private static final int DIALOG_LOGIN_PROGRESS = 0;
    private static final int DIALOG_NO_INTERNET_CONNECTION = 1;
    private static final int DIALOG_INCORRECT_LOGIN = 2;

    private static final String LOGIN_RESULT_KEY = "result";
    private static final String LOGIN_RESULT_ERROR_KEY = "error";
    private static final int LOGIN_RESULT_INCORRECT = 0;
    private static final int LOGIN_RESULT_SUCCESSFUL = 1;
    private static final int LOGIN_RESULT_NO_INTERNET_CONNECTION = 2;
    private static final int LOGIN_RESULT_SERVER_CONNECTION_ERROR = 3;

    private final Handler handler = new Handler() {
        public void handleMessage(Message message) {
            switch (message.getData().getInt(LOGIN_RESULT_KEY)) {
                case LOGIN_RESULT_SUCCESSFUL:
                    SharedPreferencesService sharedPreferencesService = SharedPreferencesService.getInstance(LoginActivity.this);
                    sharedPreferencesService.setRemembered(((CheckBox) findViewById(R.id.remember_me_input)).isChecked());
                    sharedPreferencesService.setUsername(((EditText) findViewById(R.id.username_input)).getText().toString());

                    Intent intent = new Intent(LoginActivity.this, MainScreenActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                    break;
                case LOGIN_RESULT_INCORRECT:
                    dismissDialog(DIALOG_LOGIN_PROGRESS);
                    showDialog(DIALOG_INCORRECT_LOGIN);
                    break;
                case LOGIN_RESULT_NO_INTERNET_CONNECTION:
                    dismissDialog(DIALOG_LOGIN_PROGRESS);
                    showDialog(DIALOG_NO_INTERNET_CONNECTION);
                    break;
                case LOGIN_RESULT_SERVER_CONNECTION_ERROR:
                    dismissDialog(DIALOG_LOGIN_PROGRESS);
                    Dialogs.buildOkDialog(LoginActivity.this, getString(R.string.server_conn_err_msg)
                            + ": " + message.getData().getString(LOGIN_RESULT_ERROR_KEY)).show();
                    break;
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (SharedPreferencesService.getInstance(this).isRemembered()) {
            Intent intent = new Intent(LoginActivity.this, MainScreenActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.login);

        Button loginBtn = (Button) findViewById(R.id.login_btn);
        Button registerBtn = (Button) findViewById(R.id.register_btn);

        final EditText usernameInput = (EditText) findViewById(R.id.username_input);
        final EditText passwordInput = (EditText) findViewById(R.id.password_input);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!validateRequired(usernameInput) | !validateRequired(passwordInput)) {
                    return;
                }

                showDialog(DIALOG_LOGIN_PROGRESS);
                new Login(handler, usernameInput.getText().toString(), passwordInput.getText().toString()).start();
            }

            private boolean validateRequired(EditText editText) {
                if ("".equals(editText.getText().toString().trim())) {
                    editText.setError(getString(R.string.required));
                    return false;
                } else {
                    editText.setError(null);
                    return true;
                }
            }
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
            }
        });
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_LOGIN_PROGRESS:
                return Dialogs.buildIndeterminateProgressDialog(LoginActivity.this, R.string.login_progress_msg, true);
            case DIALOG_INCORRECT_LOGIN:
                return Dialogs.buildOkDialog(LoginActivity.this, R.string.incorrect_login_msg);
            case DIALOG_NO_INTERNET_CONNECTION:
                return Dialogs.buildOkDialog(LoginActivity.this, R.string.connect_to_internet_msg);
        }

        return null;
    }

    private class Login extends Thread {
        private Handler handler;
        private String username, password;

        Login(Handler handler, String username, String password) {
            this.handler = handler;
            this.username = username;
            this.password = password;
        }

        @Override
        public void run() {
            Bundle bundle = new Bundle();
            Message message = handler.obtainMessage();
            message.setData(bundle);

            int loginResult = -1;
            try {
                new LoginService().login(LoginActivity.this, username, password);
                loginResult = LOGIN_RESULT_SUCCESSFUL;
            } catch (IncorrectLoginException e) {
                loginResult = LOGIN_RESULT_INCORRECT;
            } catch (NoInternetConnectionException e) {
                loginResult = LOGIN_RESULT_NO_INTERNET_CONNECTION;
            } catch (ServerConnectionException e) {
                loginResult = LOGIN_RESULT_SERVER_CONNECTION_ERROR;
                bundle.putString(LOGIN_RESULT_ERROR_KEY, e.getMessage());
            }

            bundle.putInt(LOGIN_RESULT_KEY, loginResult);
            handler.sendMessage(message);
        }
    }
}
