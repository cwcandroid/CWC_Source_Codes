package com.cwc.courierclient.service;

import android.content.Context;
import android.util.Log;
import com.cwc.courierclient.R;
import com.cwc.courierclient.dao.TaskDao;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.exception.NoInternetConnectionException;
import com.cwc.courierclient.exception.ServerConnectionException;
import com.cwc.courierclient.webservice.WebService;
import com.cwc.courierclient.webservice.WebServiceFactory;

import java.util.List;

/**
 * Author: sharafat
 * Date: 1/26/12 9:45 PM
 */
public class TaskService {
    private Context context;
    private TaskDao taskDao;

    public TaskService(Context context) {
        this.context = context;
        taskDao = new TaskDao(context);
    }

    public List<Object[]> findTaskCountsPerDayByStatusAndNoOfDaysService(int taskStatus, int days) {
        return taskDao.findTaskCountsPerDayByStatusAndNoOfDays(taskStatus,days);
    }

    public long insert(Task task) {
        return taskDao.insert(task);
    }

    public boolean reportTask(Task task, double reportingLatitude, double reportingLongitude) {
        String signatureFileName = "signature";

        WebService webService = WebServiceFactory.getWebService(context.getString(R.string.reportTask_returnType), context);
        try {
            webService.reportSpecificTask(SharedPreferencesService.getInstance(context).getUsername(), task,
                    reportingLatitude, reportingLongitude, signatureFileName);
            return true;
        } catch (NoInternetConnectionException e) {
            saveTaskReportToDb(task, reportingLatitude, reportingLongitude);
            return false;
        } catch (ServerConnectionException e) {
            saveTaskReportToDb(task, reportingLatitude, reportingLongitude);
            return false;
        }
    }

    public void syncTask(List<Task> contentFromWeb, List<Task> contentFromDB) {
        if (contentFromDB.size() != contentFromWeb.size()) {
            for (Task taskFromWeb : contentFromWeb) {
//                boolean alreadyExists = true;
//                for (Task taskInDb : contentFromDB) {
//                    if (taskFromWeb.getId() != taskInDb.getId()) {
//                        alreadyExists = false;
//                        break;
//                    }
//                }
//                if (!alreadyExists || contentFromDB.size()==0) {
                    long id = taskDao.insert(taskFromWeb);
                Log.d("ABC", "id: "+id);
//                }
            }
        }
    }

    private void saveTaskReportToDb(Task task, double reportingLatitude, double reportingLongitude) {
        //TODO
    }

    public static String getStatusText(Context context, int status) {
        switch (status) {
            case Task.STATUS_COMPLETE:
                return context.getString(R.string.task_status_complete);
            case Task.STATUS_INCOMPLETE:
                return context.getString(R.string.task_status_incomplete);
            case Task.STATUS_PENDING:
                return context.getString(R.string.task_status_pending);
            default:
                return null;
        }
    }

    public static String getReasonText(Context context, int reasonType) {
        int reasonTextResource;

        switch (reasonType) {
            case Task.REASON_TYPE_NOT_DELIVERED:
                reasonTextResource = R.string.task_reason_not_delivered;
                break;
            case Task.REASON_TYPE_DELIVERED:
                reasonTextResource = R.string.task_reason_delivered;
                break;
            case Task.REASON_TYPE_ADDRESS_NOT_FOUND:
                reasonTextResource = R.string.task_reason_address_not_found;
                break;
            case Task.REASON_TYPE_RECIPIENT_ABSENT:
                reasonTextResource = R.string.task_reason_recipient_absent;
                break;
            default:
                reasonTextResource = R.string.task_reason_others;
        }

        return context.getString(reasonTextResource);
    }

}
