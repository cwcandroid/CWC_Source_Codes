package com.cwc.courierclient.utils.imagecrop;

import android.content.Intent;
import android.graphics.drawable.Drawable;

class CropOption {
    CharSequence title;
    Drawable icon;
    Intent appIntent;
}
