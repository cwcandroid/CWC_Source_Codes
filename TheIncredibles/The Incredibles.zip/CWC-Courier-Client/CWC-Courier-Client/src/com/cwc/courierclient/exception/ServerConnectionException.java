package com.cwc.courierclient.exception;

/**
 * Author: sharafat
 * Date: 1/23/12 4:59 PM
 */
public class ServerConnectionException extends RuntimeException {

    public ServerConnectionException() {
    }

    public ServerConnectionException(String detailMessage) {
        super(detailMessage);
    }

    public ServerConnectionException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public ServerConnectionException(Throwable throwable) {
        super(throwable);
    }
}
