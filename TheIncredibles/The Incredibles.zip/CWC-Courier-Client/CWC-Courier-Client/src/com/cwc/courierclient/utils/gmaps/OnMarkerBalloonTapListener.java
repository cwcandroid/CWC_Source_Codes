package com.cwc.courierclient.utils.gmaps;

import com.google.android.maps.OverlayItem;

/**
 * Author: sharafat
 * Date: 1/25/12 3:26 PM
 */
public interface OnMarkerBalloonTapListener {
    boolean onMarkerBalloonTapped(int index, OverlayItem overlayItem);
}
