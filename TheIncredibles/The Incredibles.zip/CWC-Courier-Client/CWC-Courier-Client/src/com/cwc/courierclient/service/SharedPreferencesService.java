package com.cwc.courierclient.service;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Author: sharafat
 * Date: 1/26/12 4:05 PM
 */
public class SharedPreferencesService {
    private static final String PREFERENCES_FILE_NAME = "Preferences";
    private static final String USERNAME = "username";
    private static final String REMEMBERED = "remembered";

    private static SharedPreferencesService sharedPreferencesService;

    private SharedPreferences preferences;

    private SharedPreferencesService() {
    }

    public static SharedPreferencesService getInstance(Context context) {
        if (sharedPreferencesService == null) {
            sharedPreferencesService = new SharedPreferencesService();
            sharedPreferencesService.preferences =
                    context.getSharedPreferences(PREFERENCES_FILE_NAME, Context.MODE_PRIVATE);
        }

        return sharedPreferencesService;
    }

    public String getUsername() {
        return preferences.getString(USERNAME, "");
    }

    public void setUsername(String username) {
        preferences.edit().putString(USERNAME, username).commit();
    }

    public boolean isRemembered() {
        return preferences.getBoolean(REMEMBERED, false);
    }

    public void setRemembered(boolean remembered) {
        preferences.edit().putBoolean(REMEMBERED, remembered).commit();
    }
}
