package com.cwc.courierclient.activity;

import android.content.Intent;
import android.os.Bundle;

public class LocationHistoryTabActivity extends TabGroupActivity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		startChildActivity(TaskHistoryListActivity.class.getCanonicalName(),
				new Intent(this, LocationLogActivity.class));
	}
}
