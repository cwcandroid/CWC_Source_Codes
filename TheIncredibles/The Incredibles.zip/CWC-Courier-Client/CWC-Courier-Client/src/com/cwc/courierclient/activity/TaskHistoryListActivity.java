package com.cwc.courierclient.activity;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.service.TaskRepository;
import com.cwc.courierclient.utils.Dialogs;

import java.io.Serializable;
import java.util.ArrayList;

public class TaskHistoryListActivity extends ListActivity {
    private static final int DIALOG_TASK_FETCHING_IN_PROGRESS = 0;

    private Handler updateTaskListHandler = new Handler() {
        public void handleMessage(Message message) {
            setListAdapter(new TaskListAdapter(TaskHistoryListActivity.this, TaskRepository.getTaskHistory()));
            dismissDialog(DIALOG_TASK_FETCHING_IN_PROGRESS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history);

        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent = new Intent(getParent(), TaskDetailsActivity.class);
                intent.putExtra(TaskListActivity.SELECTED_TASK, (Serializable) getListAdapter().getItem(position));
                ((TabGroupActivity) getParent()).startChildActivity(
                        TaskDetailsActivity.class.getCanonicalName(), intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (TaskRepository.isTaskHistoryInitialized()) {
            setListAdapter(new TaskListAdapter(this, TaskRepository.getTaskHistory()));
        } else {
            setListAdapter(new TaskListAdapter(this, new ArrayList<Task>()));

            showDialog(DIALOG_TASK_FETCHING_IN_PROGRESS);
            TaskRepository.initializeTaskHistory(this, updateTaskListHandler);
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_TASK_FETCHING_IN_PROGRESS:
                return Dialogs.buildIndeterminateProgressDialog(getParent(), R.string.fetching_tasks_progress_msg, true);
        }

        return null;
    }

}
