package com.cwc.courierclient.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.widget.TabHost;
import com.cwc.courierclient.R;

public class MainScreenActivity extends TabActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// setup tabs
		TabHost tabHost = getTabHost();
		TabHost.TabSpec tabSpec;
		Intent intent;

		intent = new Intent().setClass(this, TasksTabActivity.class);
		tabSpec = tabHost.newTabSpec("tasks").setIndicator(getString(R.string.tasks), null).setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, HistoryTabActivity.class);
		tabSpec = tabHost.newTabSpec("history").setIndicator(getString(R.string.history), null).setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, PerformanceActivity.class);
		tabSpec = tabHost.newTabSpec("performance").setIndicator(getString(R.string.performance), null).setContent(intent);
		tabHost.addTab(tabSpec);
		
		//shaiekh
		intent = new Intent().setClass(this, LocationHistoryTabActivity.class);
		tabSpec = tabHost.newTabSpec("locationHistory").setIndicator(getString(R.string.locationhistory), null).setContent(intent);
		tabHost.addTab(tabSpec);
		
		doInBackground();
		
	}
	
	
	protected void doInBackground() {
		 
        File dbFile =
                 new File(Environment.getDataDirectory() + "/data/com.cwc.courierclient/databases/cwc_courier_client.db");

        File exportDir = new File(Environment.getExternalStorageDirectory(), "exampledata");
        if (!exportDir.exists()) {
           exportDir.mkdirs();
        }
        File file = new File(Environment.getExternalStorageDirectory(), dbFile.getName());

        try {
           file.createNewFile();
           this.copyFile(dbFile, file);
           //return true;
        } catch (IOException e) {
           //Log.e(MyApplication.APP_NAME, e.getMessage(), e);
           //return false;
        	e.printStackTrace();
        }
     }


     void copyFile(File src, File dst) throws IOException {
        FileChannel inChannel = new FileInputStream(src).getChannel();
        FileChannel outChannel = new FileOutputStream(dst).getChannel();
        try {
           inChannel.transferTo(0, inChannel.size(), outChannel);
        } finally {
           if (inChannel != null)
              inChannel.close();
           if (outChannel != null)
              outChannel.close();
        }
     }
	
	

}
