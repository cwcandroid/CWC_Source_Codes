package com.cwc.courierclient.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.cwc.courierclient.R;
import com.cwc.courierclient.exception.NoInternetConnectionException;
import com.cwc.courierclient.exception.RegistrationFailedException;
import com.cwc.courierclient.exception.ServerConnectionException;
import com.cwc.courierclient.service.RegistrationService;
import com.cwc.courierclient.utils.Dialogs;
import com.cwc.courierclient.utils.Validator;

public class RegistrationActivity extends Activity {
    private static final int DIALOG_REGISTRATION_PROGRESS = 0;
    private static final int DIALOG_NO_INTERNET_CONNECTION = 1;

    private static final String REGISTRATION_RESULT_KEY = "status";
    private static final String REGISTRATION_RESULT_ERROR_KEY = "text";
    private static final int REGISTRATION_RESULT_FAILED = 0;
    private static final int REGISTRATION_RESULT_SUCCESSFUL = 1;
    private static final int REGISTRATION_RESULT_NO_INTERNET_CONNECTION = 2;
    private static final int REGISTRATION_RESULT_SERVER_CONNECTION_ERROR = 3;

    private EditText usernameInput;
    private EditText emailInput;
    private EditText passwordInput;
    private EditText confirmPasswordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        usernameInput = (EditText) findViewById(R.id.username_input);
        emailInput = (EditText) findViewById(R.id.email_input);
        passwordInput = (EditText) findViewById(R.id.password_input);
        confirmPasswordInput = (EditText) findViewById(R.id.confirm_password_input);

        Button registerBtn = (Button) findViewById(R.id.register_btn);
        Button loginBtn = (Button) findViewById(R.id.login_btn);

        registerBtn.setOnClickListener(new RegisterButtonClickListener());

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
            }
        });
    }

    private final Handler handler = new Handler() {
        public void handleMessage(Message message) {
            dismissDialog(DIALOG_REGISTRATION_PROGRESS);

            switch (message.getData().getInt(REGISTRATION_RESULT_KEY)) {
                case REGISTRATION_RESULT_SUCCESSFUL:
                    Dialogs.buildOkDialog(RegistrationActivity.this, getString(R.string.registration_success_msg),
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                    finish();
                                }
                            }).show();
                    break;
                case REGISTRATION_RESULT_FAILED:
                    Dialogs.buildOkDialog(RegistrationActivity.this, getString(R.string.error)
                            + ": " + message.getData().getString(REGISTRATION_RESULT_ERROR_KEY)).show();
                    break;
                case REGISTRATION_RESULT_NO_INTERNET_CONNECTION:
                    showDialog(DIALOG_NO_INTERNET_CONNECTION);
                    break;
                case REGISTRATION_RESULT_SERVER_CONNECTION_ERROR:
                    Dialogs.buildOkDialog(RegistrationActivity.this, getString(R.string.server_conn_err_msg)
                            + ": " + message.getData().getString(REGISTRATION_RESULT_ERROR_KEY)).show();
                    break;
            }
        }
    };

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_REGISTRATION_PROGRESS:
                return Dialogs.buildIndeterminateProgressDialog(RegistrationActivity.this,
                        R.string.registration_progress_msg, true);
            case DIALOG_NO_INTERNET_CONNECTION:
                return Dialogs.buildOkDialog(RegistrationActivity.this, R.string.connect_to_internet_msg);
        }

        return null;
    }

    private class RegisterButtonClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            if (!validateUsername() | !validateEmail() | !validatePasswords()) {
                return;
            }

            showDialog(DIALOG_REGISTRATION_PROGRESS);

            new Registration(handler, usernameInput.getText().toString(), emailInput.getText().toString(),
                    passwordInput.getText().toString()).start();
        }

        private boolean validateUsername() {
            return validateRequired(usernameInput) && validateUsernamePattern(usernameInput);
        }

        private boolean validateEmail() {
            return validateRequired(emailInput) && validateEmailPattern(emailInput);
        }

        private boolean validatePasswords() {
            return (validateRequired(passwordInput) & validateRequired(confirmPasswordInput))
                    && validatePasswordsMatch(passwordInput, confirmPasswordInput);
        }

        private boolean validateRequired(EditText editText) {
            if ("".equals(editText.getText().toString().trim())) {
                editText.setError(getString(R.string.required));
                return false;
            } else {
                editText.setError(null);
                return true;
            }
        }

        private boolean validateUsernamePattern(EditText editText) {
            if (!Validator.validUsername(editText.getText().toString())) {
                editText.setError(getString(R.string.invalid_username));
                return false;
            } else {
                editText.setError(null);
                return true;
            }
        }

        private boolean validateEmailPattern(EditText editText) {
            if (!Validator.validEmail(editText.getText().toString())) {
                editText.setError(getString(R.string.invalid_email));
                return false;
            } else {
                editText.setError(null);
                return true;
            }
        }

        private boolean validatePasswordsMatch(EditText passwordInput, EditText confirmPasswordInput) {
            if (!passwordInput.getText().toString().equals(confirmPasswordInput.getText().toString())) {
                passwordInput.setError(getString(R.string.passwords_dont_match));
                passwordInput.setText("");
                confirmPasswordInput.setText("");
                return false;
            } else {
                passwordInput.setError(null);
                return true;
            }
        }
    }

    private class Registration extends Thread {
        private Handler handler;
        private String username, password, email;

        Registration(Handler handler, String username, String email, String password) {
            this.handler = handler;
            this.username = username;
            this.email = email;
            this.password = password;
        }

        @Override
        public void run() {
            Bundle bundle = new Bundle();
            Message message = handler.obtainMessage();
            message.setData(bundle);

            int registrationResult = -1;
            try {
                new RegistrationService().register(RegistrationActivity.this, username, email, password);
                registrationResult = REGISTRATION_RESULT_SUCCESSFUL;
            } catch (RegistrationFailedException e) {
                registrationResult = REGISTRATION_RESULT_FAILED;
                bundle.putString(REGISTRATION_RESULT_ERROR_KEY, e.getMessage());
            } catch (NoInternetConnectionException e) {
                registrationResult = REGISTRATION_RESULT_NO_INTERNET_CONNECTION;
            } catch (ServerConnectionException e) {
                registrationResult = REGISTRATION_RESULT_SERVER_CONNECTION_ERROR;
                bundle.putString(REGISTRATION_RESULT_ERROR_KEY, e.getMessage());
            }

            bundle.putInt(REGISTRATION_RESULT_KEY, registrationResult);
            handler.sendMessage(message);
        }
    }
}
