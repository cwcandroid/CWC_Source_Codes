package com.cwc.courierclient.exception;

/**
 * Author: sharafat
 * Date: 1/23/12 12:37 PM
 */
public class NoInternetConnectionException extends RuntimeException {

}
