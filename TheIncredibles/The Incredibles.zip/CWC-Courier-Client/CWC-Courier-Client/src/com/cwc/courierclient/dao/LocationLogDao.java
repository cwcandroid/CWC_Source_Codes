package com.cwc.courierclient.dao;

import java.util.ArrayList;
import java.util.List;

import com.cwc.courierclient.domain.LocationHistory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class LocationLogDao {
	private static final String TABLE = "locationlog";
	private static final String COL_ID = "_id";
	private static final String COL_LATITUDE = "latitude";
	private static final String COL_LONGITUDE = "longitude";
	private static final String COL_DUE_DATE = "duedate";

	private DB db;

	public LocationLogDao(Context context) {
		db = DB.getInstance(context);
	}

	public long insert(LocationHistory locationHistory) {
		
		return db.getWritableDatabase().insertOrThrow(TABLE, null,
				getContentValues(locationHistory));
	}

	public List<LocationHistory> listAll() {
		List<LocationHistory> locationHistories = new ArrayList<LocationHistory>();

		Cursor mCursor = db.getReadableDatabase().query(TABLE, getAllColumns(),
				null, null, null, null, null);
		if (mCursor != null) {
			if (mCursor.moveToFirst()) {
				do {
					locationHistories.add(populateLocation(mCursor));
				} while (mCursor.moveToNext());
			}
			mCursor.close();
		}

		return locationHistories;
	}
	
	
	public List<LocationHistory> listAllByDate(String dueDate) {
		List<LocationHistory> locationHistories = new ArrayList<LocationHistory>();

		Cursor mCursor = db.getReadableDatabase().query(TABLE, getAllColumns(),
				COL_DUE_DATE + "=" + dueDate, null, null, null, null);
		if (mCursor != null) {
			if (mCursor.moveToFirst()) {
				do {
					locationHistories.add(populateLocation(mCursor));
				} while (mCursor.moveToNext());
			}
			mCursor.close();
		}

		return locationHistories;
	}
	
	

	private LocationHistory populateLocation(Cursor cursor) {
		LocationHistory locationHistory = new LocationHistory();
		locationHistory.setLatitude(cursor.getDouble(0));
		locationHistory.setLongitude(cursor.getDouble(1));
		locationHistory.setDuedate(cursor.getString(2));
		return locationHistory;
	}

	private ContentValues getContentValues(LocationHistory locationHistory) {
		ContentValues contentValues = new ContentValues();
		contentValues.put(COL_LATITUDE, locationHistory.getLatitude());
		contentValues.put(COL_LONGITUDE, locationHistory.getLongitude());
		contentValues.put(COL_DUE_DATE, locationHistory.getDuedate());
		return contentValues;
	}

	private String[] getAllColumns() {
		return new String[] { COL_ID, COL_LATITUDE, COL_LONGITUDE, COL_DUE_DATE };
	}

}
