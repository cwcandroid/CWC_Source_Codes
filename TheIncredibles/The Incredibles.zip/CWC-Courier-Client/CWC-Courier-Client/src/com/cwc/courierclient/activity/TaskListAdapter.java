package com.cwc.courierclient.activity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;

import java.util.List;

/**
* Author: sharafat
* Date: 1/26/12 6:14 PM
*/
class TaskListAdapter extends ArrayAdapter<Task> {
    private List<Task> tasks;
    private LayoutInflater layoutInflater;
    private Context context;

    public TaskListAdapter(Context context, List<Task> taskList) {
        super(context, R.layout.task_list_entry, taskList);

        this.context = context;
        tasks = taskList;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = layoutInflater.inflate(R.layout.task_list_entry, null);

        ImageView taskStatusImageView = (ImageView) convertView.findViewById(R.id.image);
        TextView taskNameTextView = (TextView) convertView.findViewById(R.id.task_name);
        TextView taskAddressTextView = (TextView) convertView.findViewById(R.id.task_address);

        Task task = tasks.get(position);

        int taskStatusDrawableResId;
        switch (task.getStatus()) {
            case Task.STATUS_COMPLETE:
                taskStatusDrawableResId = R.drawable.task_complete;
                break;
            case Task.STATUS_INCOMPLETE:
                taskStatusDrawableResId = R.drawable.task_incomplete;
                break;
            default:
                taskStatusDrawableResId = R.drawable.task_pending;
                break;
        }

        taskStatusImageView.setImageDrawable(context.getResources().getDrawable(taskStatusDrawableResId));
        taskNameTextView.setText(task.getName());
        taskAddressTextView.setText(task.getAddress());

        return convertView;
    }
}
