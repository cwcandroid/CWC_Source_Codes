package com.cwc.courierclient.activity;

import android.content.Intent;
import android.os.Bundle;

/**
 * Author: sharafat
 * Date: 1/25/12 12:55 AM
 */
public class TasksTabActivity extends TabGroupActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startChildActivity(TaskListActivity.class.getCanonicalName(), new Intent(this, TaskListActivity.class));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // This is called when the camera and image-crop app returns result.
        // We simply delegate the call to the activity from which those apps were started.
        ((ReportTaskActivity) getLocalActivityManager().getActivity(ReportTaskActivity.class.getCanonicalName()))
                .onActivityResult(requestCode, resultCode, data);
    }
}
