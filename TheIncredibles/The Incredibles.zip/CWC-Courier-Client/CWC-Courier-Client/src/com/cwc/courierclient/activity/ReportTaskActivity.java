package com.cwc.courierclient.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import com.cwc.courierclient.R;
import com.cwc.courierclient.domain.Task;
import com.cwc.courierclient.service.TaskService;
import com.cwc.courierclient.utils.BitmapByteArrayConverter;
import com.cwc.courierclient.utils.Dialogs;
import com.cwc.courierclient.utils.GPSLocation;
import com.cwc.courierclient.utils.gmaps.LatLongGeoPoint;
import com.cwc.courierclient.utils.imagecrop.ImageCrop;

import java.io.File;

/**
 * Author: sharafat
 * Date: 1/26/12 9:34 PM
 */
public class ReportTaskActivity extends Activity {
    public static final int TAKE_PHOTO_FROM_CAMERA = 0;
    public static final int CROP_IMAGE = 1;

    private static final int DIALOG_SENDING_TASK_REPORT = 0;

    private static final String SENDING_TASK_REPORT_SUCCESSFUL = "sending_task_report_success";

    private TaskService taskService;
    private Task task;
    private Bitmap signature;
    private Uri imageCaptureUri;

    private final Handler dialogHandler = new Handler() {
        public void handleMessage(Message message) {
            dismissDialog(DIALOG_SENDING_TASK_REPORT);

            Dialogs.buildOkDialog(ReportTaskActivity.this.getParent(), message.getData().getBoolean(SENDING_TASK_REPORT_SUCCESSFUL)
                    ? R.string.task_reporting_successful : R.string.task_reporting_failed, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            }).show();
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(LayoutInflater.from(this.getParent()).inflate(R.layout.report_task, null));

        taskService = new TaskService(this);
        task = (Task) getIntent().getSerializableExtra(TaskDetailsActivity.SELECTED_TASK);

        prepareReasonTypeSpinner();
        prepareTakeSignatureButton();
        prepareCancelButton();
        prepareSubmitButton();
    }

    private void prepareReasonTypeSpinner() {
        final Spinner reasonTypeSpinner = (Spinner) findViewById(R.id.reason_type_spinner);

        @SuppressWarnings("unchecked")
        ArrayAdapter reasonTypeSpinnerAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
                new ReasonTypeSpinnerOption[]{
                        new ReasonTypeSpinnerOption(Task.REASON_TYPE_DELIVERED, TaskService.getReasonText(this, Task.REASON_TYPE_DELIVERED)),
                        new ReasonTypeSpinnerOption(Task.REASON_TYPE_NOT_DELIVERED, TaskService.getReasonText(this, Task.REASON_TYPE_NOT_DELIVERED)),
                        new ReasonTypeSpinnerOption(Task.REASON_TYPE_ADDRESS_NOT_FOUND, TaskService.getReasonText(this, Task.REASON_TYPE_ADDRESS_NOT_FOUND)),
                        new ReasonTypeSpinnerOption(Task.REASON_TYPE_RECIPIENT_ABSENT, TaskService.getReasonText(this, Task.REASON_TYPE_RECIPIENT_ABSENT)),
                        new ReasonTypeSpinnerOption(Task.REASON_TYPE_OTHERS, TaskService.getReasonText(this, Task.REASON_TYPE_OTHERS))
                });

        reasonTypeSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reasonTypeSpinner.setAdapter(reasonTypeSpinnerAdapter);
        reasonTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ReasonTypeSpinnerOption reasonTypeSpinnerOption = (ReasonTypeSpinnerOption) reasonTypeSpinner.getSelectedItem();
                boolean itemDeliveredOptionSelected = reasonTypeSpinnerOption.reasonType == Task.REASON_TYPE_DELIVERED;
                findViewById(R.id.take_signature_btn).setEnabled(itemDeliveredOptionSelected);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void prepareTakeSignatureButton() {
        final Button takeSignatureButton = (Button) findViewById(R.id.take_signature_btn);
        takeSignatureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                imageCaptureUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(),
                        "tmp_cwc-courier-service_signature_" + String.valueOf(System.currentTimeMillis()) + ".jpg"));
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageCaptureUri);
                try {
                    cameraIntent.putExtra("return-data", true);
                    getParent().startActivityForResult(cameraIntent, TAKE_PHOTO_FROM_CAMERA);
                } catch (ActivityNotFoundException ignore) {    // device has no camera
                    Log.w(getClass().getCanonicalName(), "Camera not available in device.");
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case TAKE_PHOTO_FROM_CAMERA:
                if (resultCode == RESULT_OK) {
                    if (ImageCrop.imageCroppingAppAvailable(this)) {
                        ImageCrop.cropImage(imageCaptureUri, getParent(), 200, 100, 0, 0, true);
                    } else {
                        Log.i(getClass().getCanonicalName(), "No crop app found.");
                        manageTakenSignature(BitmapFactory.decodeFile(imageCaptureUri.getPath()));
                    }
                }
                break;
            case CROP_IMAGE:
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    if (extras != null) {
                        manageTakenSignature((Bitmap) extras.getParcelable("data"));
                    }

                    Uri tmpImageUri = data.getData();
                    if (tmpImageUri != null) {
                        deleteTempFile(tmpImageUri);
                    }
                }
                break;
        }
    }

    private void manageTakenSignature(Bitmap bitmap) {
        if (bitmap != null) {
            signature = bitmap;
            ((ImageView) findViewById(R.id.signature_imageview)).setImageBitmap(signature);
        }

        deleteTempFile(imageCaptureUri);
    }

    private void deleteTempFile(Uri uri) {
        File tempImageFile = new File(uri.getPath());
        if (tempImageFile.exists()) {
            tempImageFile.delete();
        }
    }

    private void prepareCancelButton() {
        Button cancelButton = (Button) findViewById(R.id.cancel_btn);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void prepareSubmitButton() {
        Button submitButton = (Button) findViewById(R.id.submit_btn);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedReasonType = ((ReasonTypeSpinnerOption) ((Spinner) findViewById(R.id.reason_type_spinner))
                        .getSelectedItem()).reasonType;
                String reasonDetails = ((EditText) findViewById(R.id.reason_details_input)).getText().toString();

                LatLongGeoPoint myLocation = GPSLocation.getMyLocation();
                double reportingLatitude = myLocation.getLatitude();
                double reportingLongitude = myLocation.getLongitude();

                task.setReasontype(selectedReasonType);
                task.setStatus(getTaskStatusAccordingToReasonType(selectedReasonType));
                if (selectedReasonType == Task.REASON_TYPE_DELIVERED && signature != null) {
                    task.setSignaturefile(BitmapByteArrayConverter.bitmap2ByteArray(signature));
                }
                task.setReasondetails(reasonDetails);
                task.setReportlatitude(reportingLatitude);
                task.setReportlongitude(reportingLongitude);

                showDialog(DIALOG_SENDING_TASK_REPORT);
                new TaskReporting(dialogHandler, task, reportingLatitude, reportingLongitude).start();
            }
        });
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_SENDING_TASK_REPORT:
                return Dialogs.buildIndeterminateProgressDialog(getParent(), R.string.report_tasks_progress_msg, true);
        }

        return null;
    }

    private int getTaskStatusAccordingToReasonType(int reasonType) {
        if (reasonType == Task.REASON_TYPE_DELIVERED) {
            return Task.STATUS_COMPLETE;
        } else {
            return Task.STATUS_PENDING;
        }
    }

    private class ReasonTypeSpinnerOption {
        int reasonType;
        String reasonTypeText;

        private ReasonTypeSpinnerOption(int reasonType, String reasonTypeText) {
            this.reasonType = reasonType;
            this.reasonTypeText = reasonTypeText;
        }

        @Override
        public String toString() {
            return reasonTypeText;
        }
    }

    private class TaskReporting extends Thread {
        private Handler handler;
        private Task task;
        private double reportingLatitude, reportingLongitude;

        TaskReporting(Handler handler, Task task, double reportingLatitude, double reportingLongitude) {
            this.handler = handler;
            this.task = task;
            this.reportingLatitude = reportingLatitude;
            this.reportingLongitude = reportingLongitude;
        }

        @Override
        public void run() {
            Bundle bundle = new Bundle();
            Message message = handler.obtainMessage();
            message.setData(bundle);

            boolean taskReportingSuccessful = taskService.reportTask(task, reportingLatitude, reportingLongitude);

            bundle.putBoolean(ReportTaskActivity.SENDING_TASK_REPORT_SUCCESSFUL, taskReportingSuccessful);
            handler.sendMessage(message);
        }
    }

}
