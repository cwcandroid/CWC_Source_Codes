package com.cwc.courierclient.utils;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import com.cwc.courierclient.R;

/**
 * Author: sharafat
 * Date: 1/23/12 4:03 PM
 */
public class Dialogs {

    public static Dialog buildOkDialog(Context context, int msgResourceId) {
        return buildOkDialog(context, context.getString(msgResourceId));
    }

    public static Dialog buildOkDialog(Context context, int msgResourceId, DialogInterface.OnClickListener onClickListener) {
        return buildOkDialog(context, context.getString(msgResourceId), onClickListener);
    }

    public static Dialog buildOkDialog(Context context, String message) {
        return buildOkDialog(context, message, null);
    }

    public static Dialog buildOkDialog(Context context, String message, DialogInterface.OnClickListener onClickListener) {
        return new AlertDialog.Builder(context)
                .setTitle(context.getString(R.string.app_name))
                .setMessage(message)
                .setPositiveButton(context.getString(R.string.ok), onClickListener)
                .setCancelable(true)
                .create();
    }

    public static Dialog buildIndeterminateProgressDialog(Context context, int msgResourceId, boolean cancellable) {
        return buildIndeterminateProgressDialog(context, context.getString(msgResourceId), cancellable);
    }

    public static Dialog buildIndeterminateProgressDialog(Context context, String message, boolean cancellable) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage(message);
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(cancellable);

        return progressDialog;
    }
}
