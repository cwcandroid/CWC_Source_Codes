package com.cwc.courierclient.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * Author: sharafat
 * Date: 1/23/12 1:33 AM
 */
public class UrlBuilder {

    public static String build(String baseUrl, String[] paramNames, String[] paramValues) {
        if (paramNames.length > 0) {
            StringBuilder url = new StringBuilder(baseUrl);
            url.ensureCapacity(paramNames.length * 20);
            url.append("?");

            for (int i = 0; i < paramNames.length; i++) {
                String paramName = paramNames[i];
                String paramValue = paramValues[i];

                try {
                    paramName = URLEncoder.encode(paramName, "UTF-8");
                    paramValue = URLEncoder.encode(paramValue, "UTF-8");
                } catch (UnsupportedEncodingException ignore) {
                }

                url.append(paramName).append("=").append(paramValue);
                if (i < paramNames.length - 1) {
                    url.append("&");
                }
            }

            return url.toString();
        }

        return baseUrl;
    }
}
