package com.cwc.courierclient.utils.gmaps;

import android.graphics.drawable.Drawable;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import com.readystatesoftware.mapviewballoons.BalloonItemizedOverlay;

import java.util.ArrayList;
import java.util.List;

/**
 * Author: sharafat
 * Date: 1/25/12 3:18 PM
 */
public class MapMarkerOverlay extends BalloonItemizedOverlay<OverlayItem> {
    private List<OverlayItem> overlayItems;
    private OnMarkerBalloonTapListener onMarkerBalloonTapListener;

    public MapMarkerOverlay(Drawable defaultMarker, MapView mapView,
                            OnMarkerBalloonTapListener onMarkerBalloonTapListener) {
        super(boundCenterBottom(defaultMarker), mapView);
        this.onMarkerBalloonTapListener = onMarkerBalloonTapListener;
        overlayItems = new ArrayList<OverlayItem>();
    }

    public void addMarkerOverlayItem(double latitude, double longitude, String title, String snippet, Drawable marker) {
        OverlayItem overlayItem = new OverlayItem(new LatLongGeoPoint(latitude, longitude), title, snippet);
        overlayItem.setMarker(boundCenterBottom(marker));
        overlayItems.add(overlayItem);
    }

    public void populateOverlays() {
        populate();
    }

    @Override
    protected OverlayItem createItem(int i) {
        return overlayItems.get(i);
    }

    @Override
    public int size() {
        return overlayItems.size();
    }

    @Override
    protected boolean onBalloonTap(int index, OverlayItem overlayItem) {
        return onMarkerBalloonTapListener != null ?
                onMarkerBalloonTapListener.onMarkerBalloonTapped(index, overlayItem) : false;
    }

}
