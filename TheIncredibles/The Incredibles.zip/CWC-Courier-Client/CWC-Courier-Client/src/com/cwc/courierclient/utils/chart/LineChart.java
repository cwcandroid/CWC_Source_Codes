package com.cwc.courierclient.utils.chart;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.renderer.XYMultipleSeriesRenderer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * User: mashiur
 * Date: 1/27/12
 * Time: 2:44 PM
 */
public class LineChart extends AbstractDemoChart {
    private List<LineChartLineElement> lineElements = new ArrayList<LineChartLineElement>();
    private String chartName;
    private String xAxisLabel;
    private String yAxisLabel;

    public LineChart(List<LineChartLineElement> lineElements, String chartName, String xAxisLabel, String yAxisLabel) {
        this.lineElements = lineElements;
        this.chartName = chartName;
        this.xAxisLabel = xAxisLabel;
        this.yAxisLabel = yAxisLabel;
    }

    /**
     * Returns the chart name.
     *
     * @return the chart name
     */
    public String getName() {
        return "Line Graph with Date";
    }

    public Intent execute(Context context) {
        int[] lineColors = getLineColors();
        PointStyle[] styles = getPointStyles();

        double xMin = lineElements.get(0).getDates()[0].getTime();
        double xMax = lineElements.get(0).getDates()[lineElements.get(0).getDates().length - 1].getTime();
        double yMin = 0;
        double yMax = 100;
        int axesColor = Color.GRAY;
        int labelsColor = Color.LTGRAY;
        int xLabels = 30;
        int yLabels = 10;

        XYMultipleSeriesRenderer renderer = buildRenderer(lineColors, styles);
        renderer.setXLabels(xLabels);
        renderer.setXLabelsAngle(-90);
        renderer.setYLabels(yLabels);

        setChartSettings(renderer, chartName, xAxisLabel, yAxisLabel, xMin, xMax, yMin, yMax, axesColor, labelsColor);

        for (int i = 0; i < renderer.getSeriesRendererCount(); i++) {
            renderer.getSeriesRendererAt(i).setDisplayChartValues(true);
        }

        String[] lineNames = getLineNames();
        List<Date[]> datesList = getDates();
        List<double[]> countsList = getCounts();

        return ChartFactory.getTimeChartIntent(context, buildDateDataset(lineNames, datesList, countsList), renderer, "MM/dd/yyyy");
    }

    private List<double[]> getCounts() {
        List<double[]> countsList = new ArrayList<double[]>();
        for (LineChartLineElement lineElement : lineElements) {
            countsList.add(lineElement.getTaskCounts());
        }

        return countsList;
    }

    private List<Date[]> getDates() {
        List<Date[]> datesList = new ArrayList<Date[]>();
        for (LineChartLineElement lineElement : lineElements) {
            datesList.add(lineElement.getDates());
        }

        return datesList;
    }

    private PointStyle[] getPointStyles() {
        PointStyle[] pointStyles = new PointStyle[lineElements.size()];

        for (int i = 0; i < lineElements.size(); i++) {
            pointStyles[i] = lineElements.get(i).getPointStyle();
        }

        return pointStyles;
    }

    private int[] getLineColors() {
        int[] lineColors = new int[lineElements.size()];

        for (int i = 0; i < lineElements.size(); i++) {
            lineColors[i] = lineElements.get(i).getLineColor();
        }

        return lineColors;
    }

    private String[] getLineNames() {
        String[] lineNames = new String[lineElements.size()];

        for (int i = 0; i < lineElements.size(); i++) {
            lineNames[i] = lineElements.get(i).getLineName();
        }

        return lineNames;
    }
}
