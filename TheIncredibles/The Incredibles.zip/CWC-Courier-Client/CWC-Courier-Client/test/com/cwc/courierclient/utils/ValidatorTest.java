package com.cwc.courierclient.utils;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


/**
 * Author: sharafat
 * Date: 1/24/12 4:56 PM
 */
public class ValidatorTest {

    @Test
    public void testEmailValidation() {
        assertTrue(Validator.validEmail("cwuser1@gmail.com"));
        assertTrue(Validator.validEmail("a@b.com"));
        assertTrue(Validator.validEmail("a@b.co.cc"));
        assertTrue(Validator.validEmail("a_b.c-d@e.com.bd"));
        assertTrue(Validator.validEmail("1@2.com"));
        assertTrue(Validator.validEmail("1@2-1.com"));

        assertFalse(Validator.validEmail(".a@b.com"));
        assertFalse(Validator.validEmail("-a@b.com"));
        assertFalse(Validator.validEmail("_a@b.com"));
        assertFalse(Validator.validEmail("a..b@c.com"));
        assertFalse(Validator.validEmail("a--b@c.com"));
        assertFalse(Validator.validEmail("a__b@c.com"));
        assertFalse(Validator.validEmail("a_@b.com"));
        assertFalse(Validator.validEmail("a-@b.com"));
        assertFalse(Validator.validEmail("a.@b.com"));
        assertFalse(Validator.validEmail("a.b@.c.com"));
        assertFalse(Validator.validEmail("a.b@-c.com"));
        assertFalse(Validator.validEmail("a.b@_c.com"));
    }


}
