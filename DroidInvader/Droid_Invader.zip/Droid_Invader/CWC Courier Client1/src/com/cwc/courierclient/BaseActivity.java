package com.cwc.courierclient;

import android.app.Activity;

public class BaseActivity extends Activity{

}
