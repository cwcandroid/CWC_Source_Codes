package com.cwc.courierclient.adapters;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.cwc.courierclient.R;

public class ViewWrapper {
	View base;
	ImageView flagImageView;
	TextView itemName;
	TextView placeName;
	
	public ViewWrapper(View base) {
		this.base=base;
	}
	
	public ImageView getFlagImageView() {
		if (flagImageView==null) {
			flagImageView=(ImageView)base.findViewById(R.id.flagImageView);
		}
		return flagImageView;
	}
	public TextView getItemName() {
		if (itemName==null) {
			itemName=(TextView)base.findViewById(R.id.itemName);
		}
		return itemName;
	}
	public TextView getPlaceName() {
		if (placeName==null) {
			placeName=(TextView)base.findViewById(R.id.placeName);
		}
		return placeName;
	}
}
