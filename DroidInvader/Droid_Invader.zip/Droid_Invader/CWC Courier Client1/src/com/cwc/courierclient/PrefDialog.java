package com.cwc.courierclient;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

public class PrefDialog extends Activity {
	SharedPreferences app_preferences;
	private CheckBox donotChk;
	private Button yBtn, nBtn;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.datawarning);
		// Get the app's shared preferences
		donotChk = (CheckBox) findViewById(R.id.doNot);
		yBtn = (Button) findViewById(R.id.yesBtn);
		nBtn = (Button) findViewById(R.id.noBtn);
		app_preferences = PreferenceManager.getDefaultSharedPreferences(this);

		donotChk
				.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

					public void onCheckedChanged(CompoundButton buttonView,
							boolean isChecked) {
						if (isChecked == true) {
							SharedPreferences.Editor editor = app_preferences
									.edit();
							editor.putBoolean("doordont", true);
							editor.commit(); // Very important
						}
					}
				});
		nBtn.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent outData = new Intent();
				outData.putExtra("yes", false);
				setResult(Activity.RESULT_OK, outData);
				finish();
			}
		});
		yBtn.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent outData = new Intent();
				outData.putExtra("yes", true);
				setResult(Activity.RESULT_OK, outData);
				finish();
			}
		});
	}
}
