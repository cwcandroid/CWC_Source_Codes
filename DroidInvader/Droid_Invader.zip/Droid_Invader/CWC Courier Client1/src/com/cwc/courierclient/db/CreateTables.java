package com.cwc.courierclient.db;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class CreateTables {
	// Database creation SQL statement
	
	private static final String CREATE_TASK_TABLE = "create table if not exists tasklist "
		+ "(_id INTEGER  PRIMARY KEY autoincrement,"
		+ "task_id VARCHAR(20),"
		+ "address VARCHAR(300),"
		+ "comments TEXT,"
		+ "contactno VARCHAR(30),"
		+ "description TEXT,"
		+ "latitude VARCHAR(20),"
		+ "longitude  VARCHAR(20),name VARCHAR(100),status VARCHAR(2),time VARCHAR(10));";
	private static final String  CREATE_TASKHISTORY_TABLE = "create table if not exists taskhistorylist "
		+ "(_id INTEGER  PRIMARY KEY autoincrement,"
		+ "task_id VARCHAR(20),"
		+ "address VARCHAR(300),"
		+ "comments TEXT,"
		+ "contactno VARCHAR(30),"
		+ "description TEXT,"
		+ "latitude VARCHAR(20),"
		+ "longitude  VARCHAR(20),name VARCHAR(100),status VARCHAR(2),time VARCHAR(10),reasontype VARCHAR(2),reasondetails VARCHAR(100),reportlatitude VARCHAR(20),reportlongitude VARCHAR(20),signaturefile VARCHAR(100),duedate VARCHAR(20),duetime VARCHAR(10);";
	

	
	public static void onCreate(SQLiteDatabase database) {
		database.execSQL(CREATE_TASK_TABLE);
		database.execSQL(CREATE_TASKHISTORY_TABLE);
	}

	public static void onUpgrade(SQLiteDatabase database, int oldVersion,
			int newVersion) {
		Log.w(CreateTables.class.getName(), "Upgrading database from version "
				+ oldVersion + " to " + newVersion
				+ ", which will destroy all old data");
		database.execSQL("DROP TABLE IF EXISTS todo");
		onCreate(database);
	}
}
