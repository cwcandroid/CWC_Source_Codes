package com.cwc.courierclient.task;

import java.util.ArrayList;

import android.app.ActivityGroup;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;


public class TasksActivity extends ActivityGroup{
	public static TasksActivity group;
	private static ArrayList<View> history;
	Context con;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.history = new ArrayList<View>();
		group = this;
		con=this;
		
		
		// Start the root activity withing the group and get its view
		View view = getLocalActivityManager().startActivity(
				"TaskListActivity",
				new Intent(this, TaskListActivity.class)
						.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
				.getDecorView();

		// Replace the view of this ActivityGroup
		replaceView(view);
	}
	public void replaceView(View v) {
		// Adds the old one to history
		history.add(v);
		Log.v("History size:", history.size()+"");
		// Changes this Groups View to the new View.
		setContentView(v);
	}
	public void replaceView(View v,String s)
	{
		setContentView(v);
	}
	public static void historySizeDecrese()
	{
		history.remove(history.size() - 1);
		Log.v("history size:", history.size()+"");
	}

	public void back() {
		Log.v("history.size()", history.size()+"");
		if (history.size() > 1) {
			history.remove(history.size() - 1);
			setContentView(history.get(history.size() - 1));
		}
		else
		{
			finish();
		}
	}
//
//	
//	
    public void onBackPressed() {
		//finish();
    	TasksActivity.group.back();
        //return;
    }
}
