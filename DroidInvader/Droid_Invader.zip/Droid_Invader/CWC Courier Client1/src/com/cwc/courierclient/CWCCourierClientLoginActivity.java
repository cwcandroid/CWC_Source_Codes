package com.cwc.courierclient;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import com.cwc.courierclient.components.CheckInternet;
import com.cwc.courierclient.components.StaticClass;

public class CWCCourierClientLoginActivity extends Activity {
	
	protected static final int LOGININFOLOADED = 1;
	
	private CheckBox savePref;
	private EditText userID,userPass;
	private SharedPreferences app_preferences;
	private String loginurl = "";
	private Context contxt;
	private ProgressDialog progressDialog;
	private String usr;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        contxt = this;
        loadGui();
        app_preferences = PreferenceManager.getDefaultSharedPreferences(this);
		boolean checkTik = app_preferences.getBoolean("saveP", false);

		if (checkTik) {
			// Get the value
			String userValue = app_preferences.getString("userid", "nomail");
			// Log.d("emailValue",""+emailValue);
			String passValue = app_preferences.getString("userpass", "nopass");
			// Log.d("passValue",""+passValue);
			savePref.setChecked(checkTik);
			userID.setText(userValue);
			userPass.setText(passValue);
		}
        
        savePref
		.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				if (isChecked == true) {
					SharedPreferences.Editor editor = app_preferences
							.edit();
					editor.putBoolean("saveP", true);
					editor.putString("userid", userID.getText().toString());
					editor.putString("userpass", userPass.getText().toString());
					editor.commit(); // Very important
				} else {
					SharedPreferences.Editor editor = app_preferences
							.edit();
					editor.putBoolean("saveP", false);
					editor.commit(); // Very important
				}
			}
		});
        
    }
    
    public void loginClick(View button){
    	usr = userID.getText().toString();
    	String pass = userPass.getText().toString();
		if(usr.length()>0){
			if(pass.length()>0){
				if(CheckInternet.checkConn(contxt)){
					loginurl = StaticClass.baseUrl + "login?username="+usr+"&password="+pass+"&returnType=json";
					Log.e("loginurl",loginurl);
					progressDialog = ProgressDialog.show(contxt, "Login", "getting verified...");
					
					if (loginurl.length() > 0) {
						new Thread() {
							@Override
							public void run() {
								String response = StaticClass.getResponseString(loginurl);
								Bundle bd = new Bundle();
								bd.putString("response", response);
								Message msg = new Message();
								msg.what = LOGININFOLOADED;
								msg.setData(bd);
								loginHandler.sendMessage(msg);
							}
						}.start();
					}
				}else{
					StaticClass.showToastMessageLong(contxt, "Network unavilable, please check you connectivity settings");
				}
			}else{
				userPass.requestFocus();
				StaticClass.showAlertMessage(contxt, "Please enter your password correctly");
			}

		}else{
			StaticClass.showAlertMessage(contxt, "Please enter your username correctly");
		}
    }
    
    public void registerClick(View button){
		Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientRegistrationActivity.class);
		startActivity(i);
    }
	private void loadGui() {
		// TODO Auto-generated method stub
        savePref = (CheckBox) findViewById(R.id.savePref);
        userID = (EditText) findViewById(R.id.userID);
        userPass = (EditText)findViewById(R.id.userPass);
	}
	
	private Handler loginHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case LOGININFOLOADED:
				if(progressDialog!=null && progressDialog.isShowing()){
					progressDialog.dismiss();	
				}
				Bundle bd = msg.getData();
				String resp = bd.getString("response");
				if(resp.contains("status")&&resp.contains("true")){	
					StaticClass.username = usr;
					// If authentication successful
					Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientMainScreenActivity.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}else{
					StaticClass.showAlertMessage(contxt, "Can not login please try again");
				}

				break;
			}

		}
	};
	
}