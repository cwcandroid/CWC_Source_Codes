package com.cwc.courierclient;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.cwc.courierclient.components.CheckInternet;
import com.cwc.courierclient.components.StaticClass;
import com.cwc.courierclient.components.ValidatorClass;

public class CWCCourierClientRegistrationActivity extends Activity{
	private EditText regUserId,regEmail,regPass,regConPass;
	private Context contxt;
	private ValidatorClass validator;
	private String registerUrl = "";
	private ProgressDialog progressDialog;
	protected static final int REGINFOLOADED = 1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		contxt = this;
		loadGui();
		validator = new ValidatorClass();
	}
	
	public void loginMe(View button){
		Intent i=new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientLoginActivity.class);
		startActivity(i);
	}
	public void registerMe(View button){
		String userid = regUserId.getText().toString();
		String userpass = regPass.getText().toString();
		String repass = regConPass.getText().toString();
		String useremail = regEmail.getText().toString();
		
		if(userid.length()>0){			
			if(validator.validateEmail(useremail)){
				if(userpass.length()>0&&repass.length()>0){
					if(validator.validate(userpass)&&validator.validate(repass)){
						if(userpass.equals(repass)){						
							if(CheckInternet.checkConn(contxt)){
							registerUrl = StaticClass.baseUrl+"register?username="+userid+"&password="+userpass+"&returnType=json&email="+useremail;
							progressDialog = ProgressDialog.show(contxt, "Login", "getting verified...");							
								new Thread() {
									@Override
									public void run() {
										String response = StaticClass.getResponseString(registerUrl);
										Bundle bd = new Bundle();
										bd.putString("response", response);
										Message msg = new Message();
										msg.what = REGINFOLOADED;
										msg.setData(bd);
										regHandler.sendMessage(msg);
									}
								}.start();
							}else{
								StaticClass.showToastMessageLong(contxt, "Network unavilable, please check you connectivity settings");
							}
						
					}else{
						regConPass.requestFocus();
						StaticClass.showToastMessageLong(contxt, "Password does not match");
					}
				}else{
					regPass.requestFocus();
					StaticClass.showToastMessageLong(contxt, "Password can contain characters from a-z_.A-Z$ only");
				}
			}else{
				regPass.requestFocus();
				StaticClass.showToastMessageLong(contxt, "Password field can not be blank");
			}
			}else{
				regEmail.requestFocus();
				StaticClass.showToastMessageLong(contxt, "Please enter a valid email address");	
			}
		}else{
			regUserId.requestFocus();
			StaticClass.showToastMessageLong(contxt, "Please a insert username correctly");
		}
	}
	
	private void loadGui() {
		// TODO Auto-generated method stub
		regUserId = (EditText)findViewById(R.id.regUserId);
		regPass = (EditText)findViewById(R.id.regPass);
		regEmail = (EditText)findViewById(R.id.regEmail);
		regConPass = (EditText)findViewById(R.id.regConPass);
//		loginBT = (Button)findViewById(R.id.loginBT);
	}
	private Handler regHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case REGINFOLOADED:
				if(progressDialog!=null && progressDialog.isShowing()){
					progressDialog.dismiss();	
				}
				Bundle bd = msg.getData();
				String resp = bd.getString("response");
				if(resp.contains("status")&&resp.contains("Success")){					
					// If authentication successful
					Intent i=new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientLoginActivity.class);
					startActivity(i);
				}else{
					StaticClass.showAlertMessage(contxt, "Can not login please try again");
				}

				break;
			}

		}
	};
}
