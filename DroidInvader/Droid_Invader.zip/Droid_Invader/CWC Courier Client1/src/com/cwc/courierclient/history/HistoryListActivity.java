package com.cwc.courierclient.history;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ListView;

import com.cwc.courierclient.R;
import com.cwc.courierclient.adapters.TaskListItemAdapter;
import com.cwc.courierclient.components.CheckInternet;
import com.cwc.courierclient.components.StaticClass;
import com.cwc.courierclient.xmlparse.MyXMLHandlerItems;
import com.cwc.courierclient.xmlparse.XmlParseClass;

public class HistoryListActivity extends Activity {
	protected static final int NULLFLAGON = 0,TASKITEMLOADING = 1;
	String taskGettingUrl = StaticClass.baseUrl+"getTaskHistory?username="+StaticClass.username+"&returnType=xml";
	private int nullFlag;
	private Context contxt;
	private Activity con;
	private ArrayList<XmlParseClass> list;
	private ListView historyTaskList;
	private TaskListItemAdapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history);
		contxt = this;
		con = this;
		list = new ArrayList<XmlParseClass>();
		
		historyTaskList = (ListView)findViewById(R.id.historyTaskList);
		adapter = new TaskListItemAdapter(con, list);
		historyTaskList.setAdapter(adapter);
		
		if (CheckInternet.checkConn(contxt)) {
			new Thread() {
				@Override
				public void run() {
					getResponseData(taskGettingUrl);
				}
			}.start();
		}
	}
	
	private void getResponseData(String link) {
		Vector vvv = null;
		synchronized (this) {
			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser sp;
			try {
				sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();
				URL sourceUrl = new URL(link);
				MyXMLHandlerItems myXMLHandler = new MyXMLHandlerItems();
				xr.setContentHandler(myXMLHandler);
				xr.parse(new InputSource(sourceUrl.openStream()));
				vvv = myXMLHandler.v;
			} catch (ParserConfigurationException e) {
				// Log.d("problem: ", "1");
				e.printStackTrace();
			} catch (SAXException e) {
				// Log.d("problem: ", "2");
				e.printStackTrace();
			} catch (IOException e) {
				// Log.d("problem: ", "3");
				e.printStackTrace();
			}
		}
		if (vvv == null) {
			nullFlag = 0;
		} else {
			nullFlag = 1;
		}
		if (nullFlag == 0) {
			Message msg = new Message();
			msg.what = NULLFLAGON;
			taskHandler.sendMessage(msg);
		} else {
			int length = vvv.size();
				for (int i = 0; i < length; i++) {
					XmlParseClass stationListObj = (XmlParseClass) vvv
							.elementAt(i);
					Bundle bd= new Bundle();
					bd.putSerializable("taskdata", stationListObj);
					Message msg = new Message();
					msg.what = TASKITEMLOADING;
					msg.setData(bd);
					taskHandler.sendMessage(msg);
				}

		}

	}
	private Handler taskHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case TASKITEMLOADING:
				Bundle bd = msg.getData();
				XmlParseClass item =  (XmlParseClass) bd.getSerializable("taskdata");
				if(bd!=null){
					list.add(item);
					adapter.notifyDataSetChanged();
				}
				break;
			}

		}
	};
}
