package com.cwc.courierclient.task;

import com.cwc.courierclient.R;

import android.app.Activity;
import android.os.Bundle;

public class TaskSpecificActivity extends Activity{
	 @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.taskspecificlayout);
	}
}
