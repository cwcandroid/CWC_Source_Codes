package com.cwc.courierclient.maptask;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.cwc.courierclient.R;
import com.cwc.courierclient.xmlparse.XmlParseClass;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class GMapsActivity extends MapActivity {
    
    private MapView mapView;
    private GeoPoint gpoint;
    private int latitudeE6 = 37985339;
    private int longitudeE6 = 23716735;
    private ArrayList<XmlParseClass> list;
    private Context contxt;
    @SuppressWarnings("unchecked")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maptasklayout);
        contxt = getParent();
        Intent i = getIntent();
        Bundle bd = i.getBundleExtra("bd");
        if(bd!=null){
        	list = (ArrayList<XmlParseClass>) bd.getSerializable("items");
        }
        
        mapView = (MapView) findViewById(R.id.map_view);       
        mapView.setBuiltInZoomControls(true);
        
        List<Overlay> mapOverlays = mapView.getOverlays();
        Drawable drawable = this.getResources().getDrawable(R.drawable.compass_arrow);
        if(list!=null&&!list.isEmpty()){
        	int a = list.size();
        	for(int j=0;j<a;j++){
        		if(list.get(j).getLatitude().contains(".")){
        			latitudeE6 = Integer.parseInt(list.get(j).getLatitude().replace(".", ""));
        		}
        		if(list.get(j).getLongitude().contains(".")){
        			longitudeE6 = Integer.parseInt(list.get(j).getLongitude().replace(".", ""));
        		}
                CustomItemizedOverlay itemizedOverlay = 
                    new CustomItemizedOverlay(drawable, contxt);
                GeoPoint point = new GeoPoint(latitudeE6,longitudeE6);
                String name = "Item Name: "+list.get(j).getName();
                String id = "Item Id: "+list.get(j).getId();
                String finalString = name+"\n"+id;
                OverlayItem overlayitem = 
                     new OverlayItem(point, "Task Info", finalString);
                itemizedOverlay.addOverlay(overlayitem);
                mapOverlays.add(itemizedOverlay);
                if(j==(a-1)){
                	gpoint = point;
                }
        	}
        }
//        GeoPoint point = new GeoPoint(latitudeE6, longitudeE6);
//        OverlayItem overlayitem = 
//             new OverlayItem(point, "Hello", "I'm in Athens, Greece!");
//        
//        itemizedOverlay.addOverlay(overlayitem);
//        mapOverlays.add(itemizedOverlay);
        
        MapController mapController = mapView.getController();
        if(gpoint!=null){
        	mapController.animateTo(gpoint);
        }      
        mapController.setZoom(6);
        
    }

    @Override
    protected boolean isRouteDisplayed() {
        return false;
    }
    
}