package com.cwc.courierclient.task;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ListView;

import com.cwc.courierclient.R;
import com.cwc.courierclient.adapters.TaskListItemAdapter;
import com.cwc.courierclient.components.CheckInternet;
import com.cwc.courierclient.components.StaticClass;
import com.cwc.courierclient.maptask.GMapsActivity;
import com.cwc.courierclient.xmlparse.MyXMLHandlerItems;
import com.cwc.courierclient.xmlparse.XmlParseClass;

public class TaskListActivity extends Activity {
	protected static final int NULLFLAGON = 0,TASKITEMLOADING = 1;
	String taskGettingUrl = StaticClass.baseUrl+"getTaskList?username="+StaticClass.username+"&returnType=xml&duedate=28-01-2012";
	private int nullFlag;
	private Context contxt;
	private Activity con;
	private ArrayList<XmlParseClass> list;
	private ListView currentTaskList;
	private TaskListItemAdapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tasks);
		contxt = this;
		con = this;
		list = new ArrayList<XmlParseClass>();
		
		currentTaskList = (ListView)findViewById(R.id.currentTaskList);
		adapter = new TaskListItemAdapter(con, list);
		currentTaskList.setAdapter(adapter);
		
		if (CheckInternet.checkConn(contxt)) {
			new Thread() {
				@Override
				public void run() {
					getResponseData(taskGettingUrl);
				}
			}.start();
		}
	}
	
	public void mapItemList(View button){
		if(list!=null&&!list.isEmpty()){
			Bundle bd = new Bundle();
			bd.putSerializable("items", list);
			Intent i = new Intent(TaskListActivity.this,GMapsActivity.class);
			i.putExtra("bd", bd);
			View view=TasksActivity.group.getLocalActivityManager()
			.startActivity("TaskListActivity",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
			.getDecorView();
			TasksActivity.group.replaceView(view);
		}

	}
	
	private void getResponseData(String link) {
		Vector vvv = null;
		synchronized (this) {
			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser sp;
			try {
				sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();
				URL sourceUrl = new URL(link);
				MyXMLHandlerItems myXMLHandler = new MyXMLHandlerItems();
				xr.setContentHandler(myXMLHandler);
				xr.parse(new InputSource(sourceUrl.openStream()));
				vvv = myXMLHandler.v;
			} catch (ParserConfigurationException e) {
				// Log.d("problem: ", "1");
				e.printStackTrace();
			} catch (SAXException e) {
				// Log.d("problem: ", "2");
				e.printStackTrace();
			} catch (IOException e) {
				// Log.d("problem: ", "3");
				e.printStackTrace();
			}
		}
		if (vvv == null) {
			nullFlag = 0;
		} else {
			nullFlag = 1;
		}
		if (nullFlag == 0) {
			Message msg = new Message();
			msg.what = NULLFLAGON;
			taskHandler.sendMessage(msg);
		} else {
			int length = vvv.size();
				for (int i = 0; i < length; i++) {
					XmlParseClass stationListObj = (XmlParseClass) vvv
							.elementAt(i);
					Bundle bd= new Bundle();
					bd.putSerializable("taskdata", stationListObj);
					Message msg = new Message();
					msg.what = TASKITEMLOADING;
					msg.setData(bd);
					taskHandler.sendMessage(msg);
				}

		}

	}
	private Handler taskHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case TASKITEMLOADING:
				Bundle bd = msg.getData();
				XmlParseClass item =  (XmlParseClass) bd.getSerializable("taskdata");
				if(bd!=null){
					list.add(item);
					adapter.notifyDataSetChanged();
				}
				break;
			}

		}
	};
}
