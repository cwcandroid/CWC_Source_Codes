package com.cwc.courierclient;

import java.util.ArrayList;

import com.cwc.courierclient.history.HistoryActivity;
import com.cwc.courierclient.task.TasksActivity;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;

public class CWCCourierClientMainScreenActivity extends TabActivity {

	private static ArrayList<Integer> historyTab;
	private int tabtracker;
	public static CWCCourierClientMainScreenActivity tabSwitchTest;
	Intent taskIntent,historyIntent,perfIntent;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		tabSwitchTest = this;

		this.historyTab = new ArrayList<Integer>();
		
		taskIntent = new Intent().setClass(this, TasksActivity.class);
		historyIntent = new Intent().setClass(this, HistoryActivity.class);
		perfIntent = new Intent().setClass(this, PerformanceActivity.class);
		
		// setup tabs
		TabHost tabHost = getTabHost();
		TabHost.TabSpec tabSpec;
		Intent intent;
 
		tabSpec = tabHost.newTabSpec("tasks").setIndicator("Tasks", null)
				.setContent(taskIntent);
		tabHost.addTab(tabSpec);

		tabSpec = tabHost.newTabSpec("history").setIndicator("History", null)
				.setContent(historyIntent);
		tabHost.addTab(tabSpec);

		tabSpec = tabHost.newTabSpec("performance").setIndicator("Performance", null)
				.setContent(perfIntent);
		tabHost.addTab(tabSpec);
	}

}
