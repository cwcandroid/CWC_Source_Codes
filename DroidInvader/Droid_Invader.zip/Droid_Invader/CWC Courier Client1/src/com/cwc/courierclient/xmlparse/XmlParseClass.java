package com.cwc.courierclient.xmlparse;

import java.io.Serializable;

public class XmlParseClass implements Serializable{
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReasontype() {
		return reasontype;
	}
	public void setReasontype(String reasontype) {
		this.reasontype = reasontype;
	}
	public String getReasondetails() {
		return reasondetails;
	}
	public void setReasondetails(String reasondetails) {
		this.reasondetails = reasondetails;
	}
	public String getReportlatitude() {
		return reportlatitude;
	}
	public void setReportlatitude(String reportlatitude) {
		this.reportlatitude = reportlatitude;
	}
	public String getReportlongitude() {
		return reportlongitude;
	}
	public void setReportlongitude(String reportlongitude) {
		this.reportlongitude = reportlongitude;
	}
	public String getSignaturefile() {
		return signaturefile;
	}
	public void setSignaturefile(String signaturefile) {
		this.signaturefile = signaturefile;
	}
	public String getDuedate() {
		return duedate;
	}
	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}
	public String getDuetime() {
		return duetime;
	}
	public void setDuetime(String duetime) {
		this.duetime = duetime;
	}
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

	private String time = new String();
	private String id = new String();
	private String address = new String();
	private String comments = new String();
	private String contactno = new String();
	private String description = new String();
	private String latitude = new String();
	private String longitude = new String();
	private String name = new String();
	private String status = new String();
	private String reasontype = new String();
	private String reasondetails = new String();
	private String reportlatitude = new String();
	private String reportlongitude = new String();
	private String signaturefile = new String();
	private String duedate = new String();
	private String duetime = new String();
}
