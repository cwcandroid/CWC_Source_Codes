package com.cwc.courierclient.adapters;

import java.io.Serializable;

public class TaskItems implements Serializable{

	
	
}
