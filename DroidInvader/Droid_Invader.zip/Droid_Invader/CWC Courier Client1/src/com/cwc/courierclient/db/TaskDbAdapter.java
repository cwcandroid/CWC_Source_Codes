package com.cwc.courierclient.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class TaskDbAdapter {

	// Database fields
	public static final String KEY_ID = "_id";
	public static final String KEY_TASKID = "task_id";
	public static final String KEY_ADDRESS = "address";
	public static final String KEY_COMMENTS = "comments";
	public static final String KEY_CONTACTNO = "contactno";
	public static final String KEY_DESCRIPTION = "description";
	public static final String KEY_LATITUDE = "latitude";
	public static final String KEY_LONGITUDE = "longitude";
	public static final String KEY_NAME = "name";
	public static final String KEY_STATUS = "status";
	public static final String KEY_REASONTYPE = "reasontype";
	public static final String KEY_REASONDETAILS = "reasondetails";
	public static final String KEY_REPORTLATITUDE = "reportlatitude";
	public static final String KEY_REPORTLONGITUDE = "reportlongitude";
	public static final String KEY_SIGNATUREFILE = "signaturefile";
	public static final String KEY_DUEDATE = "duedate";
	public static final String KEY_DUETIME = "duetime";
	
	
	private static final String DB_TABLE_TASK = "tasklist";
	private static final String DB_TABLE_TASKHISTORY = "taskhistorylist";
	
	private Context context;
	private SQLiteDatabase db;
	private DatabaseHelper dbHelper;

	public TaskDbAdapter(Context context) {
		this.context = context;
	}

	public TaskDbAdapter open() throws SQLException {
		dbHelper = new DatabaseHelper(context);
		db = dbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		dbHelper.close();
	}

	
/**
	 * Create a new todo If the todo is successfully created return the new
	 * rowId for that note, otherwise return a -1 to indicate failure.
	 */

	public long createNote(String task_id) {
		ContentValues values = createTaskTableContentValues(task_id
				);

		return db.insert(DB_TABLE_TASK, null, values);
	}

	public Cursor getLastPlayedListResult(String sql)
	{
		Log.e("SQL:", sql);
		 Cursor mCursor =db.rawQuery(sql, null);
		 return mCursor;		
	}
	public Cursor executeQuery(String sql)
	{
		Log.e("SQL:", sql);
		 Cursor mCursor =db.rawQuery(sql, null);
		 return mCursor;		
	}
/**
	 * Update the todo
	 */

	public boolean updateNote(long rowId,String task_id) {
		ContentValues values = createTaskTableContentValues(task_id);

		return db.update(DB_TABLE_TASK, values, KEY_ID + "=" + rowId, null) > 0;
	}
	
	public long createTaskEntry(String task_id) {
		ContentValues values = new ContentValues();
		values.put(KEY_TASKID, task_id);
		return db.insert(DB_TABLE_TASK, null, values);
	}
	public long updateTaskEntry(long rowId,String task_id) {
		ContentValues values = new ContentValues();
		values.put(KEY_TASKID, task_id);
		return db.update(DB_TABLE_TASK, values, rowId + "= '"+ rowId+"'",null);
	}
	
/**
	 * Deletes todo
	 */

	public boolean deleteTask(long rowId) {
		return db.delete(DB_TABLE_TASK, KEY_ID + "=" + rowId, null) > 0;
	}

	
/**
	 * Return a Cursor over the list of all todo in the database
	 * 
	 * @return Cursor over all notes
	 */

	public Cursor fetchAllTask(String date) {
		return db.query(DB_TABLE_TASK, new String[] { KEY_ID,
				KEY_TASKID},KEY_TASKID +" = '"+date+"'", null, null, null, null);
	}
	
/**
	 * Return a Cursor positioned at the defined todo
	 */

	public Cursor fetchTask(long rowId) throws SQLException {
		String sql = "Select * from "+DB_TABLE_TASK+" where ='"+rowId+"'";
		Log.e("Sql:::::",sql);
		Cursor mCursor;
		try{
			mCursor = db.rawQuery(sql, null);
		}catch (Exception e) {
			// TODO: handle exception
			mCursor = db.rawQuery(sql, null);
			Log.e("Jamela hoisilo","Thik Hoise");
		}
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;
	}

	private ContentValues createTaskTableContentValues(String taks_id) {
		ContentValues values = new ContentValues();
		values.put(KEY_TASKID, taks_id);
		return values;
	}

}
