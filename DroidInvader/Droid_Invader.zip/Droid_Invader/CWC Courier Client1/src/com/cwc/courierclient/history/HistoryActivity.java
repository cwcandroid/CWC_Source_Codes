package com.cwc.courierclient.history;

import java.util.ArrayList;

import android.app.ActivityGroup;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.cwc.courierclient.R;

public class HistoryActivity extends ActivityGroup{
	public static HistoryActivity historyActivityGroup;
	private static ArrayList<View> history;
	Context con;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.history = new ArrayList<View>();
		historyActivityGroup = this;
		con=this;
		
		
		// Start the root activity withing the group and get its view
		View view = getLocalActivityManager().startActivity(
				"HistoryListActivity",
				new Intent(this, HistoryListActivity.class)
						.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
				.getDecorView();

		// Replace the view of this ActivityGroup
		replaceView(view);
	}
	public void replaceView(View v) {
		// Adds the old one to history
		history.add(v);
		Log.v("History size:", history.size()+"");
		// Changes this Groups View to the new View.
		setContentView(v);
	}
	public void replaceView(View v,String s)
	{
		setContentView(v);
	}
	public static void historySizeDecrese()
	{
		history.remove(history.size() - 1);
		Log.v("history size:", history.size()+"");
	}

	public void back() {
		Log.v("history.size()", history.size()+"");
		if (history.size() > 1) {
			history.remove(history.size() - 1);
			setContentView(history.get(history.size() - 1));
		}
		else
		{
		}
	}
//
//	
//	
    public void onBackPressed() {
		//finish();
    	HistoryActivity.historyActivityGroup.back();
        //return;
    }
}
