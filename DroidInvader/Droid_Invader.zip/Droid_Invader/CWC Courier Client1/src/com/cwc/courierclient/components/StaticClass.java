package com.cwc.courierclient.components;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.cwc.courierclient.R;
import com.cwc.courierclient.R.string;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.Toast;

public class StaticClass {

	public static String username = "";
	public static String baseUrl = "http://192.168.1.2/cwc/index.php/android/";
	
	public static void showToastMessageLong(Context con,String msg){
		Toast.makeText(con, msg,
				Toast.LENGTH_LONG).show();
	}
	public static void showToastMessageShort(Context con,String msg){
		Toast.makeText(con, msg,
				Toast.LENGTH_SHORT).show();
	}
	public static void showAlertMessage(Context con,String msg){
        new AlertDialog.Builder(con)
        .setTitle(con.getResources().getText(R.string.alert_title_failure))
        .setMessage(msg)
        .setPositiveButton(
                R.string.alert_ok_button,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                            int whichButton) {
                    	dialog.dismiss();
                    }
                })
                .setCancelable(false)
                .show();
	}
	public static String getResponseString(String url) {
		String responseString = "0";
		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response = httpclient.execute(new HttpGet(url));
			StatusLine statusLine = response.getStatusLine();
			if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				response.getEntity().writeTo(out);
				out.close();
				responseString = out.toString();
			} else {
				// Closes the connection.
				response.getEntity().getContent().close();
				throw new IOException(statusLine.getReasonPhrase());
			}
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return responseString;
	}
}
