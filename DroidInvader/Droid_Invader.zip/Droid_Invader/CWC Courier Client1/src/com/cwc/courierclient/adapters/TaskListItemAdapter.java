package com.cwc.courierclient.adapters;

import java.util.ArrayList;

import android.app.Activity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cwc.courierclient.R;
import com.cwc.courierclient.xmlparse.XmlParseClass;

public class TaskListItemAdapter extends ArrayAdapter<XmlParseClass> {
	Activity context;

	public TaskListItemAdapter(Activity context, ArrayList<XmlParseClass> list) {
		super(context, R.layout.taskitemlayout, list);

		this.context = context;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		ViewWrapper wrapper;
		ImageView flagImageView;
		TextView itemName;
		TextView placeName;
		XmlParseClass model = getItem(position);
		if (row == null) {
			LayoutInflater inflater = context.getLayoutInflater();

			row = inflater.inflate(R.layout.taskitemlayout, null);
			wrapper = new ViewWrapper(row);
			row.setTag(wrapper);
		} else {
			wrapper = (ViewWrapper) row.getTag();
		}
		flagImageView = wrapper.getFlagImageView();
		itemName = wrapper.getItemName();
		placeName = wrapper.getPlaceName();
		
		itemName.setText(model.getDescription());
		placeName.setText(model.getAddress());
		
		if(model.getStatus().equalsIgnoreCase("0")){
			flagImageView.setBackgroundResource(R.drawable.rate_star_big_off);
		}else if(model.getStatus().equalsIgnoreCase("1")){
			flagImageView.setBackgroundResource(R.drawable.rate_star_big_on);
		}else{
			flagImageView.setBackgroundResource(R.drawable.rate_star_big_half);
		}

		return (row);
	}
}
