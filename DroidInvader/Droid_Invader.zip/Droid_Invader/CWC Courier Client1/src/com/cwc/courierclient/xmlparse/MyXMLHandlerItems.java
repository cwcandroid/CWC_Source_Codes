package com.cwc.courierclient.xmlparse;

import java.util.Vector;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MyXMLHandlerItems extends DefaultHandler {

	Boolean currentElement = false;
	String currentValue = null;
	public Vector v = new Vector();
	public static XmlParseClass itemList = null;

	/** Called when tag starts ( ex:- <name>AndroidPeople</name>
	 * -- <name> )*/
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		
		currentElement = true;
		currentValue = "";
		if (localName.equals("task"))
		{
			/** Start */
			itemList = new XmlParseClass();
		}
	}

	/** Called when tag closing ( ex:- <name>AndroidPeople</name>
	 * -- </name> )*/
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		
		currentElement = false;
		currentValue = currentValue.trim();
		if (localName.equalsIgnoreCase("task"))
		{	
			v.add(itemList);
		}
		else if (localName.equalsIgnoreCase("id")){
			
			itemList.setId(currentValue);
		}
		else if (localName.equalsIgnoreCase("address")){
			
			itemList.setAddress(currentValue);
		}
		else if (localName.equalsIgnoreCase("comments")){
			
			itemList.setComments(currentValue);
		}
		else if (localName.equalsIgnoreCase("contactno")){		
			itemList.setContactno(currentValue);
		}
			
		else if (localName.equalsIgnoreCase("description")){
			itemList.setDescription(currentValue);
		}
		else if (localName.equalsIgnoreCase("latitude")){
			itemList.setLatitude(currentValue);
		}
		else if (localName.equalsIgnoreCase("longitude")){
			itemList.setLongitude(currentValue);
		}
		else if (localName.equalsIgnoreCase("name")){
			itemList.setName(currentValue);
		}
		else if (localName.equalsIgnoreCase("status"))
		{
			itemList.setStatus(currentValue);
		}
		else if (localName.equalsIgnoreCase("reasontype")){
			itemList.setReasontype(currentValue);
		}
		else if (localName.equalsIgnoreCase("reasondetails")){
			itemList.setReasondetails(currentValue);
		}
		else if (localName.equalsIgnoreCase("reportlatitude")){
			itemList.setReportlatitude(currentValue);
		}
		else if (localName.equalsIgnoreCase("reportlongitude")){
			itemList.setReportlongitude(currentValue);
		}
		else if (localName.equalsIgnoreCase("signaturefile")){
			itemList.setSignaturefile(currentValue);
		}
		else if (localName.equalsIgnoreCase("duedate"))
		{
			itemList.setDuedate(currentValue);
		}
		else if (localName.equalsIgnoreCase("duetime"))
		{
			itemList.setDuetime(currentValue);
		}
		else if (localName.equalsIgnoreCase("time"))
		{
			itemList.setTime(currentValue);
		}
	}

	/** Called to get tag characters ( ex:- <name>AndroidPeople</name>
	 * -- to get AndroidPeople Character ) */
	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		
		if (currentElement) {
			currentValue+= new String(ch, start, length);
//			currentElement = false;
		}

	}

}
