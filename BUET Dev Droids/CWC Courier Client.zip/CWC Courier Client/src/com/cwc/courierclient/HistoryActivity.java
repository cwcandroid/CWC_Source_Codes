package com.cwc.courierclient;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.json.JSONException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class HistoryActivity extends ListActivity implements OnItemClickListener{
	Context context;
	Button filter;
	DatePicker date;
	ArrayList<ListData> Tasks;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history);

		context = this;
		
		filter=(Button)findViewById(R.id.hstry_filter);
		date=(DatePicker)findViewById(R.id.histry_date);
		

		SharedPreferences pref = context.getSharedPreferences("login",
				MODE_WORLD_READABLE);
		String username = pref.getString("username", "");
		String url = MakeURL(username);

		Intent intent = new Intent(context, DownloadData.class);
		intent.putExtra("url", url);
		startActivityForResult(intent, 0);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == 0) {
			if (resultCode == RESULT_OK) {

				try {
					File file = new File("/sdcard/jsondata.dat");
					FileInputStream fIn = new FileInputStream(file);
					BufferedReader myReader = new BufferedReader(
							new InputStreamReader(fIn));

					String received_xml = "";
					String line = "";

					while ((line = myReader.readLine()) != null) {
						received_xml = received_xml.concat(line);
					}

					Log.d("OnActivityResult", "ReceivedJSON = " + received_xml);
					Log.d("OnActivityResult", "ReceivedJSON Length = "
							+ received_xml.length());

					CustomXMLParser myparser = new CustomXMLParser();
					Document doc = myparser.getDomElement(received_xml);
					NodeList nl = doc.getElementsByTagName("task");
					
					if(nl.getLength() == 0){
						Toast.makeText(context, "No Tasks", 2000);
					}else{
						int items = nl.getLength();
						Tasks = new ArrayList<HistoryActivity.ListData>();
						DataHelper dh=new DataHelper(context);
						dh.open();
						for (int i = 0; i < nl.getLength(); i++) {
							Element e = (Element) nl.item(i);
							
						    String id = myparser.getValue(e, "id"); // name child value
						    String address = myparser.getValue(e,"address"); // cost child value
						    String comments = myparser.getValue(e, "comments");
						    String contactno = myparser.getValue(e, "contactno");
						    String description = myparser.getValue(e, "description");
						    String latitude = myparser.getValue(e, "latitude");
						    String longitude = myparser.getValue(e, "longitude");
						    String name = myparser.getValue(e, "name");
						    String status = myparser.getValue(e, "status");
						    String reasontype = myparser.getValue(e, "reasontype");
						    String reasondetails = myparser.getValue(e, "reasondetails");
						    String reportlat = myparser.getValue(e, "reportlatitude");
						    String reportlong = myparser.getValue(e, "reportlongitude");
						    String duedate = myparser.getValue(e, "duedate");
						    String duetime = myparser.getValue(e, "duetime");
						  
						  
						    Log.d("loop" + i , "id = " + id);
							Log.d("loop" + i, "address = " + address);	
							Log.d("loop" + i, "comments =" + comments);
							Log.d("loop" + i, "Contactno = " + contactno);
							Log.d("loop" + i, "Description = " + description);
							Log.d("loop" + i, "lat = " + latitude);
							Log.d("loop" + i, "Longitude = " + longitude);
							Log.d("loop" + i, "name = " + name);
							Log.d("loop" + i, "status = " + status);
							
							Double lat = Double.parseDouble(latitude);
							Double longi = Double.parseDouble(longitude);
											
							ListData D = new ListData();
							Log.d("loop" + i, "Setting Data to class array");
							D.SetData(address, comments , contactno,
									description, lat, longi, name,
									status , reasontype , reasondetails , Double.parseDouble(reportlat) , Double.parseDouble(reportlong) , duedate , duetime , id);
							
							dh.insert_into_history_table(D.name, D.description, D.duedate, D.contactno, D.address, D.status, D.comment, D.longitude, D.latitude, D.reasontype, D.reasondetails, D.reportlongitude, D.reportlatitude, "");
							Log.d("loop" + i, "Calling Showdata");
							Tasks.add(D);
						}

						TaskAdapter adapter=new TaskAdapter(this, R.layout.list_item, Tasks);
						  setListAdapter(adapter);

						  ListView lv = getListView();
						  lv.setOnItemClickListener(this);
					}

				} catch (FileNotFoundException e) {
					Log.d("OnActivityResult", "File not found");
				} catch (IOException e) {
					Log.d("OnActivityResult", "I/O error");
				}

			} else if (resultCode == RESULT_CANCELED) {
				Toast.makeText(this, "Process Interrupted", 2000).show();
			} else if (resultCode == 378) {
				Toast.makeText(this, "Internet Connection Not Available", 2000)
						.show();
			}
		}

	}

	String MakeURL(String un) {
		String BaseURL = "http://192.168.1.2/cwc/index.php/android/getTaskHistory?";
		String _username = "username=" + un + "&";
		String _ret = "returnType=xml";

		String url = BaseURL + _username + _ret;
		return url;
	}

	public class ListData {
		private String address;
		private String comment;
		private String contactno;
		private String description;
		private double latitude;
		private double longitude;
		private String name;
		private String status;
		private String reasontype;
		private String reasondetails;
		private double reportlatitude;
		private double reportlongitude;
		private String signaturefile;
		private String duedate;
		private String duetime; 
		private String id;
		
		public ListData() {

		}

		public void SetData(String address, String comment, String contactno,
				String description, double latitude, double longitude,
				String name, String status, String reasontype,
				String reasondetails, double rlat, double rlong,
				String date , String duetime , String id) {

			this.address = address;
			this.comment = comment;
			this.contactno = contactno;
			this.description = description;
			this.latitude = latitude;
			this.longitude = longitude;
			this.name = name;
			this.status = status;

			this.reasontype = reasontype;
			this.reasondetails = reasondetails;
			this.reportlatitude = rlat;
			this.reportlongitude = rlong;
			this.duedate = date;
			this.duetime = duetime;
			this.id = id;
		}
		
		public Bundle toBundle()
		{
			Bundle b=new Bundle();
			
			b.putString("adrs", this.address);
			b.putString("cmnt", this.comment);
			b.putString("phno", this.contactno);
			b.putString("desc", this.description);
			b.putDouble("lat", this.latitude);
			b.putDouble("long", this.longitude);
			b.putString("stts", this.status);
			b.putString("nm", this.name);
			
			b.putString("reasontype", this.reasontype); 
			b.putString("reasondetails", this.reasondetails);
			b.putString("repportlat", String.valueOf(this.reportlatitude));
			b.putString("reportlong", String.valueOf(this.reportlongitude));
			b.putString("duedate", this.duedate);
			b.putString("duetime", this.duetime);
			b.putString("id", this.id);
			
			return b;
		}

		public void ShowData() {

			Log.d("ListDataShow", "address = " + this.address);
			Log.d("ListDataShow", "comment = " + this.comment);
			Log.d("ListDataShow", "contactno = " + this.contactno);
			Log.d("ListDataShow", "description = " + this.description);
			Log.d("ListDataShow", "latitude = " + this.latitude);
			Log.d("ListDataShow", "longitude = " + this.longitude);
			Log.d("ListDataShow", "name = " + this.name);
			Log.d("ListDataShow", "status = " + this.status);
			Log.d("ListDataShow", "reasontype = " + this.reasontype);
			Log.d("ListDataShow", "reasondetails = " + this.reasondetails);
			Log.d("ListDataShow", "reportlatitude = " + this.reportlatitude);
			Log.d("ListDataShow", "reportlongitude = " + this.reportlongitude);
			Log.d("ListDataShow", "Signature = " + this.signaturefile);
			Log.d("ListDataShow", "duedate = " + this.duedate);
		}
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
		// TODO Auto-generated method stub
		ListData data=Tasks.get(position);
		Intent i=new Intent(context, TaskView.class);
		i.putExtra("mode", "history");
		
		Bundle b=data.toBundle();
		i.putExtra("extras", b);
		startActivity(i);
	}
	
	private class TaskAdapter extends ArrayAdapter<ListData>{
		
		ArrayList<ListData> items;
		
		public TaskAdapter(Context context, int textViewResourceId, ArrayList<ListData> Items) {
			super(context, textViewResourceId, Items);
			this.items=Items;
			// TODO Auto-generated constructor stub
		}


		
		@Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	            View v = convertView;
	            if (v == null) {
	                LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	                v = vi.inflate(R.layout.list_item, null);
	            }
	            final ListData o = items.get(position);
	            if (o != null) {
	                    
	                    TextView itemTitle = (TextView) v.findViewById(R.id.lst_txt);
	                    ImageView icon=(ImageView) v.findViewById(R.id.lst_icon);
	                    TextView desc=(TextView)v.findViewById(R.id.lst_desc);
	                      
	                    itemTitle.setText(o.name);
	                    desc.setText(o.description);
	                    if(Integer.parseInt(o.status) ==1)
	                    {
	                    	icon.setImageResource(R.drawable.ok);
	                    }
	                    else
	                    {
	                    	icon.setImageResource(R.drawable.todo);
	                    }
	            }
	            return v;
	    }

	}

}
