package com.cwc.courierclient;

import java.util.ArrayList;


import android.app.ListActivity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class CallHistory extends ListActivity{
	
	Context context;
	ArrayList<callHistory> History=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history);

		context = this;
		
		try{
			DataHelper dh=new DataHelper(context);
			dh.open();
			Cursor cur=dh.get_all_call_history();
			if(cur.moveToFirst())
			{
				History=new ArrayList<CallHistory.callHistory>();
				callHistory chistory=new callHistory(cur.getString(cur.getColumnIndex("phone")), cur.getInt(cur.getColumnIndex("duration")), cur.getString(cur.getColumnIndex("call_datetime")));
				History.add(chistory);
				while(cur.moveToNext())
				{
					chistory=new callHistory(cur.getString(cur.getColumnIndex("phone")), cur.getInt(cur.getColumnIndex("duration")),cur.getString(cur.getColumnIndex("call_datetime")));
					History.add(chistory);
					
				}
				cHistoryAdapter adapter=new cHistoryAdapter(this, R.layout.list_item2, History);
				  setListAdapter(adapter);

				  ListView lv = getListView();
			}
			dh.close();
		}catch (Exception e) {
			// TODO: handle exception
			Log.d("DBERR", e.getMessage());
		}
	}
	
	class callHistory{
		String phno;
		int duration;
		String date;
		
		callHistory(String p,int d,String dt)
		{
			phno=p;
			duration=d;
			date=dt;
		}
	}
	
private class cHistoryAdapter extends ArrayAdapter<callHistory>{
		
		ArrayList<callHistory> items;
		
		public cHistoryAdapter(Context context, int textViewResourceId, ArrayList<callHistory> Items) {
			super(context, textViewResourceId, Items);
			this.items=Items;
			// TODO Auto-generated constructor stub
		}


		
		@Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	            View v = convertView;
	            if (v == null) {
	                LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	                v = vi.inflate(R.layout.list_item2, null);
	            }
	            final callHistory o = items.get(position);
	            if (o != null) {
	                    
	                    TextView itemTitle = (TextView) v.findViewById(R.id.lst_txt2);
	                    ImageView icon=(ImageView) v.findViewById(R.id.lst_icon2);
	                    TextView desc=(TextView)v.findViewById(R.id.lst_desc2);
	                      
	                    itemTitle.setText(o.phno);
	                    desc.setText("Date Time: "+o.date+" Duration:  "+o.duration);
	                    
	                   icon.setImageResource(R.drawable.callhistory);
	                    
	            }
	            return v;
	    }

	}



}
