package com.cwc.courierclient;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class PerformanceActivity extends Activity implements OnClickListener{
	Context context;
	Spinner chooser;
	Button show;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.performance);
		
		context=this;
		
		chooser=(Spinner)findViewById(R.id.perf_time);
		show=(Button)findViewById(R.id.perf_show_btn);
		
		show.setOnClickListener(this);
		
		ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(context, R.array.spinner_array, android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		chooser.setAdapter(adapter);
		chooser.setSelection(0);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		//take the time
		//send time to chart activity
		
		IDemoChart ch=new SalesGrowthChart();
		Intent i= ch.execute(context);
		i.putExtra("time", chooser.getSelectedItemPosition());
		startActivity(i);
		
	}
}
