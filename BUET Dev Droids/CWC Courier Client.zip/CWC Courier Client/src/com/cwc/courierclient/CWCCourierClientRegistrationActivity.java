package com.cwc.courierclient;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CWCCourierClientRegistrationActivity extends Activity {
	Button btnLogin, btnSubmit;
	EditText username, password, email, conform_password;
	Context context;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		context = this;
		btnLogin = (Button) findViewById(R.id.reg_login);
		btnSubmit = (Button) findViewById(R.id.reg_register);
		username = (EditText) findViewById(R.id.reg_nm);
		email = (EditText) findViewById(R.id.reg_mail);
		password = (EditText) findViewById(R.id.reg_pass);
		conform_password = (EditText) findViewById(R.id.reg_rpwd);

		username.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (username.getText().toString().equals("Username")) {
					username.setText("");
				}

			}
		});

		email.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (email.getText().toString().equals("Email Id")) {
					email.setText("");
				}

			}
		});

		password.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (password.getText().toString().equals("Password")) {
					password.setText("");
				}
			}
		});

		conform_password.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (conform_password.getText().toString()
						.equals("Confirm Password")) {
					conform_password.setText("");
				}

			}
		});

		btnLogin.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				CWCCourierClientRegistrationActivity.this.finish();
			}
		});

		btnSubmit.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				if (Validate(username, "Username")
						&& Validate(email, "Email Id")
						&& Validate(password, "Password")
						&& Validate(conform_password, "Confirm Password")) {
					if (password.getText().toString()
							.equals(conform_password.getText().toString())) {
						String url = MakeURL(username.getText().toString(),
								password.getText().toString(), email.getText()
										.toString());
						String ResponseMessage = DataFetcher(url);

						if (!ResponseMessage.equals("")) {
							try {
								JSONObject obj = new JSONObject(ResponseMessage);
								String status = obj.getString("status");
								if (status.equals("Success")) {
									Toast.makeText(
											context,
											"Registration Successful...Returning to Login Screen",
											3000).show();
									/*Intent i = new Intent(
											CWCCourierClientRegistrationActivity.this,
											CWCCourierClientLoginActivity.class);
									startActivity(i);*/
									CWCCourierClientRegistrationActivity.this.finish();
								} else {
									Toast.makeText(
											context,
											"Registration not Successful."
													+ status, 3000).show();
								}
							} catch (JSONException e) {
								Log.d("Parsing JSON", "Could not parse JSON");
							}
						}

					} else {
						Toast.makeText(context, "Password Didn't Match", 2000)
								.show();
					}

				} else {
					Toast.makeText(context, "Invalid Data", 2000).show();
				}

			}
		});

	}

	boolean Validate(EditText ET, String str) {
		if (ET.getText().toString().equals("")
				|| ET.getText().toString().equals(str)) {
			return false;
		}
		return true;
	}

	String MakeURL(String un, String pass, String email) {
		String BaseURL = "http://192.168.1.2/cwc/index.php/android/register?";
		String _username = "username=" + un + "&";
		String _password = "password=" + pass + "&";
		String _ret = "returnType=json&";
		String _email = "email=" + email;

		String url = BaseURL + _username + _password + _ret + _email;
		return url;
	}

	String DataFetcher(String url) {
		String JSONMessage = "";
		try {
			URL _url = new URL(url);
			URLConnection urlConnection = _url.openConnection();
			HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
			int response = httpURLConnection.getResponseCode();

			if (response == HttpURLConnection.HTTP_OK) {
				InputStream in = urlConnection.getInputStream();
				JSONMessage = IOUtils.toString(in);
			}
		} catch (MalformedURLException e) {
			Toast.makeText(context, "Invalid URL", 2000).show();
			e.printStackTrace();
		} catch (IOException e) {
			Toast.makeText(context, "Please Check internet Connection", 2000).show();
		}
		return JSONMessage;
	}
}
