package com.cwc.courierclient;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class MapItemizedOverlay extends ItemizedOverlay<OverlayItem>{
	
	private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
	
	Context mContext;

	public MapItemizedOverlay(Drawable defaultMarker, Context context) {
		//super(defaultMarker);
		
		super(boundCenterBottom(defaultMarker));
		//int markerHeight = ((BitmapDrawable) defaultMarker).getBitmap().getHeight();
		
		this.mContext = context;
		// TODO Auto-generated constructor stub
	}

	@Override
	protected OverlayItem createItem(int i) {
		// TODO Auto-generated method stub
		return mOverlays.get(i);
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return mOverlays.size();
	}
	
	public void addOverlay(OverlayItem overlay) {
	    mOverlays.add(overlay);
	    populate();
	}
	
	@Override
	public boolean onTap(int index) {
	
		GeoPoint g = mOverlays.get(index).getPoint();
		
		double la = (g.getLatitudeE6()/1E6);
		double lo = (g.getLongitudeE6()/1E6);
		
		Log.d("sd", Double.toString(la));
		Log.d("df", Double.toString(lo));

		//Intent myIntent = new Intent(mContext, FormInputActivity.class);
		
		//myIntent.putExtra("latitude", Double.toString(la));
		//myIntent.putExtra("longitude", Double.toString(lo));
		
	    //mContext.startActivity(myIntent);
	    
	    
      
	  return true;
				
	}
	
	@Override
    public void draw(android.graphics.Canvas canvas, MapView mapView, boolean shadow)
    {
        super.draw(canvas, mapView, shadow);

        // go through all OverlayItems and draw title for each of them
        for (OverlayItem item:mOverlays)
        {
            /* Converts latitude & longitude of this overlay item to coordinates on screen.
             * As we have called boundCenterBottom() in constructor, so these coordinates
             * will be of the bottom center position of the displayed marker.
             */
            GeoPoint point = item.getPoint();
            Point markerBottomCenterCoords = new Point();
            mapView.getProjection().toPixels(point, markerBottomCenterCoords);

            /* Find the width and height of the title*/
            TextPaint paintText = new TextPaint();
            Paint paintRect = new Paint();

            Rect rect = new Rect();
            paintText.setTextSize(10);
            paintText.getTextBounds(item.getTitle(), 0, item.getTitle().length(), rect);

            rect.inset(-1, -1);
            rect.offsetTo(markerBottomCenterCoords.x - rect.width()/2, markerBottomCenterCoords.y - 15 - rect.height());

            paintText.setTextAlign(Paint.Align.CENTER);
            paintText.setTextSize(10);
            paintText.setARGB(255, 255, 255, 255);
            paintRect.setARGB(130, 0, 0, 0);

            canvas.drawRoundRect( new RectF(rect), 2, 2, paintRect);
            canvas.drawText(item.getTitle(), rect.left + rect.width() / 2,
                    rect.bottom - 1, paintText);
        }
    }

}

