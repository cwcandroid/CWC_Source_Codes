package com.cwc.courierclient;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class TaskView extends Activity implements OnClickListener{

	Context context;
	Button report,viewonmap;
	ImageButton call;
	ImageView sign;
	TextView inm,iid,rnm,rad,phno,ddt,stts,cmnt,sig;
	int id;
	int longitude , latiude ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.taskview);
		
		context=this;
		
		inm=(TextView)findViewById(R.id.tsk_ttl);
		iid=(TextView)findViewById(R.id.tsk_id);
		rnm=(TextView)findViewById(R.id.tsk_rcvr);
		rad=(TextView)findViewById(R.id.tsk_adrs);
		phno=(TextView)findViewById(R.id.tsk_phno);
		ddt=(TextView)findViewById(R.id.tsk_dlvr_dt);
		stts=(TextView)findViewById(R.id.tsk_stts);
		cmnt=(TextView)findViewById(R.id.tsk_cmnt);
		sig=(TextView)findViewById(R.id.tsk_sig);
		
		sign=(ImageView)findViewById(R.id.tsk_signature);
		
		report=(Button)findViewById(R.id.tsk_report);
		viewonmap=(Button)findViewById(R.id.tsk_map);
		call=(ImageButton)findViewById(R.id.tsk_call);
		
		report.setOnClickListener(this);
		viewonmap.setOnClickListener(this);
		call.setOnClickListener(this);
		
		//fetch the id 
		Bundle b= this.getIntent().getBundleExtra("extras");
		id=b.getInt("id");
		if(this.getIntent().getExtras().getString("mode").equals("task"))
		{
			inm.setText(inm.getText()+b.getString("nm"));
			iid.setText(iid.getText()+String.valueOf(b.getInt("id")));
			//rnm.setText(rnm.getText()+b.getString("rname"));
			rad.setText(rad.getText()+b.getString("adrs"));
			phno.setText(b.getString("phno"));
			
			Double Templat = b.getDouble("lat");
			Double Templong = b.getDouble("long");
			latiude = (int) (Templat * 1e6);
			longitude = (int) (Templong * 1e6);
			
			ddt.setVisibility(View.INVISIBLE);
			stts.setVisibility(View.INVISIBLE);
			cmnt.setVisibility(View.INVISIBLE);
			sig.setVisibility(View.INVISIBLE);
			sign.setVisibility(View.INVISIBLE);
		}
		else
		{
			report.setVisibility(View.INVISIBLE);
			inm.setText(inm.getText()+b.getString("nm"));
			iid.setText(iid.getText()+String.valueOf(b.getInt("id")));
			//rnm.setText(rnm.getText()+b.getString("rname"));
			rad.setText(rad.getText()+b.getString("adrs"));
			phno.setText(b.getString("phno"));
			//ddt.setText(ddt.getText()+b.getString("ddate"));
			cmnt.setText(cmnt.getText()+b.getString("cmnt"));
			/*****/
			Double Templat = b.getDouble("lat");
			Double Templong = b.getDouble("long");
			latiude = (int) (Templat * 1e6);
			longitude = (int) (Templong * 1e6);
			/****/
			
			switch(b.getInt("stts"))
			{
				case 1:
					stts.setText(stts.getText()+"Delivered");
				break;
				
				case 0:
					stts.setText(stts.getText()+"Pending");
				break;
			}
			//show signature
			/*String path=Environment.getExternalStorageDirectory()+"signature.png";
			Bitmap bm=BitmapFactory.decodeFile(path);
			sign.setImageBitmap(bm);*/
		}
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
			case R.id.tsk_report:
				//open report window
				Intent i=new Intent(context, ReportTask.class);
				i.putExtra("id", id);
				startActivity(i);
			break;
			
			case R.id.tsk_map:
				//show in map
				Intent intent = new Intent(this,GoogleMap.class);
				intent.putExtra("lat", latiude);
				intent.putExtra("long", longitude);
				intent.putExtra("do", "single");
				startActivityForResult(intent, 0);
			break;
			
			case R.id.tsk_call:
				Intent ic=new Intent(context,CallDialog.class);
				ic.putExtra("phno", phno.getText());
				startActivity(ic);
			break;
		}
	}

}
