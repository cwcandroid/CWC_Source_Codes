package com.cwc.courierclient;

import java.util.List;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class GoogleMap extends MapActivity {
	MapView map;
	List<Overlay> mapOverlays;
	MapItemizedOverlay mymarker;
	MapController mc;
	int latitude, longitude;
	int[] latitudes;
	int[] longitudes;
	int items;
	int op = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map);

		map = (MapView) findViewById(R.id.mapview);
		mapOverlays = map.getOverlays();
		Drawable marker = getResources()
				.getDrawable(R.drawable.location_marker);
		mymarker = new MapItemizedOverlay(marker, this);

		Bundle extras = getIntent().getExtras();
		if (extras.getString("do").equals("single")) {
			latitude = extras.getInt("lat");
			longitude = extras.getInt("long");
			op = 1;
		} else if (extras.getString("do").equals("list")) {
			items = extras.getInt("items");
			if (items > 0) {
				latitudes = new int[items];
				longitudes = new int[items];
				latitudes = extras.getIntArray("latlist");
				longitudes = extras.getIntArray("longlist");
				op = 2;
			}
		}

		if (op == 1) {
			GeoPoint point = new GeoPoint(latitude , longitude);
			OverlayItem item1 = new OverlayItem(point, "Hello", "From Dhaka");
			map.setBuiltInZoomControls(true);
			mymarker.addOverlay(item1);
			mapOverlays.add(mymarker);
			mc = map.getController();
			mc.animateTo(point);
			mc.setZoom(17);
		}

		// map.setStreetView(true);

		else if (op == 2) {
			Log.d("GoogleMap", "items = " + items);
			for (int i = 0; i < items; i++) {
				GeoPoint point = new GeoPoint(latitudes[i], longitudes[i]);
				OverlayItem item1 = new OverlayItem(point, "", "");
				map.setBuiltInZoomControls(true);
				mymarker.addOverlay(item1);
				mapOverlays.add(mymarker);
				mc = map.getController();
				mc.animateTo(point);
				mc.setZoom(5);
				Log.d("GoogleMap", "Loc" + "[" + i + "] = " + "lat = "
						+ latitudes[i] + " long = " + longitudes[i]);
			}
		}

	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
}
