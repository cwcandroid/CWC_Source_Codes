package com.cwc.courierclient;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class TasksActivity extends ListActivity implements OnClickListener,
		OnItemClickListener {
	ArrayList<ListData> Tasks = null;
	// ListData[] Mydata;
	Button viewMap;
	Context context;
	int[] latitudes;
	int[] longitudes;
	int items;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tasklist);

		context = this;

		SharedPreferences pref = context.getSharedPreferences("login",
				MODE_WORLD_READABLE);
		String username = pref.getString("username", "");

		viewMap = (Button) findViewById(R.id.task_map);

		Calendar C = Calendar.getInstance();
		int day = C.get(Calendar.DAY_OF_MONTH);
		int month = C.get(Calendar.MONTH);
		int year = C.get(Calendar.YEAR);
		String Date = day + "-" + month + "-" + year;
		// Current date to be used later (Ayon)

		String url = MakeURL(username, "27-01-2012");
		Intent intent = new Intent(context, DownloadData.class);
		intent.putExtra("url", url);
		startActivityForResult(intent, 0);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == 0) {
			if (resultCode == RESULT_OK) {

				try {
					File file = new File("/sdcard/jsondata.dat");
					FileInputStream fIn = new FileInputStream(file);
					BufferedReader myReader = new BufferedReader(
							new InputStreamReader(fIn));

					String received_xml = "";
					String line = "";

					while ((line = myReader.readLine()) != null) {
						received_xml = received_xml.concat(line);
					}

					Log.d("OnActivityResult", "ReceivedJSON = " + received_xml);
					Log.d("OnActivityResult", "ReceivedJSON Length = "
							+ received_xml.length());
					
					CustomXMLParser myparser = new CustomXMLParser();
					Document doc = myparser.getDomElement(received_xml);
					NodeList nl = doc.getElementsByTagName("task");
					
					if(nl.getLength() == 0){
						Toast.makeText(context, "No Tasks", 2000);
					}
					else{
						items = nl.getLength();
						latitudes = new int[items];
						longitudes = new int[items];
						Tasks = new ArrayList<TasksActivity.ListData>();
						for (int i = 0; i < nl.getLength(); i++) {
							Element e = (Element) nl.item(i);
							
						    String id = myparser.getValue(e, "id"); // name child value
						    String address = myparser.getValue(e,"address"); // cost child value
						    String comments = myparser.getValue(e, "comments");
						    String contactno = myparser.getValue(e, "contactno");
						    String description = myparser.getValue(e, "description");
						    String latitude = myparser.getValue(e, "latitude");
						    String longitude = myparser.getValue(e, "longitude");
						    String name = myparser.getValue(e, "name");
						    String status = myparser.getValue(e, "status");
						    String time = myparser.getValue(e, "time");
						    
						  
						    Log.d("loop" + i , "id = " + id);
							Log.d("loop" + i, "address = " + address);	
							Log.d("loop" + i, "comments =" + comments);
							Log.d("loop" + i, "Contactno = " + contactno);
							Log.d("loop" + i, "Description = " + description);
							Log.d("loop" + i, "lat = " + latitude);
							Log.d("loop" + i, "Longitude = " + longitude);
							Log.d("loop" + i, "name = " + name);
							Log.d("loop" + i, "status = " + status);
							Log.d("loop" + i, "time = " + time);

							Double lat = Double.parseDouble(latitude);
							Double longi = Double.parseDouble(longitude);
							latitudes[i] = (int)(lat * 1e6);
							longitudes[i] = (int)(longi * 1e6);
											
							ListData D = new ListData();
							Log.d("loop" + i, "Setting Data to class array");
							D.SetData(address, comments, contactno,
									description, Double.parseDouble(latitude), Double.parseDouble(longitude), name,
									status , id , time);
							Log.d("loop" + i, "Calling Showdata");
							Tasks.add(D);
						}
						TaskAdapter adapter=new TaskAdapter(this, R.layout.list_item, Tasks);
						  setListAdapter(adapter);

						  ListView lv = getListView();
						  //lv.setTextFilterEnabled(false);
						  lv.setOnItemClickListener(this);
						
					}
					
					viewMap.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
								Intent intent = new Intent(TasksActivity.this , GoogleMap.class);
								intent.putExtra("latlist", latitudes);
								intent.putExtra("longlist", longitudes);
								intent.putExtra("do", "list");
								intent.putExtra("items", items);
								startActivity(intent);
						}
					});

				} catch (FileNotFoundException e) {
					Log.d("OnActivityResult", "File not found");
				} catch (IOException e) {
					Log.d("OnActivityResult", "I/O error");
				}

			} else if (resultCode == RESULT_CANCELED) {
				Toast.makeText(this, "Process Interrupted", 2000).show();
			} else if (resultCode == 378) {
				Toast.makeText(this, "Internet Connection Not Available", 2000)
						.show();
			}
		}

	}

	String MakeURL(String un, String date) {
		String BaseURL = "http://192.168.1.2/cwc/index.php/android/getTaskList?";
		String _username = "username=" + un + "&";
		String _date = "duedate=" + date;
		String _ret = "returnType=xml&";

		String url = BaseURL + _username + _ret + _date;
		return url;
	}

	public class ListData {
		private String address;
		private String comment;
		private String contactno;
		private String description;
		private double latitude;
		private double longitude;
		private String name;
		private String status;
		private String id;
		private String time;

		public ListData() {

		}

		public void SetData(String address, String comment, String contactno,
				String description, double latitude, double longitude,
				String name, String status , String id , String time ) {

			this.address = address;
			this.comment = comment;
			this.contactno = contactno;
			this.description = description;
			this.latitude = latitude;
			this.longitude = longitude;
			this.name = name;
			this.status = status;
			this.time = time;
			this.id = id;
		}

		public void ShowData() {
			Log.d("ListDataShow", "address = " + this.address);
			Log.d("ListDataShow", "comment = " + this.comment);
			Log.d("ListDataShow", "contactno = " + this.contactno);
			Log.d("ListDataShow", "description = " + this.description);
			Log.d("ListDataShow", "latitude = " + this.latitude);
			Log.d("ListDataShow", "longitude = " + this.longitude);
			Log.d("ListDataShow", "name = " + this.name);
			Log.d("ListDataShow", "status = " + this.status);
			Log.d("ListDataShow", "id = " + this.id);
			Log.d("ListDataShow", "time = " + this.time);
		}

		public Bundle toBundle() {
			Bundle b = new Bundle();
			b.putString("id", this.id);
			b.putString("nm", this.name);
			b.putString("desc", this.description);
			b.putString("adrs", this.address);
			b.putString("cmnt", this.comment);
			b.putString("phno", this.contactno);
			b.putDouble("lat", this.latitude);
			b.putDouble("long", this.longitude);
			b.putString("stts", this.status);
			b.putString("time", this.time);
		//	b.putInt("id", this.id);

			return b;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		// fetch the id of task clicked
		// start the taskView
		ListData data = Tasks.get(position);
		Intent i = new Intent(context, TaskView.class);
		i.putExtra("mode", "task");
		Bundle b = data.toBundle();
		i.putExtra("extras", b);
		startActivity(i);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		// show tasks on Map
	}

	private class TaskAdapter extends ArrayAdapter<ListData> {

		ArrayList<ListData> items;

		public TaskAdapter(Context context, int textViewResourceId,
				ArrayList<ListData> Items) {
			super(context, textViewResourceId, Items);
			this.items = Items;
			// TODO Auto-generated constructor stub
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = convertView;
			if (v == null) {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.list_item, null);
			}
			final ListData o = items.get(position);
			if (o != null) {

				TextView itemTitle = (TextView) v.findViewById(R.id.lst_txt);
				ImageView icon = (ImageView) v.findViewById(R.id.lst_icon);
				TextView desc = (TextView) v.findViewById(R.id.lst_desc);

				itemTitle.setText(o.name);
				desc.setText(o.description);
				if (Integer.parseInt(o.status) == 1) {
					icon.setImageResource(R.drawable.ok);
				} else {
					icon.setImageResource(R.drawable.todo);
				}
			}
			return v;
		}

	}

}
