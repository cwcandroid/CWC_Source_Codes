package com.cwc.courierclient;

import java.util.Calendar;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Window;

public class CallDialog extends Activity {

	
	private boolean offhook,idle;
	private ListenToPhoneState listener;
	
	Context context;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.call);

		Log.d("Call Dialog", "At onCreate");
		
		context=this;
		
		String tmp = this.getIntent().getExtras().getString("phno");
		String number = "tel:" + tmp.trim();
		Intent callIntent = new Intent(Intent.ACTION_CALL, Uri
				.parse(number));
		startActivity(callIntent);

		try {
			TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
			listener = new ListenToPhoneState();
			tManager.listen(listener,
					PhoneStateListener.LISTEN_CALL_STATE);
			
			while(offhook == true && idle == false ){
				try {
					wait(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			//insert call duration in DB
			String[] strFields = {
			        android.provider.CallLog.Calls.NUMBER, 
			        android.provider.CallLog.Calls.TYPE,
			        android.provider.CallLog.Calls.DURATION
			        };
			String selection=android.provider.CallLog.Calls.NUMBER+"=?";
			String selectionargs[]={tmp.trim()};
			String strOrder = android.provider.CallLog.Calls.DATE + " DESC"; 
			 
			Cursor mCallCursor = getContentResolver().query(
			        android.provider.CallLog.Calls.CONTENT_URI,
			        strFields,
			        selection,
			        selectionargs,
			        strOrder
			        );
			if(mCallCursor.moveToFirst())
			{
				String duration=mCallCursor.getString(mCallCursor.getColumnIndex(android.provider.CallLog.Calls.DURATION));
				Log.d("CALL", duration);
				//insert into database
				try{
					DataHelper dh=new DataHelper(context);
					dh.open();
					Calendar cal=Calendar.getInstance();
					final String[] MONTHS = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
					String datetime = Integer.toString(cal.get(Calendar.YEAR))+ "-" + MONTHS[cal.get(Calendar.MONTH)] + "-" +Integer.toString(cal.get(Calendar.DAY_OF_MONTH)) + " " + Integer.toString(cal.get(Calendar.HOUR_OF_DAY)) + ":" + Integer.toString(cal.get(Calendar.MINUTE)) + ":" + Integer.toString(cal.get(Calendar.SECOND));
					dh.insert_into_call_history(tmp, datetime, duration);
					dh.close();
					Log.d("CallHistory", "Added call"+tmp);
				}catch (Exception e) {
					// TODO: handle exception
					Log.d("DBERR", e.getMessage());
				}
				
			}
			finish();
					
		} catch (ActivityNotFoundException activityException) {
			Log.d("telephony-example", "Call failed", activityException);
		
	}
}

	private class ListenToPhoneState extends PhoneStateListener {

		public void onCallStateChanged(int state, String incomingNumber) {
			Log.d("telephony-example", "State changed: " + stateName(state));
		}

		String stateName(int state) {
			switch (state) {
			case TelephonyManager.CALL_STATE_IDLE:
				offhook = false;
				idle = true;
				return "Idle";
			case TelephonyManager.CALL_STATE_OFFHOOK:
				idle = false;
				offhook = true;
				return "Off hook";
			case TelephonyManager.CALL_STATE_RINGING:
				return "Ringing";
			}
			return Integer.toString(state);
		}
	}

}

