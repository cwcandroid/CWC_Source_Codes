
package com.cwc.courierclient;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataHelper {

	  
	    public static final String KEY_C_EVENT_DES = "event_des";
	    public static final String KEY_C_EVENT_TIME = "event_datetime";
	    public static final String KEY_C_LONG = "geopoint_long";
	    public static final String KEY_C_LAT = "geopoint_lat";
	    
	    public static final String KEY_C_PHONE = "phone";
	    public static final String KEY_C_DURATION = "duration";
	    public static final String KEY_C_CALL_DATETIME = "call_datetime";
	    
	    public static final String KEY_C_TASK_DES = "task_des";
	    
	    
	    private static final String TAG = "DBAdapter";
	 
	    private static final String DATABASE_NAME = "courier6.db";
	    private static final String DATABASE_TABLE1 = "task_history";
	    private static final String DATABASE_TABLE2 = "call_history";
	    private static final String DATABASE_TABLE3 = "location_history";
	    private static final String DATABASE_TABLE4 = "report_table";
	    private static final String DATABASE_TABLE5= "history_table";
	    private static final int DATABASE_VERSION = 1;
	    
	    
	    
	  
	   private static final String DATABASE_CREATE1 =
	    		 "create table IF NOT EXISTS task_history (task_id integer primary key autoincrement,task_name text not null, task_des text not null, task_datetime datetime not null, phone_no text not null, address text not null, status text not null, cmnt text not null, geopoint_long DECIMAL(10,8) not null, geopoint_lat DECIMAL(10,8) not null);";
	    
	    private static final String DATABASE_CREATE2 =
	    		 "create table IF NOT EXISTS call_history (c_history integer primary key autoincrement, phone text not null, call_datetime datetime not null, duration int not null);";
	    
	    private static final String DATABASE_CREATE3 =
	    		"create table IF NOT EXISTS location_history (l_history_id integer primary key autoincrement, event_des text not null, event_datetime datetime not null, geopoint_long DECIMAL(10,8) not null, geopoint_lat DECIMAL(10,8) not null);";
	    
	    
	    private static final String DATABASE_CREATE4 =
	    		"create table IF NOT EXISTS report_table (report_id integer primary key autoincrement, reason_type text not null, reason_details not null, geopoint_long DECIMAL(10,8) not null, geopoint_lat DECIMAL(10,8) not null, image text not null);";
	    
	    
	    private static final String DATABASE_CREATE5 =
	    		"create table IF NOT EXISTS history_table (history_id integer primary key autoincrement, name text not null, description text not null, ddate datetime not null, phone text not null, address text not null, status text not null,comment text not null, geopoint_long DECIMAL(10,8) not null, geopoint_lat DECIMAL(10,8) not null, reason_type text not null, reason_details text not null, response_long DECIMAL(10,8) not null, response_lat DECIMAL(10,8) not null, image text not null);";
	    
	    
	   
	    private final Context context; 
	 
	    public DatabaseHelper DBHelper;
	    private SQLiteDatabase db;
	    public String temp_criteria[] ;
	    
	    public DataHelper(Context ctx) 
	    {
	        this.context = ctx;
	        DBHelper = new DatabaseHelper(context);
	    }
	 
	    public static class DatabaseHelper extends SQLiteOpenHelper 
	    {
	        DatabaseHelper(Context context) 
	        { 	
	            super(context, DATABASE_NAME, null, DATABASE_VERSION);
	            
	            Log.d("asche", "creating..");
	        }
	 
	        @Override
	        public void onCreate(SQLiteDatabase db) 
	        {
	        	Log.d("here", "calling");
	            db.execSQL(DATABASE_CREATE1);
	            db.execSQL(DATABASE_CREATE2);
	            db.execSQL(DATABASE_CREATE3);
	            db.execSQL(DATABASE_CREATE4);
	            db.execSQL(DATABASE_CREATE5);
	        }
	 
	        
	        
	        @Override
	        public void onUpgrade(SQLiteDatabase db, int oldVersion, 
	        int newVersion) 
	        {
	            Log.w(TAG, "Upgrading database from version " + oldVersion 
	                    + " to "
	                    + newVersion + ", which will destroy all old data");
	            db.execSQL("DROP TABLE IF EXISTS titles");
	            onCreate(db);
	        }
	    }    
	 
	    //---opens the database---
	    public DataHelper open() throws SQLException 
	    {
	        db = DBHelper.getWritableDatabase();
	        return this;
	    }
	 
	    //---closes the database---    
	    public void close() 
	    {
	        DBHelper.close();
	    }
	    
	    public void deleteAll() {
	       // this.db.delete(DATABASE_TABLE, null, null);
	    	
	        
	        this.db.delete(DATABASE_TABLE1, null, null);
	        this.db.delete(DATABASE_TABLE2, null, null);
	       // this.db.execSQL("Drop table titles");
	        
	        
	    	
	     }
	   
	    
	   
	    public long insert_into_history_table(String name, String des, String date, String phone, String address, String status, String cmnt, double lon, double lat, String r_type, String r_details, double res_lon, double res_lat, String image)
	    {
	    	
	    	   Log.d("reg","inserting..");   
	    	
	    	   ContentValues initialValues = new ContentValues();
	        
		        initialValues.put("name", name);
		        initialValues.put("description", des);
		        initialValues.put("ddate", date);
		        initialValues.put("phone", phone);
		        initialValues.put("address", address);
		        initialValues.put("status", status);
		        initialValues.put("comment", cmnt);
		        initialValues.put("geopoint_long", lon);
		        initialValues.put("geopoint_lat", lat);
		        initialValues.put("reason_type", r_type);
		        initialValues.put("reason_details", r_details);
		        initialValues.put("response_long", res_lon);
		        initialValues.put("response_lat", res_lat);
		        initialValues.put("image", image);
		        
		        
		        
		        return db.insert(DATABASE_TABLE5, null, initialValues);
	    }
	  
	    public long insert_into_location_history(String event_des, String datetime, double lon, double lat)
	    {
	    	
	    	   Log.d("reg","inserting..");   
	    	
	    	   ContentValues initialValues = new ContentValues();
	        
		        initialValues.put(KEY_C_EVENT_DES, event_des);
		        initialValues.put(KEY_C_EVENT_TIME, datetime);
		        initialValues.put(KEY_C_LONG, lon);
		        initialValues.put(KEY_C_LAT, lat);
		        
		        
		        return db.insert(DATABASE_TABLE3, null, initialValues);
	    }
	    
	    public long insert_into_call_history(String phone, String datetime,  String duration)
	    {
	    	
	    	   Log.d("reg","inserting..");   
	    	
	    	   ContentValues initialValues = new ContentValues();
	        
		        initialValues.put(KEY_C_PHONE, phone);
		        initialValues.put(KEY_C_CALL_DATETIME, datetime);
		        initialValues.put(KEY_C_DURATION, duration);
		        
		        
		        return db.insert(DATABASE_TABLE2, null, initialValues);
	    }
	    
	    public long insert_into_task(String t_name, String des, String date, String phone, String address,String status, String cmnt, double lat, double lon)
	    {
	    	
	    	   Log.d("reg","inserting..");   
	    	
	    	   ContentValues initialValues = new ContentValues();
	        
		        initialValues.put("task_name", t_name);
		        initialValues.put("task_des", des);
		        initialValues.put("task_datetime", date);
		        initialValues.put("phone_no", phone);
		        initialValues.put("address", address);
		        initialValues.put("status", status);
		        initialValues.put("cmnt", cmnt);
		        initialValues.put("geopoint_long", lat);
		        initialValues.put("geopoint_lat", lon);
		        
		        
		        
		        return db.insert(DATABASE_TABLE1, null, initialValues);
	    }
	    
	    
	    public long insert_into_report_table(String reason_type, String reason_details, double lon, double lat, String img)
	    {
	    	
	    	   Log.d("reg","inserting..");   
	    	
	    	   ContentValues initialValues = new ContentValues();
	        
		        initialValues.put("reason_type", reason_type);
		        initialValues.put("reason_details", reason_details);
		        initialValues.put("geopoint_long", lon);
		        initialValues.put("geopoint_lat", lat);
		        initialValues.put("image", img);
		        
		        
		        
		        return db.insert(DATABASE_TABLE4, null, initialValues);
	    }
	    
	    
	    public Cursor get_all_time()
	    {
	    	String q = "Select task_datetime from task_history";
	    	return db.rawQuery(q, null);
	    	
	    }
	    
	    
	    public Cursor get_all_call_history()
	    {
	    	String q = "Select * from call_history";
	    	return db.rawQuery(q, null);
	    	
	    }
	    
	    public Cursor get_call_history_by_date(String date)
	    {
	    	String q = "Select * from call_history order by call_datetime asc";
	    	
	    	return db.rawQuery(q, null);
	    }
	   
	   
	   
	    
	    /*public String[] getAllEmail()
	    {
	    	
	    	String q = "SELECT p_email FROM pathfinder";
	    	
	        Cursor cursor = db.rawQuery(q, null);
	 
	        if(cursor.getCount() >0)
	        {
	            String[] str = new String[cursor.getCount()];
	            int i = 0;
	 
	            while (cursor.moveToNext())
	            {
	                 str[i] = cursor.getString(cursor.getColumnIndex(KEY_P_EMAIL));
	                 i++;
	             }
	            return str;
	        }
	        else
	        {
	            return new String[] {};
	        }
	    }*/
	    
	    
	    
}

