package com.cwc.courierclient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.io.IOUtils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;

public class DownloadData extends Activity {
	ProgressDialog progressDialog;
	ImageView viewer;
	Bitmap bitmap;
	String url;
	ProgressBar progress;
	String JsonText;
	boolean opmode;
	int count;
	boolean retFlag ;
	int internet = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.downloading);
		
		retFlag = false;
		progress = (ProgressBar) findViewById(R.id.progressBar1);

		Bundle extras = getIntent().getExtras();
		if (extras == null) {
			return;
		}
		url = extras.getCharSequence("url").toString();
		new CheckForImage().execute("");
	}

	public class CheckForImage extends AsyncTask<String, Integer, Long> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

		@Override
		protected Long doInBackground(String... params) {

			try {
				URL imageURL = new URL(url);
				URLConnection connection = imageURL.openConnection();
				HttpURLConnection httpURLConnection = (HttpURLConnection) connection;
				int ResponseCode = httpURLConnection.getResponseCode();

				if (ResponseCode == HttpURLConnection.HTTP_OK) {
					InputStream in = connection.getInputStream();
					Log.d("Daily", "InputStream GOT");
					Log.d("Daily", "Reading STream");
					JsonText = IOUtils.toString(in);
					Log.d("Daily", "Finished Reading STream");
					Log.d("Daily", "JSON String = " + JsonText);
					Log.d("Daily", "JSON String Length = " + JsonText.length());
								
					File file = new File("/sdcard/jsondata.dat");
					file.createNewFile();
					FileOutputStream fout = new FileOutputStream(file);
					OutputStreamWriter filewriter = new OutputStreamWriter(fout);
					filewriter.append(JsonText);
					
					filewriter.close();
					fout.close();
					Log.d("File", "JSON Written");
					retFlag = true ;

				} else {
					Log.d("Daily", "DoINBack...ResponseCode not as expected");
				}

			} catch (MalformedURLException e) {
				Log.d("Daily", "Malformed URL");
				retFlag = false ;
			} catch (IOException e) {
				Log.d("Daily", "DoINBack...Unknown Host Exception");
				internet = 377 ;
				retFlag = false ;
			} catch (Exception e) {
				Log.d("Daily", "File I/O error");
				retFlag = false ;
			}
			return null;
		}

		@Override
		protected void onPostExecute(Long result) {
			super.onPostExecute(result);
			Log.d("PostExe", "Calling Finish");
			finish();
		}
	}

	@Override
	public void finish() {
		Intent intent = new Intent();
		if(retFlag == false){
			if(internet == 377){
				setResult(378 , intent);
			} else {
				setResult(RESULT_CANCELED, intent);
				Log.d("Finish", "Result canceled");
			}
			
		}else{
			intent.putExtra("opmode", opmode);
			setResult(RESULT_OK, intent);
			Log.d("Finish", "Result ok");
		}
		Log.d("Finsh" , "Returning...");
		super.finish();
	}
}
