package com.cwc.courierclient;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class CWCCourierClientLoginActivity extends Activity {
	Button btnLogin, btnRegister;
	EditText username , password;
	CheckBox remember;
	Context context;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        
        context=this;
        
        btnLogin=(Button)findViewById(R.id.login);
        btnRegister=(Button)findViewById(R.id.register);
        username = (EditText) findViewById(R.id.login_nm);
        password = (EditText) findViewById(R.id.login_pass);
        remember=(CheckBox)findViewById(R.id.login_remember);
        
        SharedPreferences prefs=context.getSharedPreferences("login", MODE_WORLD_READABLE);
        if(prefs.getBoolean("remember", false))
        {
        	username.setText(prefs.getString("username", ""));
        	password.setText(prefs.getString("password", ""));
        	remember.setChecked(true);
        }
        btnLogin.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(Validate(username, "Username") && Validate(password, "Password")){
					String url = MakeURL(username.getText().toString(), password.getText().toString());
					String responseString = DataFetcher(url);
					
					try {
						JSONObject obj = new JSONObject(responseString);
						boolean status = obj.getBoolean("status");
						if(status == true){
							Toast.makeText(context,"Login Successful",2000).show();
							/****************************************/
							SharedPreferences myPrefs = context.getSharedPreferences("login", MODE_WORLD_READABLE);
					        SharedPreferences.Editor prefsEditor = myPrefs.edit();
					        prefsEditor.putString("username", username.getText().toString());
					        prefsEditor.putString("password", password.getText().toString());
					        if(remember.isChecked())
					        {
					        	prefsEditor.putBoolean("remember", true);
					        }
					        else
					        {
					        	prefsEditor.putBoolean("remember",false);
					        }
					        prefsEditor.commit();
							
							/********************************************/
							Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientMainScreenActivity.class);
							i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i);
						}else{
							Toast.makeText(context, "Login Failed", 2000).show();
						}
					} catch (JSONException e) {
						Log.d("Parse JSON for login", "Couldnt parse json");
						Toast.makeText(context, "Unknown Response", 2000).show();
						e.printStackTrace();
					}
				}else{
					Toast.makeText(context, "Username/Password can't be empty", 2000).show();
				}
			}
		});
        
        btnRegister.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientRegistrationActivity.class);
				startActivity(i);
			}
		});
        
        username.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (username.getText().toString().equals("Username")) {
					username.setText("");
				}
			}
		});
        
        password.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (password.getText().toString().equals("Password")) {
					password.setText("");
				}
			}
		});
               
    }
    
    boolean Validate(EditText ET, String str) {
		if (ET.getText().toString().equals("")
				|| ET.getText().toString().equals(str)) {
			return false;
		}
		return true;
	}

	String MakeURL(String un, String pass) {
		String BaseURL = "http://192.168.1.2/cwc/index.php/android/login?";
		String _username = "username=" + un + "&";
		String _password = "password=" + pass + "&";
		String _ret = "returnType=json";

		String url = BaseURL + _username + _password + _ret ;
		return url;
	}

	String DataFetcher(String url) {
		String JSONMessage = "";
		try {
			URL _url = new URL(url);
			URLConnection urlConnection = _url.openConnection();
			HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
			int response = httpURLConnection.getResponseCode();

			if (response == HttpURLConnection.HTTP_OK) {
				InputStream in = urlConnection.getInputStream();
				JSONMessage = IOUtils.toString(in);
			}
		} catch (MalformedURLException e) {
			Toast.makeText(context, "Invalid URL", 2000).show();
			e.printStackTrace();
		} catch (IOException e) {
			Toast.makeText(context, "Please Check internet Connection", 2000).show();
		}
		return JSONMessage;
	}
}