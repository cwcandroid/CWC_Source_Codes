package com.cwc.courierclient;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class ReportTask extends Activity implements OnClickListener{
	Context context;
	Spinner type;
	Button locate,sign,submit,cancel;
	EditText comment;
	ImageView signature;
	
	private LocationManager locationManager;
	private String provider;
	double mylat , mylong ;
	int latitude , longitude;
	String date;
	
	int id;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.report);
		
		context=this;
		
		type=(Spinner)findViewById(R.id.rpt_tp);
		locate=(Button)findViewById(R.id.rpt_lct);
		sign=(Button)findViewById(R.id.rpt_sign_btn);
		submit=(Button)findViewById(R.id.rpt_submit);
		cancel=(Button)findViewById(R.id.rpt_cancel);
		
		signature=(ImageView)findViewById(R.id.rpt_sign_img);
		
	//	locate.setOnClickListener(this);
		sign.setOnClickListener(this);
		submit.setOnClickListener(this);
		cancel.setOnClickListener(this);
		
		id=this.getIntent().getIntExtra("id", -1);
		
		ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(context, R.array.rpt_array, android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		type.setAdapter(adapter);
		type.setSelection(0);
		
		
		locate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				/**************************/
		
				locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
				Criteria criteria = new Criteria();
				criteria.setAccuracy(Criteria.ACCURACY_FINE);
				criteria.setPowerRequirement(Criteria.POWER_LOW);
				provider = locationManager.getBestProvider(criteria, false);
				Location location = locationManager.getLastKnownLocation(provider);

				if(location != null){
					mylat = location.getLatitude();
					mylong = location.getLongitude();
					latitude = (int) (mylat * 1e6);
					longitude = (int) (mylong * 1e6);
				} else {
					Toast.makeText(ReportTask.this , "Provider Unavailable", 2000);
				}
				
				Intent intent = new Intent(context, GoogleMap.class);
				intent.putExtra("lat", latitude);
				intent.putExtra("long", longitude);
				intent.putExtra("do", "single");
				startActivityForResult(intent, 0);
				/****************************/
			}
		});
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
			case R.id.rpt_sign_btn:
				Intent i=new Intent(context, CaptureSignature.class);
				startActivityForResult(i, 0);
			break;
			
			case R.id.rpt_submit:
				
				
				
				Intent i1=new Intent(context, CaptureSignature.class);
				startActivityForResult(i1, 0);
			break;
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(requestCode==0)
		{
			if(resultCode==RESULT_OK)
			{
				Toast.makeText(context, "Signature image saved", 2000);
				Bitmap bm=BitmapFactory.decodeFile(Environment.getExternalStorageDirectory()+"/"+"signatures"+"/"+"signature.png");
				signature.setImageBitmap(bm);
			}
		}
	}

	String MakeURL(String un, String rtype , String rd , int tid , double rlat , double rlong ) {
		String BaseURL = "http://test.sentisol.com/cwc/index.php/android/getTaskList?";
		String _username = "username=" + un + "&";
		String _date = "duedate=" + date;
		String _ret = "returnType=json&";

		String url = BaseURL + _username + _ret + _date;
		return url;
	}
}
