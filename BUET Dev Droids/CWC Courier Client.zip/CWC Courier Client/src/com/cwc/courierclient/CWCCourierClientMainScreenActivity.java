package com.cwc.courierclient;

import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;

public class CWCCourierClientMainScreenActivity extends TabActivity {

	Context context;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.maintab);
		
		context=this;
		
		// setup tabs
		TabHost tabHost = getTabHost();
		Resources res=getResources();
		TabHost.TabSpec tabSpec;
		Intent intent;

		intent = new Intent().setClass(this, TasksActivity.class);
		tabSpec = tabHost.newTabSpec("tasks").setIndicator("Tasks", res.getDrawable(R.drawable.taskicon))
				.setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, HistoryActivity.class);
		tabSpec = tabHost.newTabSpec("history").setIndicator("History", res.getDrawable(R.drawable.historyicon))
				.setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, PerformanceActivity.class);
		tabSpec = tabHost.newTabSpec("performance").setIndicator("Performance", res.getDrawable(R.drawable.performanceicon))
				.setContent(intent);
		tabHost.addTab(tabSpec);
		
		intent = new Intent().setClass(this, CallHistory.class);
		tabSpec = tabHost.newTabSpec("callhistory").setIndicator("Call History", res.getDrawable(R.drawable.call_history))
				.setContent(intent);
		tabHost.addTab(tabSpec);
		
		intent = new Intent().setClass(this, LocationHistory.class);
		tabSpec = tabHost.newTabSpec("locationhistory").setIndicator("Location History", res.getDrawable(R.drawable.location_history))
				.setContent(intent);
		tabHost.addTab(tabSpec);
	}

}
