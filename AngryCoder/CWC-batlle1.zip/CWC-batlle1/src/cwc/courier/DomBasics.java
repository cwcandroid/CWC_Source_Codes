package cwc.courier;


/* 
	a java class that uses regular expressions to parse dom to a basic level 
	Author: Sayeed Mahmud
	Please give the author some credit ::
*/


import java.util.* ;
import java.util.regex.* ;

class DomBasics{
	private String html = "" ;

	public DomBasics(String html){
		this.html = html ;
	}

	/* 
		get all the valuse of a certain attribute irrespective of tag name
		for example get all src or href value
	 */
	public ArrayList<String> getAllAttribute(String attribute){
		ArrayList<String> temp = new ArrayList<String>() ;
		Pattern p = Pattern.compile(attribute + "\\s*=\\s*[\"']\\s*(.*?)\\s*[\"']", Pattern.MULTILINE) ;
		
		Matcher m = p.matcher(html) ;
		while (m.find()){
			temp.add(m.group(1)) ;
		}
		return temp ;
	}

	/* 
		get innertext of a tag
		<tag attributes> InnerText </tag>
	 */
	public ArrayList<String>getInnerTextByTag(String tag){
		ArrayList<String> temp = new ArrayList<String>() ;
		Pattern p = Pattern.compile("<" + tag + "(?:\\s+[^>]*)*?>\\s*(.*?)\\s*<\\s*/\\s*" + tag + ">", Pattern.MULTILINE) ;
	
	                                             
		Matcher m = p.matcher(html) ;
		while (m.find()){
			temp.add(m.group(1)) ;
		}
		return temp ;

	}

	/*
		get the value of an attribute of a tag, returns all occurences
		for example <div id="id1"> it will return id1 in response to getValueByTagAttribute("div", "id")
	 */
	public ArrayList<String>getValueByTagAttribute(String tag, String attribute){
		ArrayList<String> temp = new ArrayList<String>() ;
		Pattern p = Pattern.compile("<(?:" + tag +")[^>]*" + attribute + "\\s*=\\s*" + "(?:[\"'])(.*?)[\"'][^>]*>(?:.*?)<\\s*/\\s*" + tag + ">", Pattern.MULTILINE) ;
	
		Matcher m = p.matcher(html) ;
		while (m.find()){
			temp.add(m.group(1)) ;
		}
		return temp ;

	}

	/*
		Equivalent to getElementById().innerTEXT
	 */
	public ArrayList<String>getInnerTextByTagAttribute(String tag, String attribute, String value){
		ArrayList<String> temp = new ArrayList<String>() ;
		Pattern p = Pattern.compile("<(?:" + tag +")[^>]*" + attribute + "\\s*=\\s*" + "(?:[\"'])" + value + "[\"'][^>]*>(.*?)<\\s*/\\s*" + tag + ">", Pattern.MULTILINE) ;
	                                             
		Matcher m = p.matcher(html) ;
		while (m.find()){
			temp.add(m.group(1)) ;
		}
		return temp ;
		
	}

	/*
		Gets all attributes and its values of a certain tag
		as usual all occurences
	 */
	public ArrayList< HashMap<String, String> >getTagAttributes(String tag){
		ArrayList< HashMap<String, String> > temp = new ArrayList< HashMap<String, String> >() ;

		Pattern p = Pattern.compile("<" + tag + "\\s+([^>]+(?:[\"']))\\s?/?>", Pattern.MULTILINE) ;
	
		Matcher m = p.matcher(html) ;
		while (m.find()){
			String ts = m.group(1) ;
	
			Pattern subPattern = Pattern.compile("([^\\s=]+)\\s*=\\s*[\"']([^\"']*)[\"']") ;
			Matcher subMatcher = subPattern.matcher(ts) ;
			HashMap<String, String> th = new HashMap<String, String>() ;
			while(subMatcher.find()){
				th.put(subMatcher.group(1), subMatcher.group(2)) ;
			}
			temp.add(th) ;
		}
		return temp ;
	}
}

