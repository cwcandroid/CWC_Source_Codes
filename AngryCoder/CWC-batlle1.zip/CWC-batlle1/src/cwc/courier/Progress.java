package cwc.courier;

/*
 * 
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * The abstract class for the screen for progress bar.
 * Motivation: There are lots of background tasks to show progressbars for
 * with few differences
 * We can choose to create a layout and activity class for each of them
 * or
 * we can use an activity and layout as skeleton and inherit them to handle
 * the minor differences
 * Example: Login progress bars show the message Logging in with success status
 * Logged In Successful, switch to activity TabHost while the register class shows
 * Registering message, with status of Registered Successful and switching to Login
 * screen, or even better no message at all, just updating a list view
 * 
 * So instead of a large block of switch case or if-else we resort to inheritence tree
 * 
 * Author: Sayeed Mahmud
 * Angry Coders
 */

import android.app.Activity ;
import android.os.Bundle ;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;




abstract class Progress extends Activity{
	/* flag for inter-thread communication */
	final String COMPLETE_FLAG = "DONE" ;
	final String ERROR_FLAG = "Error" ;
	
	/* controls on the UI */
	TextView txtStatus ;
	ProgressBar pb ;
	
	/* message handling */
	Handler handler = new Handler(){
		@Override
        public void handleMessage(Message msg) {
			String s ;
			s = (String)msg.obj ;
			Log.e("Handler Code", s + "") ;
			if (s.equals(COMPLETE_FLAG)){
				switchActivity() ;
			}else if(s.equals(ERROR_FLAG)){
				Toast.makeText(Progress.this, Error.lastError, Toast.LENGTH_LONG).show() ;
				Error.lastError = "" ;
			}else{
				if (s != null)
					txtStatus.setText(s) ;
			}
        }
	} ;
	
	/*
	 * (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 * On create is essential as it extends activity
	 */
	@Override
	public void onCreate(Bundle bOs){
		super.onCreate(bOs) ;
		setContentView(R.layout.progress) ;
		txtStatus = (TextView)findViewById(R.id.txtStatus) ;
	}
	
	/* 
	 * to be overriden
	 * Leave it to the subclasses where to switch or if switch at all
	 */
	abstract void switchActivity() ;
			
	
	
	
}
