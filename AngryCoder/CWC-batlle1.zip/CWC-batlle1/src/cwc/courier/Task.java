package cwc.courier;

/*
 * Prototype for a class
 */
public class Task {
	public String address ;
	public String comments ;
	public String contactno ;
	public String description ;
	public String latitude ;
	public String longitude ;
	public String name ;
	public String status ;
	public String id ;
}
