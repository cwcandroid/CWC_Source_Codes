package cwc.courier;

/*
 * 
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * The concrete class of Progress to handle
 * on screen messaging of Progress of API login
 * 
 * Author: Sayeed Mahmud
 * Angry Coders
 */ 
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class ProgressLogin extends Progress{
	/* the task object */
	LoginTask l = null ;
	String user = "" ;
	String pass = "" ;
	
	/* to refer to onCreate up to two levels of inheitence tree*/
	@Override
	public void onCreate(Bundle bOS){
		super.onCreate(bOS) ;
		/* yes message must be passed -- in order to perform the task */
		Intent i = getIntent() ;
		/* getting the login parameters */
		user = i.getStringExtra("USER") ;
		pass = i.getStringExtra("PASS") ;
		//Log.e("ProgressLogin onCreate", user + " " + pass) ;
		/* initiate the task */
		l = new LoginTask(user, pass, handler) ;
		/* perform it */
		l.doInBackground() ;
	}
	/*
	 * (non-Javadoc)
	 * @see cwc.courier.Progress#switchActivity()
	 * The switch  -- implementation of the abstract method
	 */
	@Override
	public void switchActivity(){
		Intent i ;
		if (l.isSuccessful){
			/* success -- go to app mai screen */
			AppData.user = user ;
			i = new Intent(ProgressLogin.this, ProgressFetch.class);
			
		}else
			/* no success -- go to log in screen */
			i = new Intent(ProgressLogin.this, CourierActivity.class);
        startActivity(i);
        /* we don't want to show interim progress bar if back was pressed */
        finish() ;
	}
}
