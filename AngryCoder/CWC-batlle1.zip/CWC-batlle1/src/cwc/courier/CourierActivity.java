package cwc.courier;
//******************** May  Allah Bless Us***************************//////////


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class CourierActivity extends Activity {
    
	
	EditText Name,Password;
	Button Login,Register;
	CheckBox chkRem ;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        
        AppData.db = new Database(this) ;
        
        AppData.reasonsValue.put(0, "Not Delivered") ;
        AppData.reasonsValue.put(1, "Delivered") ;
        AppData.reasonsValue.put(2, "Address Not found") ;
        AppData.reasonsValue.put(3, "Recipient Absent") ;
        AppData.reasonsValue.put(4, "Others") ;
        
        AppData.reasonsId.put("Not Delivered", 0) ;
        AppData.reasonsId.put("Delivered", 1) ;
        AppData.reasonsId.put("Delivered", 2) ;
        AppData.reasonsId.put("Recipient Absent", 3) ;
        AppData.reasonsId.put("Others", 4) ;
        
        
        
        
        Name = (EditText) findViewById(R.id.nameEdit);
        Password = (EditText) findViewById(R.id.passEdit);
        chkRem = (CheckBox)findViewById(R.id.chkRemember) ;
        
        // ** Removable Portion Begins here ***********
        // Loading preferences
        SharedPreferences sp = getPreferences(MODE_PRIVATE) ;
        String u = sp.getString("USER", "") ;
        String p = sp.getString("PASS", "") ;
        Name.setText(u) ;
        Password.setText(p) ;
        // ** Removable Portion ends here ***********
        
        
        Login=(Button)findViewById(R.id.log_log);
        Register=(Button)findViewById(R.id.log_reg);
        
        Login.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
            	String user = Name.getText().toString() ;
            	if (user.equals("")){
            		Toast.makeText(CourierActivity.this, "Please Enter a User Name", Toast.LENGTH_LONG).show() ;
            		return ;
            	}
            	boolean isRem = chkRem.isChecked() ;
            	if (isRem){
            		SharedPreferences sp = getPreferences(MODE_PRIVATE) ;
            		SharedPreferences.Editor editor = sp.edit();
            	    editor.putString("USER", Name.getText().toString());
            	    editor.putString("PASS", Password.getText().toString());
            	    editor.commit();
            	}
            	boolean conn = Common.isNetworkAvailable(CourierActivity.this) ;
            	if (!conn){
            		Toast.makeText(CourierActivity.this, "Network Connection Not Available", Toast.LENGTH_LONG).show() ;
            		return ;
            		
            	}
            	Intent i = new Intent(CourierActivity.this, ProgressLogin.class);
            	i.putExtra("USER", Name.getText().toString()) ;
            	i.putExtra("PASS", Password.getText().toString()) ;
                startActivity(i);
            }

          });
        Register.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
              Intent intent = new Intent(CourierActivity.this, Register.class);
              startActivity(intent);
            }

          });
    }
}