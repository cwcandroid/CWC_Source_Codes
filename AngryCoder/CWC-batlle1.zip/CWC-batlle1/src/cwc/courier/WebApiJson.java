package cwc.courier;

/*
 * @Copyright: Do not modify this header
 * Give due credit to author
 *  
 * A class for handling WebApis for the problem in JSON format
 * The base class provided most of the functionality 
 * We just handle a little JSON here
 * 
 * FileName: WebApiJson.java
 * Author: Sayeed Mahmud
 * Angry Coders
 * 
 *   
 *   TO DO:
 *   
 */


import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import org.json.JSONArray;
import org.json.JSONObject;
import android.util.Log;

public class WebApiJson extends WebApi{
	
	public WebApiJson(){
		/* specifying returnType field in super class */
		super.returnType = "returnType=json" ;
	}
	
	/*
	 * (non-Javadoc)
	 * @see angrycoders.CourierClient.WebApi#parse(java.lang.String)
	 * The JSON Parse Method
	 * Phiosophy: A JSON response may contain only one object or many
	 * we treat all the same in this single method instead of creating
	 * parseSingle(), parseMultiple() like method.
	 * We return a arraylist of properties where each element represents
	 * a raw JSON object and each field(key) of property represents key of JSON
	 * which has a corresponding value
	 * 
	 * Input: String containing JSON
	 */
	@Override
	ArrayList<Properties> parse(String s) {
		ArrayList<Properties> temp = new ArrayList<Properties>() ;
		try{
			/*
			 * If not array, make this array -- simple concatenation of
			 * String after all
			 */
			if (!s.startsWith("["))
				s = "[" + s + "]" ;
			JSONArray array = new JSONArray(s) ;
			int szArray = array.length() ;
			/* loop through objects */
			for (int i = 0 ; i < szArray ; i++){
				JSONObject obj = array.getJSONObject(i) ;
				Iterator<String> it = obj.keys();
				Properties prop = new Properties() ;
				/* loop through keys and put corresponding values in properties */
				while (it.hasNext()){
					String key = it.next() ;
					Log.e("KEY", key) ;
					prop.put(key, obj.get(key)) ; 
				}
				temp.add(prop) ;
			}
		}catch (Exception e){
			Log.e(this.getClass().toString() + " Parse()", e.toString()) ;
		}
		return temp;
	}

}
