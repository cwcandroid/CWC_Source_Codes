package cwc.courier;

/*
 * 
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * The concrete class of Progress to handle
 * on screen messaging of Progressing of API Register
 * 
 * Author: Sayeed Mahmud
 * Angry Coders
 */ 
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class ProgressRegister extends Progress{
	/* the task object */
	RegisterTask r = null ;
	
	/* to refer to onCreate up to two levels of inheitence tree*/
	@Override
	public void onCreate(Bundle bOS){
		super.onCreate(bOS) ;
		/* yes message must be passed -- in order to perform the task */
		Intent i = getIntent() ;
		/* getting the login parameters */
		String user = i.getStringExtra("USER") ;
		String pass = i.getStringExtra("PASS") ;
		String email = i.getStringExtra("EMAIL") ;
		
		//Log.e("ProgressLogin onCreate", user + " " + pass) ;
		/* initiate the task */
		r = new RegisterTask(user, pass, email, handler) ;
		/* perform it */
		r.doInBackground() ;
	}
	/*
	 * (non-Javadoc)
	 * @see cwc.courier.Progress#switchActivity()
	 * The switch  -- implementation of the abstract method
	 */
	@Override
	public void switchActivity(){
		Intent i ;
		if (r.isSuccessful)
			/* success -- go to app mai screen */
			i = new Intent(ProgressRegister.this, CourierActivity.class);
		else
			/* no success -- go to log in screen */
			i = new Intent(ProgressRegister.this, Register.class);
        startActivity(i);
        /* we don't want to show interim progress bar if back was pressed */
        finish() ;
	}
}
