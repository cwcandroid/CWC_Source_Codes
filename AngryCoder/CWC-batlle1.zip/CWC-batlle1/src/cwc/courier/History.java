package cwc.courier;



import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import cwc.courier.quickaction.ActionItem;
import cwc.courier.quickaction.QuickAction;


public class History extends ListActivity {
	Button cmdRefresh, cmdGo ;
	EditText txtFilter ;
	int lstPos = 0 ;
	 @Override
	 public void onCreate(Bundle savedInstanceState) {
	  super.onCreate(savedInstanceState);
	  setContentView(R.layout.tab_one);
	  
	  
	  cmdRefresh =(Button)findViewById(R.id.taskRefresh) ;
	  cmdRefresh.setOnClickListener(new OnClickListener(){
		  public void onClick(View v){
			  Intent i = new Intent(History.this, ProgressFetch.class) ;
			  startActivity(i) ;
			  finish() ;
		  }
	  }) ;
	  
		//Add action item
      ActionItem addAction = new ActionItem();
		
		addAction.setTitle("Task Detail");
		

		//Accept action item
		ActionItem accAction = new ActionItem();
		
		accAction.setTitle("Show in Map");
		
		
		//Upload action item
		ActionItem upAction = new ActionItem();
		
		upAction.setTitle("Report");
		
		
		final QuickAction mQuickAction 	= new QuickAction(this);
		
		mQuickAction.addActionItem(addAction);
		mQuickAction.addActionItem(accAction);
		mQuickAction.addActionItem(upAction);
		
		//setup the action item click listener
		mQuickAction.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() {			
			
			public void onItemClick(int pos) {
				Intent i ;
				if (pos == 0) { //Add item selected
					Toast.makeText(History.this, "Add item selected", Toast.LENGTH_SHORT).show();
				} else if (pos == 1) { //Accept item selected
					Toast.makeText(History.this, "Accept item selected", Toast.LENGTH_SHORT).show();
				} else if (pos == 2) { //Upload item selected
					
					i = new Intent(History.this, Report.class) ;
					i.putExtra("ID", lstPos + "") ;
					startActivity(i) ;
					Toast.makeText(History.this, "Upload items selected", Toast.LENGTH_SHORT).show();
				}	
			}
		});

	  
	  
	  //setListAdapter(new ArrayAdapter<String>(
			//	 this, android.R.layout.simple_list_item_1, 
		//		 getResources().getStringArray(R.array.Sleeping)));
	  
	  /////// Customized list which is not working on Clicks
	  setListAdapter(new MyAdapter(
				 this, android.R.layout.simple_list_item_1,R.id.textView1, 
				 AppData.taskHeadline));
	  
	  ListView ls = getListView();


	  
	  ls.setOnItemClickListener(new AdapterView.OnItemClickListener() {
		    public void onItemClick(AdapterView<?> av, View v, int pos, long id) {
		    	lstPos = pos ;
		    	return ;
				//mQuickAction.show(v);
				//mQuickAction.setAnimStyle(QuickAction.ANIM_GROW_FROM_CENTER);
		    }
		});
	
	  
	  
	  
	 }
	 /////////// Customize ******List Class**** but not working on CLicks

		public class MyAdapter extends ArrayAdapter<String>{
				String [] itemName =  new String[AppData.historyList.size()];
				String [] itemAddress = new String[AppData.historyList.size()];
				String [] itemDesc = new String[AppData.historyList.size()];
				public MyAdapter(Context context,int resource,int textViewResourceId,
						String [] string) {
							super(context, resource, textViewResourceId, string);
							int sz = AppData.historyList.size() ;
							itemName = new String[sz] ;
							itemAddress = new String[sz] ;
							itemDesc = new String[sz] ;
							
							itemName = AppData.historyName ;
							itemAddress = AppData.historyAddress ;
							itemDesc = AppData.historyHeadline ;
							/*for (int i = 0 ; i < sz ; i++){
								itemName[i] = AppData.historyList.get(i).name;
								itemAddress[i] = AppData.historyList.get(i).address ;
								itemDesc[i] = AppData.historyList.get(i).description ;
							}*/
							//items = new String[AppData.taskList.size()] ;
							//items = string ;
				}

				@Override
				public View getView(int position, View convertView, ViewGroup parent) {
					LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
					View row=inflater.inflate(R.layout.list_item, parent,false);
					//int sz = AppData.taskList.size() ;
					//Task [] tasks = new Task[sz] ;
					//tasks = (Task[]) AppData.taskList.toArray() ;
					//String[] items = new String[sz] ;
					//items = AppData.taskHeadline ;
					TextView tv = (TextView) row.findViewById(R.id.textView2);
					TextView tv1 = (TextView) row.findViewById(R.id.textView3);
					TextView tv2 = (TextView) row.findViewById(R.id.textView4);
					ImageView img = (ImageView)row.findViewById(R.id.imageView1);
					tv.setText(itemDesc[position]);
					tv1.setText(itemName[position]);
					tv2.setText(itemAddress[position]);
					if(AppData.taskDone[position]){
						img.setVisibility(ImageView.INVISIBLE);
						
					}
					else
						img.setVisibility(ImageView.VISIBLE);
					
					return row;
				}
				
			
				
			 }
	 
	 
	 
	 
}
