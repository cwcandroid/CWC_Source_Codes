package cwc.courier;

import java.util.ArrayList;
import java.util.HashMap;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;

/*
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * This class is for a Temporary Global Dataspace for application
 * TO DO:
 *     1.Planning on replacing this
 * 
 * Author: Sayeed Mahmud
 * Angry Coders 
 */

public class AppData {
	public static String user = "" ;
	public static ArrayList<Task> taskList = new ArrayList<Task>() ;
	public static ArrayList<Task> historyList = new ArrayList<Task>() ;
	
	public static String [] taskHeadline ;
	public static String [] taskName ;
	public static String [] taskAddress ;
	public static boolean [] taskDone ;
	public static double [] longitude ;
	public static double [] latitude ;
	public static GeoPoint []  geo ;
	public static OverlayItem [] overlay ;
	
	public static String [] historyHeadline ;
	public static String [] historyName ;
	public static String [] historyAddress ;
	
	public static Database db = null ;
	
	public static HashMap<Integer, String> reasonsValue = new HashMap<Integer, String>();
	public static HashMap<String, Integer> reasonsId =  new HashMap<String, Integer>() ;
	
	public static String currentFile = "" ;
	
	
}
