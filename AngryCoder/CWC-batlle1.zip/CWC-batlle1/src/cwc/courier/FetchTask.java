package cwc.courier;



/*
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * This class is a concrete subclass for Background task -- for fetching data
 * the request and its data are sent to a remote serever, so its a long time blocking
 * operation, so instead of just showing the pressed button look we can show status
 * and progress bar.
 * 
 *  Author: Sayeed Mahmud
 *  Angry Coders
 */

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Properties;

import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;

public class FetchTask extends BackgroundTask{
	/* params for getTaskList */
	String user = "" ;
	String duedate = "" ;
	
	/* constructor */
	public FetchTask(String user, String duedate, final Handler handler) {
		/* ohh we need to communicate with the UI thread */
		super(handler);
		/* what if the name contains spaces or ampersand ?? */
		this.user = URLEncoder.encode(user) ;
		this.duedate = duedate ;
	}
	
	/* 
	 * we implement the task  - abstarct method
	 * each subclass of BackgroundTask implements its own version of task 
	 */
	@Override
	public boolean task(){
		sendMessage("Fetching Task List .. ") ;
		//Log.e("Login Task", "Sent Logging in .. ") ;
		WebApiJson w = new WebApiJson() ;
		/* check network connection */
		/* check network connection */
    	
    	
		ArrayList<Properties> temp = w.getTaskList(user, duedate) ;
		//ArrayList<Properties> temp2 = w.getTaskHistory(user) ;
		
		int sz = temp.size();
		isSuccessful = (sz > 0) ;
		//Log.e("task()", this.isSuccessful + "") ;
		if (isSuccessful){
			sendMessage("Fetching Task ... Successful") ;
			sendMessage("Formatting Task List") ;
		//	Log.e("SZ", temp2.size() + "") ;
			Common.populateCache(sz, temp) ;
			/* putting data into application cache */
			
			//Log.e("Login Task", "Sent successful .. ") ;
		}else{
			sendMessage("Error") ;
			//Log.e("Login Task", "Sent Error .. ") ;
			//Error.lastError = "" ;
		}
		return isSuccessful ;
	}
	

}
