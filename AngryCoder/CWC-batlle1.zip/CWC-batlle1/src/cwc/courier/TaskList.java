package cwc.courier;



import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import courier.map.Map;
import cwc.courier.quickaction.ActionItem;
import cwc.courier.quickaction.QuickAction;


public class TaskList extends ListActivity {
	Button cmdRefresh ;
	int lstPos = 0 ;
	 @Override
	 public void onCreate(Bundle savedInstanceState) {
	  super.onCreate(savedInstanceState);
	  setContentView(R.layout.tab_one);
	  
	  
	  cmdRefresh =(Button)findViewById(R.id.taskRefresh) ;
	  cmdRefresh.setOnClickListener(new OnClickListener(){
		  public void onClick(View v){
			  Intent i = new Intent(TaskList.this, ProgressFetch.class) ;
			  startActivity(i) ;
			  finish() ;
		  }
	  }) ;
		//Add action item
      ActionItem addAction = new ActionItem();
		
		addAction.setTitle("Task Detail");
		

		//Accept action item
		ActionItem accAction = new ActionItem();
		
		accAction.setTitle("Show in Map");
		
		
		//Upload action item
		ActionItem upAction = new ActionItem();
		
		upAction.setTitle("Report");
		
		
		final QuickAction mQuickAction 	= new QuickAction(this);
		
		mQuickAction.addActionItem(addAction);
		mQuickAction.addActionItem(accAction);
		mQuickAction.addActionItem(upAction);
		
		//setup the action item click listener
		mQuickAction.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() {			
			
			public void onItemClick(int pos) {
				Intent i ;
				if (pos == 0) { //Add item selected

					i = new Intent(TaskList.this, InfoOfTask.class) ;
					  i.putExtra("NAME",AppData.taskName[lstPos]);
					  i.putExtra("ADDRESS",AppData.taskAddress[lstPos]);
					  i.putExtra("ID",AppData.taskList.get(lstPos).id);
					  i.putExtra("DESC",AppData.taskHeadline[lstPos]);
					  i.putExtra("INDEX",lstPos + "");
					  
					startActivity(i) ;
				} else if (pos == 1) { //Accept item selected
					i = new Intent(TaskList.this, Map.class) ;
					i.putExtra("ID", lstPos + "") ;
					startActivity(i) ;
				} else if (pos == 2) { //Upload item selected
					
					i = new Intent(TaskList.this, Report.class) ;
					i.putExtra("ID", lstPos + "") ;
					i.putExtra("TID", AppData.taskList.get(lstPos).id + "") ;
					startActivity(i) ;
					Toast.makeText(TaskList.this, "Upload items selected", Toast.LENGTH_SHORT).show();
				}	
			}
		});

	  
	  
	  
	  
	  /////// Customized list which is not working on Clicks
	  setListAdapter(new MyAdapter(
				 this, android.R.layout.simple_list_item_1,R.id.textView2, 
				 AppData.taskHeadline));
	  
	  ListView ls = getListView();


	  
	  ls.setOnItemClickListener(new AdapterView.OnItemClickListener() {
		    public void onItemClick(AdapterView<?> av, View v, int pos, long id) {
		    	lstPos = pos ;
		    	if (AppData.taskDone[pos])
		    		return ;
				mQuickAction.show(v);
				mQuickAction.setAnimStyle(QuickAction.ANIM_GROW_FROM_CENTER);
		    }
		});
	
	  
	  
	  
	 }
	 /////////// Customize ******List Class**** but not working on CLicks

		public class MyAdapter extends ArrayAdapter<String>{
				String [] itemName ;
				String [] itemAddress ;
				String [] itemDesc ;
				public MyAdapter(Context context,int resource,int textViewResourceId,
						String [] string) {
							super(context, resource, textViewResourceId, string);
							int sz = AppData.taskList.size() ;
							itemName = new String[sz] ;
							itemAddress = new String[sz] ;
							itemDesc = new String[sz] ;
							
							//itemName = new String[sz] ;
							//itemAddress = new String[sz] ;
							//itemDesc = new String[sz] ;
							
							itemName = AppData.taskName ;
							itemAddress = AppData.taskAddress ;
							itemDesc = AppData.taskHeadline ;
						
				}

				@Override
				public View getView(int position, View convertView, ViewGroup parent) {
					LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
					View row=inflater.inflate(R.layout.list_item, parent,false);
					
					TextView tv = (TextView) row.findViewById(R.id.textView2);
					TextView tv1 = (TextView) row.findViewById(R.id.textView3);
					TextView tv2 = (TextView) row.findViewById(R.id.textView4);
					ImageView img = (ImageView)row.findViewById(R.id.imageView1);
					tv.setText(itemDesc[position]);
					tv1.setText(itemName[position]);
					tv2.setText(itemAddress[position]);
					if(AppData.taskDone[position]){
						img.setVisibility(ImageView.VISIBLE);
						
					}
					else
						img.setVisibility(ImageView.INVISIBLE);
					
					return row;
				}
				
			
				
			 }
	 
	 
	 
	 
}
