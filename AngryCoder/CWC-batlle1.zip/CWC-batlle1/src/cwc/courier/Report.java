package cwc.courier;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Report extends Activity {
	private String array_spinner[];
	int index = 0, tid = 0 ; 
	int sPos = 0 ;
	Button cmdSign, cmdSubmit, home ;
	EditText txtDetails ;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.report);
	Intent ii = getIntent() ;
	index = Integer.parseInt(ii.getStringExtra("ID")) ;
	tid = Integer.parseInt(ii.getStringExtra("TID")) ;
	array_spinner=new String[5];
	for (int i = 0 ; i < 5 ; i++){
		array_spinner[i] = Common.getReasonById(i) ;
	}
	txtDetails = (EditText)findViewById(R.id.editText_detail_report) ;
	
	cmdSign = (Button)findViewById(R.id.button_take_sign) ;
	cmdSign.setOnClickListener(new OnClickListener(){
		public void onClick(View v){
			Intent i = new Intent(Report.this, CaptureSignature.class) ;
			startActivity(i) ;
		}
	}) ;
	home = (Button)findViewById(R.id.button1) ;
	home.setOnClickListener(new OnClickListener(){
		public void onClick(View v){
			Intent i = new Intent(Report.this, TabWidget.class) ;
			startActivity(i) ;
		}
	}) ;
	
	cmdSign.setVisibility(Button.INVISIBLE) ;
	
	cmdSubmit = (Button)findViewById(R.id.button_submit_report) ;
	cmdSubmit.setOnClickListener(new OnClickListener(){
		public void onClick(View v){
			WebApiJson w = new WebApiJson() ;
			Task tp = AppData.taskList.get(index) ;
			AppData.historyList.add(tp) ;
			
			int sz = AppData.historyList.size() ;
			AppData.historyAddress = new String[sz] ;
			AppData.historyHeadline = new String[sz] ;
			AppData.historyName = new String[sz] ;
			
			
			
			for (int i = 0 ; i < sz ; i++){
				AppData.historyAddress[i] = tp.address ;
				AppData.historyHeadline[i] = tp.description ;
				AppData.historyName[i] = tp.name ;
			}
			
			/*AppData.taskList.remove(index);
			sz = AppData.taskList.size() ;
			AppData.taskAddress = new String[sz] ;
			AppData.taskHeadline = new String[sz] ;
			AppData.taskName = new String[sz] ;
			for (int i = 0 ; i < sz ; i++){
			 tp = AppData.taskList.get(i);
				AppData.taskAddress[i] = tp.address ;
				AppData.taskHeadline[i] = tp.description ;
				AppData.taskName[i] = tp.name ;
			}*/
			
			boolean b = w.reportSpecificTask(AppData.user, tid + "", sPos + "", txtDetails.getText().toString(), tp.latitude, tp.longitude, AppData.currentFile) ;
			AppData.taskList.remove(index) ; //
			if (!b){
				Toast.makeText(Report.this, "Report Task Error", Toast.LENGTH_LONG).show();
			}else{
				AppData.taskDone[index] = true ;
				Toast.makeText(Report.this, "Successful", Toast.LENGTH_LONG).show() ;
				Intent i = new Intent(Report.this, TabWidget.class) ;
				startActivity(i) ;
				finish() ;
			}
		}
	}) ;
	Spinner s = (Spinner) findViewById(R.id.spinner1);
	ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, array_spinner);
	s.setAdapter(adapter);
	s.setOnItemSelectedListener(new OnItemSelectedListener() {
	   
	    public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int pos, long id) {
	        if (pos == 1){
	        	cmdSign.setVisibility(Button.VISIBLE) ;
	        }else{
	        	cmdSign.setVisibility(Button.INVISIBLE) ;
	        }
	        sPos = pos ;
	    }

	   
	    public void onNothingSelected(AdapterView<?> parentView) {
	        // your code here
	    }

	});

	}
	}