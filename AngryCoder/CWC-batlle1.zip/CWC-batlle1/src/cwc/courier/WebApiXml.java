package cwc.courier;

import java.util.ArrayList;
import java.util.Properties;

import android.util.Log;

public class WebApiXml extends WebApi{

	WebApiXml(){
		super.returnType = "returnType=xml" ;
	}
	@Override
	ArrayList<Properties> parse(String s) {
		ArrayList<Properties> temp = new ArrayList<Properties>() ;
		DomBasics db = new DomBasics(s) ;
		ArrayList<String>task = db.getInnerTextByTag("task") ;
		int sz = task.size() ;
		for (int i = 0 ; i < sz ; i++){
			Properties tp = new Properties() ;
			String ss = task.get(i) ;
			DomBasics db2 = new DomBasics(ss) ;
			ArrayList<String> ta = db2.getInnerTextByTag("id") ;
			Log.e("XML", ta.get(0)) ;
			tp.put("id", ta.get(0)) ;
			ta = db2.getInnerTextByTag("address") ;
			tp.put("address", ta.get(0)) ;
			Log.e("XML", ta.get(0)) ;
			ta = db2.getInnerTextByTag("comments") ;
			tp.put("comments", ta.get(0)) ;
			Log.e("XML", ta.get(0)) ;
			ta = db2.getInnerTextByTag("contactno") ;
			tp.put("contactno", ta.get(0)) ;
			Log.e("XML", ta.get(0)) ;
			ta = db2.getInnerTextByTag("description") ;
			tp.put("description", ta.get(0)) ;
			Log.e("XML", ta.get(0)) ;
			ta = db2.getInnerTextByTag("latitude") ;
			tp.put("latitude", ta.get(0)) ;
			Log.e("XML", ta.get(0)) ;
			ta = db2.getInnerTextByTag("longitude") ;
			tp.put("longitude", ta.get(0)) ;
			Log.e("XML", ta.get(0)) ;
			ta = db2.getInnerTextByTag("name") ;
			tp.put("name", ta.get(0)) ;
			Log.e("XML", ta.get(0)) ;
			ta = db2.getInnerTextByTag("status") ;
			tp.put("status", ta.get(0)) ;
			Log.e("XML", ta.get(0)) ;
			//ta = db2.getInnerTextByTag("time") ;
			//tp.put("time", ta.get(0)) ;
			//Log.e("XML", ta.get(0)) ;
			temp.add(tp) ;
		}
		
		// TODO Auto-generated method stub
		return temp;
	}
	
}
