package cwc.courier;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;



public class InfoOfTask extends Activity {
	TextView txtName ;  
	TextView txtId ;
	TextView txtDesc ;
	TextView txtAddr ;
	Button cmdPhone ;
	
	Integer index ;
	 public void onCreate(Bundle savedInstanceState) {
		  super.onCreate(savedInstanceState);
		  setContentView(R.layout.task_info);
		  Intent i = getIntent() ;
		  String name = i.getStringExtra("NAME") ;
		  String addr = i.getStringExtra("ADDRESS") ;
		  String id = i.getStringExtra("ID") ;
		  String desc = i.getStringExtra("DESC") ;
		  index = Integer.parseInt(i.getStringExtra("INDEX")) ;
		  
		  txtName = (TextView)findViewById(R.id.RecieverName) ;
		  txtId = (TextView)findViewById(R.id.ItemId) ;
		  txtDesc = (TextView)findViewById(R.id.ItemName) ;
		  txtAddr = (TextView)findViewById(R.id.RecieverAddress) ;
		 
		  txtName.setText("") ;
		  txtName.setText(name) ;
		  txtId.setText("") ;
		  txtId.setText(id) ;
		  txtAddr.setText("") ;
		  txtAddr.setText(addr) ;
		  txtDesc.setText("") ;
		  txtDesc.setText(desc) ;
		  
		  cmdPhone = (Button)findViewById(R.id.Phone_Number) ;
		  cmdPhone.setOnClickListener(new OnClickListener(){
			  public void onClick(View v){
				  Intent callIntent = new Intent(Intent.ACTION_CALL);
				  String phoneNr = AppData.taskList.get(index).contactno ;
       	       	  callIntent.setData(Uri.parse("tel:" + phoneNr));
       	          startActivityForResult(callIntent, 0);
			  }
		  }) ;
		  
		  
	 }
}
