package cwc.courier;

import java.util.ArrayList;
import java.util.Properties;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;

public class Common{
	
	public static boolean isNetworkAvailable(Context context) {
	    ConnectivityManager connectivityManager 
	          = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
	    return activeNetworkInfo != null;
		//return false ;
	}
	
	public static void populateDatabase(){
		
	}
	
	public void uploadOfflineSavedData(){
		Cursor c = AppData.db.rawQuery("SELECT FROM offline_data") ;
		if (c.getCount() > 0){
			c.moveToFirst() ;
			while (!c.isAfterLast()){

				String id = c.getString(0) ;
				String addr = c.getString(1) ;
				String comments = c.getString(2) ;
				String contact = c.getString(3) ;
				String desc = c.getString(4) ;
				String lat = c.getString(5) ;
				String lon = c.getString(6) ;
				String name = c.getString(7) ;
				String status = c.getString(8) ;
				//** TO DO -- report				
				c.moveToNext() ;
			}
		}
		if (!c.isClosed()) c.close() ;
	}
	public static void populateCache(int sz, ArrayList<Properties> temp){
		AppData.taskList = new ArrayList<Task>() ;
		AppData.taskHeadline = new String[sz] ;
		AppData.taskAddress = new String[sz] ;
		AppData.taskName =  new String [sz] ;
		AppData.longitude =  new double[sz] ;
		AppData.latitude =  new double[sz] ;
		AppData.geo = new GeoPoint[sz] ;
		AppData.overlay = new OverlayItem[sz] ;
		AppData.taskDone = new boolean[sz] ;
		
		for (int i = 0 ; i < sz ; i++){
			
			Task t = new Task() ;
			Properties tp = temp.get(i) ;
			t.address = tp.getProperty("address", "") ;
			t.comments = tp.getProperty("comments", "") ;
			t.contactno = tp.getProperty("contactno", "") ;
			t.description = tp.getProperty("description", "") ;
			t.id = tp.getProperty("task_id", "") ;
			t.latitude =tp.getProperty("latitude", "") ;
			t.longitude = tp.getProperty("longitude", "") ;
			t.name = tp.getProperty("name", "") ;
			t.status = tp.getProperty("status", "") ;
			Log.e("FetchTASK", t.description) ;
			AppData.taskList.add(t) ;
			Log.e("TIDDD", t.id) ;
			AppData.taskHeadline[i] = new String(t.description) ;
			AppData.taskAddress[i] = new String(t.address) ;
			AppData.taskName[i] = new String(t.name) ;
			AppData.longitude[i] = new Double(t.longitude) ;
			AppData.latitude[i] = new Double(t.latitude) ;
			//Log.e("LONG-LAT", AppData.latitude[i] + " " + AppData.longitude[i]) ;
			//Log.e("INT CAST", (int)(AppData.longitude[i] * 1E6) + " " + (int)(AppData.latitude[i] * 1E6));
 			AppData.geo[i] = new GeoPoint((int)(AppData.longitude[i] * 1E6), (int)(AppData.latitude[i] * 1E6));
 			AppData.overlay[i] = new OverlayItem(AppData.geo[i], new String(AppData.taskHeadline[i]), 
 			AppData.taskAddress[i]);
 			if (t.status.equals("1"))
 				AppData.taskDone[i]=true;
 			else
 				AppData.taskDone[i] = false ;
 			//Log.e("MAP ARRAY", AppData.geo[i] + " ") ;
			
		}
		/*
		AppData.historyList = new ArrayList<Task>() ;
		AppData.historyAddress = new String[sz2] ;
		AppData.historyHeadline = new String[sz2] ;
		AppData.historyName = new String[sz] ;
		for (int i = 0 ; i < sz2 ; i++){
			
			Task t = new Task() ;
			Properties tp = temp2.get(i) ;
			t.address = tp.getProperty("address", "") ;
			t.comments = tp.getProperty("comments", "") ;
			t.contactno = tp.getProperty("contactno", "") ;
			t.description = tp.getProperty("description", "") ;
			t.id = tp.getProperty("id", "") ;
			t.latitude =tp.getProperty("latitude", "") ;
			t.longitude = tp.getProperty("longitude", "") ;
			t.name = tp.getProperty("name", "") ;
			t.status = tp.getProperty("status", "") ;
			Log.e("FetchTASK", t.description) ;
			AppData.historyList.add(t) ;
			AppData.historyHeadline[i] = new String(t.description) ;
			AppData.historyAddress[i] = new String(t.address) ;
			AppData.historyName[i] = new String(t.name) ;
				
 			//AppData.taskDone[i]=false;
 			//Log.e("MAP ARRAY", AppData.geo[i] + " ") ;
			
		}*/
	}
	public static void populateCacheHistory(int sz, ArrayList<Properties> temp){
		AppData.historyList = new ArrayList<Task>() ;
		AppData.historyHeadline = new String[sz] ;
		AppData.historyAddress = new String[sz] ;
		AppData.historyName =  new String [sz] ;
		
		
		
		for (int i = 0 ; i < sz ; i++){
			
			Task t = new Task() ;
			Properties tp = temp.get(i) ;
			
			t.address = tp.getProperty("address", "") ;
			t.comments = tp.getProperty("comments", "") ;
			t.contactno = tp.getProperty("contactno", "") ;
			t.description = tp.getProperty("description", "") ;
			t.id = tp.getProperty("task_id", "") ;
			t.latitude =tp.getProperty("latitude", "") ;
			t.longitude = tp.getProperty("longitude", "") ;
			t.name = tp.getProperty("name", "") ;
			t.status = tp.getProperty("status", "") ;
			Log.e("FetchTASK", t.description) ;
			AppData.taskList.add(t) ;
			Log.e("TIDDD", t.id) ;
			AppData.historyHeadline[i] = new String(t.description) ;
			AppData.historyAddress[i] = new String(t.address) ;
			AppData.historyName[i] = new String(t.name) ;
			//AppData.longitude[i] = new Double(t.longitude) ;
			//AppData.latitude[i] = new Double(t.latitude) ;
			//Log.e("LONG-LAT", AppData.latitude[i] + " " + AppData.longitude[i]) ;
			//Log.e("INT CAST", (int)(AppData.longitude[i] * 1E6) + " " + (int)(AppData.latitude[i] * 1E6));
 			
 			//Log.e("MAP ARRAY", AppData.geo[i] + " ") ;
		}
	}
	
	/*
	 * Utility Method
	 * Get reason string by number
	 * for example 0 for "not delivered"
	 * Input - number
	 * Output - reason String
	 * 
	 * Caution: return null string on invalid param
	 */
	public static String getReasonById(int id){
		if (AppData.reasonsValue.containsKey(id))
			return new String(AppData.reasonsValue.get(id)) ;
		return "" ;
	}
	
	/*
	 * Utility Method
	 * Get reason number by reason string
	 * for example "not delivered" for 0
	 * Input - String
	 * Output - reason no
	 * 
	 * Caution: return -1 string on invalid param
	 */
	public static int getIdByReason(String reason){
		if (AppData.reasonsId.containsKey(reason))
			return AppData.reasonsId.get(reason) ;
		return -1 ;
	}
	
}
