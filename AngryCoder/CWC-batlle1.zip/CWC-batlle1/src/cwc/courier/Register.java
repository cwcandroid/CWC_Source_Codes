package cwc.courier;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends Activity {
	
	

	EditText RegName,RegEmail,RegPassword,RegRetypePass;
	Button RegBackLogin, cmdRegister;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
        
        RegName = (EditText) findViewById(R.id.RegnameEdit);
        RegPassword = (EditText) findViewById(R.id.RegPassword);
        RegEmail = (EditText) findViewById(R.id.RegEmail);
        RegRetypePass = (EditText) findViewById(R.id.RegRetypePass);
        
        RegBackLogin=(Button)findViewById(R.id.backtoLogin);
        cmdRegister=(Button)findViewById(R.id.register);
        
        
        RegBackLogin.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
              Intent intent = new Intent(Register.this,CourierActivity.class );
              startActivity(intent);
            }

          });
        
        cmdRegister.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
            	String user = RegName.getText().toString() ;
            	String pass = RegPassword.getText().toString() ;
            	String email = RegEmail.getText().toString() ;
            	String repass = RegRetypePass.getText().toString() ;
            	
            	/* check network connection */
            	boolean conn = Common.isNetworkAvailable(Register.this) ;
            	if (!conn){
            		Toast.makeText(Register.this, "Network Connection Not Available", Toast.LENGTH_LONG).show() ;
            		return ;
            		
            	}
            	/*
            	 * TO DO: validation for Email
            	 * If possible add a email control on screen
            	 */
            	if (user.equals("")){
            		Toast.makeText(Register.this, "Please Enter a User Name", Toast.LENGTH_LONG).show() ;
            		return ;
            	}
            	if (pass.equals("")){
            		Toast.makeText(Register.this, "Please Enter a Password", Toast.LENGTH_LONG).show() ;
            		return ;
            	}
            	if (email.equals("")){
            		Toast.makeText(Register.this, "Please Enter a valid Email", Toast.LENGTH_LONG).show() ;
            		return ;
            	}
            	if (!pass.equals(repass)){
            		Toast.makeText(Register.this, "Two Passwords Mismatch", Toast.LENGTH_LONG).show() ;
            		return ;	
            	}
                Intent i = new Intent(Register.this, ProgressRegister.class );
                i.putExtra("USER", user) ;
                i.putExtra("PASS", pass) ;
                i.putExtra("EMAIL", email) ;
                startActivity(i);
            }
          });
    }

}
