package cwc.courier;

/*
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * This class is a concrete subclass for Background task. When a users logs in
 * the request and its data are sent to a remote serever, so its a long time blocking
 * operation, so instead of just showing the pressed button look we can show status
 * and progress bar.
 * 
 *  Author: Sayeed Mahmud
 *  Angry Coders
 */

import java.net.URLEncoder;
import android.os.Handler;
import android.util.Log;

public class LoginTask extends BackgroundTask{
	/* params for logging in */
	String user = "" ;
	String pass = "" ;
	
	/* constructor */
	public LoginTask(String user, String pass, final Handler handler) {
		/* ohh we need to communicate with the UI thread */
		super(handler);
		/* what if the name contains spaces or ampersand ?? */
		this.user = URLEncoder.encode(user) ;
		this.pass = URLEncoder.encode(pass) ;
	}
	
	/* 
	 * we implement the task  - abstarct method
	 * each subclass of BackgroundTask implements its own ersion of task 
	 */
	@Override
	public boolean task(){
		sendMessage("Logging in .. ") ;
		//Log.e("Login Task", "Sent Logging in .. ") ;
		WebApiJson w = new WebApiJson() ;
		boolean b = w.login(user, pass) ;
		isSuccessful = b ;
		//Log.e("task()", this.isSuccessful + "") ;
		if (b){
			sendMessage("Login Successful") ;
			//Log.e("Login Task", "Sent successful .. ") ;
		}else{
			sendMessage("Error") ;
			//Log.e("Login Task", "Sent Error .. ") ;
			//Error.lastError = "" ;
		}
		return b ;
	}
	

}
