package cwc.courier;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Performance extends Activity {
	 @Override
	 public void onCreate(Bundle savedInstanceState) {
	  super.onCreate(savedInstanceState);
	  TextView tv = new TextView(this);
	  tv.setText("Performance of the client");
	  setContentView(tv);
	 }
	}
