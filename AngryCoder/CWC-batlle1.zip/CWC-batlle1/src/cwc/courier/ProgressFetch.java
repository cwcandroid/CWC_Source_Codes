package cwc.courier;



/*
 * 
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * The concrete class of Progress to handle
 * on screen messaging of Progress of API getTaskList
 * 
 * Author: Sayeed Mahmud
 * Angry Coders
 */ 
import java.sql.Date;
import java.text.SimpleDateFormat;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class ProgressFetch extends Progress{
	/* the task object */
	FetchTask f = null ;
	
	/* to refer to onCreate up to two levels of inheitence tree*/
	@Override
	public void onCreate(Bundle bOS){
		super.onCreate(bOS) ;
		/* this activity has occured means we have passed the authentication */
		
		String user = new String(AppData.user) ;
	    //SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy");
	    //Date now = new Date(System.currentTimeMillis());
	    //String strDate = sdfDate.format(now);
		String strDate = "28-01-2012";
		
		/* check network connection */
    	boolean conn = Common.isNetworkAvailable(this) ;
    	if (!conn){
    		Toast.makeText(this, "Network Connection Not Available", Toast.LENGTH_LONG).show() ;
    		Intent i = new Intent(ProgressFetch.this, CourierActivity.class);
            startActivity(i);
            /* we don't want to show interim progress bar if back was pressed */
            finish() ;
    	}
		
		/* initiate the task */
		f = new FetchTask(user, strDate, handler) ;
		/* perform it */
		f.doInBackground() ;
	}
	/*
	 * (non-Javadoc)
	 * @see cwc.courier.Progress#switchActivity()
	 * The switch  -- implementation of the abstract method
	 */
	@Override
	public void switchActivity(){
		Intent i ;
		if (f.isSuccessful)
			/* success -- go to app mai screen */
			i = new Intent(ProgressFetch.this, ProgressHistory.class);
		else
			/* no success -- go to log in screen */
			i = new Intent(ProgressFetch.this, CourierActivity.class);
        startActivity(i);
        /* we don't want to show interim progress bar if back was pressed */
        finish() ;
	}
}
