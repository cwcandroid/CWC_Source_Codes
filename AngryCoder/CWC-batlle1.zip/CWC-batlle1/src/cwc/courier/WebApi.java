package cwc.courier;

/*
 * 
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * A class for handling WebApis for the problem
 * Its an abstract base class which provides most of the methods
 * Its concrete subclasses implement the XML parsing and JSON parsing
 * 
 * FileName: WebApi.java
 * Author: Sayeed Mahmud
 * Angry Coders
 * 
 *   
 *   TO DO:
 *   1. make this a singleton pattern if necessary
 *  
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Properties;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.params.HttpParams;
import android.util.Log;


abstract class WebApi {
	/* the base url for all the web services */
	final String baseUrl = "http://192.168.1.2/cwc/index.php/android/" ;
	
	/* return type set explicitly by subclasses */
	String returnType = "returnType=json" ;
	
	/* the register API 
	 * Input : username, password and email
	 * Output: true if successful else false  
	 */
	public boolean register(String user, String pass, String email){
		String url = baseUrl+"register?username="+user+"&password="+pass+"&email="+email+"&" + returnType ;
		/* connecting and request - response */
		String response = getResponse(url) ;
		/* 
		 * all the response fields are stored in Properties data structure
		 * whether there is a single or multiple field
		 * Result - One method -- multiple usability
		 * parse is abstract method -- whether to parse JSON or XML
		 */
		ArrayList<Properties> res = parse(response) ;
		/* this particular method checks status of single entity elements */
		return checkSingleEntityStatus(res) ;	
	}
	
	/* 
	 * the login API 
	 * Input : username, password 
	 * Output: true if successful else false  
	 */
	public boolean login(String user, String pass){
		String url = baseUrl+"login?username="+user+"&password="+pass+"&"+returnType ;
		/* connecting and request - response */
		
		String response = getResponse(url) ;
		
		//String response = "{\"status\":\"true\"}";
		/* 
		 * all the response fields are stored in Properties data structure
		 * whether there is a single or multiple field
		 * Result - One method -- multiple usability
		 * parse is abstract method -- whether to parse JSON or XML
		 */
		ArrayList<Properties> res = parse(response) ;
		/* this particular method checks status of single entity elements */
		return checkSingleEntityStatus(res) ;
		
	}
	
	/* 
	 * the getTaskList API
	 * returns task list of a user 
	 * Input : username, duedate 
	 * Output: true if successful else false  
	 */
	public ArrayList<Properties>getTaskList(String user, String duedate){
		String url = baseUrl + "getTaskList?username="+user+"&duedate="+duedate+"&"+returnType ;
		
		/* connecting and request - response */
		String response = getResponse(url) ;
		//***** comment the next line out ****
		/*response = "[{\"address\":\"House: 154 Road: 22, Mohakhali DOHS, Dhaka\",\"comments\":\"Urgent\",\"contactno\":\"01718777777\",\"description\":\"One Samsung Galaxy Tab\",\"latitude\":\"23.78286\",\"longitude\":\"90.39544\",\"name\":\"Deliver Samsung Galaxy Tab\",\"status\":\"0\",\"id\":\"1\"}," +
		"{\"address\":\"House: 411 Road: 23, Mirpur Senpara\",\"comments\":\"De\",\"contactno\":\"01718777777\",\"description\":\"One Galaxy Nexus\",\"latitude\":\"27.78286\",\"longitude\":\"128.39544\",\"name\":\"Deliver Galaxy Nexus\",\"status\":\"0\",\"id\":\"1\"}," +
			"{\"address\":\"House: 152 Road: 23, 29, Kumartuli\",\"comments\":\"Deliver Slowly\",\"contactno\":\"01718676767\",\"description\":\"Cricket Bat\",\"latitude\":\"50.78286\",\"longitude\":\"98.39544\",\"name\":\"Cricket Bat for Sakib al Ahsan\",\"status\":\"0\",\"id\":\"1\"}," + 
			"{\"address\":\"House: 420 Road: 277, Dhanmondi 27\",\"comments\":\"6 Pakistani Flag\",\"contactno\":\"01718666666\",\"description\":\"Pakistani Flag for Motiur Rahman Nizmi\",\"latitude\":\"29.78286\",\"longitude\":\"90.39544\",\"name\":\"Motiur Rahman Nizmi\",\"status\":\"0\",\"id\":\"1\"}]";
	*/
		
		/* 
		 * all the response fields are stored in Properties data structure
		 * whetzher there is a single or multiple field
		 * Result - One method -- multiple usability
		 * parse is abstract method -- whether to parse JSON or XML
		 */
		ArrayList<Properties> temp = parse(response) ;
		/*
		 * TO DO: could turn it into Task class
		 */
		return temp ;
	}
	
	/* 
	 * the getTaskHistory API
	 * returns all tasks performed by a user 
	 * Input : username 
	 * Output: true if successful else false  
	 */
	public ArrayList<Properties>getTaskHistory(String user){
		String url = baseUrl + "getTaskHistory?username="+user+"&"+returnType ;
		/* connecting and request - response */
		String response = getResponse(url) ;
		/* 
		 * all the response fields are stored in Properties data structure
		 * whether there is a single or multiple field
		 * Result - One method -- multiple usability
		 * parse is abstract method -- whether to parse JSON or XML
		 */
		ArrayList<Properties> temp = parse(response) ;
		/*
		 * TO DO: could turn it into Task class
		 */
		return temp ;
	}
	
	/* 
	 * the reportSpecificTask API
	 * when a particular delivery is done
	 *  reprot to server
	 * Input : username 
	 * Output: true if successful else false
	 * 
	 */
	public boolean reportSpecificTask(String user, String taskId, String reasonType, String reasonDetails, String lat, String lon, String fileName){
		String url = baseUrl + "reportSpecificTask?username="+user+"&taskid="+ taskId+"&reasontype="+reasonType+"&reasondetails="+reasonDetails+"&reportlatitude="+lat+"&reportlongitude="+lon+"&signaturefile=" + fileName + "&" +returnType ;
		Log.e("REPORT SPEC TASK", url) ;
		String response = postFileMultipart(url, fileName, "signaturefile", "image/png") ;
		ArrayList<Properties> res = parse(response) ;
		//01-29 17:09:37.878: ERROR/REPORT SPEC TASK(3276): 
			//http://192.168.1.2/cwc/index.php/android/reportSpecificTask?username=SayeedMahmud&taskid=&reasontype=1&reasondetails=Delivered&reportlatitude=23.75768&reportlongitude=90.39184&signaturefile=asdasd.png&returnType=json

		return checkSingleEntityStatus(res) ;
	}
	
	/*
	 * Utlity methods
	 * Checks success or failure if only one entry matters
	 * Input: arraylist to Properties object
	 */
	private boolean checkSingleEntityStatus(ArrayList<Properties> res){
		/* if there are elements in ArrayList -- Just In Case */
		if (res.size() > 0){
			 String result = res.get(0).getProperty("status", "") ;
			 Log.e("CheckSingleEntity Status", result) ;
			 boolean ret = (result.equals("true") || result.equals("Success")) ? true : false ;
			 //********TO-DO: get a more catchy mechanism to handle error message
			 if (!ret){
				 /* if there was error setting last error flag in the global error space */
				 Properties tp = res.get(0) ;
				 if (tp.containsKey("text"))
					 Error.lastError = tp.getProperty("text", "") ;
				 else if (tp.containsKey("signaturefile"))
					 Error.lastError = tp.getProperty("signaturefile", "") ;
				 else
					 Error.lastError = "Unknown Error" ;
			 }
			 return ret ;
		}
		return false ;
	}
	
	/*
	 * Utility Method
	 * Performing Request-Response GET format in order to complete a API
	 * Input: Url
	 * Output: Response String containing JSON or XML
	 */
	private String getResponse(String url){
		String response = "" ;
		try{
			/* prepare request */
			HttpClient client = new DefaultHttpClient() ;
			HttpGet req = new HttpGet(url) ;
			/* execute to get response */
			HttpResponse res = client.execute(req) ;
			/* read response stream */
			response = readResponse(res) ;
		}catch(Exception e){
			Log.e(this.getClass().toString() + "Get Response", e.toString()) ;
			e.printStackTrace() ;
			return "" ;
		}
		return response ;
	}
	/*
	 * Utility Method
	 * Performing Request-Response POST format in order to complete a API
	 * Input: Url
	 * Output: Response String containing JSON or XML
	 */
	private String postResponse(String url){
		String response = "" ;
		try{
			/* prparing request */
			HttpClient client = new DefaultHttpClient() ;
			HttpPost req = new HttpPost(url) ;
			/* execute to get response */
			HttpResponse res = client.execute(req) ;
			/* read response stream */
			response = readResponse(res) ;
		}catch(Exception e){
			e.printStackTrace() ;
			return "" ;
		}
		return response ;
	}
	
	/* 
	 * the parse abstract method -- in the concrete subclasses we decide
	 * whether to parse XML or JSON 
	 */
	abstract ArrayList<Properties> parse(String s) ;
	
	/*
	 * Utility Method
	 * Performing Request-Response POST format Multipart in order to complete an API
	 * We don't need anything else in Multipart so we used this method for sending
	 * Multipart Image Signature
	 * Input: Url, fileName
	 * Output: Response String containg JSON or XML
	 * 
	 * Implementation Note: This method uses some external jars
	 * Just for the multipart purpose
	 */
	private String postFileMultipart(String url, String filePath, String field, String type) {
		String response = "" ;
		try {
			/* prepare HttpClient parameter */
			HttpParams params = new BasicHttpParams();
	        params.setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);
	        /* prepare request */
			DefaultHttpClient mHttpClient = new DefaultHttpClient(params);
            HttpPost httppost = new HttpPost(url);
            /* add Multipart entity */
            MultipartEntity multipartEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);  
            multipartEntity.addPart(field, new FileBody(new File("/data/data/cwc.courier/files/" + filePath), type));
            httppost.setEntity(multipartEntity);
            /* execute to get response */
            HttpResponse res = mHttpClient.execute(httppost) ;
            response = readResponse(res) ;
            Log.e("UPLOAD_RESPONSE", response) ;
        } catch (Exception e) {
            Log.e("UPLOAD", e.getLocalizedMessage(), e);
            return "" ;
        }
        return response ;
	}

	/*
	 * Utility Method
	 * Read Response Stream from a Http Response and return it as string
	 * Input: Response Object
	 * Output:Response String  
	 */
	private String readResponse(HttpResponse res){
		String response = "" ;
		try{
			BufferedReader rd = new BufferedReader(
			    new InputStreamReader(res.getEntity().getContent())) ;
			       
			String line = "" ;
			while ((line = rd.readLine()) != null)
			    response += line ;
		}catch (Exception e){
			e.printStackTrace() ;
			return "" ;
		}
		return response ;
	}
}

