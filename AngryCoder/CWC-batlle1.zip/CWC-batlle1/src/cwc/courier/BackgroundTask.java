package cwc.courier;

/* 
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * The class that handles all the background tasks 
 * like sending a request while not blocking or show status
 * in progressbars
 * 
 * this is an abstract class
 * Motivation: Our implementation of all background class has some common things
 * like messaging to UI thread by handler while 1 different thing: the task they perform
 * except for that all the tasks are pretty much common
 * so this class acts as a template for background tasks, while the concrere
 * subclasses are free to implement their own version of tasks.
 * 
 *   Author: Sayeed Mahmud
 *   Angry Coders
 */

import android.os.Handler;
import android.os.Message;
import android.util.Log;

abstract class BackgroundTask {
	/* flag for "a thread is done" */
	final String COMPLETE_FLAG = "DONE" ;
	Thread t = null ;
    boolean interrupted = false ;
    final Handler handler ;
    protected boolean isSuccessful = false ;
    
    /* constructor */
    public BackgroundTask(final Handler handler){
    	this.handler = handler ;
    }
    
    /*
     * Utility method 
     * Send Message to UI Thread
     * We pass messages to UI Thread as string
     * Input: String message
     * Output: none 
     */
    protected void sendMessage(String strMsg){
    	Message msg = new Message() ;
    	msg.obj = (Object)strMsg ;
    	handler.sendMessage(msg) ;
    }
    
    /* 
     * handle Backgound Task
     * that is it calls the concrete subclasses version of task()
     * Runtime Polymorphism, Late Binding whatever u call it. 
     */
    public void doInBackground(){
    	t = new Thread() {
    		public void run() {
                try{
                	isSuccessful = task() ;
                	//Log.e("Background task", isSuccessful + "") ;
                	sendMessage(COMPLETE_FLAG) ;
                } catch (Exception e) {
                	e.printStackTrace() ;
                }
                //if(!Thread.interrupted() && handler!= null){
                  //notify the user interface that the download is ready
                  //handler.sendMessage(msg);
                //}                                       
            }
         };
         t.start();
    }
	
    /*
     * This abstract method is to be overriden in the concrete subclasses
     * for instance login, register, getTaskList each will have their own 
     * task method
     */
    abstract public boolean task() ;
}
