package cwc.courier;




import courier.map.Map;
import android.os.Bundle;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TextView;


public class TabWidget extends TabActivity{
	
	TextView tab1= null,tab2 = null;
	int selectedColor = Color.argb(255, 255, 255, 255);
	int defaultColor  = Color.argb(255, 119, 119, 119);

	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tabhost);
       
        TabHost tabHost = getTabHost();  // The activity TabHost
        TabHost.TabSpec spec;  // Reusable TabSpec for each tab
        Intent intent;  // Reusable Intent for each tab
  
        // Tab 1
        intent = new Intent().setClass(this, TaskList.class);
        
        spec = tabHost.newTabSpec("tabOne");  
        
        spec.setContent(intent); 
        spec.setIndicator("Tasks"); 
        tab1 = new TextView(this);
        tab1.setGravity(android.view.Gravity.CENTER);
        tab1.setTextSize(18);
       
        tabHost.addTab(spec);
       
        tabHost.getTabWidget().getChildAt(0).getLayoutParams().height = 40;
      //  tabHost.getTabWidget().getChildAt(0).setBackgroundColor(Color.parseColor("#000000")); //unselected

        intent = new Intent().setClass(this, History.class);
        spec = tabHost.newTabSpec("tabTwo"); 
        spec.setContent(intent); 
        spec.setIndicator("History");
        tab2 = new TextView(this);
        tab2.setGravity(android.view.Gravity.CENTER);
        tab2.setTextSize(25);
        
        tabHost.addTab(spec);
        tabHost.getTabWidget().getChildAt(1).getLayoutParams().height = 40;
        
 
        
        
        
        // Do the same for the other tabs
        intent = new Intent().setClass(this, Performance.class);
        spec = tabHost.newTabSpec("tabThree"); 
        spec.setContent(intent); 
        spec.setIndicator("Performance");
        tab2 = new TextView(this);
        tab2.setGravity(android.view.Gravity.CENTER);
        tab2.setTextSize(25);
        
        tabHost.addTab(spec);
        tabHost.getTabWidget().getChildAt(2).getLayoutParams().height = 40;
      //  tabHost.getTabWidget().getChildAt(1).setBackgroundColor(Color.parseColor("#000000"));
        
        tabHost.setCurrentTab(0);
        
       

    }
	

}
