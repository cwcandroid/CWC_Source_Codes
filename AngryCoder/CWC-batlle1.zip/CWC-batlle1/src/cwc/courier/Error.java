package cwc.courier;

/*
 * @Copyright: Do not modify this header
 * Give due credit to author
 * 
 * This class is for a Global Dataspace for errors
 * Like in MSVC++ Winsock APIs WSAGetLastError()
 * 
 * Author: Sayeed Mahmud
 * Angry Coders 
 */
public class Error {
	public static String lastError = "" ;
	
}
