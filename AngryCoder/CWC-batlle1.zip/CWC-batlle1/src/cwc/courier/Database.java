package cwc.courier;

/*
 * File Name: Database.java
 * 
 * This is the Database class
 * Just an abstraction so that all class can access in a civilized manner
 * decided not to extend DatabaseHelper class, the simpler the faster and better
 * 
 * Author: Sayeed Mahmud
 */



import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.content.Context;
import java.util.Locale ;
import android.content.ContentValues;

public class Database {
	Context mContext ;
	/* Database object */
	SQLiteDatabase db ;
	
	/* query strings */
	private final String table = "CREATE TABLE IF NOT EXISTS offline_data(" + 
	                        "id TEXT PRIMARY KEY, " + 
	                        "address TEXT, " +
	                        "comments TEXT, " +
	                        "contactno TEXT, " +
	                        "description TEXT, " +
	                        "latitude TEXT, " +
	                        "longitude TEXT, " +
	                        "name TEXT" +
	                        "status TEXT" +
	                        ");" ;
	
	
	
    						 
	public Database(Context mContext){
		this.mContext = mContext ;
		/* open or create database */
		configure() ;
	}
	/* this method is responsible for opening an existing database
	 * or creating one,
	 * if the app is opened first time it will create the necessarry databases
	 * and tables
	 * else it will open them
	 * 
	 * this is possible mainly due to careful SQL statement usage
	 */
	private void configure(){
		db = mContext.openOrCreateDatabase("CourierClient.db", SQLiteDatabase.CREATE_IF_NECESSARY, null) ;
		db.setVersion(1) ;
		db.setLocale(Locale.getDefault()) ;
		db.setLockingEnabled(true) ;
		db.execSQL(table) ;
	}
	
	/* the database routines for query update insert or delete */
	public Cursor query(String table, String [] columns, String selection, String [] selectionArgs, String groupBy, String having, String orderBy){
		Cursor c = db.query(table, columns, selection, selectionArgs, groupBy, having, orderBy) ;
		return c ; 
	}
	public Cursor rawQuery(String query){
		Cursor c = db.rawQuery(query, null) ;
		return c ; 
	}
	public void update(String table, ContentValues values, String whereClause, String [] whereArgs){
		try{
			db.update(table, values, whereClause, whereArgs) ;
		}catch(Exception e){
			
		}
	}
	public void insert(String table, String nullColumnHack, ContentValues values){
		try{
			db.insertOrThrow(table, nullColumnHack, values) ;
		}catch(Exception e){
			Log.e("insert", e.toString()) ;
		}
	}
	public void delete(String table, String whereClause, String [] whereArgs){
		try{
			db.delete(table, whereClause, whereArgs) ;
		}catch(Exception e){
			
		}
		
	}
	public void close(){
		db.close() ;
	}
	
}
