package courier.map;

import android.content.Context;
import android.content.Intent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.maps.OverlayItem;


import cwc.courier.R;



public class BalloonOverlayView<Item extends OverlayItem> extends FrameLayout {

	private LinearLayout layout;
	private TextView title;
	private TextView desc;
	BalloonItemizedOverlay<Item> balloonIo;
	Item item;
	
	public BalloonOverlayView(final Context context, int balloonBottomOffset) {

		super(context);
		setPadding(10, 0, 10, balloonBottomOffset);
		layout = new LinearLayout(context);
		layout.setVisibility(VISIBLE);

		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = inflater.inflate(R.layout.balloon_overlay, layout);
		title = (TextView) v.findViewById(R.id.balloon_item_title);
		desc = (TextView) v.findViewById(R.id.balloon_item_snippet);

		final ImageView close = (ImageView) v.findViewById(R.id.close_img_button);
		close.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				layout.setVisibility(GONE);
			}
		});

		FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.gravity = Gravity.NO_GRAVITY;

		addView(layout, params);
		
		Button seeMorebutton = (Button)findViewById(R.id.see_more_button);
		seeMorebutton.setOnClickListener(new View.OnClickListener() {
			
		
			public void onClick(View v){
				String str = (String) title.getText();

				
			
				
				close.performClick();
			}
		});

	}
	public void setData(Item item) {
		
		layout.setVisibility(VISIBLE);
		if (item.getTitle() != null) {
			title.setVisibility(VISIBLE);
			title.setText(item.getTitle());
		} else {
			title.setVisibility(GONE);
		}
		if (item.getSnippet() != null) {
			desc.setVisibility(VISIBLE);
			desc.setText(item.getSnippet());
		} else {
			desc.setVisibility(GONE);
		}
		
	}

}
