package courier.map;



import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

import cwc.courier.AppData;
import cwc.courier.R;




public class Map extends MapActivity implements LocationListener{


	
	static int navigationLocationFlag=0;
	static int locateUserFlag=0;
	int notificationFlag=0;
	static LinearLayout layout;
	static LinearLayout layoutForUser;
	ImageView close2 =null,closeForuser=null;
	private NotificationManager nm;
	TextToSpeech tts;	
	private LocationManager locationManager;

	ArrayList<Double> myarrlistoflongitude = new ArrayList<Double>();
	ArrayList<Double> myarrlistoflatitude = new ArrayList<Double>();
	ArrayList<String> nameOfthePlace = new ArrayList<String>();
	EditText txted= null;
	MapController	mc = null;
	GeoPoint p= null;
	MapView mapView;
	List<Overlay> mapOverlays;
	Drawable drawable;
	Drawable drawable2;
	MyItemizedOverlay itemizedOverlay;
	MyItemizedOverlay itemizedOverlay2;
	double latitude = 23.51, longitude = 90.789;
	private double mlat;
	private double mlon;
	EditText address; 
	String[] Address;
	String[] applongitude;
	String[] applatiitude;
	String[] Autosrch;
	GeoPoint geopoint;
	OverlayItem[] overlay;
    
    public void onCreate(Bundle savedInstanceState) {
    	 super.onCreate(savedInstanceState);
         setContentView(R.layout.mapview);
         mapView = (MapView) findViewById(R.id.mapview);
 		mapView.setBuiltInZoomControls(true);
 		
 		mapOverlays = mapView.getOverlays();
 		 
		address = (EditText) findViewById(R.id.searchbox); 
	
		

 		// first overlay
 		drawable = getResources().getDrawable(R.drawable.marker);
 		itemizedOverlay = new MyItemizedOverlay(drawable, mapView);
 		Double lon,lat;


			int sz = AppData.geo.length ;
			Autosrch= new String[sz];
 			//geopoint = new GeoPoint[sz] ;
 			overlay = new OverlayItem[sz] ;
 			for (int i = 0 ; i < sz ; i++){
 				geopoint = new GeoPoint((int)(AppData.longitude[i] * 1E6), (int)(AppData.latitude[i] * 1E6));
 				
 				Autosrch[i]= AppData.taskAddress[i];
 				overlay[i] = new OverlayItem(geopoint, new String(AppData.taskName[i]), 
 				AppData.taskAddress[i]);				
 				
 				Log.e("Map longitude",geopoint.getLongitudeE6() +"");
 				Log.e("ovrlay Headline",AppData.taskHeadline[i] + "");

 				itemizedOverlay.addOverlay(overlay[i]);
 				
 				lat = AppData.latitude[i] ;
 				myarrlistoflatitude.add(lat);
 				lon = AppData.longitude[i] ;
 				myarrlistoflongitude.add(lon);
 				nameOfthePlace.add(AppData.taskAddress[i]);
 		 		
 			}
 		
 		

 
 			
 		//To locate the location of beautiful various place of Dhaka
 		
 	
 			//new
 			ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,Autosrch);
 			AutoCompleteTextView acTextView = (AutoCompleteTextView)findViewById(R.id.searchbox);
 			acTextView.setThreshold(1);
 			acTextView.setAdapter(adapter);
 			
 		/*
 			//geopoint = new GeoPoint[sz] ;
 			overlay = new OverlayItem[sz] ;
 			for (int i = 0 ; i < sz ; i++){
 				geopoint = new GeoPoint((int)(AppData.longitude[i] * 1E6), (int)(AppData.latitude[i] * 1E6));
 				
 				
 				overlay[i] = new OverlayItem(geopoint, new String(AppData.taskName[i]), 
 				"");				
 				
 				Log.e("Map longitude",geopoint.getLongitudeE6() +"");
 				Log.e("ovrlay Headline",AppData.taskHeadline[i] + "");

 				itemizedOverlay.addOverlay(overlay[i]);
 				
 				lat = AppData.latitude[i] ;
 				myarrlistoflatitude.add(lat);
 				lon = AppData.longitude[i] ;
 				myarrlistoflongitude.add(lon);
 				nameOfthePlace.add(AppData.taskAddress[i]);
 		 		
 			}
 	
 		
 			*/
 			/*
 			GeoPoint point13 = new GeoPoint((int)(23.71837 *1E6),(int)(90.3867*1E6));
 			OverlayItem overlayItem13 = new OverlayItem(point13, "Lalabagh Fort", 
 			"(Dhaka)");				
 			itemizedOverlay.addOverlay(overlayItem13);
 			lat = new Double(23.71837);
 			myarrlistoflatitude.add(lat);
 			lon = new Double(90.3867);
 			myarrlistoflongitude.add(lon);
 			nameOfthePlace.add("Lalabagh Fort ");
 			
 			GeoPoint point14 = new GeoPoint((int)(23.70861 *1E6),(int)(90.4061*1E6));
 			OverlayItem overlayItem14 = new OverlayItem(point14, "Ahsan manjil", 
 			"(Dhaka)");				
 			itemizedOverlay.addOverlay(overlayItem14);
 			lat = new Double(23.70861);
 			myarrlistoflatitude.add(lat);
 			lon = new Double(90.4061);
 			myarrlistoflongitude.add(lon);
 			nameOfthePlace.add("Ahsan manjil");
 			
 			GeoPoint point15 = new GeoPoint((int)(23.71289*1E6),(int)(90.40297*1E6));
 			OverlayItem overlayItem15 = new OverlayItem(point15, "Armenian Church", 
 			"(Dhaka)");				
 			itemizedOverlay.addOverlay(overlayItem15);
 			lat = new Double(23.71289);
 			myarrlistoflatitude.add(lat);
 			lon = new Double(90.40297);
 			myarrlistoflongitude.add(lon);
 			nameOfthePlace.add("Armenian Church");
 			
 			GeoPoint point16 = new GeoPoint((int)(23.71569 *1E6),(int)(90.4017*1E6));
 			OverlayItem overlayItem16 = new OverlayItem(point16, "Sitara Mosque", 
 			"(Dhaka)");				
 			itemizedOverlay.addOverlay(overlayItem16);
 			lat = new Double(23.71569);
 			myarrlistoflatitude.add(lat);
 			lon = new Double(90.4017);
 			myarrlistoflongitude.add(lon);
 			nameOfthePlace.add("Sitara Mosque");
 			
 			
 			
 		
 			

 		
 		*/
 		Log.e("MAP OL", itemizedOverlay.size() + "") ;
 		mapOverlays.add(itemizedOverlay);
 		
 		
 		
 		final MapController mc = mapView.getController();
 		mc.animateTo(geopoint);
 		mc.setZoom(14);
 		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
 		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10L, 1.0f, this);
   

 		Geocoder gc = new Geocoder(this); // create new geocoder instance
 		Button go = (Button) findViewById(R.id.gobutton);
 		//Onclicklistener for go button
 		go.setOnClickListener(new OnClickListener() {
 			public void onClick(View v) {
 				String addressInput = address.getText().toString(); // Get input text of the search text box
  				int index = nameOfthePlace.indexOf(addressInput);//get the index of the string input of the search text box
 				try {
 					if (index==-1) { // if no address found,
 						// display an error
 						Dialog locationError = new AlertDialog.Builder(Map.this).setIcon(0).setTitle("Error").setPositiveButton("Ok", null)
 							.setMessage("Sorry, your address doesn't exist in this list.").create();
 						locationError.show();
 						} else { // else display address on map
 							mlat = myarrlistoflatitude.get(index).doubleValue();
 							mlon = myarrlistoflongitude.get(index).doubleValue();
 			
 							navigateToLocation((mlat * 1E6), (mlon * 1E6),mapView);
 						}
 					} catch (Exception e){
 				}

 			}
 		});
 	
}
    
public  void navigateToLocation(double latitude, double longitude,MapView mv){	
	GeoPoint p = new GeoPoint((int) latitude, (int) longitude); // new
	// GeoPoint
	mv.displayZoomControls(true); 
	MapController mc = mv.getController();
	//start to show the map from the particular point p;
	mc.animateTo(p); 
	mc.setZoom(14);   
	if(close2!=null){
		close2.performClick();
	}
	if(closeForuser!=null)
		closeForuser.performClick();
	
	//for showing the layout which is shown when we tap any marker item on the map 
	layout = new LinearLayout(mv.getContext());
	layout.setVisibility(0);
	navigationLocationFlag=1;
	LayoutInflater inflater = (LayoutInflater) mv.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	View v = inflater.inflate(R.layout.clicktosee, layout);
	close2 = (ImageView) v.findViewById(R.id.close_img_button2);
	close2.setOnClickListener(new OnClickListener() {
		public void onClick(View v) {
			layout.setVisibility(8);
		}
	});
	MapView.LayoutParams pa1rams = new MapView.LayoutParams(
			LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, p,
			MapView.LayoutParams.BOTTOM_CENTER);
	pa1rams.mode = MapView.LayoutParams.MODE_MAP;
	mv.addView(layout, pa1rams);
}
	
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
	//shows user location
	public void onLocationChanged(Location location) {
		if (location != null) {
			double checkLat,checkLon;
			double lat = location.getLatitude();
			double lng = location.getLongitude();
			p = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));
			mc=mapView.getController();
			mc.animateTo(p);
			mc.setZoom(10);
			if(close2!=null){
				//Toast.makeText(this,"click", Toast.LENGTH_LONG).show();
				close2.performClick();
			}
			if(closeForuser!=null)
				closeForuser.performClick();
			layoutForUser = new LinearLayout(mapView.getContext());
			layoutForUser.setVisibility(0);
			locateUserFlag=1;
			LayoutInflater inflater2 = (LayoutInflater) mapView.getContext()
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View v = inflater2.inflate(R.layout.foruserlocation, layoutForUser);
		    closeForuser = (ImageView) v.findViewById(R.id.close_img_button_user);
		    closeForuser.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					layoutForUser.setVisibility(8);
					locateUserFlag=0;
				}
			});
			MapView.LayoutParams pa1rams = new MapView.LayoutParams(
					LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, p,
					MapView.LayoutParams.BOTTOM_CENTER);
			pa1rams.mode = MapView.LayoutParams.MODE_MAP;
			mapView.addView(layoutForUser, pa1rams);
	 		Location locationforcheck = new Location("L");
	 		for(int i=0;i<myarrlistoflatitude.size();i++){
	 			checkLat = myarrlistoflatitude.get(i).doubleValue();
	 			checkLon = myarrlistoflongitude.get(i).doubleValue();
	 			locationforcheck.setLatitude(checkLat);
	 			locationforcheck.setLongitude(checkLon);
	 			final String place = nameOfthePlace.get(i);
    			final float distance = location.distanceTo(locationforcheck);
    			
    			//give the notification to the user when he is close to any location
    			if(distance<500){
    		         tts = new TextToSpeech(Map.this, new OnInitListener() {
    					public void onInit(int status) {
    						if(status != TextToSpeech.ERROR){
    							tts.setLanguage(Locale.US);
    						}
    						String random = "Hello! You are very near to "+place;
    	    				tts.speak(random, TextToSpeech.QUEUE_FLUSH, null);
    					}
    				});    				
    		         if(notificationFlag==0){
    					nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    					notificationFlag=1;
    				}
    				else{
    					nm.cancel(R.string.notification_string);
    					nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    				}
    				shownotification(distance,place);
     			}
	 	      
	 		}
		}
		
	}
	private void shownotification(float distance,CharSequence text) {
        // In this sample, we'll use the same text for the ticker and the expanded notification

        // Set the icon, scrolling text and timestamp
        Notification notification = new Notification(R.drawable.icon, text,
                System.currentTimeMillis());

        // The PendingIntent to launch our activity if the user selects this notification
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(), 0);

        // Set the info for the views that show in the notification panel.
        notification.setLatestEventInfo(this, text,
                       distance+" meter away", contentIntent);
        // Send the notification.
        // We use a layout id because it is a unique number.  We use it later to cancel.
        nm.notify(R.string.notification_string, notification);
	}

	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}

	


}