/**
 * 
 */
package com.cwc.map;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;


import com.cwc.DAO.Task;
import com.cwc.courierclient.R;
import com.cwc.tasks.Info_activity;
import com.cwc.util.Shared_Preferences;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

/**
 * @author BABU
 * 
 */
public class ViewMapItem extends MapActivity {
	private MapView mapView;
	private MapController mapController;
	private GeoPoint geoPoint;
	private String[] description;
	private String[] address;
	private String[] taskid;
	private String[] taskname;
	private String[] taskphone;
	private String[] lat;
	private String[] lng;
	private Bundle bundle;

	protected void onCreate(Bundle icicle) {

		super.onCreate(icicle);
		setContentView(R.layout.viewonmap_layout);
		mapView = (MapView) findViewById(R.id.mapView);
		bundle = getIntent().getExtras();
		description = new String[bundle.getInt("size")];
		address = new String[bundle.getInt("size")];
		taskid = new String[bundle.getInt("size")];
		taskname = new String[bundle.getInt("size")];
		taskphone = new String[bundle.getInt("size")];
		lat = new String[bundle.getInt("size")];
		lng = new String[bundle.getInt("size")];
		description = bundle.getStringArray("itemnane");
		taskid = bundle.getStringArray("itemid");
		address = bundle.getStringArray("itemaddress");
		taskname = bundle.getStringArray("itemdelivername");
		taskphone = bundle.getStringArray("itemphone");
		lat = bundle.getStringArray("itemlat");
		lng = bundle.getStringArray("itemlng");

		LinearLayout zoomLayout = (LinearLayout) findViewById(R.id.zoom);
		View zoomView = mapView.getZoomControls();
		zoomLayout.addView(zoomView, new LinearLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		mapView.displayZoomControls(true);
		mapController = mapView.getController();
		mapView.setSatellite(true);
		// ArrayList<Task> list=getIntent().getParcelableArrayListExtra("BABU");
		double latd; 
		double lngd; 
		List<Overlay> mapOverlays = mapView.getOverlays();
		CwcmapitemItemizedOverlay cwcItemizedOverlay=null;
		OverlayItem overlayitem = null;
		for(int i=0;i<bundle.getInt("size");i++)
		{
			latd =Double.parseDouble(lat[i]);
			lngd = Double.parseDouble(lng[i]);
			Bitmap bmp = BitmapFactory.decodeResource(getResources(),
					R.drawable.bubble);
			//Bitmap bMapScaled = Bitmap.createScaledBitmap(bmp, 50, 50, true);
			Drawable drawable = new BitmapDrawable(bmp);
			cwcItemizedOverlay = new CwcmapitemItemizedOverlay(drawable,
					ViewMapItem.this);
			GeoPoint point = new GeoPoint((int) (latd), (int) (lngd));
			//mc.animateTo(point);
			//mc.setZoom(17);
			overlayitem = new OverlayItem(point, latd+"", null);
			cwcItemizedOverlay.addOverlay(overlayitem);
			mapOverlays.add(cwcItemizedOverlay);
		}
//		Bitmap bmp = BitmapFactory.decodeResource(getResources(),
//				R.drawable.pushpin);
//		Drawable drawable = new BitmapDrawable(bmp);
//		 cwcItemizedOverlay = new CwcmapitemItemizedOverlay(
//				drawable, ViewMapItem.this);
//
//		geoPoint = new GeoPoint((int) (lat), (int) (lng));
//		;
//		cwcItemizedOverlay.addOverlay(new OverlayItem(geoPoint, null, null));
//		mapOverlays.add(cwcItemizedOverlay);
//		mapView.invalidate();

	}

	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	// /////////////////
	public class CwcmapitemItemizedOverlay extends ItemizedOverlay<OverlayItem> {

		private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
		Context mContext;

		public CwcmapitemItemizedOverlay(Drawable defaultMarker, Context context) {
			super(boundCenterBottom(defaultMarker));
			mContext = context;
		}

		@Override
		protected OverlayItem createItem(int i) {
			return mOverlays.get(i);
		}

		@Override
		public int size() {
			// TODO Auto-generated method stub
			return mOverlays.size();
		}

		public void addOverlay(OverlayItem overlay) {
			mOverlays.add(overlay);
			populate();
		}

		@Override
		protected boolean onTap(int index) {
			OverlayItem item = mOverlays.get(index);
			AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
			dialog.setTitle("Are you want to See Detail?");
			dialog.setPositiveButton("Yes",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							Intent intent = new Intent(ViewMapItem.this,
									Info_activity.class);
							bundle.putInt("position", which);
							intent.putExtras(bundle);
							startActivity(intent);
						}
					});
			dialog.setNegativeButton("No",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {

						}
					});

			// dialog.setMessage("Dhaka");
			dialog.show();
			// / dialog.
			return true;
		}
	}

}
