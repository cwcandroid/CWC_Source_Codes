/**
 * 
 */
package com.cwc.map;

import java.util.List;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import com.cwc.courierclient.R;
import com.cwc.util.Shared_Preferences;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

/**
 * @author BABU
 * 
 */
public class Viewonmap extends MapActivity {
	private MapView mapView;
	private MapController mapController;
	private GeoPoint geoPoint;
	private Shared_Preferences preferences;

	protected void onCreate(Bundle icicle) {

		super.onCreate(icicle);
		setContentView(R.layout.viewonmap_layout);
		mapView = (MapView) findViewById(R.id.mapView);
		preferences = new Shared_Preferences(this);
		LinearLayout zoomLayout = (LinearLayout) findViewById(R.id.zoom);
		View zoomView = mapView.getZoomControls();
		zoomLayout.addView(zoomView, new LinearLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		mapView.displayZoomControls(true);
		mapController = mapView.getController();
		mapView.setSatellite(true);

		double lat = Double.parseDouble(preferences
				.Get_preferance("itemlatitude"));
		double lng = Double.parseDouble(preferences
				.Get_preferance("itemlongitude"));
		List<Overlay> mapOverlays = mapView.getOverlays();
		Bitmap bmp = BitmapFactory.decodeResource(getResources(),
				R.drawable.bubble);
		Drawable drawable = new BitmapDrawable(bmp);
		CwcItemizedOverlay cwcItemizedOverlay = new CwcItemizedOverlay(
				drawable, Viewonmap.this);
		geoPoint = new GeoPoint((int) (lat), (int) (lng));
		cwcItemizedOverlay.addOverlay(new OverlayItem(geoPoint, null, null));
		mapOverlays.add(cwcItemizedOverlay);
		mapView.invalidate();

	}

	protected boolean isRouteDisplayed() {
	
		return false;
	}

}
