package com.cwc.map;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.cwc.courierclient.R;
import com.cwc.tasks.Info_activity;
import com.cwc.tasks.Tasks_detail_activity;
import com.cwc.util.Shared_Preferences;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class mapitemsGoogleMaps extends MapActivity {
	MapView mapView;
	MapController mc;
	private String[] description;
	private String[] address;
	private String[] taskid;
	private String[] taskname;
	private String[] taskphone;
	private String[] lat;
	private String[] lng;
	private Bundle bundle;
	private Shared_Preferences preferences;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewonmap_layout);

		mapView = (MapView) findViewById(R.id.mapView);
		preferences=new Shared_Preferences(this);
		/////////////
		bundle = getIntent().getExtras();
		description = new String[bundle.getInt("size")];
		address = new String[bundle.getInt("size")];
		taskid = new String[bundle.getInt("size")];
		taskname = new String[bundle.getInt("size")];
		taskphone = new String[bundle.getInt("size")];
		lat = new String[bundle.getInt("size")];
		lng = new String[bundle.getInt("size")];
		description = bundle.getStringArray("itemnane");
		
		address = bundle.getStringArray("itemaddress");
		taskname = bundle.getStringArray("itemdelivername");
		taskphone = bundle.getStringArray("itemphone");
		lat = bundle.getStringArray("itemlat");
		lng = bundle.getStringArray("itemlng");
		double latd; 
		double lngd;
		///////////
		mapView.setBuiltInZoomControls(true);
		mc = mapView.getController();
		List<Overlay> mapOverlays = mapView.getOverlays();
		HelloItemizedOverlay itemizedoverlay = null;
		OverlayItem overlayitem = null;
		
		for(int i=0; i<bundle.getInt("size"); i++)
		{
			latd =Double.parseDouble(lat[i]);
			lngd = Double.parseDouble(lng[i]);
		Drawable drawable = this.getResources().getDrawable(R.drawable.bubble);
		 itemizedoverlay = new HelloItemizedOverlay(
				drawable,mapitemsGoogleMaps.this);

		GeoPoint point = new GeoPoint((int) (latd), (int) (lngd));
		mc.animateTo(point);
		mc.setZoom(17);
		 overlayitem = new OverlayItem(point, "Are you want to See Detail?",
				""+i);
		 itemizedoverlay.addOverlay(overlayitem);
		 mapOverlays.add(itemizedoverlay);
		 
		}
		

		
		
	}

	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}
	public class HelloItemizedOverlay extends ItemizedOverlay<OverlayItem> {

		private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
		Context mContext;

		public HelloItemizedOverlay(Drawable defaultMarker, Context context) {
			super(boundCenterBottom(defaultMarker));
			mContext = context;
		}

		@Override
		protected OverlayItem createItem(int i) {
			return mOverlays.get(i);
		}

		@Override
		public int size() {
			// TODO Auto-generated method stub
			return mOverlays.size();
		}

		public void addOverlay(OverlayItem overlay) {
			mOverlays.add(overlay);
			populate();
		}

		@Override
		protected boolean onTap(int index) {
			final OverlayItem item = mOverlays.get(index);

			AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
			dialog.setTitle(item.getTitle());
			//dialog.setMessage(item.getSnippet());
			dialog.setPositiveButton("Yes",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							Intent intent = new Intent(mapitemsGoogleMaps.this,
									Tasks_detail_activity.class);
							bundle.putInt("position", Integer.parseInt(item.getSnippet())-1);
							taskid = bundle.getStringArray("itemid");
							String id=taskid[Integer.parseInt(item.getSnippet())-1];
							preferences.Save_preference("taskIteid",id);
							intent.putExtras(bundle);
							startActivity(intent);
						}
					});
			dialog.setNegativeButton("No",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {

						}
					});
			dialog.show();

			return true;
		}
	}
}
