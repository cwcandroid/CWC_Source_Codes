/**
 * 
 */
package com.cwc.history;

import java.util.Locale;

import com.cwc.courierclient.R;
import com.cwc.util.Shared_Preferences;
import com.cwc.util.Status;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * @author BABU
 * 
 */
public class Histroy_info_activity extends Activity {
	private TextView itenmane, itenid, recivename, reciveaddress, deliveredon,
			status;
	private ImageView signature;
	private Button phone;
	private Shared_Preferences preferences;
	public static SQLiteDatabase callhistoryDB;
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.history_info_layout);
		preferences = new Shared_Preferences(this);
		///////
		callhistoryDB = this.openOrCreateDatabase("test.db",
				SQLiteDatabase.CREATE_IF_NECESSARY, null);
		callhistoryDB.setVersion(1);
		callhistoryDB.setLocale(Locale.getDefault());
		callhistoryDB.setLockingEnabled(true);
		callhistoryDB.execSQL("CREATE TABLE IF NOT EXISTS " + "calllist"
				+ " (number TEXT);");
		/////
		itenmane = (TextView) findViewById(R.id.itemnameTextView);
		itenid = (TextView) findViewById(R.id.itemidTextView);
		recivename = (TextView) findViewById(R.id.receivernameTextView);
		reciveaddress = (TextView) findViewById(R.id.reciveaddressTextView);
		deliveredon = (TextView) findViewById(R.id.deliveredonTextView);
		status = (TextView) findViewById(R.id.statusTextView);
		phone = (Button) findViewById(R.id.callButton);
		signature = (ImageView) findViewById(R.id.signatureImageView);

		
		preferences.Get_preferance("Iteid");
		itenmane.setText(preferences.Get_preferance("Itemname"));
		itenid.setText(preferences.Get_preferance("Itemsignature"));
		recivename.setText(preferences.Get_preferance("Recivename"));
		reciveaddress.setText(preferences.Get_preferance("Reciveadress"));
		deliveredon.setText(preferences.Get_preferance("Deliveredon"));
		status.setText(new Status().Get_status(preferences.Get_preferance("Itemstatus")));
		phone.setText(preferences.Get_preferance("Recivephone"));
		phone.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				String phonenumber = phone.getText().toString();
				callhistoryDB.execSQL("INSERT INTO " + "calllist" + " Values ('"
						+ phonenumber + "');");
				Intent callIntent = new Intent(Intent.ACTION_CALL, Uri
						.parse("tel:" + phone.getText().toString().trim()));
				startActivity(callIntent);
			}
		});

	}
}
