package com.cwc.history;

import com.cwc.courierclient.R;
import com.cwc.courierclient.R.layout;
import com.cwc.map.Viewonmap;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;

public class History_detail_activity extends TabActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detail_history_layout);
		TabHost tabHost = getTabHost();
		TabHost.TabSpec tabSpec;
		Intent intent;

		intent = new Intent().setClass(this, Histroy_info_activity.class);
		tabSpec = tabHost.newTabSpec("info").setIndicator("History Info", null)
				.setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, Viewonmap.class);
		tabSpec = tabHost.newTabSpec("viewonmap").setIndicator("View On Map",
				null).setContent(intent);
		tabHost.addTab(tabSpec);
	}
}
