package com.cwc.history;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cwc.DAO.Task;
import com.cwc.DAO.TaskHistory;
import com.cwc.courierclient.R;
import com.cwc.courierclient.R.id;
import com.cwc.courierclient.R.layout;
import com.cwc.jsonurl.Jesonurl;
import com.cwc.util.HttpRetriever;
import com.cwc.util.List_view_ArrayAdapter;
import com.cwc.util.Shared_Preferences;
import com.cwc.util.ShowAlertDialog;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class HistoryActivity extends Activity {
	private ListView listView;
	private ProgressDialog progressDialog;
	private String response;
	private HttpRetriever dataretriever = new HttpRetriever();
	private Shared_Preferences preferences;
	private Button sorteddate;
	final static int DATE=0;
	private int year,monthOfYear,dayOfMonth;
	private int daycheck,yearcheck, monthcheck;
	private Button sortbutton;
	private boolean flag=true;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history);
		listView = (ListView) findViewById(R.id.historyListView);
		sorteddate=(Button)findViewById(R.id.dateButton);
		sortbutton=(Button)findViewById(R.id.sortButton);
		sorteddate.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				showDialog(DATE);
				
			}
		});
		preferences = new Shared_Preferences(this);
		progressDialog = ProgressDialog.show(HistoryActivity.this, "",
				"Information Loading...", true, false);
		new Thread() {
			public void run() {
				try {
					response = dataretriever.retrieve(new Jesonurl()
							.GettaskHistoryUrl(preferences.Get_preferance("Cwcusername")));
				} catch (Exception ex) {
					ex.printStackTrace();
					handler.sendEmptyMessage(0);
				}
				handler.sendEmptyMessage(0);
			}
		}.start();

	}
	
    protected Dialog onCreateDialog(int id) {
    	// TODO Auto-generated method stub
    	if(id==DATE)
    	{
    		dateset listnerdate=new dateset();
    		Calendar calender=Calendar.getInstance();
    		 year=calender.get(Calendar.YEAR);
    		monthOfYear=calender.get(Calendar.MONTH);
    	 dayOfMonth=calender.get(Calendar.DAY_OF_MONTH);
    		return new DatePickerDialog(this, listnerdate, year, monthOfYear, dayOfMonth);
    	}
    	return null;
    }
    class dateset implements DatePickerDialog.OnDateSetListener{

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) {
			
			daycheck=dayOfMonth;
			yearcheck=year;
			monthcheck=dayOfMonth;
			String sday = dayOfMonth + "";
			String smonth = (monthOfYear+1) + "";
			String syear = year + "";
			if (sday.length() == 1) {
				sday = "0" + sday;
			}
			int a = smonth.length();
			if (smonth.length() == 1) {
				smonth = "0" + smonth;
			}
    	sorteddate.setText(sday + "-" + smonth + "-" + syear);
			
		}
    }
	
	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			progressDialog.dismiss();
			if (response != null) {
				JSONArray jsonArray;
				final ArrayList<Task> tasks = new ArrayList<Task>();
				try {
					jsonArray = new JSONArray(response);
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject jsonObject = jsonArray.getJSONObject(i);
						TaskHistory taskHistory = new TaskHistory(jsonObject
								.getString("reasontype"), jsonObject
								.getString("reasondetails"), jsonObject
								.getString("reportlatitude"), jsonObject
								.getString("reportlongitude"), jsonObject
								.getString("signaturefile"), jsonObject
								.getString("duedate"));
						Task task = new Task("", jsonObject.getString("name"),
								jsonObject.getString("address"), jsonObject
										.getString("comments"), jsonObject
										.getString("contactno"), jsonObject
										.getString("description"), jsonObject
										.getString("latitude"), jsonObject
										.getString("longitude"), jsonObject
										.getString("status"), taskHistory);
						tasks.add(task);
					}
					final String[] description = new String[tasks.size()];
					String[] address = new String[tasks.size()];
					int i = 0;
					for (Task task : tasks) {
						description[i] = task.getDescription();
						i++;
					}
                    sortbutton.setOnClickListener(new View.OnClickListener() {
						
						@Override
						public void onClick(View v) {
							int j=0;
							String[] descriptionofdate = new String[tasks.size()];
						for (Task task : tasks) {
							if(sorteddate.getText().toString().equals(task.getTaskHistory().getDuedate()))
							{
								descriptionofdate[j] = task.getDescription();
								j++;
							}
						}
						String[] sortlist=new String[j];
						for(int k=0 ; k<j; k++)
						{
							sortlist[k]=descriptionofdate[k];
						}
						flag=false;
						List_view_ArrayAdapter listViewArrayAdapter = new List_view_ArrayAdapter(
								getApplicationContext(), sortlist);
						listView.setAdapter(listViewArrayAdapter);
						listView.setTextFilterEnabled(true);
						}
					});
                   if(flag)
                   {
					List_view_ArrayAdapter listViewArrayAdapter = new List_view_ArrayAdapter(
							getApplicationContext(), description);
					listView.setAdapter(listViewArrayAdapter);
					listView.setTextFilterEnabled(true);
                   }
					listView.setOnItemClickListener(new OnItemClickListener() {

						@Override
						public void onItemClick(AdapterView<?> parent, View view,
								int position, long id) {
							preferences.Save_preference("Itemname", tasks.get(position).getDescription());
							preferences.Save_preference("Iteid", tasks.get(position).getId());
							preferences.Save_preference("Recivename", tasks.get(position).getDelivername());
							preferences.Save_preference("Reciveadress", tasks.get(position).getAddress());
							preferences.Save_preference("Recivephone", tasks.get(position).getContactno());
							preferences.Save_preference("Deliveredon", tasks.get(position).getTaskHistory().getDuedate());
							preferences.Save_preference("Itemstatus", tasks.get(position).getStatus());
							preferences.Save_preference("Itemsignature", tasks.get(position).getTaskHistory().getSignaturefile());
							preferences.Save_preference("itemlatitude", tasks.get(position).getLatitude());
							preferences.Save_preference("itemlongitude", tasks.get(position).getLongitude());
							Intent detail_history_task= new Intent(HistoryActivity.this,History_detail_activity.class);
							detail_history_task.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(detail_history_task);
							
						}
					});
				} catch (JSONException e) {
					e.printStackTrace();
				}
			} else {
				new ShowAlertDialog(HistoryActivity.this, "Erro",
						"Problem to fetch data from server");
			}

		};
	};
}
