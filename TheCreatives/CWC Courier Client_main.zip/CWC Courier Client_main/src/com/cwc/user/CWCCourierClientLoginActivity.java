package com.cwc.user;

import org.json.JSONException;
import org.json.JSONObject;

import com.cwc.courierclient.CWCCourierClientMainScreenActivity;
import com.cwc.courierclient.R;
import com.cwc.courierclient.R.id;
import com.cwc.courierclient.R.layout;
import com.cwc.jsonurl.Jesonurl;
import com.cwc.util.HttpRetriever;
import com.cwc.util.Shared_Preferences;
import com.cwc.util.ShowAlertDialog;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class CWCCourierClientLoginActivity extends Activity {
	private Button btnLogin, btnRegister;
	private EditText username, userpassword;
	private HttpRetriever dataretriever = new HttpRetriever();
	private ProgressDialog progressDialog;
	private String response;
	private Shared_Preferences preferences;
	private CheckBox rememberme;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		btnLogin = (Button) findViewById(R.id.loginButton);
		btnRegister = (Button) findViewById(R.id.registerButton);
		username = (EditText) findViewById(R.id.usernameEditText);
		userpassword = (EditText) findViewById(R.id.passwordEditText);
		rememberme = (CheckBox) findViewById(R.id.rememberCheckBox);
		preferences = new Shared_Preferences(this);

		if (!preferences.Get_preferance("Cwcusername").equals("")
				&& !preferences.Get_preferance("Cwcpassword").equals("")) {
			Intent Go_Tabhost_activity = new Intent(
					CWCCourierClientLoginActivity.this,
					CWCCourierClientMainScreenActivity.class);
			Go_Tabhost_activity.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(Go_Tabhost_activity);
		}

		btnLogin.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				progressDialog = ProgressDialog.show(
						CWCCourierClientLoginActivity.this, "",
						"Information Loading...", true, false);
				new Thread() {
					public void run() {
						try {
							response = dataretriever.retrieve(new Jesonurl()
									.Getloginurl(username.getText().toString(),
											userpassword.getText().toString()));
						} catch (Exception ex) {
							ex.printStackTrace();
							handler.sendEmptyMessage(0);
						}
						handler.sendEmptyMessage(0);
					}
				}.start();

			}
		});

		btnRegister.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent i = new Intent(CWCCourierClientLoginActivity.this,
						CWCCourierClientRegistrationActivity.class);
				startActivity(i);
			}
		});
	}

	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			progressDialog.dismiss();

			if (response != null) {
				try {
					JSONObject jObject = new JSONObject(response);
					String Ressult = jObject.getString("status");

					if (Ressult.equals("true")) {
						
						if (rememberme.isChecked()) {
							preferences.Save_preference("Cwcusername", username.getText()
									.toString());
							preferences.Save_preference("Cwcpassword", userpassword
									.getText().toString());
						} else {

							preferences.Save_preference("Cwcusername", username.getText()
									.toString());
						}

						Intent Go_Tabhost_activity = new Intent(
								CWCCourierClientLoginActivity.this,
								CWCCourierClientMainScreenActivity.class);
						Go_Tabhost_activity
								.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(Go_Tabhost_activity);
					} else {
						new ShowAlertDialog(CWCCourierClientLoginActivity.this,
								"Input Erro", "Username and Password Wrong");

					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			} else {
				new ShowAlertDialog(CWCCourierClientLoginActivity.this, "Erro",
						"Problem to fetch data from server");

			}
		};
	};
}