/**
 * 
 */
package com.cwc.user;

import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.app.ListActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;

/**
 * @author BABU
 * 
 */
public class CallHistory extends ListActivity {

	ArrayList<String> searchResult;
	SQLiteDatabase callhistoryDB;
	ArrayAdapter<String> adapter;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		searchResult = new ArrayList<String>();
	
		callhistoryDB = this.openOrCreateDatabase("test.db",
				SQLiteDatabase.CREATE_IF_NECESSARY, null);
		callhistoryDB.setVersion(1);
		callhistoryDB.setLocale(Locale.getDefault());
		callhistoryDB.setLockingEnabled(true);
		callhistoryDB.execSQL("CREATE TABLE IF NOT EXISTS " + "calllist"
				+ " (number TEXT);");
	
		Cursor c = callhistoryDB.rawQuery("SELECT * FROM calllist", null);
		if (c != null) {
			if (c.moveToFirst()) {
				do {
					String callnumber = c.getString(c.getColumnIndex("number"));

					searchResult.add(callnumber);
				} while (c.moveToNext());
			}
		}
		
		/////
		this.setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,searchResult));
	}

}
