package com.cwc.user;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import com.cwc.courierclient.R;
import com.cwc.courierclient.R.id;
import com.cwc.courierclient.R.layout;
import com.cwc.jsonurl.Jesonurl;
import com.cwc.util.HttpRetriever;
import com.cwc.util.ShowAlertDialog;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CWCCourierClientRegistrationActivity extends Activity {
	private Button btnLogin, btnSubmit;
	private EditText username, email, password, repassword;
	private String emailtext;
	private boolean EmailmatchFound;
	private HttpRetriever dataretriever = new HttpRetriever();
	private String response;
	private ProgressDialog progressDialog;
	private String s_username;
	private String s_email;
	private String s_password;
	private String s_repassword;

	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		username = (EditText) findViewById(R.id.userNameEditText);
		email = (EditText) findViewById(R.id.emaileditText);
		password = (EditText) findViewById(R.id.passwordEditText);
		repassword = (EditText) findViewById(R.id.confirmpasswordEditText);
		btnLogin = (Button) findViewById(R.id.registrationloginButton);
		btnSubmit = (Button) findViewById(R.id.submiteButton);

		btnLogin.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent i = new Intent(
						CWCCourierClientRegistrationActivity.this,
						CWCCourierClientLoginActivity.class);
				startActivity(i);
			}
		});

		btnSubmit.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				s_username = username.getText().toString().trim();
				s_password = password.getText().toString();
				s_repassword = repassword.getText().toString();
				s_email = email.getText().toString().trim();

				if (s_username.equals("") && s_email.equals("")
						&& s_password.equals("") && s_repassword.equals("")) {
					new ShowAlertDialog(
							CWCCourierClientRegistrationActivity.this,
							"Input Erro", "Some Input fild are Empty");
				} else {
					// emailtext = email.getText().toString().trim();
					Pattern formEmailPattern = Pattern
							.compile(".+@.+\\.[a-z]+");
					Matcher FormEmailMatch = formEmailPattern.matcher(s_email);
					EmailmatchFound = FormEmailMatch.matches();

					if (!EmailmatchFound) {
						new ShowAlertDialog(
								CWCCourierClientRegistrationActivity.this,
								"Email Format Erro", "user@domain.com");

					} else {
						if (s_password.equals(s_repassword)) {
							progressDialog = ProgressDialog.show(
									CWCCourierClientRegistrationActivity.this,
									"", "Information Saving...", true, false);
							new Thread() {
								public void run() {
									try {
										response = dataretriever
												.retrieve(new Jesonurl()
														.Getregistrationurl(
																s_username,
																s_password,
																s_email));
									} catch (Exception ex) {
										ex.printStackTrace();
										handler.sendEmptyMessage(0);
									}
									handler.sendEmptyMessage(0);
								}
							}.start();

						} else {
							new ShowAlertDialog(
									CWCCourierClientRegistrationActivity.this,
									"Erro", "Password not match");
							password.setText("");
							repassword.setText("");
						}
					}
				}
				// ///////////
			}
		});

	}

	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			progressDialog.dismiss();
			if (response != null) {
				JSONObject jObject;
				try {
					jObject = new JSONObject(response);
					String Ressult = jObject.getString("status");
					if (Ressult.equals("Success")) {
						Intent i = new Intent(
								CWCCourierClientRegistrationActivity.this,
								CWCCourierClientLoginActivity.class);
						startActivity(i);
					} else {
						new ShowAlertDialog(
								CWCCourierClientRegistrationActivity.this,
								"Erro", "User Name must be Unique, Try again");
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}

			} else {
				new ShowAlertDialog(CWCCourierClientRegistrationActivity.this,
						"Erro", "Problem to fetch data from server");
			}
		};
	};

}
