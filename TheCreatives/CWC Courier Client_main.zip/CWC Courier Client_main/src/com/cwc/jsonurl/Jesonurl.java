/**
 * 
 */
package com.cwc.jsonurl;

import android.provider.MediaStore.Images;
import android.widget.ImageView;

/**
 * @author Babu
 */
public class Jesonurl {
	private String url = "http://192.168.1.2/cwc/index.php/android/";

	public String Getloginurl(String username, String password) {
		return url + "login?username=" + username + "&password=" + password
				+ "&returnType=json";
	}

	public String Getregistrationurl(String username, String password,
			String email) {
		return url + "register?username=" + username + "&password=" + password
				+ "&returnType=json&email=" + email;
	}

	public String GettaskHistoryUrl(String username) {
		return url + "getTaskHistory?username=" + username + "&returnType=json";
	}

	public String Get_tasksurl(String username, String date)
	{
		return url+"getTaskList?username="+username+"&returnType=json&duedate="+date;
	}
	
	public String Get_reporttaskurl(String username,String taskid,String reasontype,String reasondetail,double lat,double lng, ImageView signatureimage)
	{
		return url+"reportSpecificTask?username="+username+"&returnType=json&taskid="+taskid+"&reasontype="+reasontype+"&reasondetails="+reasondetail+"&reportlatitude="+lat+"&reportlongitude="+lng+"&signaturefile="+signatureimage;
	}
}
