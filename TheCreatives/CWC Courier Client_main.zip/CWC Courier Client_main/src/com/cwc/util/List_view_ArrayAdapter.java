/**
 * 
 */
package com.cwc.util;

/**
 * @author BABU
 *
 */
import com.cwc.courierclient.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * 
 */

/**
 * @author BABU
 * 
 */
public class List_view_ArrayAdapter extends ArrayAdapter<String> {
	private Context context;
	private String[] values;

	public List_view_ArrayAdapter(Context context, String[] values) {
		super(context, R.layout.list_view_layout, values);
		this.context = context;
		this.values = values;

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View rowView = inflater.inflate(R.layout.list_view_layout, parent,
				false);
		TextView textView = (TextView) rowView.findViewById(R.id.listTextview);
		ImageView tasksimageView = (ImageView) rowView
				.findViewById(R.id.tasksstatusImageView);
		ImageView moreimageView = (ImageView) rowView
				.findViewById(R.id.moreImageView);
		textView.setText(values[position]);
		// imageView.setImageResource(imageid[position]);
		return rowView;
	}

}
