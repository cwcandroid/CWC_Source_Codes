/**
 * 
 */
package com.cwc.util;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

/**
 * @author BABU
 * 
 */
public class ShowAlertDialog extends AlertDialog {

	public ShowAlertDialog(Context context, String title, String message) {
		super(context);
		AlertDialog.Builder adb = new AlertDialog.Builder(context);
		adb.setTitle(title);
		adb.setMessage(message);
		adb.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {

				dialog.cancel();
			}
		});
		adb.show();
	}
}
