/**
 * 
 */
package com.cwc.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 ***Author*** Md abdul Gafur. Khulna University. 
 */

public class ConnectivityManagers {
	private ConnectivityManager connectivity;
	private NetworkInfo netInfo;
	private Context context;

	public ConnectivityManagers(Context context) {

		this.context = context;
	}

	public boolean GetNetworInformation() {
		connectivity = (ConnectivityManager) context
				.getSystemService(context.CONNECTIVITY_SERVICE);
		netInfo = connectivity.getActiveNetworkInfo();

		if (netInfo != null) {
			return true;

		} else {
			return false;
		}

	}

	public boolean TestConectionIsValid() {
		if (netInfo.isConnected()) {
			return true;
		} else {
			return false;
		}
	}
}
