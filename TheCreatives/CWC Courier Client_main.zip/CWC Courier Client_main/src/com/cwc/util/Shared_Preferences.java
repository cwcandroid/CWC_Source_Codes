/**
 * 
 */
package com.cwc.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * @author BABU
 * 
 */
public class Shared_Preferences {
	private Context context;
	private SharedPreferences preferences;

	public Shared_Preferences(Context context) {
		this.context = context;
		preferences = PreferenceManager.getDefaultSharedPreferences(context);
	}

	public boolean Save_preference(String key, String value) {
		SharedPreferences.Editor editor = preferences.edit();
		editor.putString(key, value);
		editor.commit();
		return true;
	}

	public String Get_preferance(String key) {

		return preferences.getString(key, "");
	}
}
