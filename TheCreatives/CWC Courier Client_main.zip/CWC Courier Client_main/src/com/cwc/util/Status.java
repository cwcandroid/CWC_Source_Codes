/**
 * 
 */
package com.cwc.util;

/**
 * @author BABU
 * 
 */
public class Status {
	private String status;

	public String Get_status(String status) {
		if (status.equals("0")) {
			status = "Not delivered";
		}

		if (status.equals("1")) {
			status = "Delivered";
		}
		if (status.equals("")) {
			status = "Address Not found";
		}
		if (status.equals("")) {
			status = "No One available";
		}
		return status;

	}
}
