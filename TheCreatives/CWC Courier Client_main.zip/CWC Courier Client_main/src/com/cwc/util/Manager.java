package com.cwc.util;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;

public class Manager {
	private Context context;
	private SQLiteDatabase database;
	ConnectivityManagers connectivityManagers = new ConnectivityManagers(
			context);

	public Manager(Context context) {
		this.context = context;
	}

	public String Networkinfo() {
		if (connectivityManagers.GetNetworInformation()) {
			if (!connectivityManagers.TestConectionIsValid()) {
				return "Conection Is Not Available";
			}

		} else {
			// /(context)startActivity(new
			// Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));
			return "No NetWork Found";
		}
		return "";

	}

	public boolean SqlInsert(SQLiteDatabase database, String number) {
		ContentValues values = new ContentValues();
		values.put("Number", number);
		database.insert("CallHistroy", null, values);
		database.close();
		return true;
	}

}
