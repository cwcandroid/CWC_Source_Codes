package com.cwc.courierclient;

import java.util.Locale;

import com.cwc.graph.XYChartBuilder;
import com.cwc.history.HistoryActivity;
import com.cwc.tasks.TasksActivity;
import com.cwc.user.CallHistory;

import android.app.TabActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TabHost;

public class CWCCourierClientMainScreenActivity extends TabActivity {

	///private SQLiteDatabase database;
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		
		///////////
//		database = this.openOrCreateDatabase("DataBase1.sql",SQLiteDatabase.CREATE_IF_NECESSARY, null);
//		database.setVersion(1);
//		database.setLocale(Locale.getDefault());
//		database.setLockingEnabled(false);
//		String CreateTable = "Create table if not exists Histroy(id INTEGER PRIMARY KEY AUTOINCREMENT,number INTEGER)";
//		database.execSQL(CreateTable);
		//////////
		// setup tabs
		TabHost tabHost = getTabHost();
		TabHost.TabSpec tabSpec;
		Intent intent;

		intent = new Intent().setClass(this, TasksActivity.class);
		tabSpec = tabHost.newTabSpec("tasks").setIndicator("Task", getResources().getDrawable(R.drawable.task))
				.setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, HistoryActivity.class);
		tabSpec = tabHost.newTabSpec("history").setIndicator("", getResources().getDrawable(R.drawable.history))
				.setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, XYChartBuilder.class);
		tabSpec = tabHost.newTabSpec("performance").setIndicator("Performance", getResources().getDrawable(R.drawable.performance))
				.setContent(intent);
		tabHost.addTab(tabSpec);
		
		intent = new Intent().setClass(this, CallHistory.class);
		tabSpec = tabHost.newTabSpec("Callhistory").setIndicator("Call History", null)
				.setContent(intent);
		tabHost.addTab(tabSpec);
	}

}
