package com.cwc.tasks;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cwc.DAO.Task;

import com.cwc.courierclient.R;
import com.cwc.jsonurl.Jesonurl;
import com.cwc.map.mapitemsGoogleMaps;
import com.cwc.map.ViewMapItem;

import com.cwc.util.HttpRetriever;
import com.cwc.util.List_view_ArrayAdapter;
import com.cwc.util.Shared_Preferences;
import com.cwc.util.ShowAlertDialog;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class TasksActivity extends Activity {
	private Button mapitems, time, location;
	private ListView listView;
	private ProgressDialog progressDialog;
	private String response;
	private HttpRetriever dataretriever = new HttpRetriever();
	private Shared_Preferences preferences;
	private String date;
	ArrayList<Task> tasks;
	private String[] description;
	private String[] address;
	private String[] taskid;
	private String[] taskname;
	private String[] taskphone;
	private String[] lat;
	private String[] lng;
	private boolean location_flag = true;
	private boolean time_flag = true;

	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.task_list);
		mapitems = (Button) findViewById(R.id.mapitemButton);
		location = (Button) findViewById(R.id.tasklocationButton);
		time = (Button) findViewById(R.id.tasktimeButton);
		listView = (ListView) findViewById(R.id.historyListView);
		Calendar c = Calendar.getInstance();
		int day = c.get(Calendar.DAY_OF_MONTH);
		int month = c.get(Calendar.MONTH) + 1;
		int year = c.get(Calendar.YEAR);
		String sday = day + "";
		String smonth = month + "";
		final String syear = year + "";

		if (sday.length() == 1) {
			sday = "0" + sday;
		}
		int a = smonth.length();
		if (smonth.length() == 1) {
			smonth = "0" + smonth;
		}
		// date="20-01-2012";
		date = sday + "-" + smonth + "-" + syear;
		listView = (ListView) findViewById(R.id.historyListView);
		preferences = new Shared_Preferences(this);
		progressDialog = ProgressDialog.show(TasksActivity.this, "",
				"Information Loading...", true, false);
		new Thread() {
			public void run() {
				try {

					response = dataretriever.retrieve(new Jesonurl()
							.Get_tasksurl(preferences
									.Get_preferance("Cwcusername"), date));
				} catch (Exception ex) {
					ex.printStackTrace();
					handler.sendEmptyMessage(0);
				}
				handler.sendEmptyMessage(0);
			}
		}.start();
		mapitems.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent i = new Intent(TasksActivity.this,
						mapitemsGoogleMaps.class);
				Bundle bundle = new Bundle();

				bundle.putStringArray("itemnane", description);
				bundle.putStringArray("itemid", taskid);
				bundle.putStringArray("itemaddress", address);
				bundle.putStringArray("itemdelivername", taskname);
				bundle.putStringArray("itemphone", taskphone);
				bundle.putStringArray("itemlat", lat);
				bundle.putStringArray("itemlng", lng);
				bundle.putInt("size", tasks.size());
				i.putExtras(bundle);
				startActivity(i);
			}
		});
	}

	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			progressDialog.dismiss();
			if (response != null) {
				JSONArray jsonArray;
				tasks = new ArrayList<Task>();
				try {
					jsonArray = new JSONArray(response);
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject jsonObject = jsonArray.getJSONObject(i);
						Task task = new Task(jsonObject.getString("task_id"),
								jsonObject.getString("name"), jsonObject
										.getString("address"), jsonObject
										.getString("comments"), jsonObject
										.getString("contactno"), jsonObject
										.getString("description"), jsonObject
										.getString("latitude"), jsonObject
										.getString("longitude"), jsonObject
										.getString("status"), jsonObject
										.getString("duetime"));
						tasks.add(task);
					}

					description = new String[tasks.size()];
					address = new String[tasks.size()];
					taskid = new String[tasks.size()];
					taskname = new String[tasks.size()];
					taskphone = new String[tasks.size()];
					lat = new String[tasks.size()];
					lng = new String[tasks.size()];
					int i = 0;
					for (Task task : tasks) {
						description[i] = task.getDescription();
						address[i] = task.getAddress();
						taskid[i] = task.getId();
						taskname[i] = task.getDelivername();
						taskphone[i] = task.getContactno();
						lat[i] = task.getLatitude();
						lng[i] = task.getLongitude();
						i++;
					}
					location.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							String[] slocation = new String[tasks.size()];
							// ////////////
							double temp = 0.0;
							for (int counter = 0; counter < tasks.size() - 1; counter++) {

								for (int index = 0; index < tasks.size() - 1
										- counter; index++) {

									if (Double.parseDouble(lat[index]) > Double
											.parseDouble(lat[index + 1])) {

										temp = Double.parseDouble(lat[index]);

										lat[index] = lat[index + 1];
										description[index] = description[index + 1];
										lat[index + 1] = temp + "";
									}

								}

							}
							// end loop
							// ////////////
							location_flag = false;
							List_view_ArrayAdapter listViewArrayAdapter = new List_view_ArrayAdapter(
									getApplicationContext(), description);
							listView.setAdapter(listViewArrayAdapter);
							listView.setTextFilterEnabled(true);
						}
					});
					// time.setText("");
					time.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							String[] duetimearray = new String[tasks.size()];
							int[] due = new int[tasks.size()];
							int i = 0;
							for (Task task : tasks) {
								duetimearray[i] = task.getDuetime();
								String time = duetimearray[i] + ":00";
								DateFormat sdf = new SimpleDateFormat(
										"hh:mm:ss");
								Date date;
								try {
									date = sdf.parse(time);
									int h = date.getHours();
									int m = date.getMinutes();
									due[i] = h + m;
								} catch (ParseException e) {
									e.printStackTrace();
								}
								i++;
							}

							// ///////////////////
							int temp = 0;
							for (int counter = 0; counter < tasks.size() - 1; counter++) {

								for (int index = 0; index < tasks.size() - 1
										- counter; index++) {

									if (due[index] > due[index + 1]) {

										temp = due[index];

										due[index] = due[index + 1];
										description[index] = description[index + 1];
										due[index + 1] = temp;
									}

								}

							}
							// ////////////////
							time_flag = false;
							List_view_ArrayAdapter listViewArrayAdapter = new List_view_ArrayAdapter(
									getApplicationContext(), description);
							listView.setAdapter(listViewArrayAdapter);
							listView.setTextFilterEnabled(true);
						}
					});
					if (location_flag && time_flag) {
						List_view_ArrayAdapter listViewArrayAdapter = new List_view_ArrayAdapter(
								getApplicationContext(), description);
						listView.setAdapter(listViewArrayAdapter);
						listView.setTextFilterEnabled(true);
					}
					listView.setOnItemClickListener(new OnItemClickListener() {

						@Override
						public void onItemClick(AdapterView<?> parent,
								View view, int position, long id) {
							preferences.Save_preference("taskItemname", tasks
									.get(position).getDescription());
							preferences.Save_preference("taskIteid", tasks.get(
									position).getId());
							preferences.Save_preference("taskRecivename", tasks
									.get(position).getDelivername());
							preferences.Save_preference("taskReciveadress",
									tasks.get(position).getAddress());
							preferences.Save_preference("taskRecivephone",
									tasks.get(position).getContactno());
							preferences.Save_preference("taskitemlatitude",
									tasks.get(position).getLatitude());
							preferences.Save_preference("taskitemlongitude",
									tasks.get(position).getLongitude());
							Intent i = new Intent(TasksActivity.this,
									Tasks_detail_activity.class);
							// / i.putExtra("BABU", tasks);
							i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i);
						}
					});

				} catch (JSONException e) {
					e.printStackTrace();
				}
			} else {
				new ShowAlertDialog(TasksActivity.this, "Erro",
						"Problem to fetch data from server");
			}
		};
	};
	static final String[] COUNTRIES = new String[] { "Products", "Tickets",
			"Photo of the day", "Wall papers", "Ringtones", "Musics", "Videos" };
}
