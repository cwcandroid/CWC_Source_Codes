/**
 * 
 */
package com.cwc.tasks;

import java.util.Locale;

import com.cwc.courierclient.R;
import com.cwc.courierclient.R.layout;
import com.cwc.util.Manager;
import com.cwc.util.Shared_Preferences;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @author BABU
 * 
 */
public class Info_activity extends Activity {
	private TextView itenmane, itenid, recivename, reciveaddress;
	private Button phone;
	private Shared_Preferences preferences;
	private String[] description;
	private String[] address;
	private String[] taskid;
	private String[] taskname;
	private String[] taskphone;
	private Bundle bundle;
	int position;
	public static SQLiteDatabase callhistoryDB;
	

	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.info_layout);
		preferences = new Shared_Preferences(this);
		// //////
		callhistoryDB = this.openOrCreateDatabase("test.db",
				SQLiteDatabase.CREATE_IF_NECESSARY, null);
		callhistoryDB.setVersion(1);
		callhistoryDB.setLocale(Locale.getDefault());
		callhistoryDB.setLockingEnabled(true);
		callhistoryDB.execSQL("CREATE TABLE IF NOT EXISTS " + "calllist"
				+ " (number TEXT);");
		// //////
		bundle = getIntent().getExtras();

		itenmane = (TextView) findViewById(R.id.itemnameTextView);
		itenid = (TextView) findViewById(R.id.itemidTextView);
		recivename = (TextView) findViewById(R.id.receivernameTextView);
		reciveaddress = (TextView) findViewById(R.id.itemaddressTextView);
		phone = (Button) findViewById(R.id.callButton);

		if (bundle == null) {
			itenmane.setText(preferences.Get_preferance("taskItemname"));
			itenid.setText(preferences.Get_preferance("taskIteid"));
			recivename.setText(preferences.Get_preferance("taskRecivename"));
			reciveaddress.setText(preferences
					.Get_preferance("taskReciveadress"));
			phone.setText(preferences.Get_preferance("taskRecivephone"));
		} else {
			description = new String[bundle.getInt("size")];
			address = new String[bundle.getInt("size")];
			taskid = new String[bundle.getInt("size")];
			taskname = new String[bundle.getInt("size")];
			taskphone = new String[bundle.getInt("size")];

			description = bundle.getStringArray("itemnane");
			taskid = bundle.getStringArray("itemid");
			address = bundle.getStringArray("itemaddress");
			taskname = bundle.getStringArray("itemdelivername");
			taskphone = bundle.getStringArray("itemphone");
			position = bundle.getInt("position");

			itenmane.setText(description[position]);
			itenid.setText(taskid[position]);
			recivename.setText(taskname[position]);
			reciveaddress.setText(address[position]);
			phone.setText(taskphone[position]);

		}

		phone.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				String phonenumber = phone.getText().toString();
				callhistoryDB.execSQL("INSERT INTO " + "calllist" + " Values ('"
						+ phonenumber + "');");
				Intent callIntent = new Intent(Intent.ACTION_CALL, Uri
						.parse("tel:" + phone.getText().toString().trim()));
				startActivity(callIntent);

			}
		});
	}
}
