/**
 * 
 */
package com.cwc.tasks;

import com.cwc.courierclient.R;
import com.cwc.courierclient.R.id;
import com.cwc.courierclient.R.layout;

import com.cwc.map.Viewonmap;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TabHost;

/**
 * @author BABU
 * 
 */
public class Tasks_detail_activity extends TabActivity {

	private Button taskreport;

	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.task_detail_layout);
		taskreport = (Button) findViewById(R.id.taskreportButton);
		TabHost tabHost = getTabHost();
		TabHost.TabSpec tabSpec;
		Intent intent;

		intent = new Intent().setClass(this, Info_activity.class);
		tabSpec = tabHost.newTabSpec("info").setIndicator("Info", null)
				.setContent(intent);
		tabHost.addTab(tabSpec);

		intent = new Intent().setClass(this, Viewonmap.class);
		tabSpec = tabHost.newTabSpec("viewonmap").setIndicator("View On Map",
				null).setContent(intent);
		tabHost.addTab(tabSpec);

		taskreport.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent i = new Intent(Tasks_detail_activity.this,
						task_report.class);
				startActivity(i);
			}
		});

	}
}
