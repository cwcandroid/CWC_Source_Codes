/**
 * 
 */
package com.cwc.tasks;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;




import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cwc.courierclient.CWCCourierClientMainScreenActivity;
import com.cwc.courierclient.R;
import com.cwc.courierclient.R.id;
import com.cwc.courierclient.R.layout;
import com.cwc.jsonurl.Jesonurl;
import com.cwc.location.GprsLocation;
import com.cwc.util.HttpRetriever;
import com.cwc.util.Shared_Preferences;
import com.cwc.util.ShowAlertDialog;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

/**
 * @author BABU
 * 
 */
public class task_report extends Activity {

	public static final int SIGNATURE_ACTIVITY = 1;
	private Button locate, signature, submit, cancel;
	private EditText comments;
	private Spinner type;
	private ImageView signatureimage;
	private double lat=0.0,lng=0.0;
	private GprsLocation gprsLocation;
	private int reasonytpe=0;
	private ProgressDialog progressDialog;
	private HttpRetriever dataretriever = new HttpRetriever();
	private String response;
	private Shared_Preferences preferences;
	Bitmap bm;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.task_report_layout);
		preferences = new Shared_Preferences(this);
		locate = (Button) findViewById(R.id.locatemeButton);
		signature = (Button) findViewById(R.id.takesignatureButton);
		submit = (Button) findViewById(R.id.tasksubmiteButton);
		cancel = (Button) findViewById(R.id.taskcancelButton);
		comments=(EditText)findViewById(R.id.commentsEditTxt);
		type = (Spinner) findViewById(R.id.reporttypeSpinner);
		
		ArrayAdapter<String> adapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, detail_report);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        type.setAdapter(adapter);
        
        locate.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				gprsLocation= new GprsLocation();
				lat=gprsLocation.getLocationLatitud()*1E6;
				lng=gprsLocation.getLocationLongitud()*1E6;
			}
		});
        
        type.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				reasonytpe=position;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
        
        
		signature.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(task_report.this,
						com.cwc.util.CaptureSignature.class);
				startActivityForResult(intent, SIGNATURE_ACTIVITY);

			}
		});
		
		cancel.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent Go_previous= new  Intent(task_report.this, Tasks_detail_activity.class);
				startActivity(Go_previous);
				
			}
		});
		
		////////////////
		submit.setOnClickListener(new View.OnClickListener() {
			
			
			public void onClick(View v) {
				if(!comments.getText().toString().equals(""))
				{
					progressDialog = ProgressDialog.show(task_report.this, "",
				"Information Loading...", true, false);
					new ImageUploadTask().execute();
//					new Thread() {
//						public void run() {
//							try {
//								///response = dataretriever.retrieve(new Jesonurl().Get_reporttaskurl(preferences.Get_preferance("Cwcusername"), preferences.Get_preferance("taskIteid"), reasonytpe+"", comments.getText().toString().trim(), lat, lng, signatureimage));
//							} catch (Exception ex) {
//								ex.printStackTrace();
//								handler.sendEmptyMessage(0);
//							}
//							handler.sendEmptyMessage(0);
//						}
//					}.start();
				}
				else
				{
					new ShowAlertDialog(task_report.this, "Input Erro",
					"please submit data in all fild");
				}
			}
		});
		
	}

	
//	Handler handler= new Handler()
//	{
//		public void handleMessage(android.os.Message msg) {
//			if (response != null) {
//				JSONObject jObject;
//				try {
//					jObject = new JSONObject(response);
//					String Ressult = jObject.getString("status");
//					if (Ressult.equals("Success")) {
//						Intent Go_main= new Intent(task_report.this, CWCCourierClientMainScreenActivity.class);
//						startActivity(Go_main);
//					}
//					else
//					{
//						new ShowAlertDialog(task_report.this, "Save Erro",
//						"Fail to Save Data");
//					}
//				} catch (JSONException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				
//			}
//			else
//			{
//				new ShowAlertDialog(task_report.this, "Erro",
//				"Problem to save data in server");
//			}
//		};
//	};
	
	final static String detail_report[] = { "Not Delivered", "Delivered",
			"Address Not found", "No One available" };

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case SIGNATURE_ACTIVITY:
			if (resultCode == RESULT_OK) {
				Bundle bundle = data.getExtras();
				String status = bundle.getString("status");
				byte[] by = bundle.getByteArray("image");
				signatureimage = (ImageView) findViewById(R.id.signatureimageView);
				bm= BitmapFactory.decodeByteArray(by, 0, by.length);
				signatureimage.setImageBitmap(bm);
				if (status.equalsIgnoreCase("done")) {
					Toast toast = Toast.makeText(this,
							"Signature capture successful!--" + by.length,
							Toast.LENGTH_SHORT);
					toast.setGravity(Gravity.TOP, 105, 50);
					toast.show();
				}
			}
			break;
		}

	}
	
	// Upload picture and data
	class ImageUploadTask extends AsyncTask<Void, Void, String> {
		@Override
		protected String doInBackground(Void... unsued) {
			try {
				HttpClient httpClient = new DefaultHttpClient();
				HttpContext localContext = new BasicHttpContext();
				HttpPost httpPost = new HttpPost("http://test.sentisol.com/cwc/index.php/android/reportSpecificTask?username="+preferences.Get_preferance("Cwcusername")+"&returnType=json&taskid="+preferences.Get_preferance("taskIteid")+"&reasontype="+reasonytpe+""+"&reasondetails="+comments.getText().toString().trim()+"&reportlatitude="+lat+"&reportlongitude="+lng+"&signaturefile=customersignature.png");

				MultipartEntity entity = new MultipartEntity(
						HttpMultipartMode.BROWSER_COMPATIBLE);

				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				bm.compress(CompressFormat.JPEG, 100, bos);
				byte[] data = bos.toByteArray();
				entity.addPart("returnformat", new StringBody("json"));
				entity.addPart("uploaded", new ByteArrayBody(data,
						"myImage.jpg"));
				httpPost.setEntity(entity);
				HttpResponse response = httpClient.execute(httpPost,
						localContext);
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(
								response.getEntity().getContent(), "UTF-8"));

				String sResponse = reader.readLine();
				return sResponse;
			} catch (Exception e) {
				
				Toast.makeText(getApplicationContext(),
						e.getMessage(),
						Toast.LENGTH_LONG).show();
				Log.e(e.getClass().getName(), e.getMessage(), e);
				return null;
			}

			
		}

		@Override
		protected void onProgressUpdate(Void... unsued) {

		}

		protected void onPostExecute(String sResponse) {
			try {
				if (progressDialog.isShowing())
					progressDialog.dismiss();

				if (sResponse != null) {
					JSONObject JResponse = new JSONObject(sResponse);
					String message = JResponse.getString("status");
					if (message.equals("Success")) {
						Toast.makeText(getApplicationContext(), message,
								Toast.LENGTH_LONG).show();
						Intent Go_main= new Intent(task_report.this,CWCCourierClientMainScreenActivity.class);
						startActivity(Go_main);
					} else {
						Toast.makeText(getApplicationContext(),
								"Photo uploaded successfully",
								Toast.LENGTH_SHORT).show();
						Intent Go_main= new Intent(task_report.this,CWCCourierClientMainScreenActivity.class);
						startActivity(Go_main);
						
					}
				}
			} catch (Exception e) {
				Toast.makeText(getApplicationContext(),
						e.getMessage(),
						Toast.LENGTH_LONG).show();
				Log.e(e.getClass().getName(), e.getMessage(), e);
			}
		}
	}
}
