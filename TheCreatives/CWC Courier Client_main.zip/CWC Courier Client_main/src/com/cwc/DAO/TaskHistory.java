/**
 * 
 */
package com.cwc.DAO;

/**
 * @author BABU
 * 
 */
public class TaskHistory {

	private String reasontype;
	private String reasondetails;
	private String reportlatitude;
	private String reportlongitude;
	private String signaturefile;
	private String duedate;

	public TaskHistory(String reasontype, String reasondetails,
			String reportlatitude, String reportlongitude,
			String signaturefile, String duedate) {

		this.reasontype = reasontype;
		this.reasondetails = reasondetails;
		this.reportlatitude = reportlatitude;
		this.reportlongitude = reportlongitude;
		this.signaturefile = signaturefile;
		this.duedate = duedate;
	}

	public String getReasontype() {
		return reasontype;
	}

	public void setReasontype(String reasontype) {
		this.reasontype = reasontype;
	}

	public String getReasondetails() {
		return reasondetails;
	}

	public void setReasondetails(String reasondetails) {
		this.reasondetails = reasondetails;
	}

	public String getReportlatitude() {
		return reportlatitude;
	}

	public void setReportlatitude(String reportlatitude) {
		this.reportlatitude = reportlatitude;
	}

	public String getReportlongitude() {
		return reportlongitude;
	}

	public void setReportlongitude(String reportlongitude) {
		this.reportlongitude = reportlongitude;
	}

	public String getSignaturefile() {
		return signaturefile;
	}

	public void setSignaturefile(String signaturefile) {
		this.signaturefile = signaturefile;
	}

	public String getDuedate() {
		return duedate;
	}

	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}

}
