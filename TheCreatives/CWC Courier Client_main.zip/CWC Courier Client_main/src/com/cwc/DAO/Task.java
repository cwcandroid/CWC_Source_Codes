/**
 * 
 */
package com.cwc.DAO;

/**
 * @author BABU
 * 
 */
public class Task {

	private String id;
	private String delivername;
	private String address;
	private String comments;
	private String contactno;
	private String description;
	private String latitude;
	private String longitude;
	private String status;
	private TaskHistory taskHistory;
	private String duetime;

	public Task(String id, String delivername, String address, String comments,
			String contactno, String description, String latitude,
			String longitude, String status, TaskHistory taskHistory) {
		this.id = id;
		this.delivername = delivername;
		this.address = address;
		this.comments = comments;
		this.contactno = contactno;
		this.description = description;
		this.latitude = latitude;
		this.longitude = longitude;
		this.status = status;
		this.taskHistory = taskHistory;
	}

	public Task(String id, String delivername, String address, String comments,
			String contactno, String description, String latitude,
			String longitude, String status,String duetime) {
		this.id = id;
		this.delivername = delivername;
		this.address = address;
		this.comments = comments;
		this.contactno = contactno;
		this.description = description;
		this.latitude = latitude;
		this.longitude = longitude;
		this.status = status;
		this.duetime=duetime;

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDelivername() {
		return delivername;
	}

	public void setDelivername(String delivername) {
		this.delivername = delivername;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public TaskHistory getTaskHistory() {
		return taskHistory;
	}

	public void setTaskHistory(TaskHistory taskHistory) {
		this.taskHistory = taskHistory;
	}

	public String getDuetime() {
		return duetime;
	}

	public void setDuetime(String duetime) {
		this.duetime = duetime;
	}

}
