/**
 * 
 */
package com.cwc.location;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

/**
 ***Author*** Md abdul Gafur. Khulna University. CSE, 07 Batch. Android App
 * Developer. Satkira, Khulna. Bangladesh.
 */

public class GprsLocation implements LocationListener {
	private double locationLatitud, locationLongitud, locationAltitude;

	public double getLocationLatitud() {
		return locationLatitud;
	}

	public double getLocationAltitude() {
		return locationAltitude;
	}

	public double getLocationLongitud() {
		return locationLongitud;
	}

	@Override
	public void onLocationChanged(Location loc) {
		locationLatitud = loc.getLatitude();
		locationLongitud = loc.getLongitude();
		locationAltitude = loc.getAltitude();

	}

	@Override
	public void onProviderDisabled(String provider) {
		// Toast.makeText(context, "Gps Disabled", Toast.LENGTH_LONG).show();

	}

	@Override
	public void onProviderEnabled(String provider) {
		// Toast.makeText(context, "Gps Enabled", Toast.LENGTH_LONG).show();

	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub

	}

}