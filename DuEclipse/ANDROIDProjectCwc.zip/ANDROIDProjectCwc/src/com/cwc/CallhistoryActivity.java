package com.cwc;

import java.util.Date;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class CallhistoryActivity extends Activity {
    /** Called when the activity is first created. */
    Button but;
    TextView call;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.callhist);
        but=(Button)findViewById(R.id.but);
        call=(TextView)findViewById(R.id.call);
        but.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				getCallDetails();
			}

			private void getCallDetails() {
					StringBuffer sb = new StringBuffer();
					Cursor managedCursor = managedQuery( CallLog.Calls.CONTENT_URI,null, null,null, null);
					int number = managedCursor.getColumnIndex( CallLog.Calls.NUMBER );
					int type = managedCursor.getColumnIndex( CallLog.Calls.TYPE );
					int date = managedCursor.getColumnIndex( CallLog.Calls.DATE);
					int duration = managedCursor.getColumnIndex( CallLog.Calls.DURATION);
					sb.append( "Call Details :");
					while ( managedCursor.moveToNext() ) {
						String phNumber = managedCursor.getString( number );
						String callType = managedCursor.getString( type );
						String callDate = managedCursor.getString( date );
						Date callDayTime = new Date(Long.valueOf(callDate));
						String callDuration = managedCursor.getString( duration );
						String dir = null;
						int dircode = Integer.parseInt( callType );
						switch( dircode ) {
								case CallLog.Calls.OUTGOING_TYPE:
										dir = "OUTGOING";
										break;
	
								/*case CallLog.Calls.INCOMING_TYPE:
									dir = "INCOMING";
										break;
	
									case CallLog.Calls.MISSED_TYPE:
											dir = "MISSED";
											break;*/
									}
							sb.append( "\nPhone Number:--- "+phNumber +" \nCall Type:--- "+dir+" \nCall Date:--- "+callDayTime+" \nCall duration in sec :--- "+callDuration );
							sb.append("\n----------------------------------");
					}
							managedCursor.close();
							call.setText(sb);
					}
		
		});
	}
        
}