package com.cwc;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;


public class HistoryActivity extends Activity{
	CWCSQLite database;
	TableLayout table;
	TableRow tableRow,divRow;
	TextView firstEntry,secondEntry,divider;

	void showFromDB(Cursor cs)
	{
		final String allCol[]={"_id","address","comments",
		"contactno","description","latitude","longitude",
		"name","status","tdate","username"};
		int len=allCol.length;
		int i=0;
		String value,name;
		if(cs.moveToFirst())
		{
			do{
				tableRow = new TableRow(this);
				tableRow.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT)); 
				tableRow.setOnClickListener(new OnClickListener() {				
				
					public void onClick(View v) {}						
				});
				divRow=new TableRow(this);
				divRow.setLayoutParams(new LayoutParams(
							LayoutParams.FILL_PARENT,
							LayoutParams.WRAP_CONTENT));
				firstEntry=new TextView(this);				
				 tableRow.setPadding(0,10, 0, 10);
				 tableRow.addView(firstEntry);
			
				 
				divider=new TextView(this);
				divider.setHeight(5);						
				divRow.setBackgroundColor(Color.WHITE);
				firstEntry.setText("");
				for(i=0;i<len;i++)
				{
					value=cs.getString(cs.getColumnIndex(allCol[i]));
					name=allCol[i];			
					firstEntry.append(" " +name);
					firstEntry.append("  : "+value+"\n");
					
									
					
				}
				divRow.addView(divider);
				table.addView(tableRow);
				table.addView(divRow);	
				
			}while(cs.moveToNext());
		}
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history);
		table=(TableLayout)findViewById(R.id.historytable);
		database = new CWCSQLite(this);
		Cursor cs = database.fetchAllByDate();
		showFromDB(cs);
	}
}
