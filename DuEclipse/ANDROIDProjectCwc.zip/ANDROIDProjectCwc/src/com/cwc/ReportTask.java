package com.cwc;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

public class ReportTask extends ActivityGroup  implements AdapterView.OnItemSelectedListener{

	Button takesig;
	String[] items={"lorem", "ipsum", "dolor", "sit", "amet"};

	@Override

	public void onCreate(Bundle icicle) {

		super.onCreate(icicle);

		setContentView(R.layout.report);
		
		
		takesig=(Button)findViewById(R.id.takesig);
		takesig.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {				// TODO Auto-generated method stub
				
				Intent intent=new Intent(v.getContext(), SignatureClass.class);
				//intent.putExtra("taskId", Integer.toString(id));
				replaceContentView("SignatureClass",intent );
			
				}
				private void replaceContentView(String id, Intent newintent) {
						View view=getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
						setContentView(view);}
		});

		//selection=(TextView)findViewById(R.id.selection);

		Spinner spin=(Spinner)findViewById(R.id.spinner);

		spin.setOnItemSelectedListener((OnItemSelectedListener) this);

		ArrayAdapter<String> aa=new ArrayAdapter<String>(this,

				android.R.layout.simple_list_item_1,items);
		
		aa.setDropDownViewResource(
	
				android.R.layout.simple_spinner_dropdown_item);

		spin.setAdapter(aa);
	
	}
	
	public void onItemSelected(AdapterView parent, View v,

			int position, long id) {
	
	}

	public void onNothingSelected(AdapterView parent) {
	
	
	}

}