package com.cwc;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import com.google.android.maps.*;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ZoomControls;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;


public class logo extends MapActivity implements LocationListener {
	/** Called when the activity is first created. */
	
	EditText		txted			= null;
	
	Button			btnSimple		= null;
	
	MapView			gMapView		= null;
	
	MapController	mc				= null;
	
	Drawable		defaultMarker	= null;
	
	GeoPoint		p				= null;
	
	double			latitude		= 23.72945, longitude = 90.4121;
	
	String addressString;
	
	boolean gps_enabled=false;

	boolean network_enabled=false;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		LocationManager lm;
		
		
		
		
		//String provider = LocationManager.GPS_PROVIDER;
		
		
		gMapView = (MapView) findViewById(R.id.myGMap);
		p = new GeoPoint((int) (latitude * 1000000), (int) (longitude * 1000000));
		mc = gMapView.getController();
		gMapView.setSatellite(false);
		mc.setCenter(p);
		mc.setZoom(14);
		gMapView.setBuiltInZoomControls(true);
		gMapView.displayZoomControls(true);
		
		MyLocationOverlay myLocationOverlay = new MyLocationOverlay();
		List<Overlay> list = gMapView.getOverlays();
		list.add(myLocationOverlay);	
	
		lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		
		try{gps_enabled=lm.isProviderEnabled(LocationManager.GPS_PROVIDER);}catch(Exception ex){}
        try{network_enabled=lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);}catch(Exception ex){}
		//Location loc = lm.getLastKnownLocation(provider);
		if(gps_enabled)
		{
			 Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
			 yourLocation(loc);
		}
	    if(network_enabled)
	    {
	    	 	Location loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
	    	 	yourLocation(loc);
	    }		
		
      //exceptions will be thrown if provider is not permitted.
       
        //don't start listeners if no provider is enabled

       
		// Creating and initializing Map
		
		//lm.requestLocationUpdates(provider, 1000L, 100.0f, this);
		 if(gps_enabled)
		 {
		        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 10, this);
		 }
	     if(network_enabled)
	     {
	            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000, 10, this);
	     }
	}
	public void yourLocation(Location loc)
	{	
		
		if(loc!=null)
		{
			double lat2 = loc.getLatitude();
			double long2 =loc.getLongitude();
			Geocoder gc = new Geocoder(this, Locale.getDefault());
			try {
				List<Address> addresses = gc.getFromLocation(lat2, long2, 1);
				StringBuilder sb = new StringBuilder();
		if (addresses.size() > 0) 
			{
		
				Address address = addresses.get(0);
				for (int i = 0; i < address.getMaxAddressLineIndex(); i++)
				sb.append(address.getAddressLine(i)).append("\n");
						
				sb.append(address.getLocality()).append("\n");
						
				sb.append(address.getPostalCode()).append("\n");
						
				sb.append(address.getCountryName());
		
			}
		
			addressString = sb.toString();
		}
		catch (IOException e) 
		{
			
		}
		
		
		p = new GeoPoint((int) lat2 * 1000000, (int) long2 * 1000000);
		mc.animateTo(p);
	
		}
		
}
	/* This method is called when use position will get changed */
	public void onLocationChanged(Location location) {
		
		
		if (location != null) 
		{
			double lat = location.getLatitude();
			double lng = location.getLongitude();
			
			Geocoder gc = new Geocoder(this, Locale.getDefault());
			try {
				List<Address> addresses = gc.getFromLocation(lat, lng, 1);
				StringBuilder sb = new StringBuilder();
				if (addresses.size() > 0) 
				{
			
					Address address = addresses.get(0);
			
					for (int i = 0; i < address.getMaxAddressLineIndex(); i++)
							sb.append(address.getAddressLine(i)).append("\n");
							
					sb.append(address.getLocality()).append("\n");
							
					sb.append(address.getPostalCode()).append("\n");
							
					sb.append(address.getCountryName());
			
				}
			
				addressString = sb.toString();
			
			} 
			catch (IOException e) 
			{}
			
			//txted.setText("Your Current Position is:\n"  + addressString);
			p = new GeoPoint((int) lat * 1000000, (int) lng * 1000000);
			mc.animateTo(p);
		}
		else {
	
		}
		
		
		
	}
	
	public void onProviderDisabled(String provider) {
		// required for interface, not used
	}
	
	public void onProviderEnabled(String provider) {
		// required for interface, not used
	}
	
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// required for interface, not used
	}
	
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
	
	/* User can zoom in/out using keys provided on keypad */
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_I) {
			gMapView.getController().setZoom(gMapView.getZoomLevel() + 1);
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_O) {
			gMapView.getController().setZoom(gMapView.getZoomLevel() - 1);
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_S) {
			//gMapView.setSatellite(true);
			
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_T) {
			//gMapView.setTraffic(true);
			return true;
		}
		return false;
	}
	
	/* Class overload draw method which actually plot a marker,text etc. on Map */
	protected class MyLocationOverlay extends Overlay {
		
		@Override
		public boolean draw(Canvas canvas, MapView mapView, boolean shadow, long when) {
			Paint paint = new Paint();
			
			super.draw(canvas, mapView, shadow);
			// Converts lat/lng-Point to OUR coordinates on the screen.
			Point myScreenCoords = new Point();
			mapView.getProjection().toPixels(p, myScreenCoords);
			
			paint.setStrokeWidth(1);
			paint.setARGB(255, 255, 255, 255);
			paint.setStyle(Paint.Style.STROKE);
			
			Bitmap bmp = BitmapFactory.decodeResource(getResources(), R.drawable.icon);
			
			canvas.drawBitmap(bmp, myScreenCoords.x, myScreenCoords.y, paint);
			canvas.drawText("Your Location", myScreenCoords.x, myScreenCoords.y, paint);
			return true;
		}
	}
}
