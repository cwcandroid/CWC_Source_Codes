package com.cwc;

import java.util.ArrayList;

import org.apache.http.NameValuePair;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class CWCSQLite extends SQLiteOpenHelper{

	static final String dbName="demoDB";
	static final String taskTable="TaskTable";
	
	
	static final String allCol[]={"_id","address","comments",
		"contactno","description","latitude","longitude",
		"name","status","tdate","username"};
	static final String uAllcol[]={"uname","pword","remember"};
	public CWCSQLite(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
		
	}
	public CWCSQLite(Context context)
	{
		super(context,dbName,null,33); //to change db need
		//to change version number
		createDB();
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL("CREATE TABLE IF NOT EXISTS " + taskTable+
				" ( "+ allCol[0] + " INTEGER , " +
				allCol[1] + " TEXT, "+ allCol[2] + 
				" TEXT, " + allCol[3] + " TEXT, "+
				allCol[4] + " TEXT, "+
				allCol[5] + " TEXT, " +
				allCol[6] + " TEXT, "+
				allCol[7] + " TEXT, " +
				allCol[8] + " TEXT, " +
				allCol[9] + " TEXT, " +
				allCol[10] + " TEXT , " +  "PRIMARY KEY( " + allCol[0] + " , " + allCol[10]  +" );");
		
		db.execSQL("CREATE TABLE IF NOT EXISTS " + "utable"+
				" ( "+ uAllcol[0] + " TEXT , " +
				uAllcol[1] + " TEXT, "+ uAllcol[2] + 
				" TEXT  );");
		
	}
	void createDB()
	{
		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL("CREATE TABLE IF NOT EXISTS " + taskTable+
				" ( "+ allCol[0] + " INTEGER , " +
				allCol[1] + " TEXT, "+ allCol[2] + 
				" TEXT, " + allCol[3] + " TEXT, "+
				allCol[4] + " TEXT, "+
				allCol[5] + " TEXT, " +
				allCol[6] + " TEXT, "+
				allCol[7] + " TEXT, " +
				allCol[8] + " TEXT, " +
				allCol[9] + " TEXT, " +
				allCol[10] + " TEXT , " +  "PRIMARY KEY( " + allCol[0] + " , " + allCol[10]  +" ));");
		db.execSQL("CREATE TABLE IF NOT EXISTS " + "utable"+
				" ( "+ uAllcol[0] + " TEXT , " +
				uAllcol[1] + " TEXT, "+ uAllcol[2] + 
				" TEXT  );");
	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		db.execSQL("DROP TABLE IF EXISTS " +taskTable);
		db.execSQL("DROP TABLE IF EXISTS " +"utable");
	}
	public void dropTable()
	{
		SQLiteDatabase db=this.getWritableDatabase();
		db.execSQL("DROP TABLE IF EXISTS " +taskTable);
		db.execSQL("DROP TABLE IF EXISTS " +"utable");
	}
	public void dbInsert(ArrayList<NameValuePair> data)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues cv = new ContentValues();
		int length=data.size();
		int i=0;
		NameValuePair tmp;
		for(i=0;i<length;i++)
		{
			tmp= data.get(i);
			if(tmp.getName().equals("_id")) //id column is integer
				cv.put("_id",Integer.parseInt(tmp.getValue()));
			else
				cv.put(tmp.getName(), tmp.getValue());
		}
		db.insert(taskTable,allCol[0] , cv);
		db.close();
	}
	public void dbUserInsert(ArrayList<NameValuePair> data)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues cv = new ContentValues();
		int length=data.size();
		int i=0;
		System.out.println(data.size());
		NameValuePair tmp;
		for(i=0;i<length;i++)
		{
			tmp= data.get(i);
			cv.put(tmp.getName(), tmp.getValue());
		}
		db.insert("utable",null, cv);
		db.close();
	}
	public Cursor dbFetchAll(String where)
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		if(where.equals(""))
		{
			fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
					allCol[1] + ", " + allCol[2] + ", " +
					allCol[3] + ", " +
					allCol[4] + ", " +
					allCol[5] + ", " +
					allCol[6] + ", " +
					allCol[7] + ", " +
					allCol[8] + ", " +
					allCol[9] + " TEXT, " +
					allCol[10] + " from "+ taskTable, new String[]{});
		}
		else
		{
			fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
					allCol[1] + ", " + allCol[2] + ", " +
					allCol[3] + ", " +
					allCol[4] + ", " +
					allCol[5] + ", " +
					allCol[6] + ", " +
					allCol[7] + ", " +
					allCol[8] + ", " +
					allCol[9] + " TEXT, " +
					allCol[10] + " from "+ taskTable + " where _id=?", new String[]{where});
			
		}
		return fetchResult;
	}
	public Cursor getById(int id)
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
				allCol[1] + ", " + allCol[2] + ", " +
				allCol[3] + ", " +
				allCol[4] + ", " +
				allCol[5] + ", " +
				allCol[6] + ", " +
				allCol[7] + ", " +
				allCol[8] + ", " +
				allCol[9] + ", " +
				allCol[10] + " from "+ taskTable + " where _id=?", new String[]{Integer.toString(id)});
		return fetchResult;
	}
	public Cursor getByDate(String tdate)
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
				allCol[1] + ", " + allCol[2] + ", " +
				allCol[3] + ", " +
				allCol[4] + ", " +
				allCol[5] + ", " +
				allCol[6] + ", " +
				allCol[7] + ", " +
				allCol[8] + ", " +
				allCol[9] + ", " +
				allCol[10] + " from "+ taskTable + " where tdate=?", new String[]{tdate});
		return fetchResult;
	}
	public Cursor getByIdDate(int id,String tdate)
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
				allCol[1] + ", " + allCol[2] + ", " +
				allCol[3] + ", " +
				allCol[4] + ", " +
				allCol[5] + ", " +
				allCol[6] + ", " +
				allCol[7] + ", " +
				allCol[8] + ", " +
				allCol[9] + ", " +
				allCol[10] + " from "+ taskTable + " where tdate=? and _id=?", new String[]{tdate,Integer.toString(id)});
		return fetchResult;
	}
	public Cursor getByIdUser(String user)
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
				allCol[1] + ", " + allCol[2] + ", " +
				allCol[3] + ", " +
				allCol[4] + ", " +
				allCol[5] + ", " +
				allCol[6] + ", " +
				allCol[7] + ", " +
				allCol[8] + ", " +
				allCol[9] + ", " +
				allCol[10] + " from "+ taskTable + " where tdate=? and username=?", new String[]{user});
		return fetchResult;
	}
	public Cursor getByIdUser(int id,String user)
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
				allCol[1] + ", " + allCol[2] + ", " +
				allCol[3] + ", " +
				allCol[4] + ", " +
				allCol[5] + ", " +
				allCol[6] + ", " +
				allCol[7] + ", " +
				allCol[8] + ", " +
				allCol[9] + ", " +
				allCol[10] + " from "+ taskTable + " where username=? and _id=?", new String[]{user,Integer.toString(id)});
		return fetchResult;
	}
	public Cursor getByDateUser(String  tdate,String user)
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
				allCol[1] + ", " + allCol[2] + ", " +
				allCol[3] + ", " +
				allCol[4] + ", " +
				allCol[5] + ", " +
				allCol[6] + ", " +
				allCol[7] + ", " +
				allCol[8] + ", " +
				allCol[9] + ", " +
				allCol[10] + " from "+ taskTable + " where username=? and tdate=?", new String[]{user,tdate});
		return fetchResult;
	}
	public Cursor getByUserReminder()
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		fetchResult= db.rawQuery("select " + uAllcol[0]+ " , " + 
				uAllcol[1] + " , " + uAllcol[2] + " from utable ", new String[]{});
		return fetchResult;
	}
	public void deleteUserReminder()
	{
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete("utable",null,new String[]{});
		
	}
	public void deleteTaskTable()
	{
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(taskTable,null,new String[]{});
		
	}
	public Cursor fetchAllByDate()
	{
		Cursor fetchResult=null;
		SQLiteDatabase db = this.getReadableDatabase();
		/*fetchResult= db.rawQuery("select " + allCol[0] + " as _id, "+
				allCol[1] + ", " + allCol[2] + ", " +
				allCol[3] + ", " +
				allCol[4] + ", " +
				allCol[5] + ", " +
				allCol[6] + ", " +
				allCol[7] + ", " +
				allCol[8] + ", " +
				allCol[9] + " TEXT, " +
				allCol[10] + " from "+ taskTable, new String[]{});*/
		fetchResult = db.query(taskTable, allCol, allCol[10]+  " like ? ",new String[] {SharedClass.username},null,null,allCol[9]+" ASC");
		
		return fetchResult;
	}
}