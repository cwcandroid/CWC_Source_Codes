package com.cwc;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class CWCCourierClientLoginActivity extends Activity {
	Button btnLogin, btnRegister;
	EditText username,password;
	CheckBox rememberme;
	CWCSQLite database=null;
	void checkUser(String user,String pass,boolean remember)
	{
		ArrayList<String> userData=new ArrayList<String>();
		try{
			CWCSQLite database = new CWCSQLite(this);
			FileInputStream fin = new FileInputStream("userStat.txt");
			DataInputStream di = new DataInputStream(fin);
			BufferedReader br = new BufferedReader(new InputStreamReader(di));
			
			String line="";
			while( (line = br.readLine()) !=null)
			{
				userData.add(line);
			}
			if(userData.size() ==0 || userData.get(0).equals(user) ==false)
			{
				database.dropTable();
			}
			fin.close();
			FileOutputStream fOut = openFileOutput("userStat.txt", MODE_WORLD_READABLE);
			OutputStreamWriter osw = new OutputStreamWriter(fOut);	

			// Write the string to the file
			osw.write(user + "\n");
			osw.write(pass + "\n");
			osw.write(remember + "\n");
			/* ensure that everything is 
			 * really written out and close */
			//osw.flush();
			osw.close();
		}
		catch(Exception e)
		{
			
		}
	
	}
	ArrayList<String> userState()
	{
		ArrayList<String> userData=new ArrayList<String>();
		FileInputStream fin=null;
		try{
			CWCSQLite database = new CWCSQLite(this);
			fin = new FileInputStream("userStat.txt");
			DataInputStream di = new DataInputStream(fin);
			BufferedReader br = new BufferedReader(new InputStreamReader(di));
			
			String line="";
			while( (line = br.readLine()) !=null)
			{
				userData.add(line);
			}
			fin.close();
		}
		catch(Exception e)
		{
			
		}
		
		return userData;
	}
	protected void alertbox(String title,String message)
	{
		Builder alertBox = new AlertDialog.Builder(this);
		alertBox.setMessage(message);
		alertBox.setTitle(title);
		alertBox.setCancelable(true);
		alertBox.setNeutralButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int whichButton) {
				// TODO Auto-generated method stub
				
			}
		});
		alertBox.show();
	}
void setUserData()
{

	Cursor cs = database.getByUserReminder();
	if(cs.moveToFirst())
	{
		do{
			
			username.setText(cs.getString(cs.getColumnIndex("uname")));
			password.setText(cs.getString(cs.getColumnIndex("pword")));
		}while(cs.moveToNext());
	}
	cs.close();
}
	
void InsertUserInfo()
{	
	try{
		ArrayList<NameValuePair> data=new ArrayList<NameValuePair>();
		data.add(new BasicNameValuePair("uname",username.getText().toString()));
		data.add(new BasicNameValuePair("pword",password.getText().toString()));
		data.add(new BasicNameValuePair("remember","1"));
		
		database.dbUserInsert(data);
	}
	catch(Exception e)
	{
		//Log.i("error",e.getStackTrace());
		System.out.println(e.getStackTrace());
	}
}
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        database = new CWCSQLite(this);
        btnLogin=(Button)findViewById(R.id.button1);
        btnRegister=(Button)findViewById(R.id.button2);
        username = (EditText) findViewById(R.id.editText1);
		password = (EditText) findViewById(R.id.editText2);
		rememberme = (CheckBox) findViewById(R.id.checkBox1);
		
		setUserData();
        btnLogin.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TO DO: User input validation
				// TO DO: Client Authentication and handle different error cases
				if(username.getText().toString().equals(""))
				{
					alertbox("Error","blank user field");
					return;
				}
				if(password.getText().toString().equals(""))
				{
					alertbox("Error","black password field");
					return;
				}
				JSONParser Jparser = new JSONParser();
				//login?username=cwcuser1&password=123456&returnType=json 
				String request = getResources().getString(R.string.login_uri);
				request += "&username=" + username.getText().toString() + "&password=" + 
					password.getText().toString();
				System.out.println(request);
				String result = Jparser.getRequest(request);
				
				// If authentication successful
				if( Jparser.isValidLogin(result) ) //checking server response
				{
					SharedClass.setUsername(username.getText().toString());
					SharedClass.setPassword(password.getText().toString());
					//check and save username
					//checkUser(SharedClass.username,SharedClass.password,rememberme.isSelected());
					database.deleteUserReminder();
					SharedClass.setUsername(username.getText().toString());
					System.out.println(rememberme.isSelected());
					if(rememberme.isChecked())
						InsertUserInfo();
					Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientMainScreenActivity.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
				else{
					alertbox("Error Message","Login information is Incorrect");
					return;
				}
			}
		});
        
        btnRegister.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientRegistrationActivity.class);
				startActivity(i);
			}
		});    
    }
}