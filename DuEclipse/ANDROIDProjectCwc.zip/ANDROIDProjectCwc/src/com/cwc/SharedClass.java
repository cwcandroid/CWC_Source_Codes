package com.cwc;

import android.app.LocalActivityManager;

public class SharedClass {
	
	public static String username=null;
	public static String password=null;
	public static String curID=null;
	static LocalActivityManager LM;
	static void setUsername(String user)
	{
		username=user;
	}
	static void setPassword(String pass)
	{
		password=pass;
	}
	static void setCurID(String id)
	{
		curID=id;
	}
	static void setLocalActivityManager(LocalActivityManager ll)
	{
		LM=ll;
	}
	static LocalActivityManager getLocalActivityManager()
	{
		return LM;
	}
}
