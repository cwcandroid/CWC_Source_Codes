package com.cwc;

public class ParserData {
	String name=null;
	String value=null;
	ParserData()
	{
		
	}
}
