package com.cwc;

import java.util.ArrayList;  
import java.util.List;  
  
import com.google.android.maps.GeoPoint;  
import com.google.android.maps.ItemizedOverlay;  
import com.google.android.maps.MapActivity;  
import com.google.android.maps.MapController;  
import com.google.android.maps.MapView;  
import com.google.android.maps.Overlay;  
import com.google.android.maps.OverlayItem;  
  
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;  
import android.os.Bundle;  
import android.view.View;
import android.widget.Toast;  
  
public class MapViewDemoActivity extends MapActivity {  

ArrayList<Integer> latitude;
ArrayList<Integer> longitude;
ArrayList<String> address;
ArrayList<String> ID;
MapView mapView;  
MapController mc;  
List<Overlay> mapOverlays;  
Drawable drawable;  
MyItemizedOverlay itemizedOverlay;  
 
void setLongitude(Cursor cursor)
{
	
	longitude.clear();
	latitude.clear();
	address.clear();
	String lon,lat;
	Double dlon = new Double(0.0);
	Double dlat = new Double(0.0);
	if(cursor.moveToFirst())
	{
		do{
			lon = cursor.getString(cursor.getColumnIndex("longitude"));
			lat = cursor.getString(cursor.getColumnIndex("latitude"));
			
			dlon = Double.parseDouble(lon) * 1000000.00;
			dlat = Double.parseDouble(lat) * 1000000.00;
			longitude.add(dlon.intValue());
			latitude.add(dlat.intValue());
			address.add(cursor.getString(cursor.getColumnIndex("address")));
			ID.add(Integer.toString(cursor.getInt(cursor.getColumnIndex("_id"))));
		}while(cursor.moveToNext());
	}
	cursor.close();
}

void creatingPoint()
{
	int length=latitude.size();
	int i=0;

	GeoPoint point;
	OverlayItem overlayitem;
	for(i=0;i<length;i++)
	{
		point = new GeoPoint(latitude.get(i),longitude.get(i));
		overlayitem = new OverlayItem(point,address.get(i),null);
		itemizedOverlay.addOverlay(overlayitem);
	}
	mapOverlays.add(itemizedOverlay); 
}

Cursor fetchFromDB()
{
	System.out.println("DBMS");
	CWCSQLite database = new CWCSQLite(this);
	System.out.println("DBMS");
	Cursor cs = database.dbFetchAll("");
	System.out.println("DBMS");
	return cs;
}

/** Called when the activity is first created. */  
@Override  
public void onCreate(Bundle savedInstanceState) {  
	super.onCreate(savedInstanceState);  
	setContentView(R.layout.map);
	System.out.println("Moja naki?");
	longitude = new ArrayList<Integer>();
	latitude = new ArrayList<Integer>();
	address = new ArrayList<String>();
	ID = new ArrayList<String>();
	
	// Capture  mapView through their layout resources  
	mapView = (MapView) findViewById(R.id.map);  
	//Get the ZoomControls from the MapView  
	mapView.setBuiltInZoomControls(true);  
	  
	// Instantiate the new fields  
	mapOverlays = mapView.getOverlays();  
	// Mark icon  
	drawable = this.getResources().getDrawable(R.drawable.icon);  
	itemizedOverlay = new MyItemizedOverlay(drawable);  
	
	System.out.println("HERE");
	//fetch Data
	Cursor cd= fetchFromDB();
	setLongitude(cd);
	System.out.println("After long");
	creatingPoint();
	System.out.println("After point");
	// Define two locations Latitude and Longitude Values  
	mapOverlays.add(itemizedOverlay);  
	//move GeoPoint 1 to center  
	mc = mapView.getController();  
	if(latitude.size() >0)
		mc.setCenter(new GeoPoint(latitude.get(0),longitude.get(0)));  
	mc.setZoom(14);  
	cd.close();
}  
  
@Override
protected void onDestroy() {
	// TODO Auto-generated method stub
	super.onDestroy();
	
}

@Override  
protected boolean isRouteDisplayed() {  
// TODO Auto-generated method stub  
	return false;  
}  
  
	//Customized  MyItemizedOverlay class  
	class MyItemizedOverlay extends ItemizedOverlay<OverlayItem> {  
		//Define an OverlayItem ArrayList, in which we'll put each of  
		// the OverlayItem objects we want on our map  
		private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();  
  
		public MyItemizedOverlay(Drawable defaultMarker) {  
			// Wrap this around our defaultMarker  
			super(boundCenterBottom(defaultMarker));  
			// TODO Auto-generated constructor stub  
		}  
  
		// Get ArrayList items  
		@Override  
		protected OverlayItem createItem(int i) {  
			// TODO Auto-generated method stub  
			return mOverlays.get(i);  
  
		}  
  
		// return OverlayItem size  
		@Override  
		public int size() {  
			// TODO Auto-generated method stub  
			return mOverlays.size();  
		}  
  
		// Show the locations message  
		@Override  
		protected boolean onTap(int index) {  
			OverlayItem item = mOverlays.get(index);  
			// Title  
			String title = item.getTitle();  
			// Snippet  
			String snippet = item.getSnippet();  
			Toast.makeText(MapViewDemoActivity.this, title + "\n" + snippet,  
					Toast.LENGTH_LONG).show();  
			
			String id=ID.get(index);
			//Intent intent=getIntent();
			Intent intent=new Intent(getApplicationContext(), ShowSingleTaskInfo.class);	
			intent.putExtra("taskId", id);
			replaceContentView("ShowSingleTaskInfo",intent );
			
			return true;  
		}
		private void replaceContentView(String id, Intent newintent) {
			
			View view=SharedClass.getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
			SharedClass.setLocalActivityManager(SharedClass.getLocalActivityManager());
			setContentView(view);
			}
  
		// Define a method in order to add new OverlayItems to our ArrayList  
		public void addOverlay(OverlayItem overlay) {  
			// add OverlayItems  
			mOverlays.add(overlay);  
			// populate  
			populate();  
		}  
	}  
}  