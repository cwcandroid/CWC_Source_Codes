package com.cwc;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.ActivityGroup;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class TasksActivity extends ActivityGroup{
	CWCSQLite database=null;
	Button button1;
	TableLayout table;
	TableRow tableRow,divRow;
	TextView firstEntry,secondEntry,divider;
	String getTodayDate()
	{
		String result=null;
		Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
 
        try {
            result= dateFormat.format(calendar.getTime());
            System.out.println("Today: " + dateFormat.format(calendar.getTime()));
            
        } catch (Exception e) {
            e.printStackTrace();
        }
       return result;
	}
	void insertInDB(String uri)
	{
		JSONParser json = new JSONParser();
		
		String response = json.getRequest(uri);
		System.out.println(response);
		try{
			JSONArray jarray = new JSONArray(response);
			ArrayList<NameValuePair> data=new ArrayList<NameValuePair>();
			int length = jarray.length();
			int i=0;
			System.out.println("Parsing....");
			for(i=0;i<length;i++)
			{
				System.out.println("Parsing....");
				JSONObject jobj= jarray.getJSONObject(i);
				data.add(new BasicNameValuePair("_id",jobj.getString("task_id")));
				data.add(new BasicNameValuePair("address",jobj.getString("address")));
				data.add(new BasicNameValuePair("comments",jobj.getString("comments")));
				data.add(new BasicNameValuePair("contactno",jobj.getString("contactno")));
				data.add(new BasicNameValuePair("description",jobj.getString("description")));
				data.add(new BasicNameValuePair("latitude",jobj.getString("latitude")));
				data.add(new BasicNameValuePair("longitude",jobj.getString("longitude")));
				data.add(new BasicNameValuePair("name",jobj.getString("name")));
				data.add(new BasicNameValuePair("status",jobj.getString("status")));
				data.add(new BasicNameValuePair("tdate",getTodayDate()));
				data.add(new BasicNameValuePair("username",SharedClass.username));
				database.dbInsert(data);
				data.clear();
			}
		}
		catch(Exception e)
		{
		}
	}
	void handleCursor(Cursor cursor)
	{
		
		cursor.moveToFirst();
		//uniqueId.clear();
		if(cursor.moveToFirst())
		{
			do{
				String name=cursor.getString(cursor.getColumnIndex("name"));
				String address= cursor.getString(cursor.getColumnIndex("address"));
				String status=cursor.getString(cursor.getColumnIndex("status"));
				final int id=cursor.getInt(cursor.getColumnIndex("_id"));
				//uniqueId.add(new Integer(id));
								
				
				tableRow = new TableRow(this);
				tableRow.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT)); 
				tableRow.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						Intent intent=new Intent(v.getContext(), ShowSingleTaskInfo.class);
						intent.putExtra("taskId", Integer.toString(id));
						replaceContentView("ShowSingleTaskInfo",intent );
					
						}
						private void replaceContentView(String id, Intent newintent) {
								View view=getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
								setContentView(view);}
				});
				firstEntry=new TextView(this);
				firstEntry.setText(name);
				firstEntry.append("\n"+address);
				 
				if(status.equals("0"))
					tableRow.setBackgroundColor(Color.GRAY);
				else
					tableRow.setBackgroundColor(Color.DKGRAY);

				 
				 tableRow.setPadding(0,10, 0, 10);
				 tableRow.addView(firstEntry);
				// tableRow.addView(secondEntry);	
				 
				 divRow=new TableRow(this);
				 divRow.setLayoutParams(new LayoutParams(
							LayoutParams.FILL_PARENT,
							LayoutParams.WRAP_CONTENT));
				 
				divider=new TextView(this);
				divider.setHeight(5);						
				divRow.setBackgroundColor(Color.WHITE);
				divRow.addView(divider);
				table.addView(tableRow);
				table.addView(divRow);
				System.out.println(address+" "+name);
			}while(cursor.moveToNext());
		}
		
	}
	Cursor fetchFromDB()
	{
		Cursor cs = database.getByDateUser(getTodayDate(), SharedClass.username);
		//Cursor cs = database.getById(190);
		return cs;
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tasks);
		database = new CWCSQLite(this);
		//database.dropTable(); //c
		//database.createDB();
		//database.deleteTaskTable();
		//fetching and inserting data to database
		
		String taskUrl=getResources().getString(R.string.gettask_uri);
		taskUrl += "&duedate=" + getTodayDate() + "&username=" + SharedClass.username;
		//insert into db
		insertInDB(taskUrl);
		//fetching from db
		Cursor cs = fetchFromDB();
		
		
		Button mapbut=(Button)findViewById(R.id.button1);
		mapbut.setText("Show Map");
        mapbut.setGravity(Gravity.RIGHT);
        
		table=(TableLayout)findViewById(R.id.multitable);
		handleCursor(cs);
		mapbut.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
			Intent intent=new Intent(v.getContext(), MapViewDemoActivity.class);
			replaceContentView("MapViewDemoActivity",intent );}
			private void replaceContentView(String id, Intent newintent) {
					View view=getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
					SharedClass.setLocalActivityManager(getLocalActivityManager());
					setContentView(view);}
			});
		//database.dropTable();
	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
	
	
}
