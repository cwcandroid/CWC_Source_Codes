package com.cwc;

import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CWCCourierClientRegistrationActivity extends Activity{
	Button btnLogin, btnSubmit;
	EditText edtUser,edtEmail,edtPassword,edtConPassword;
	protected void alertbox(String title,String message)
	{
		Builder alertBox = new AlertDialog.Builder(this);
		alertBox.setMessage(message);
		alertBox.setTitle(title);
		alertBox.setCancelable(true);
		alertBox.setNeutralButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int whichButton) {
				// TODO Auto-generated method stub
				
			}
		});
		alertBox.show();
	}
	
	public final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(
	          "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
	          "\\@" +
	          "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
	          "(" +
	          "\\." +
	          "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
	          ")+"
	      );

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		
		btnLogin=(Button)findViewById(R.id.button2);
		btnSubmit=(Button)findViewById(R.id.button1);
		
		edtUser = (EditText)findViewById(R.id.editText1);
		edtEmail = (EditText)findViewById(R.id.editText4);
		edtPassword = (EditText)findViewById(R.id.editText2);
		edtConPassword = (EditText)findViewById(R.id.editText3);
		btnLogin.setOnClickListener(new View.OnClickListener() {
		
			@Override
			public void onClick(View v) {
				Intent i=new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientLoginActivity.class);
				startActivity(i);
				
			}
		});
		
		btnSubmit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TO DO: user input validation
				// TO DO: Submit request for registration and handle different error cases
				//checked all empty, password verify, and valid email address
				if(edtUser.getText().toString().equals(""))
				{
					alertbox("Error","Blank Username Field");
					return;
				}
				if( edtEmail.getText().toString().equals("") )
				{
					alertbox("Error","Blank Email Field");
					return;
				}
				/*if(EMAIL_ADDRESS_PATTERN.matcher(edtEmail.getText().toString()).matches() ==false)
				{
					alertbox("Error","Invalid Email Address");
					return;
				}*/
				if(edtPassword.getText().toString().equals(""))
				{
					alertbox("Error","Blank Password Field");
					return;
				}
				if(edtPassword.getText().toString().equals(edtConPassword.getText().toString()) == false)
				{
					alertbox("Error","Both Password are not same");
					return;
				}
				
				
				
				JSONParser jparser = new JSONParser();
				String request = getResources().getString(R.string.reg_uri); //getting reg_uri from xml string
				//String request = "http://10.0.2.2/android/register.php?returnType=json";
				request += "&username=" + edtUser.getText().toString() + "&password="+edtPassword.getText().toString() +
				"@email="+edtEmail.getText().toString();
				
				String result = jparser.getRequest(request);
				if( jparser.isValidReg(result) )
				{
					Intent i=new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientLoginActivity.class);
					startActivity(i);
				}
				else
				{
					alertbox("Error Message","Registration Failed");
				}
			}
		});
		
	}

}
