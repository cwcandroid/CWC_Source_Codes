package com.cwc;



import android.app.ActivityGroup;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class ShowSingleTaskInfo extends ActivityGroup
{
	TextView show;
	Button showOnMap,contactNo;
	String mobileNo;
	Button task;
	
	void ShowInfoById(String id)
	{
		CWCSQLite database = new CWCSQLite(this);
		//Cursor cs = database.getById(Integer.parseInt(id));
		Cursor cs = database.getByIdUser((Integer.parseInt(id)),SharedClass.username);
		if(cs.moveToFirst())
		{
			do{
				show.append("Name : "+cs.getString(cs.getColumnIndex("name"))+"\n");
				show.append("Item Id : "+cs.getString(cs.getColumnIndex("_id"))+"\n");
				show.append("Receiver Name : \n");
				show.append("Receiver Address : "+cs.getString(cs.getColumnIndex("address"))+"\n");
				mobileNo=cs.getString(cs.getColumnIndex("contactno"));
			}while(cs.moveToNext()); 
		}
		database.close();
		cs.close();
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.singleinfo);
		show=(TextView)findViewById(R.id.text);
		task=(Button)findViewById(R.id.reptask);
		task.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(v.getContext(), ReportTask.class);
				replaceContentView("ReportTask",intent );
				}
				private void replaceContentView(String id, Intent newintent) {
					View view=getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
					SharedClass.setLocalActivityManager(getLocalActivityManager());
					setContentView(view);
			}
		});
		Bundle extras=getIntent().getExtras();
		String value=null;
		if(extras!=null)
		{
			value=extras.getString("taskId");
			SharedClass.setCurID(value);
			//Fetch all data from database using taskId as _id
			//and append it in show textView
			
		}
		//show.append(value);
		ShowInfoById(value);
		//System.out.println(mobileNo);
		showOnMap=(Button)findViewById(R.id.viewmap);
		showOnMap.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				// TODO Auto-generated method stub
				//here replace intent to MapView Intent 
				Intent intent=new Intent(v.getContext(), TaskSubViewMap.class);
				replaceContentView("TaskSubViewMap",intent );
				}
				private void replaceContentView(String id, Intent newintent) {
					View view=getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
					SharedClass.setLocalActivityManager(getLocalActivityManager());
					setContentView(view);
					}
			
		});
		contactNo=(Button)findViewById(R.id.num);
		contactNo.setText(mobileNo);
		contactNo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent callIntent= new Intent(Intent.ACTION_CALL);
				callIntent.setData(Uri.parse("tel:"+mobileNo.toString()));
				callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(callIntent);
				
			}
		});
		
		
		
		
	}

/*	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Intent intent=new Intent(this, MultipleRow.class);
		replaceContentView("ShowSingleEntry",intent );}
		private void replaceContentView(String id, Intent newintent) {
			View view=getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
			setContentView(view);
	}*/
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
}

