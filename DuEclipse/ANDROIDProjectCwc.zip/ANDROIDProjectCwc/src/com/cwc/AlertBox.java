package com.cwc;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;

public class AlertBox {
	Builder alertBox=null;
	AlertBox(Builder alertBox,String title,String message)
	{
		this.alertBox=alertBox;
		alertBox.setMessage(message);
		alertBox.setTitle(title);
		alertBox.setCancelable(true);
		alertBox.setNeutralButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int whichButton) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}


	void show()
	{
		alertBox.show();
	}
}
