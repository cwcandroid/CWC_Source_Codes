package com.cwc;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.cwc.MapViewDemoActivity.MyItemizedOverlay;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class TaskSubViewMap extends MapActivity {
	Button infoButton,task;
	String taskId,latitude,longitude;
	MapView mapView;  
    MapController mc;  
    List<Overlay> mapOverlays;  
    Drawable drawable;  
    MyItemizedOverlay itemizedOverlay;
	void ShowInfoById(String id)
	{
		CWCSQLite database = new CWCSQLite(this);
		//Cursor cs = database.getById(Integer.parseInt(id));
		Cursor cs = database.getByIdUser((Integer.parseInt(id)),SharedClass.username);

		if(cs.moveToFirst())
		{
			do{
				latitude=cs.getString(cs.getColumnIndex("latitude"));
				longitude=cs.getString(cs.getColumnIndex("longitude"));;
				
			}while(cs.moveToNext()); 
		}
		
		
		database.close();
		cs.close();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
			setContentView(R.layout.submap);
			 taskId=SharedClass.curID;
			 
			 	ShowInfoById(taskId);
			    mapView = (MapView) findViewById(R.id.sub_map);  
			    mapView.setBuiltInZoomControls(true);  
			    mapOverlays = mapView.getOverlays();  
			    drawable = this.getResources().getDrawable(R.drawable.icon); 
			    itemizedOverlay = new MyItemizedOverlay(drawable);  
			    Double lat = Double.parseDouble(latitude) * 1E6;  
			    Double lng = Double.parseDouble(longitude) * 1E6;  		   
			    GeoPoint point = new GeoPoint(lat.intValue(), lng.intValue());  
			    OverlayItem overlayitem = new OverlayItem(point, null,  null);  
			    itemizedOverlay.addOverlay(overlayitem);
			    mapOverlays.add(itemizedOverlay);  
			   
			   task=(Button)findViewById(R.id.reptask1);
				task.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent intent=new Intent(v.getContext(), ReportTask.class);
						replaceContentView("ReportTask",intent );
						}
						private void replaceContentView(String id, Intent newintent) {
							View view=SharedClass.getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
							SharedClass.setLocalActivityManager(SharedClass.getLocalActivityManager());
							setContentView(view);
					}
				});
				
			    infoButton=(Button)findViewById(R.id.info);
			    infoButton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub					
					Intent intent=new Intent(v.getContext(), ShowSingleTaskInfo.class);
					intent.putExtra("taskId", SharedClass.curID);
					replaceContentView("ShowSingleTaskInfo",intent );
				
					}
					private void replaceContentView(String id, Intent newintent) {
							//View view=getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
							View view = SharedClass.getLocalActivityManager().startActivity(id, newintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)).getDecorView();
							setContentView(view);}
			});
			    
			    mc = mapView.getController();  
			    mc.setCenter(point);  
			    mc.setZoom(15);  
			
	
	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
	//Customized  MyItemizedOverlay class  
	class MyItemizedOverlay extends ItemizedOverlay<OverlayItem> {  
		//Define an OverlayItem ArrayList, in which we'll put each of  
		// the OverlayItem objects we want on our map  
		private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();  
  
		public MyItemizedOverlay(Drawable defaultMarker) {  
			// Wrap this around our defaultMarker  
			super(boundCenterBottom(defaultMarker));  
			// TODO Auto-generated constructor stub  
		}  
  
		// Get ArrayList items  
		@Override  
		protected OverlayItem createItem(int i) {  
			// TODO Auto-generated method stub  
			return mOverlays.get(i);  
  
		}  
  
		// return OverlayItem size  
		@Override  
		public int size() {  
			// TODO Auto-generated method stub  
			return mOverlays.size();  
		}  
  
		// Show the locations message  
		@Override  
		protected boolean onTap(int index) {  
			OverlayItem item = mOverlays.get(index);  
			// Title  
			String title = item.getTitle();  
			// Snippet  
			String snippet = item.getSnippet();  
			//Toast.makeText(TaskSubViewMap.this, title + "\n" + snippet,  
				//	Toast.LENGTH_LONG).show();  
			return true;  
		}  
  
		// Define a method in order to add new OverlayItems to our ArrayList  
		public void addOverlay(OverlayItem overlay) {  
			// add OverlayItems  
			mOverlays.add(overlay);  
			// populate  
			populate();  
		}  
	}	

}
