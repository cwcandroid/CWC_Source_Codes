package com.cwc;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;


public class JSONParser{
	HttpClient client;
	HttpPost post;
	HttpGet get =null;
	HttpResponse response = null;
	HttpEntity entity=null;
	InputStream inputstream=null;
	BufferedReader reader=null;
	StringBuilder stringbuffer=null;
	String result=null;
	JSONParser()
	{
		
	}
	ArrayList<NameValuePair> getNameValuePair(ArrayList<String> value)
	{
		ArrayList<NameValuePair> namevaluepair = new ArrayList<NameValuePair>();
		int length = value.size();
		int i=0;
		for(i=0;i<length;i+=2)
		{
			namevaluepair.add(new BasicNameValuePair(value.get(i),value.get(i+1)));
		}
		return namevaluepair;
	}
	String getStringFromResponse(HttpResponse response)
	{
		String result="";
		try
		{
			entity = response.getEntity();
			inputstream = entity.getContent();
			stringbuffer = new StringBuilder();
			reader = new BufferedReader(new InputStreamReader(inputstream));
			String line=null;
			while((line = reader.readLine())!=null)
			{
				stringbuffer.append(line);
			}
		}
		catch(Exception e){}
		if(stringbuffer !=null)
			result = stringbuffer.toString();
		return result;
	}
	boolean isValidLogin(String str)
	{
		boolean bresult=false;
		/*try{
			JSONArray jarray = new JSONArray(str);
			JSONObject obj = jarray.getJSONObject(jarray.length()-1);
			if( obj.getString("status").equals("true") )
			{
				bresult=true;
			}
		}*/
		try{
			//JSONArray jarray = new JSONArray(str);
			JSONObject obj = new JSONObject(str);
			if( obj.getString("status").equals("true") )
			{
				bresult=true;
			}
		}
		
		catch(Exception e){}
		return bresult;
	}
	boolean isValidReg(String str)
	{
		boolean bresult=false;
		try{
			JSONArray jarray = new JSONArray(str);
			JSONObject obj = jarray.getJSONObject(0);
			if( obj.getString("status").equals("Success") )
			{
				bresult=true;
			}
		}
		catch(Exception e){}
		return bresult;
	}
	String getRequest(String request) //send get request
	{
		try{
			client = new DefaultHttpClient();
			get = new HttpGet(request);
			response = client.execute(get); //executing get request
			int statuscode = response.getStatusLine().getStatusCode();
			if(statuscode == 200) //internet is ok
			{
				result = getStringFromResponse(response);
			}
			else if(statuscode == 404) //file not found in server
				result=Integer.toString(statuscode) + " error";
			else
				result=statuscode + " error";
		}
		catch(Exception e){
			//result="[{'status':'false'}]";
			e.printStackTrace();
		}
		
		return result;
	}
	String postRequest(String serverLink,ArrayList<NameValuePair> request)
	{
		try{
			client = new DefaultHttpClient();
			post = new HttpPost(serverLink);
			post.setEntity(new UrlEncodedFormEntity(request));
			response = client.execute(post);
			int statuscode = response.getStatusLine().getStatusCode();
			if(statuscode == 200)
			{
				result = getStringFromResponse(response);
			}
			else if(statuscode == 404)
			{
				result=Integer.toString(statuscode) + " error";
			}
			else{
				result=Integer.toString(statuscode) + " error";
			}
		}
		catch(Exception e){}
		return result;
	}
}
//JSONArray jArray = new JSONArray(result);	
//JSONObject json_data = jArray.getJSONObject(i);	
        