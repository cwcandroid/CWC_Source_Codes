package com.cwc;

import android.app.Activity;
import android.os.Bundle;

public class PerformanceActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.performance);
	}
}
