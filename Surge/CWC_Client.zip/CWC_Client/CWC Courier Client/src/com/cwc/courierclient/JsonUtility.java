package com.cwc.courierclient;

import android.util.Log;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class JsonUtility {
	
	private static final String TAG = JsonUtility.class.getSimpleName();
    //private static final String BASE_URL = "http://test.sentisol.com/cwc/index.php/android/";
    private static final String BASE_URL = "http://192.168.1.2/cwc/index.php/android/";
	
	public String getJsonResponse(String urlAddress) {
        urlAddress = BASE_URL + urlAddress;
		
        try {
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet();
            request.setURI(new URI(urlAddress));
            HttpResponse response = client.execute(request);
            InputStream ips  = response.getEntity().getContent();
            BufferedReader buf = new BufferedReader(new InputStreamReader(ips,"UTF-8"));

            StringBuilder sb = new StringBuilder();
            String s;
            while(true )
            {
                s = buf.readLine();
                if(s==null || s.length()==0)
                    break;
                sb.append(s);

            }
            buf.close();
            ips.close();

            Log.d(TAG, sb.toString());

            return sb.toString();

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (ClientProtocolException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (URISyntaxException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } finally {
            // any cleanup code...
        }
        return null;
    }

    public ArrayList<HashMap<String, String>> getJsonResponseForTaskList (String urlAddress) {
        ArrayList<HashMap<String, String>> ret = new ArrayList<HashMap<String, String>>();


        String jsonResponse = getJsonResponse(urlAddress);

        Log.d(TAG, "json: " + jsonResponse);

        try{

            JSONArray jsonArray = new JSONArray(jsonResponse);

            for ( int i = 0; i < jsonArray.length(); i++ ) {

                JSONObject jsonObject = jsonArray.getJSONObject(i);
                HashMap<String, String> jsonDataMap = new HashMap<String, String>();

                jsonDataMap.put("address", jsonObject.getString("address"));
                jsonDataMap.put("comments", jsonObject.getString("comments"));
                jsonDataMap.put("contactno", jsonObject.getString("contactno"));
                Log.d(TAG, "contactno" + jsonObject.getString("contactno"));
                jsonDataMap.put("description", jsonObject.getString("description"));
                jsonDataMap.put("latitude", jsonObject.getString("latitude"));
                jsonDataMap.put("longitude", jsonObject.getString("longitude"));
                jsonDataMap.put("name", jsonObject.getString("name"));
                jsonDataMap.put("status", jsonObject.getString("status"));
                //jsonDataMap.put("id", jsonObject.getString("id"));
                jsonDataMap.put("duetime", jsonObject.getString("duetime"));

                ret.add(jsonDataMap);
            }
        }catch(JSONException e)        {
            Log.e(TAG, "Error parsing data "+e.toString());
        }

        return ret;
    }

    public ArrayList<HashMap<String, String>> getJsonResponseForHistoryList (String urlAddress) {
        ArrayList<HashMap<String, String>> ret = new ArrayList<HashMap<String, String>>();


        String jsonResponse = getJsonResponse(urlAddress);

        Log.d(TAG, "json: " + jsonResponse);

        try{

            JSONArray jsonArray = new JSONArray(jsonResponse);

            for ( int i = 0; i < jsonArray.length(); i++ ) {
                HashMap<String, String> map = new HashMap<String, String>();
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                map.put("address", jsonObject.getString("address"));
                map.put("comments", jsonObject.getString("comments"));
                map.put("contactno", jsonObject.getString("contactno"));
                map.put("description", jsonObject.getString("description"));
                map.put("latitude", jsonObject.getString("latitude"));
                map.put("longitude", jsonObject.getString("longitude"));
                map.put("name", jsonObject.getString("name"));
                map.put("status", jsonObject.getString("status"));
                map.put("reasontype", jsonObject.getString("reasontype"));
                map.put("reasondetails", jsonObject.getString("reasondetails"));
                map.put("reportlatitude", jsonObject.getString("reportlatitude"));
                map.put("reportlongitude", jsonObject.getString("reportlongitude"));
                map.put("signaturefile", jsonObject.getString("signaturefile"));
                map.put("duedate", jsonObject.getString("duedate"));

                ret.add(map);
            }
        }catch(JSONException e)        {
            Log.e(TAG, "Error parsing data "+e.toString());
        }

        return ret;
    }

}

