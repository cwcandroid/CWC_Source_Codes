package com.cwc.courierclient;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HistoryDetailsActivity extends Activity {
	/**
	 * @see android.app.Activity#onCreate(Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history_details);

		
		TextView textView = (TextView) findViewById(R.id.tvItemName);
		textView.setText(textView.getText() + getIntent().getExtras().getString("ItemName"));
		
		textView = (TextView) findViewById(R.id.tvItemId);
		textView.setText(textView.getText() + getIntent().getExtras().getString("ItemId"));
		
		textView = (TextView) findViewById(R.id.tvReceiverAddress);
		textView.setText(textView.getText() + getIntent().getExtras().getString("ReceiverAddress"));
		
		textView = (TextView) findViewById(R.id.tvPhoneNumber);
		textView.setText(getIntent().getExtras().getString("contactno"));
		
		textView = (TextView) findViewById(R.id.tvDeliveredOn);
		textView.setText(textView.getText() + getIntent().getExtras().getString("duedate"));
		
		textView = (TextView) findViewById(R.id.tvStatus);
		textView.setText(textView.getText() + getIntent().getExtras().getString("reasondetails"));
		
		textView = (TextView) findViewById(R.id.tvComments);
		textView.setText(textView.getText() + getIntent().getExtras().getString("comments"));

        Button btnViewOnMap = (Button) findViewById(R.id.btnViewOnMap);
        btnViewOnMap.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(HistoryDetailsActivity.this, DisplayMap.class);

                intent.putExtra("latitudeArray", new int [] {getIntent().getExtras().getInt("latitude")});
                intent.putExtra("longitudeArray",  new int [] {getIntent().getExtras().getInt("longitude")});
                intent.putExtra("addressArray", new String [] {getIntent().getExtras().getString("ReceiverAddress")});
                intent.putExtra("layout", R.layout.display_map);

                View view = HistoryActivityGroup.group.getLocalActivityManager()
                    .startActivity("DisplayMap", intent
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                    .getDecorView();

                HistoryActivityGroup.group.replaceView(view);
            }
        });
		
	}
}
