package com.cwc.courierclient;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

public class HistoryActivity extends ListActivity {
	
	private static final String TAG = HistoryActivity.class.getSimpleName();
	ArrayList<HashMap<String, String>> taskList = new ArrayList<HashMap<String, String>>();
    TaskListAdapter taskListAdapter;
    CheckBox checkBoxFilterByDate;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.history);
        
        checkBoxFilterByDate = (CheckBox) findViewById(R.id.chkFilterByDate);
        checkBoxFilterByDate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if ( checkBoxFilterByDate.isChecked() ) {
                    sortArrayListByDate();
                    Log.d(TAG, "checkbox filter clicked!");
                    taskListAdapter.notifyDataSetChanged();
                    setTaskListAdapter();

                }
            }
        });

		//  http://test.sentisol.com/cwc/index.php/android/getTaskHistory?username=cwcuser1&returnType=json
		String urlAddress = "getTaskHistory?username="
				+ "cwcuser1"
				// + getPrefsString("user_name") 
				+ "&returnType=xml";
		
		Log.d(TAG, "url: " + urlAddress);

		//JsonUtility util = new JsonUtility();
		//taskList = util.getJsonResponseForHistoryList(urlAddress);

        XmlUtility utility = new XmlUtility();
        taskList = utility.getXmlResponseForHistoryList(urlAddress);
		
		Log.d(TAG, "length: " + taskList.size());

        setTaskListAdapter ();

	}

    private void setTaskListAdapter() {
        //To change body of created methods use File | Settings | File Templates.
        int listSize = taskList.size();

        String strProductName [] = new String[listSize];
        String strAddress [] = new String[listSize];
        int taskStatus [] = new int[listSize];

        for ( int i = 0; i <listSize; i++ ) {
            strProductName [i] = taskList.get(i).get("name");
            strAddress [i] = taskList.get(i).get("address");
            taskStatus [i] = Integer.parseInt(taskList.get(i).get("status"));
        }

        taskListAdapter = new TaskListAdapter(this, strProductName, strAddress, taskStatus);

        setListAdapter(taskListAdapter);
        taskListAdapter.setNotifyOnChange(true);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {

        HashMap<String, String> map = taskList.get(position);
        Toast.makeText(HistoryActivity.this, map.get("duedate"), Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(HistoryActivity.this, HistoryDetailsActivity.class);
        intent.putExtra("ItemName", map.get("name"));
        intent.putExtra("ItemId", map.get("id"));
        intent.putExtra("ReceiverAddress", map.get("address"));
        intent.putExtra("contactno", map.get("contactno"));
        intent.putExtra("duedate", map.get("duedate"));
        intent.putExtra("reasondetails", map.get("reasondetails"));
        intent.putExtra("signaturefile", map.get("signaturefile"));
        intent.putExtra("comments", map.get("comments"));
        intent.putExtra("latitude", (int)(Double.parseDouble(map.get("latitude")) * 1e6));
        intent.putExtra("longitude", (int)(Double.parseDouble(map.get("longitude")) * 1e6));



        View view = HistoryActivityGroup.group.getLocalActivityManager()
            .startActivity("HistoryDetailsActivity", intent
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            .getDecorView();

        HistoryActivityGroup.group.replaceView(view);
    }

    private void sortArrayListByDate () {
        HashMap<String, String> tmp;

        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");

        for ( int i = 0; i < taskList.size(); i++ ) {
            for ( int j = i + 1; j < taskList.size(); j++ ) {
                try {
                    if ( df.parse(taskList.get(i).get("duedate")).compareTo(df.parse(taskList.get(j).get("duedate"))) < 0  ) {
                        tmp = taskList.get(i);
                        taskList.set(i, taskList.get(j));
                        taskList.set(j, tmp);
                    }
                } catch (ParseException e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        }
    }
}
