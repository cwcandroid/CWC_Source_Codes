package com.cwc.courierclient;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.google.android.maps.*;

import java.util.List;

public class DisplayMap extends MapActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getIntent().getExtras().getInt("layout"));
        
        if ( getIntent().getExtras().getInt("layout") == R.layout.display_map_small ) {
        	Button btnReportTask = (Button) findViewById(R.id.btnReportTask);
        	btnReportTask.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					startActivity(new Intent(DisplayMap.this, ReportTaskActivity.class));
				
					Intent intent = new Intent(DisplayMap.this, ReportTaskActivity.class);
				
					View view = TaskActivityGroup.group.getLocalActivityManager()
					        .startActivity("ReportTaskActivity", intent
					        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					        .getDecorView();
					
					TaskActivityGroup.group.replaceView(view);
						 
					}
			});
        }
        
        MapView mapView = (MapView) findViewById(R.id.themap);
        mapView.setBuiltInZoomControls(true);
        mapView.getController().setZoom(14);

        List<Overlay> mapOverlays = mapView.getOverlays();
        Drawable drawable = this.getResources().getDrawable(R.drawable.pushpin);
        MapViewItemizedOverlay itemizedoverlay = new MapViewItemizedOverlay(drawable, this);
        
        int lat [] = getIntent().getExtras().getIntArray("latitudeArray");
        int lon [] = getIntent().getExtras().getIntArray("longitudeArray");
        String strAddress [] = getIntent().getExtras().getStringArray("addressArray");
        
        GeoPoint coordinatePoint;
        OverlayItem mapOverlayItem;
        
        for ( int i = 0; i < lat.length; i++ ) {
        	coordinatePoint = new GeoPoint(lat [i], lon [i]);
        	mapOverlayItem = new OverlayItem(coordinatePoint, strAddress [i], strAddress [i]);
        	itemizedoverlay.addOverlay(mapOverlayItem);
            mapView.getController().setCenter(coordinatePoint);
        }
        
        mapOverlays.add(itemizedoverlay);
    }

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
}
