package com.cwc.courierclient;

import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

public class CurrentGpsData implements LocationListener {

    String providerString;
	Location location = null;
	
	public CurrentGpsData (Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
		Criteria criteria = new Criteria();
		providerString = locationManager.getBestProvider(criteria, false);
		location = locationManager.getLastKnownLocation(providerString);
	}
	
	public int getCurrentLatitude () {
		if ( location != null ) {
			return (int) location.getLatitude();
		} 
		return 0;
	}
	
	public int getCurrentLongitude () {
		if ( location != null ) {
			return (int) location.getLongitude();
		}
		return 0;
	}
	
	@Override
	public void onLocationChanged(Location arg0) {

	}

	@Override
	public void onProviderDisabled(String arg0) {

	}

	@Override
	public void onProviderEnabled(String arg0) {

	}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {

	}

}
