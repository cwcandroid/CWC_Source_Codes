package com.cwc.courierclient;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by IntelliJ IDEA.
 * User: KITTY
 * Date: 1/28/12
 * Time: 6:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationHistory extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_history);
    }
}