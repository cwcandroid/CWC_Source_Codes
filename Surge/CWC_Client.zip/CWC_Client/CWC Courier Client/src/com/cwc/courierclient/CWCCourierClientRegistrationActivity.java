package com.cwc.courierclient;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CWCCourierClientRegistrationActivity extends Activity{

	Button btnBackToLogin, btnSubmit;
    EditText editTextUserId, editTextEmailAddress, editTextPassword, editTextConfirmPassword;

    private static final String TAG = CWCCourierClientRegistrationActivity.class.getSimpleName();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		
		btnBackToLogin =(Button)findViewById(R.id.btnBacktoLogin);
		btnSubmit=(Button)findViewById(R.id.btnSubmit);
        editTextUserId = (EditText) findViewById(R.id.etUserName);
        editTextEmailAddress = (EditText) findViewById(R.id.etEmail);
        editTextPassword = (EditText) findViewById(R.id.etPassword);
        editTextConfirmPassword = (EditText) findViewById(R.id.etConfirmPassword);
		
		btnBackToLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientLoginActivity.class);
                startActivity(i);
            }
        });
		
		btnSubmit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TO DO: user input validation
				// TO DO: Submit request for registration and handle different error cases

                if ( !isInternetAvailable() ) return;

                if ( userInputValidation() ) {
                    String urlAddress = "register?username="  +
                        editTextUserId.getText().toString() +
                        "&password=" + 
                        editTextPassword.getText().toString() + 
                        "&returnType=json&email=" + 
                        editTextEmailAddress.getText().toString();
                    
                    Log.d(TAG + "url: ", urlAddress);
                    
                    JsonUtility jsonUtility = new JsonUtility();
                    String jsonResponse  = jsonUtility.getJsonResponse(urlAddress);
                    Log.d(TAG + "json: ", jsonResponse);
                    
                    try {
                        JSONObject jsonObject = new JSONObject(jsonResponse); // 
                        if ( jsonObject.getString("status").equals("Success") ) { // {"status":"Success"}
                        	Toast.makeText(getApplicationContext(), "Registration Successful!!", Toast.LENGTH_LONG).show();
                        	startActivity(new Intent(CWCCourierClientRegistrationActivity.this, CWCCourierClientLoginActivity.class));
                        	
                        } else { // {"status":"Failed","text":"Email already exist."}
                        	AlertDialog.Builder builder = new AlertDialog.Builder(CWCCourierClientRegistrationActivity.this);
                            builder.setMessage("Email Already Exist")
                                .setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // put your code here
                                    }
                                }).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();  
                    }  
                }

            }
		});
		
	}
    
    private boolean userInputValidation () {
        Pattern pattern;
        Matcher matcher;

        // user id validation
        pattern = Pattern.compile("^[a-z0-9_-]{3,15}$");
        matcher = pattern.matcher(editTextUserId.getText().toString());

        if (!matcher.matches() ) {
            Toast.makeText(getApplicationContext(), "User Id Invalid Format", Toast.LENGTH_LONG).show();
            Log.d(TAG, "user id invalid!!");
            return false;
        }

        // email id validation
        pattern = Pattern.compile("[A-Za-z0-9.@_-~#]+");
        String str = editTextEmailAddress.getText().toString();
        matcher = pattern.matcher(str);

        if ( !matcher.matches() ) {
            Toast.makeText(getApplicationContext(), "Email Id Invalid Format", Toast.LENGTH_LONG).show();
            Log.d(TAG, "email id invalid!!");
            return false;
        }


        // password validation
        String password = editTextPassword.getText().toString();
        String confirmPassword = editTextConfirmPassword.getText().toString();
        
        if ( password.length() == 0 || confirmPassword.length() == 0 ) {
            Toast.makeText(getApplicationContext(), "Password Field Empty", Toast.LENGTH_LONG).show();
            Log.d(TAG, "password field empty");
            return false;

        } else if ( !password.equals(confirmPassword) ) {
            Toast.makeText(getApplicationContext(), "Both Password donot match", Toast.LENGTH_LONG).show();
            Log.d(TAG, "password invalid!!");
            return false;
        }

        return true;
    }

    private boolean isInternetAvailable () {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CWCCourierClientLoginActivity.CONNECTIVITY_SERVICE);

        if ( connectivityManager.getActiveNetworkInfo() != null &&
            connectivityManager.getActiveNetworkInfo().isAvailable() &&
            connectivityManager.getActiveNetworkInfo().isConnectedOrConnecting() ) {
            return true;
        }
        Toast.makeText(CWCCourierClientRegistrationActivity.this, "Internet Not Available", Toast.LENGTH_LONG).show();
        return false;
    }

}