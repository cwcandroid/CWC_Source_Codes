package com.cwc.courierclient;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class PerformanceActivity extends Activity {

    private static final String TAG = PerformanceActivity.class.getSimpleName();
    ArrayList<HashMap<String, String>> taskList = new ArrayList<HashMap<String, String>>();
    int totalDelivered;
    final int RECORD = 7;
    String[] horlabels = new String[RECORD];  
    float[] values = new float[RECORD];
    

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        parseJsonResponse ();
        generateData ();

        //values = new float[] { 2.0f,1.5f, 2.5f, 1.0f , 3.0f, 5.0f, 2.5f };
        String[] verlabels = new String[] { "more", "7", "6", "5", "4", "3", "2", "1", "0" };
        //String[] horlabels = new String[] { "1", "2", "3", "4", "5", "6", "7", "8" };
        GraphView graphView = new GraphView(this, values, "Total Items Delivered: " + totalDelivered,horlabels, verlabels, GraphView.LINE);
        setContentView(graphView);
    }

    private void generateData() {

        long maximumTimeInMilis = Calendar.getInstance().getTimeInMillis();
        long oneDayInMilis = 24 * 60 * 60 * 1000;
        long minimumTimeInMilis = maximumTimeInMilis - (RECORD * oneDayInMilis);
        
        Log.d(TAG, "maxi: " + maximumTimeInMilis);
        Log.d(TAG, "one: " + oneDayInMilis);
        Log.d(TAG, "mini: " + minimumTimeInMilis);


        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        long inputTime = 0;

        for (HashMap<String, String> aTaskList : taskList) {
            try {
                inputTime = df.parse(aTaskList.get("duedate")).getTime();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (minimumTimeInMilis <= inputTime && inputTime <= maximumTimeInMilis && Integer.parseInt(aTaskList.get("status")) == 1) {  // delivered task
                values[(int) ((inputTime - minimumTimeInMilis) / oneDayInMilis)]++;
                totalDelivered++;
            }
        }
        
        Date date = new Date();

        for ( int i = 0; i < RECORD; i++ ) {
            Log.d(TAG, "" + i + ": " + (minimumTimeInMilis + oneDayInMilis * (i + 1)));
            date.setTime(minimumTimeInMilis + oneDayInMilis * (i + 1));
            horlabels [i] = Integer.toString(date.getDate()) + "/" + Integer.toString(date.getMonth() + 1);
        }


    }

    private void parseJsonResponse() {

        //  http://test.sentisol.com/cwc/index.php/android/getTaskHistory?username=cwcuser1&returnType=json
        String urlAddress = "getTaskHistory?username="
            + "cwcuser1"
            // + getPrefsString("user_name")
            + "&returnType=json";

        Log.d(TAG, "url: " + urlAddress);

        JsonUtility jsonUtility = new JsonUtility();
        String jsonResponse = jsonUtility.getJsonResponse(urlAddress);

        Log.d(TAG, "json: " + jsonResponse);

        try{

            JSONArray jsonArray = new JSONArray(jsonResponse);

            for ( int i = 0; i < jsonArray.length(); i++ ) {
                HashMap<String, String> map = new HashMap<String, String>();
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                map.put("status", jsonObject.getString("status"));
                map.put("duedate", jsonObject.getString("duedate"));

                taskList.add(map);
            }
        }catch(JSONException e)        {
            Log.e(TAG, "Error parsing data "+e.toString());
        }

        Log.d(TAG, "length: " + taskList.size());

    }
}