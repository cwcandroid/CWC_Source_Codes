package com.cwc.courierclient;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class TaskListAdapter extends ArrayAdapter<String> {
	
	private final Context context;
	private final String[] strProductName;
	private final String[] strAddress;
	private final int [] taskStatus;

	public TaskListAdapter(Context context, String[] strProductName, String [] strAddress, int [] taskStatus ) {
		super(context, R.layout.list_items, strProductName);
		this.context = context;
		this.strProductName = strProductName;
		this.strAddress = strAddress;
		this.taskStatus = taskStatus;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		View rowView = inflater.inflate(R.layout.list_items, parent, false);
		TextView textView = (TextView) rowView.findViewById(R.id.tvName);
		ImageView imageView = (ImageView) rowView.findViewById(R.id.iconTask);
		TextView subTextView = (TextView) rowView.findViewById(R.id.tvAddress);
		textView.setText( strProductName [position] );
		subTextView.setText( strAddress [position] );
		
		// Change the icon based on taskStatus
		if ( taskStatus [position] == 0 ) {	// incomplete
			imageView.setImageResource(R.drawable.incomplete_task_red);
		} else if ( taskStatus [position] == 1 ) {	// complete 
			imageView.setImageResource(R.drawable.complete_task_green);
		} else {// pending
			imageView.setImageResource(R.drawable.pending_task_yellow);
		}

		return rowView;
	}

}
