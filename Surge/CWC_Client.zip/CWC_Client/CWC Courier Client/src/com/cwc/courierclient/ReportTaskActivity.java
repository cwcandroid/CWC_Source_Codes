package com.cwc.courierclient;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

public class ReportTaskActivity extends Activity {

	Button btnLocateMe, btnTakeSignature, btnSubmit, btnCancel;
	Spinner spinnerTaskOptions;
	ImageView imageViewSignature;

	/**
	 * @see android.app.Activity#onCreate(Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		View viewToLoad = LayoutInflater.from(this.getParent()).inflate(R.layout.report_task, null);
		this.setContentView(viewToLoad);

		btnLocateMe = (Button) findViewById(R.id.btnLocateMe);
		btnTakeSignature = (Button) findViewById(R.id.btnTakeSignature);
		btnSubmit = (Button) findViewById(R.id.btnSubmit);
		btnCancel = (Button) findViewById(R.id.btnCancel);
		spinnerTaskOptions = (Spinner) findViewById(R.id.spnTaskReport);
		imageViewSignature = (ImageView) findViewById(R.id.ivSignature);

		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this.getParent(), R.array.taskReportOptions, android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerTaskOptions.setAdapter(adapter);
		//spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());

		spinnerTaskOptions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int pos, long l) {
				//To change body of implemented methods use File | Settings | File Templates.
				Toast.makeText(parent.getContext(), "Spinner Selected: " +
						parent.getItemAtPosition(pos).toString(), Toast.LENGTH_LONG).show();
			}

			@Override
			public void onNothingSelected(AdapterView<?> adapterView) {

			}
		});

		// set on click listeners 
		btnLocateMe.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(ReportTaskActivity.this, DisplayMap.class);
				CurrentGpsData currentGpsData = new CurrentGpsData(ReportTaskActivity.this);

				intent.putExtra("latitudeArray", new int [] {currentGpsData.getCurrentLatitude()});
				intent.putExtra("longitudeArray",  new int [] {currentGpsData.getCurrentLongitude()});
				intent.putExtra("layout", R.layout.display_map);

				View view = TaskActivityGroup.group.getLocalActivityManager()
						.startActivity("DisplayMap", intent
								.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
								.getDecorView();

				TaskActivityGroup.group.replaceView(view);
			}
		});

		btnTakeSignature.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				dispatchTakePictureIntent (0);
			}
		});

        btnCancel.setOnClickListener( new OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

	}

	private void dispatchTakePictureIntent(int actionCode) {

		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		startActivityForResult(takePictureIntent, actionCode);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if ( requestCode == 0 && resultCode == RESULT_OK ) {
			handleSmallCameraPhoto(data);
		}
	}

	private void handleSmallCameraPhoto(Intent intent) {
		Bundle extras = intent.getExtras();
		Bitmap mImageBitmap = (Bitmap) extras.get("data");
		imageViewSignature.setImageBitmap(mImageBitmap);
	}

}
