package com.cwc.courierclient;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import org.json.JSONException;
import org.json.JSONObject;

public class CWCCourierClientLoginActivity extends Activity {

	Button btnLogin, btnRegister;
    EditText editTextUserName, editTextPassword;
    CheckBox checkBoxRemeberMe;

    private static final String TAG = CWCCourierClientLoginActivity.class.getSimpleName();
    public static final String SHARED_PREFS = "User_Data";

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        
        btnLogin=(Button)findViewById(R.id.btnLogin);
        btnRegister=(Button)findViewById(R.id.btnRegister);
        editTextUserName = (EditText) findViewById(R.id.etUserName);
        editTextPassword = (EditText) findViewById(R.id.etPassword);
        checkBoxRemeberMe = (CheckBox) findViewById(R.id.chkRemember);
        
        if ( getPrefsString("pass_code").length() > 0 ) {
            editTextUserName.setText(getPrefsString("user_name"));
            editTextPassword.setText(getPrefsString("pass_code"));
        }

        btnLogin.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TO DO: User input validation
				// TO DO: Client Authentication and handle different error cases
                
                if ( !isInternetAvailable() ) return;
				
				// If authentication successful
                if ( isAuctheticated()  ) {

                    //getPrefsString("user_name");

                    if ( checkBoxRemeberMe.isChecked() ) {
                        setPrefsString("pass_code", editTextPassword.getText().toString());
                    }

                	setPrefsString ("user_name", editTextUserName.getText().toString());
                    Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientMainScreenActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(CWCCourierClientLoginActivity.this);
                    builder.setMessage("Invalid User! Please Register")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // put your code here
                                Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientRegistrationActivity.class);
                                startActivity(i);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // put your code here
                                dialog.cancel();
                            }
                        }).show();
                }

				
			}
		});
        
        btnRegister.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i=new Intent(CWCCourierClientLoginActivity.this, CWCCourierClientRegistrationActivity.class);
				startActivity(i);
			}
		});
        
        
        
    }

    private boolean isAuctheticated() {
        
        final String urlAddress = "login?username="
                + editTextUserName.getText().toString()
                + "&password="
                + editTextPassword.getText().toString()
                + "&returnType=json";
        
        Log.d(TAG, urlAddress);

        JsonUtility jsonUtility = new JsonUtility();
        String jsonResponse  = jsonUtility.getJsonResponse(urlAddress);
        Log.d(TAG, jsonResponse);
        
        try {
            JSONObject jsonObject = new JSONObject(jsonResponse); // {"status":"false"}
            if ( jsonObject.getString("status").equals("true") ) return true;
        } catch (JSONException e) {
            e.printStackTrace();  
        }  
        
        return false;
    }
    
    private void setPrefsString (String key, String value) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    private String getPrefsString (String key) {
        SharedPreferences sharedPreferences = getSharedPreferences(CWCCourierClientLoginActivity.SHARED_PREFS, MODE_PRIVATE);
        return sharedPreferences.getString(key, "");
    }

    private boolean isInternetAvailable () {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CWCCourierClientLoginActivity.CONNECTIVITY_SERVICE);
        
        if ( connectivityManager.getActiveNetworkInfo() != null &&
            connectivityManager.getActiveNetworkInfo().isAvailable() &&
            connectivityManager.getActiveNetworkInfo().isConnectedOrConnecting() ) {
            return true;
        }
        Toast.makeText(CWCCourierClientLoginActivity.this, "Internet Not Available", Toast.LENGTH_LONG).show();
        return false;
    }
}