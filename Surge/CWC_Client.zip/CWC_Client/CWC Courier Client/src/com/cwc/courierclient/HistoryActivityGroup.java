package com.cwc.courierclient;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class HistoryActivityGroup extends ActivityGroup {

	//Keep this in a static variable to make it accessible for all the nesten activities, lets them manipulate the view
	public static HistoryActivityGroup group;

	// Need to keep track of the history if you want the back-button to work properly, don't use this if your activities requires a lot of memory.
	private ArrayList<View> activityHistory;

	/**
	 * @see android.app.Activity#onCreate(Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.activityHistory = new ArrayList<View>();
		group = this;

		// Start the root activity within the group and get its view 
		View view = getLocalActivityManager().startActivity("HistoryActivity", new
				Intent(this, HistoryActivity.class)
		.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
		.getDecorView();

		// Replace the view of this ActivityGroup
		replaceView (view);
	}


	public void replaceView(View v) {
		// Adds the old one to history
		activityHistory.add(v);
		// Changes this Groups View to the new View.
		setContentView(v);
	}

	public void back() {
		if(activityHistory.size() > 0) {
			activityHistory.remove(activityHistory.size() - 1);
			setContentView(activityHistory.get(activityHistory.size()-1));
		}else {
			finish();
		}
	}

	@Override
	public void onBackPressed() {
		HistoryActivityGroup.group.back();
    }
}
