package com.cwc.courierclient;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class TasksDetailsActivity extends Activity {
	/**
	 * @see android.app.Activity#onCreate(Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.task_details);

		TextView textView = (TextView) findViewById(R.id.tvItemName);
		textView.setText(textView.getText() + getIntent().getExtras().getString("ItemName"));
		
		textView = (TextView) findViewById(R.id.tvItemId);
		textView.setText(textView.getText() + getIntent().getExtras().getString("ItemId"));
		
		textView = (TextView) findViewById(R.id.tvReceiverAddress);
		textView.setText(textView.getText() + getIntent().getExtras().getString("ReceiverAddress"));
		
		textView = (TextView) findViewById(R.id.tvPhoneNumber);
		textView.setText(getIntent().getExtras().getString("contactno"));
		
		Button btnViewOnMap = (Button) findViewById(R.id.btnViewOnMap);
		btnViewOnMap.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {

				Intent intent = new Intent(TasksDetailsActivity.this, DisplayMap.class);

				intent.putExtra("latitudeArray", new int [] {getIntent().getExtras().getInt("latitude")});
				intent.putExtra("longitudeArray",  new int [] {getIntent().getExtras().getInt("longitude")});
                intent.putExtra("addressArray", new String [] {getIntent().getExtras().getString("ReceiverAddress")});
				intent.putExtra("layout", R.layout.display_map_small);
				
				View view = TaskActivityGroup.group.getLocalActivityManager()
				        .startActivity("DisplayMap", intent
				        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
				        .getDecorView();
				
				TaskActivityGroup.group.replaceView(view);
			}
		});
		
		Button btnReportTask = (Button) findViewById(R.id.btnReportTask);
		btnReportTask.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// startActivity(new Intent(TasksDetailsActivity.this, ReportTaskActivity.class));
				
				Intent intent = new Intent(TasksDetailsActivity.this, ReportTaskActivity.class);
				
				View view = TaskActivityGroup.group.getLocalActivityManager()
				        .startActivity("ReportTaskActivity", intent
				        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
				        .getDecorView();
				
				TaskActivityGroup.group.replaceView(view);
				
			}
		});
	}
}
