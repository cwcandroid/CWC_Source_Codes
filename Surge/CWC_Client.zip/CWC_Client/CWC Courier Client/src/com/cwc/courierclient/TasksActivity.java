package com.cwc.courierclient;


import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class TasksActivity extends ListActivity {
	
	private static final String TAG = TasksActivity.class.getSimpleName();
	ArrayList<HashMap<String, String>> taskList = new ArrayList<HashMap<String, String>>();
    TaskListAdapter taskListAdapter;
	Button btnShowMapItems;
    CheckBox checkBoxFilterByDate;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tasks);

        checkBoxFilterByDate = (CheckBox) findViewById(R.id.chkFilterByDate);
        checkBoxFilterByDate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if ( checkBoxFilterByDate.isChecked() ) {
                    sortArrayListByTime();
                    Log.d(TAG, "checkbox filter clicked!");
                    taskListAdapter.notifyDataSetChanged();
                    setTaskListAdapter();

                }
            }
        });
		
		btnShowMapItems = (Button) findViewById(R.id.btnShowMapItems);
		btnShowMapItems.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(TasksActivity.this, DisplayMap.class);
				
				int lat [] = new int [taskList.size()];
				int lon [] = new int [taskList.size()];
                String address [] = new String[taskList.size()];
				
				for ( int i = 0; i < taskList.size(); i++ ) {
					lat [i] = (int) (Double.parseDouble(taskList.get(i).get("latitude")) * 1e6);
					lon [i] = (int) (Double.parseDouble(taskList.get(i).get("longitude")) * 1e6);
                    address [i] = taskList.get(i).get("address");


					// Log.d(TAG, "lat : " + lat [i] + " lon: " + lon [i]);
				}
				
				intent.putExtra("latitudeArray", lat);
				intent.putExtra("longitudeArray", lon);
                intent.putExtra("addressArray", address);
				intent.putExtra("layout", R.layout.display_map);
				
				View view = TaskActivityGroup.group.getLocalActivityManager()
				        .startActivity("DisplayMap", intent
				        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
				        .getDecorView();
				
				TaskActivityGroup.group.replaceView(view);
			}
		});

        Calendar calender = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");

        // http://test.sentisol.com/cwc/index.php/android/getTaskList?username=cwcuser1&returnType=json&duedate=20-01-2012
        String urlAddress = "getTaskList?username="
                + "cwcuser1"
                //+ getPrefsString("user_name")
                + "&returnType=xml&duedate="
                + df.format(calender.getTime ());
                //+ "22-01-2012";

        Log.d(TAG, "task url: " + urlAddress);

        //JsonUtility util = new JsonUtility();
        //taskList = util.getJsonResponseForTaskList(urlAddress);

        XmlUtility utility = new XmlUtility();
        taskList = utility.getXmlResponseForTaskList(urlAddress);
		
		sortArrayListByTaskStatus ();
		
		Log.d(TAG, "length: " + taskList.size());

        setTaskListAdapter ();
	}

    private void setTaskListAdapter() {
        //To change body of created methods use File | Settings | File Templates.
        
        int listSize = taskList.size();
         
        String strProductName [] = new String[listSize];
        String strAddress [] = new String[listSize];
        int taskStatus [] = new int[listSize];

        for ( int i = 0; i < listSize; i++ ) {
            strProductName [i] = taskList.get(i).get("name");
            strAddress [i] = taskList.get(i).get("address");
            taskStatus [i] = Integer.parseInt(taskList.get(i).get("status"));
        }
        
        taskListAdapter = new TaskListAdapter(this, strProductName, strAddress, taskStatus);
        setListAdapter(taskListAdapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {

        HashMap<String, String> map = taskList.get(position);

        Intent intent = new Intent(TasksActivity.this, TasksDetailsActivity.class);
        intent.putExtra("ItemName", map.get("name"));
        intent.putExtra("ItemId", map.get("id"));
        intent.putExtra("ReceiverAddress", map.get("address"));
        intent.putExtra("contactno", map.get("contactno"));
        intent.putExtra("latitude", (int)(Double.parseDouble(map.get("latitude")) * 1e6));
        intent.putExtra("longitude", (int)(Double.parseDouble(map.get("longitude")) * 1e6));

        View view = TaskActivityGroup.group.getLocalActivityManager()
            .startActivity("TasksDetailsActivity", intent
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            .getDecorView();

        TaskActivityGroup.group.replaceView(view);
    }
	
	private void sortArrayListByTaskStatus () {
		HashMap<String, String> tmp;
		
		for ( int i = 0; i < taskList.size(); i++ ) {
			for ( int j = i + 1; j < taskList.size(); j++ ) {
				if ( Integer.parseInt(taskList.get(i).get("status")) > Integer.parseInt(taskList.get(j).get("status")) ) {
					tmp = taskList.get(i);
					taskList.set(i, taskList.get(j));
					taskList.set(j, tmp);
				}
			}
		}
	}

    private void sortArrayListByTime () {
        HashMap<String, String> tmp;

        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");

        for ( int i = 0; i < taskList.size(); i++ ) {
            for ( int j = i + 1; j < taskList.size(); j++ ) {
                if ( taskList.get(i).get("duetime").compareTo(taskList.get(j).get("duetime")) < 0  ) {
                    tmp = taskList.get(i);
                    taskList.set(i, taskList.get(j));
                    taskList.set(j, tmp);
                }
            }
        }
    }
	
	private String getPrefsString (String key) {
        SharedPreferences sharedPreferences = getSharedPreferences(CWCCourierClientLoginActivity.SHARED_PREFS, MODE_PRIVATE);
        return sharedPreferences.getString(key, "");
    }
}
